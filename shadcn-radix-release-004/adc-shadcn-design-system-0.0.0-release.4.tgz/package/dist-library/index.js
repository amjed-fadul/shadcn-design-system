var Wr = (e) => {
  throw TypeError(e);
};
var Hr = (e, t, n) => t.has(e) || Wr("Cannot " + n);
var be = (e, t, n) => (Hr(e, t, "read from private field"), n ? n.call(e) : t.get(e)), Gr = (e, t, n) => t.has(e) ? Wr("Cannot add the same private member more than once") : t instanceof WeakSet ? t.add(e) : t.set(e, n), to = (e, t, n, o) => (Hr(e, t, "write to private field"), o ? o.call(e, n) : t.set(e, n), n);
import { jsx as d, Fragment as Xe, jsxs as Z } from "react/jsx-runtime";
import * as s from "react";
import { useState as Tc, useLayoutEffect as Ic, useContext as Ac, createContext as kc, forwardRef as ka, createElement as bo } from "react";
import * as Ut from "react-dom";
var Mc = Object.defineProperty, Wo = (e, t) => Mc(e, "name", { value: t, configurable: !0 });
function vo(e, t) {
  if (typeof e == "function")
    return e(t);
  e != null && (e.current = t);
}
Wo(vo, "setRef");
function Ma(...e) {
  return (t) => {
    let n = !1;
    const o = e.map((r) => {
      const a = vo(r, t);
      return !n && typeof a == "function" && (n = !0), a;
    });
    if (n)
      return () => {
        for (let r = 0; r < o.length; r++) {
          const a = o[r];
          typeof a == "function" ? a() : vo(e[r], null);
        }
      };
  };
}
Wo(Ma, "composeRefs");
function H(...e) {
  return s.useCallback(Ma(...e), e);
}
Wo(H, "useComposedRefs");
var Oc = Object.defineProperty, De = (e, t) => Oc(e, "name", { value: t, configurable: !0 });
// @__NO_SIDE_EFFECTS__
function ze(e) {
  const t = s.forwardRef((n, o) => {
    let { children: r, ...a } = n, i = null, c = !1;
    const l = [];
    wo(r) && typeof on == "function" && (r = on(r._payload)), s.Children.forEach(r, (p) => {
      if ($a(p)) {
        c = !0;
        const h = p;
        let g = "child" in h.props ? h.props.child : h.props.children;
        wo(g) && typeof on == "function" && (g = on(g._payload)), i = Dc(h, g), l.push(i?.props?.children);
      } else
        l.push(p);
    }), i ? i = s.cloneElement(i, void 0, l) : (
      // A `Slottable` was found but it didn't resolve to a single element (e.g.
      // it wrapped multiple elements, text, or a render-prop `child` that
      // wasn't an element). Don't fall back to treating the `Slottable` wrapper
      // itself as the slot target — throw a descriptive error below instead.
      !c && s.Children.count(r) === 1 && s.isValidElement(r) && (i = r)
    );
    const u = i ? La(i) : void 0, m = H(o, u);
    if (!i) {
      if (r || r === 0)
        throw new Error(
          c ? $c(e) : Lc(e)
        );
      return r;
    }
    const f = Na(a, i.props ?? {});
    return i.type !== s.Fragment && (f.ref = o ? m : u), s.cloneElement(i, f);
  });
  return t.displayName = `${e}.Slot`, t;
}
De(ze, "createSlot");
var ht = /* @__PURE__ */ ze("Slot"), Oa = /* @__PURE__ */ Symbol.for("radix.slottable");
// @__NO_SIDE_EFFECTS__
function Da(e) {
  const t = /* @__PURE__ */ De((n) => "child" in n ? n.children(n.child) : n.children, "Slottable");
  return t.displayName = `${e}.Slottable`, t.__radixId = Oa, t;
}
De(Da, "createSlottable");
var Dc = /* @__PURE__ */ De((e, t) => {
  if ("child" in e.props) {
    const n = e.props.child;
    return s.isValidElement(n) ? s.cloneElement(n, void 0, e.props.children(n.props.children)) : null;
  }
  return s.isValidElement(t) ? t : null;
}, "getSlottableElementFromSlottable");
function Na(e, t) {
  const n = { ...t };
  for (const o in t) {
    const r = e[o], a = t[o];
    /^on[A-Z]/.test(o) ? r && a ? n[o] = (...c) => {
      const l = a(...c);
      return r(...c), l;
    } : r && (n[o] = r) : o === "style" ? n[o] = { ...r, ...a } : o === "className" && (n[o] = [r, a].filter(Boolean).join(" "));
  }
  return { ...e, ...n };
}
De(Na, "mergeProps");
function La(e) {
  let t = Object.getOwnPropertyDescriptor(e.props, "ref")?.get, n = t && "isReactWarning" in t && t.isReactWarning;
  return n ? e.ref : (t = Object.getOwnPropertyDescriptor(e, "ref")?.get, n = t && "isReactWarning" in t && t.isReactWarning, n ? e.props.ref : e.props.ref || e.ref);
}
De(La, "getElementRef");
function $a(e) {
  return s.isValidElement(e) && typeof e.type == "function" && "__radixId" in e.type && e.type.__radixId === Oa;
}
De($a, "isSlottable");
var Nc = /* @__PURE__ */ Symbol.for("react.lazy");
function wo(e) {
  return e != null && typeof e == "object" && "$$typeof" in e && e.$$typeof === Nc && "_payload" in e && Fa(e._payload);
}
De(wo, "isLazyComponent");
function Fa(e) {
  return typeof e == "object" && e !== null && "then" in e;
}
De(Fa, "isPromiseLike");
var Lc = /* @__PURE__ */ De((e) => `${e} failed to slot onto its children. Expected a single React element child or \`Slottable\`.`, "createSlotError"), $c = /* @__PURE__ */ De((e) => `${e} failed to slot onto its \`Slottable\`. Expected \`Slottable\` to receive a single React element child.`, "createSlottableError"), on = s[" use ".trim().toString()], Fc = Object.defineProperty, zc = (e, t) => Fc(e, "name", { value: t, configurable: !0 }), Bc = [
  "a",
  "button",
  "div",
  "form",
  "h2",
  "h3",
  "img",
  "input",
  "label",
  "li",
  "nav",
  "ol",
  "p",
  "select",
  "span",
  "svg",
  "ul"
], $ = Bc.reduce((e, t) => {
  const n = /* @__PURE__ */ ze(`Primitive.${t}`), o = s.forwardRef((r, a) => {
    const { asChild: i, ...c } = r, l = i ? n : t;
    return typeof window < "u" && (window[/* @__PURE__ */ Symbol.for("radix-ui")] = !0), /* @__PURE__ */ d(l, { ...c, ref: a });
  });
  return o.displayName = `Primitive.${t}`, { ...e, [t]: o };
}, {});
function Ho(e, t) {
  e && Ut.flushSync(() => e.dispatchEvent(t));
}
zc(Ho, "dispatchDiscreteCustomEvent");
var Vc = Object.defineProperty, Wc = (e, t) => Vc(e, "name", { value: t, configurable: !0 }), za = Object.freeze({
  // See: https://github.com/twbs/bootstrap/blob/main/scss/mixins/_visually-hidden.scss
  position: "absolute",
  border: 0,
  width: 1,
  height: 1,
  padding: 0,
  margin: -1,
  overflow: "hidden",
  clip: "rect(0, 0, 0, 0)",
  whiteSpace: "nowrap",
  wordWrap: "normal"
}), Hc = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ Wc(function(t, n) {
    return /* @__PURE__ */ d(
      $.span,
      {
        ...t,
        ref: n,
        style: { ...za, ...t.style }
      }
    );
  }, "VisuallyHidden")
), Gc = Hc, Uc = Object.defineProperty, Ae = (e, t) => Uc(e, "name", { value: t, configurable: !0 });
// @__NO_SIDE_EFFECTS__
function jc(e, t) {
  const n = s.createContext(t);
  n.displayName = e + "Context";
  const o = /* @__PURE__ */ Ae((a) => {
    const { children: i, ...c } = a, l = s.useMemo(() => c, Object.values(c));
    return /* @__PURE__ */ d(n.Provider, { value: l, children: i });
  }, "Provider");
  o.displayName = e + "Provider";
  function r(a, i = {}) {
    const { optional: c = !1 } = i, l = s.useContext(n);
    if (l) return l;
    if (t !== void 0) return t;
    if (!c)
      throw new Error(`\`${a}\` must be used within \`${e}\``);
  }
  return Ae(r, "useContext"), [o, r];
}
Ae(jc, "createContext");
// @__NO_SIDE_EFFECTS__
function we(e, t = []) {
  let n = [];
  function o(a, i) {
    const c = s.createContext(i);
    c.displayName = a + "Context";
    const l = n.length;
    n = [...n, i];
    const u = /* @__PURE__ */ Ae((f) => {
      const { scope: p, children: h, ...g } = f, b = p?.[e]?.[l] || c, v = s.useMemo(() => g, Object.values(g));
      return /* @__PURE__ */ d(b.Provider, { value: v, children: h });
    }, "Provider");
    u.displayName = a + "Provider";
    function m(f, p, h = {}) {
      const { optional: g = !1 } = h, b = p?.[e]?.[l] || c, v = s.useContext(b);
      if (v) return v;
      if (i !== void 0) return i;
      if (!g)
        throw new Error(`\`${f}\` must be used within \`${a}\``);
    }
    return Ae(m, "useContext"), [u, m];
  }
  Ae(o, "createContext");
  const r = /* @__PURE__ */ Ae(() => {
    const a = n.map((i) => s.createContext(i));
    return /* @__PURE__ */ Ae(function(c) {
      const l = c?.[e] || a;
      return s.useMemo(
        () => ({ [`__scope${e}`]: { ...c, [e]: l } }),
        [c, l]
      );
    }, "useScope");
  }, "createScope");
  return r.scopeName = e, [o, Ba(r, ...t)];
}
Ae(we, "createContextScope");
function Ba(...e) {
  const t = e[0];
  if (e.length === 1) return t;
  const n = /* @__PURE__ */ Ae(() => {
    const o = e.map((r) => ({
      useScope: r(),
      scopeName: r.scopeName
    }));
    return /* @__PURE__ */ Ae(function(a) {
      const i = o.reduce((c, { useScope: l, scopeName: u }) => {
        const f = l(a)[`__scope${u}`];
        return { ...c, ...f };
      }, {});
      return s.useMemo(() => ({ [`__scope${t.scopeName}`]: i }), [i]);
    }, "useComposedScopes");
  }, "createScope");
  return n.scopeName = t.scopeName, n;
}
Ae(Ba, "composeContextScopes");
var Kc = Object.defineProperty, me = (e, t) => Kc(e, "name", { value: t, configurable: !0 });
// @__NO_SIDE_EFFECTS__
function jt(e) {
  const t = e + "CollectionProvider", [n, o] = /* @__PURE__ */ we(t), [r, a] = n(
    t,
    { collectionRef: { current: null }, itemMap: /* @__PURE__ */ new Map() }
  ), i = /* @__PURE__ */ me((b) => {
    const { scope: v, children: x } = b, y = s.useRef(null), w = s.useRef(/* @__PURE__ */ new Map()).current;
    return /* @__PURE__ */ d(r, { scope: v, itemMap: w, collectionRef: y, children: x });
  }, "CollectionProvider");
  i.displayName = t;
  const c = e + "CollectionSlot", l = /* @__PURE__ */ ze(c), u = s.forwardRef(
    (b, v) => {
      const { scope: x, children: y } = b, w = a(c, x), C = H(v, w.collectionRef);
      return /* @__PURE__ */ d(l, { ref: C, children: y });
    }
  );
  u.displayName = c;
  const m = e + "CollectionItemSlot", f = "data-radix-collection-item", p = /* @__PURE__ */ ze(m), h = s.forwardRef(
    (b, v) => {
      const { scope: x, children: y, ...w } = b, C = s.useRef(null), R = H(v, C), P = a(m, x);
      return s.useEffect(() => (P.itemMap.set(C, { ref: C, ...w }), () => {
        P.itemMap.delete(C);
      })), /* @__PURE__ */ d(p, { [f]: "", ref: R, children: y });
    }
  );
  h.displayName = m;
  function g(b) {
    const v = a(e + "CollectionConsumer", b);
    return s.useCallback(() => {
      const y = v.collectionRef.current;
      if (!y) return [];
      const w = Array.from(y.querySelectorAll(`[${f}]`));
      return Array.from(v.itemMap.values()).sort(
        (P, E) => w.indexOf(P.ref.current) - w.indexOf(E.ref.current)
      );
    }, [v.collectionRef, v.itemMap]);
  }
  return me(g, "useCollection"), [
    { Provider: i, Slot: u, ItemSlot: h },
    g,
    o
  ];
}
me(jt, "createCollection");
var Ur = /* @__PURE__ */ new WeakMap(), se, Ee, no = (Ee = class extends Map {
  constructor(n) {
    super(n);
    Gr(this, se);
    to(this, se, [...super.keys()]), Ur.set(this, !0);
  }
  set(n, o) {
    return Ur.get(this) && (this.has(n) ? be(this, se)[be(this, se).indexOf(n)] = n : be(this, se).push(n)), super.set(n, o), this;
  }
  insert(n, o, r) {
    const a = this.has(o), i = be(this, se).length, c = Go(n);
    let l = c >= 0 ? c : i + c;
    const u = l < 0 || l >= i ? -1 : l;
    if (u === this.size || a && u === this.size - 1 || u === -1)
      return this.set(o, r), this;
    const m = this.size + (a ? 0 : 1);
    c < 0 && l++;
    const f = [...be(this, se)];
    let p, h = !1;
    for (let g = l; g < m; g++)
      if (l === g) {
        let b = f[g];
        f[g] === o && (b = f[g + 1]), a && this.delete(o), p = this.get(b), this.set(o, r);
      } else {
        !h && f[g - 1] === o && (h = !0);
        const b = f[h ? g : g - 1], v = p;
        p = this.get(b), this.delete(b), this.set(b, v);
      }
    return this;
  }
  with(n, o, r) {
    const a = new Ee(this);
    return a.insert(n, o, r), a;
  }
  before(n) {
    const o = be(this, se).indexOf(n) - 1;
    if (!(o < 0))
      return this.entryAt(o);
  }
  /**
   * Sets a new key-value pair at the position before the given key.
   */
  setBefore(n, o, r) {
    const a = be(this, se).indexOf(n);
    return a === -1 ? this : this.insert(a, o, r);
  }
  after(n) {
    let o = be(this, se).indexOf(n);
    if (o = o === -1 || o === this.size - 1 ? -1 : o + 1, o !== -1)
      return this.entryAt(o);
  }
  /**
   * Sets a new key-value pair at the position after the given key.
   */
  setAfter(n, o, r) {
    const a = be(this, se).indexOf(n);
    return a === -1 ? this : this.insert(a + 1, o, r);
  }
  first() {
    return this.entryAt(0);
  }
  last() {
    return this.entryAt(-1);
  }
  clear() {
    return to(this, se, []), super.clear();
  }
  delete(n) {
    const o = super.delete(n);
    return o && be(this, se).splice(be(this, se).indexOf(n), 1), o;
  }
  deleteAt(n) {
    const o = this.keyAt(n);
    return o !== void 0 ? this.delete(o) : !1;
  }
  at(n) {
    const o = hn(be(this, se), n);
    if (o !== void 0)
      return this.get(o);
  }
  entryAt(n) {
    const o = hn(be(this, se), n);
    if (o !== void 0)
      return [o, this.get(o)];
  }
  indexOf(n) {
    return be(this, se).indexOf(n);
  }
  keyAt(n) {
    return hn(be(this, se), n);
  }
  from(n, o) {
    const r = this.indexOf(n);
    if (r === -1)
      return;
    let a = r + o;
    return a < 0 && (a = 0), a >= this.size && (a = this.size - 1), this.at(a);
  }
  keyFrom(n, o) {
    const r = this.indexOf(n);
    if (r === -1)
      return;
    let a = r + o;
    return a < 0 && (a = 0), a >= this.size && (a = this.size - 1), this.keyAt(a);
  }
  find(n, o) {
    let r = 0;
    for (const a of this) {
      if (Reflect.apply(n, o, [a, r, this]))
        return a;
      r++;
    }
  }
  findIndex(n, o) {
    let r = 0;
    for (const a of this) {
      if (Reflect.apply(n, o, [a, r, this]))
        return r;
      r++;
    }
    return -1;
  }
  filter(n, o) {
    const r = [];
    let a = 0;
    for (const i of this)
      Reflect.apply(n, o, [i, a, this]) && r.push(i), a++;
    return new Ee(r);
  }
  map(n, o) {
    const r = [];
    let a = 0;
    for (const i of this)
      r.push([i[0], Reflect.apply(n, o, [i, a, this])]), a++;
    return new Ee(r);
  }
  reduce(...n) {
    const [o, r] = n;
    let a = 0, i = r ?? this.at(0);
    for (const c of this)
      a === 0 && n.length === 1 ? i = c : i = Reflect.apply(o, this, [i, c, a, this]), a++;
    return i;
  }
  reduceRight(...n) {
    const [o, r] = n;
    let a = r ?? this.at(-1);
    for (let i = this.size - 1; i >= 0; i--) {
      const c = this.at(i);
      i === this.size - 1 && n.length === 1 ? a = c : a = Reflect.apply(o, this, [a, c, i, this]);
    }
    return a;
  }
  toSorted(n) {
    const o = [...this.entries()].sort(n);
    return new Ee(o);
  }
  toReversed() {
    const n = new Ee();
    for (let o = this.size - 1; o >= 0; o--) {
      const r = this.keyAt(o), a = this.get(r);
      n.set(r, a);
    }
    return n;
  }
  toSpliced(...n) {
    const o = [...this.entries()];
    return o.splice(...n), new Ee(o);
  }
  slice(n, o) {
    const r = new Ee();
    let a = this.size - 1;
    if (n === void 0)
      return r;
    n < 0 && (n = n + this.size), o !== void 0 && o > 0 && (a = o - 1);
    for (let i = n; i <= a; i++) {
      const c = this.keyAt(i), l = this.get(c);
      r.set(c, l);
    }
    return r;
  }
  every(n, o) {
    let r = 0;
    for (const a of this) {
      if (!Reflect.apply(n, o, [a, r, this]))
        return !1;
      r++;
    }
    return !0;
  }
  some(n, o) {
    let r = 0;
    for (const a of this) {
      if (Reflect.apply(n, o, [a, r, this]))
        return !0;
      r++;
    }
    return !1;
  }
}, se = new WeakMap(), me(Ee, "OrderedDict"), Ee);
function hn(e, t) {
  if ("at" in Array.prototype)
    return Array.prototype.at.call(e, t);
  const n = Va(e, t);
  return n === -1 ? void 0 : e[n];
}
me(hn, "at");
function Va(e, t) {
  const n = e.length, o = Go(t), r = o >= 0 ? o : n + o;
  return r < 0 || r >= n ? -1 : r;
}
me(Va, "toSafeIndex");
function Go(e) {
  return e !== e || e === 0 ? 0 : Math.trunc(e);
}
me(Go, "toSafeInteger");
// @__NO_SIDE_EFFECTS__
function Yc(e) {
  const t = e + "CollectionProvider", [n, o] = /* @__PURE__ */ we(t), [r, a] = n(
    t,
    {
      collectionElement: null,
      collectionRef: { current: null },
      collectionRefObject: { current: null },
      itemMap: new no(),
      setItemMap: /* @__PURE__ */ me(() => {
      }, "setItemMap")
    }
  ), i = /* @__PURE__ */ me(({ state: w, ...C }) => w ? /* @__PURE__ */ d(l, { ...C, state: w }) : /* @__PURE__ */ d(c, { ...C }), "CollectionProvider");
  i.displayName = t;
  const c = /* @__PURE__ */ me((w) => {
    const C = v();
    return /* @__PURE__ */ d(l, { ...w, state: C });
  }, "CollectionInit");
  c.displayName = t + "Init";
  const l = /* @__PURE__ */ me((w) => {
    const { scope: C, children: R, state: P } = w, E = s.useRef(null), [S, I] = s.useState(
      null
    ), k = H(E, I), [N, M] = P;
    return s.useEffect(() => {
      if (!S) return;
      const F = Ga(() => {
      });
      return F.observe(S, {
        childList: !0,
        subtree: !0
      }), () => {
        F.disconnect();
      };
    }, [S]), /* @__PURE__ */ d(
      r,
      {
        scope: C,
        itemMap: N,
        setItemMap: M,
        collectionRef: k,
        collectionRefObject: E,
        collectionElement: S,
        children: R
      }
    );
  }, "CollectionProviderImpl");
  l.displayName = t + "Impl";
  const u = e + "CollectionSlot", m = /* @__PURE__ */ ze(u), f = s.forwardRef(
    (w, C) => {
      const { scope: R, children: P } = w, E = a(u, R), S = H(C, E.collectionRef);
      return /* @__PURE__ */ d(m, { ref: S, children: P });
    }
  );
  f.displayName = u;
  const p = e + "CollectionItemSlot", h = "data-radix-collection-item", g = /* @__PURE__ */ ze(p), b = s.forwardRef(
    (w, C) => {
      const { scope: R, children: P, ...E } = w, S = s.useRef(null), [I, k] = s.useState(null), N = H(C, S, k), M = a(p, R), { setItemMap: F } = M, V = s.useRef(E);
      Wa(V.current, E) || (V.current = E);
      const j = V.current;
      return s.useEffect(() => {
        const B = j;
        return F((z) => I ? z.has(I) ? z.set(I, { ...B, element: I }).toSorted(xo) : (z.set(I, { ...B, element: I }), z.toSorted(xo)) : z), () => {
          F((z) => !I || !z.has(I) ? z : (z.delete(I), new no(z)));
        };
      }, [I, j, F]), /* @__PURE__ */ d(g, { [h]: "", ref: N, children: P });
    }
  );
  b.displayName = p;
  function v() {
    return s.useState(new no());
  }
  me(v, "useInitCollection");
  function x(w) {
    const { itemMap: C } = a(e + "CollectionConsumer", w);
    return C;
  }
  return me(x, "useCollection"), [
    { Provider: i, Slot: f, ItemSlot: b },
    {
      createCollectionScope: o,
      useCollection: x,
      useInitCollection: v
    }
  ];
}
me(Yc, "createCollection");
function Wa(e, t) {
  if (e === t) return !0;
  if (typeof e != "object" || typeof t != "object" || e == null || t == null) return !1;
  const n = Object.keys(e), o = Object.keys(t);
  if (n.length !== o.length) return !1;
  for (const r of n)
    if (!Object.prototype.hasOwnProperty.call(t, r) || e[r] !== t[r]) return !1;
  return !0;
}
me(Wa, "shallowEqual");
function Ha(e, t) {
  return !!(t.compareDocumentPosition(e) & Node.DOCUMENT_POSITION_PRECEDING);
}
me(Ha, "isElementPreceding");
function xo(e, t) {
  return !e[1].element || !t[1].element ? 0 : Ha(e[1].element, t[1].element) ? -1 : 1;
}
me(xo, "sortByDocumentPosition");
function Ga(e) {
  return new MutationObserver((n) => {
    for (const o of n)
      if (o.type === "childList") {
        e();
        return;
      }
  });
}
me(Ga, "getChildListObserver");
var Xc = Object.defineProperty, Mt = (e, t) => Xc(e, "name", { value: t, configurable: !0 }), Ua = !!(typeof window < "u" && window.document && window.document.createElement);
function A(e, t, { checkForDefaultPrevented: n = !0 } = {}) {
  return /* @__PURE__ */ Mt(function(r) {
    if (e?.(r), n === !1 || !r || !r.defaultPrevented)
      return t?.(r);
  }, "handleEvent");
}
Mt(A, "composeEventHandlers");
function qc(e) {
  if (!Ua)
    throw new Error("Cannot access window outside of the DOM");
  return e?.ownerDocument?.defaultView ?? window;
}
Mt(qc, "getOwnerWindow");
function yo(e) {
  if (!Ua)
    throw new Error("Cannot access document outside of the DOM");
  return e?.ownerDocument ?? document;
}
Mt(yo, "getOwnerDocument");
function ja(e, t = !1) {
  const { activeElement: n } = yo(e);
  if (!n?.nodeName)
    return null;
  if (Ka(n) && n.contentDocument)
    return ja(n.contentDocument.body, t);
  if (t) {
    const o = n.getAttribute("aria-activedescendant");
    if (o) {
      const r = yo(n).getElementById(o);
      if (r)
        return r;
    }
  }
  return n;
}
Mt(ja, "getActiveElement");
function Ka(e) {
  return e.tagName === "IFRAME";
}
Mt(Ka, "isFrame");
var re = globalThis?.document ? s.useLayoutEffect : () => {
}, Zc = Object.defineProperty, Qc = (e, t) => Zc(e, "name", { value: t, configurable: !0 }), jr = s[" useEffectEvent ".trim().toString()], Kr = s[" useInsertionEffect ".trim().toString()];
function Ya(e) {
  if (typeof jr == "function")
    return jr(e);
  const t = s.useRef(() => {
    throw new Error("Cannot call an event handler while rendering.");
  });
  return typeof Kr == "function" ? Kr(() => {
    t.current = e;
  }) : re(() => {
    t.current = e;
  }), s.useMemo(() => ((...n) => t.current?.(...n)), []);
}
Qc(Ya, "useEffectEvent");
var Jc = Object.defineProperty, Kt = (e, t) => Jc(e, "name", { value: t, configurable: !0 }), el = s[" useInsertionEffect ".trim().toString()] || re;
function Pe({
  prop: e,
  defaultProp: t,
  onChange: n = /* @__PURE__ */ Kt(() => {
  }, "onChange"),
  caller: o
}) {
  const [r, a, i] = Xa({
    defaultProp: t,
    onChange: n
  }), c = e !== void 0, l = c ? e : r, u = s.useCallback(
    (m) => {
      if (c) {
        const f = qa(m) ? m(e) : m;
        f !== e && i.current?.(f);
      } else
        a(m);
    },
    [c, e, a, i]
  );
  return [l, u];
}
Kt(Pe, "useControllableState");
function Xa({
  defaultProp: e,
  onChange: t
}) {
  const [n, o] = s.useState(e), r = s.useRef(n), a = s.useRef(t);
  return el(() => {
    a.current = t;
  }, [t]), s.useEffect(() => {
    r.current !== n && (a.current?.(n), r.current = n);
  }, [n, r]), [n, o, a];
}
Kt(Xa, "useUncontrolledState");
function qa(e) {
  return typeof e == "function";
}
Kt(qa, "isFunction");
var Yr = /* @__PURE__ */ Symbol("RADIX:SYNC_STATE");
function tl(e, t, n, o) {
  const { prop: r, defaultProp: a, onChange: i, caller: c } = t, l = r !== void 0, u = Ya(i), m = [{ ...n, state: a }];
  o && m.push(o);
  const [f, p] = s.useReducer(
    (v, x) => {
      if (x.type === Yr)
        return { ...v, state: x.state };
      const y = e(v, x);
      return l && !Object.is(y.state, v.state) && u(y.state), y;
    },
    ...m
  ), h = f.state, g = s.useRef(h);
  s.useEffect(() => {
    g.current !== h && (g.current = h, l || u(h));
  }, [h, g, l]);
  const b = s.useMemo(() => r !== void 0 ? { ...f, state: r } : f, [f, r]);
  return s.useEffect(() => {
    l && !Object.is(r, f.state) && p({ type: Yr, state: r });
  }, [r, f.state, l]), [b, p];
}
Kt(tl, "useControllableStateReducer");
var nl = Object.defineProperty, qe = (e, t) => nl(e, "name", { value: t, configurable: !0 });
function Za(e, t) {
  return s.useReducer((n, o) => t[n][o] ?? n, e);
}
qe(Za, "useStateMachine");
var he = /* @__PURE__ */ qe((e) => {
  const { present: t, children: n } = e, o = Qa(t), r = typeof n == "function" ? n({ present: o.isPresent }) : s.Children.only(n), a = Ja(o.ref, ei(r));
  return typeof n == "function" || o.isPresent ? s.cloneElement(r, { ref: a }) : null;
}, "Presence");
function Qa(e) {
  const [t, n] = s.useState(), o = s.useRef(null), r = s.useRef(e), a = s.useRef("none"), i = s.useRef(void 0), c = e ? "mounted" : "unmounted", [l, u] = Za(c, {
    mounted: {
      UNMOUNT: "unmounted",
      ANIMATION_OUT: "unmountSuspended"
    },
    unmountSuspended: {
      MOUNT: "mounted",
      ANIMATION_END: "unmounted"
    },
    unmounted: {
      MOUNT: "mounted"
    }
  });
  return s.useEffect(() => {
    l === "mounted" ? (a.current = i.current ?? _t(o.current), i.current = void 0) : a.current = "none";
  }, [l]), re(() => {
    const m = o.current, f = r.current;
    if (f !== e) {
      const h = a.current, g = _t(m);
      e ? (i.current = g, u("MOUNT")) : g === "none" || m?.display === "none" ? u("UNMOUNT") : u(f && h !== g ? "ANIMATION_OUT" : "UNMOUNT"), r.current = e;
    }
  }, [e, u]), re(() => {
    if (t) {
      let m;
      const f = t.ownerDocument.defaultView ?? window, p = /* @__PURE__ */ qe((g) => {
        const v = _t(o.current).includes(CSS.escape(g.animationName));
        if (g.target === t && v && (u("ANIMATION_END"), !r.current)) {
          const x = t.style.animationFillMode;
          t.style.animationFillMode = "forwards", m = f.setTimeout(() => {
            t.style.animationFillMode === "forwards" && (t.style.animationFillMode = x);
          });
        }
      }, "handleAnimationEnd"), h = /* @__PURE__ */ qe((g) => {
        g.target === t && (a.current = _t(o.current));
      }, "handleAnimationStart");
      return t.addEventListener("animationstart", h), t.addEventListener("animationcancel", p), t.addEventListener("animationend", p), () => {
        f.clearTimeout(m), t.removeEventListener("animationstart", h), t.removeEventListener("animationcancel", p), t.removeEventListener("animationend", p);
      };
    } else
      u("ANIMATION_END");
  }, [t, u]), {
    isPresent: ["mounted", "unmountSuspended"].includes(l),
    ref: s.useCallback((m) => {
      if (m) {
        const f = getComputedStyle(m);
        o.current = f, i.current = _t(f);
      } else
        o.current = null;
      n(m);
    }, [])
  };
}
qe(Qa, "usePresence");
function Co(e, t) {
  if (typeof e == "function")
    return e(t);
  e != null && (e.current = t);
}
qe(Co, "setRef");
function Ja(...e) {
  const t = s.useRef(e);
  return t.current = e, s.useCallback((n) => {
    const o = t.current;
    let r = !1;
    const a = o.map((i) => {
      const c = Co(i, n);
      return !r && typeof c == "function" && (r = !0), c;
    });
    if (r)
      return () => {
        for (let i = 0; i < a.length; i++) {
          const c = a[i];
          typeof c == "function" ? c() : Co(o[i], null);
        }
      };
  }, []);
}
qe(Ja, "useStableComposedRefs");
function _t(e) {
  return e?.animationName || "none";
}
qe(_t, "getAnimationName");
function ei(e) {
  let t = Object.getOwnPropertyDescriptor(e.props, "ref")?.get, n = t && "isReactWarning" in t && t.isReactWarning;
  return n ? e.ref : (t = Object.getOwnPropertyDescriptor(e, "ref")?.get, n = t && "isReactWarning" in t && t.isReactWarning, n ? e.props.ref : e.props.ref || e.ref);
}
qe(ei, "getElementRef");
var ol = Object.defineProperty, rl = (e, t) => ol(e, "name", { value: t, configurable: !0 }), al = s[" useId ".trim().toString()] || (() => {
}), il = 0;
function ve(e) {
  const [t, n] = s.useState(al());
  return re(() => {
    e || n((o) => o ?? String(il++));
  }, [e]), e || (t ? `radix-${t}` : "");
}
rl(ve, "useId");
var sl = Object.defineProperty, Yt = (e, t) => sl(e, "name", { value: t, configurable: !0 }), Uo = "Collapsible", [cl, ti] = /* @__PURE__ */ we(Uo), [ll, jo] = cl(Uo), ul = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ Yt(function(t, n) {
    const {
      __scopeCollapsible: o,
      open: r,
      defaultOpen: a,
      disabled: i,
      onOpenChange: c,
      ...l
    } = t, [u, m] = Pe({
      prop: r,
      defaultProp: a ?? !1,
      onChange: c,
      caller: Uo
    });
    return /* @__PURE__ */ d(
      ll,
      {
        scope: o,
        disabled: i,
        contentId: ve(),
        open: u,
        onOpenToggle: s.useCallback(() => m((f) => !f), [m]),
        children: /* @__PURE__ */ d(
          $.div,
          {
            "data-state": En(u),
            "data-disabled": i ? "" : void 0,
            ...l,
            ref: n
          }
        )
      }
    );
  }, "Collapsible")
), dl = "CollapsibleTrigger", fl = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ Yt(function(t, n) {
    const { __scopeCollapsible: o, ...r } = t, a = jo(dl, o);
    return /* @__PURE__ */ d(
      $.button,
      {
        type: "button",
        "aria-controls": a.open ? a.contentId : void 0,
        "aria-expanded": a.open || !1,
        "data-state": En(a.open),
        "data-disabled": a.disabled ? "" : void 0,
        disabled: a.disabled,
        ...r,
        ref: n,
        onClick: A(t.onClick, a.onOpenToggle)
      }
    );
  }, "CollapsibleTrigger")
), ni = "CollapsibleContent", pl = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ Yt(function(t, n) {
    const { forceMount: o, ...r } = t, a = jo(ni, t.__scopeCollapsible);
    return /* @__PURE__ */ d(he, { present: o || a.open, children: ({ present: i }) => /* @__PURE__ */ d(ml, { ...r, ref: n, present: i }) });
  }, "CollapsibleContent")
), ml = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ Yt(function(t, n) {
  const { __scopeCollapsible: o, present: r, children: a, ...i } = t, c = jo(ni, o), [l, u] = s.useState(r), m = s.useRef(null), f = H(n, m), p = s.useRef(0), h = p.current, g = s.useRef(0), b = g.current, v = c.open || l, x = s.useRef(v), y = s.useRef(void 0);
  return s.useEffect(() => {
    const w = requestAnimationFrame(() => x.current = !1);
    return () => cancelAnimationFrame(w);
  }, []), re(() => {
    const w = m.current;
    if (w) {
      y.current = y.current || {
        transitionDuration: w.style.transitionDuration,
        animationName: w.style.animationName
      }, w.style.transitionDuration = "0s", w.style.animationName = "none";
      const C = w.getBoundingClientRect();
      p.current = C.height, g.current = C.width, x.current || (w.style.transitionDuration = y.current.transitionDuration, w.style.animationName = y.current.animationName), u(r);
    }
  }, [c.open, r]), /* @__PURE__ */ d(
    $.div,
    {
      "data-state": En(c.open),
      "data-disabled": c.disabled ? "" : void 0,
      id: c.contentId,
      hidden: !v,
      ...i,
      ref: f,
      style: {
        "--radix-collapsible-content-height": h ? `${h}px` : void 0,
        "--radix-collapsible-content-width": b ? `${b}px` : void 0,
        ...t.style
      },
      children: v && a
    }
  );
}, "CollapsibleContentImpl"));
function En(e) {
  return e ? "open" : "closed";
}
Yt(En, "getState");
var hl = ul, gl = fl, bl = pl, vl = Object.defineProperty, wl = (e, t) => vl(e, "name", { value: t, configurable: !0 }), xl = s.createContext(void 0);
function gt(e) {
  const t = s.useContext(xl);
  return e || t || "ltr";
}
wl(gt, "useDirection");
var yl = Object.defineProperty, _e = (e, t) => yl(e, "name", { value: t, configurable: !0 }), We = "Accordion", Cl = ["Home", "End", "ArrowDown", "ArrowUp", "ArrowLeft", "ArrowRight"], [Ko, Sl, Rl] = /* @__PURE__ */ jt(We), [_n, dv] = /* @__PURE__ */ we(We, [
  Rl,
  ti
]), Yo = ti(), Pl = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ _e(function(t, n) {
    const { type: o, ...r } = t, a = r, i = r;
    return /* @__PURE__ */ d(Ko.Provider, { scope: t.__scopeAccordion, children: o === "multiple" ? /* @__PURE__ */ d(Il, { ...i, ref: n }) : /* @__PURE__ */ d(Tl, { ...a, ref: n }) });
  }, "Accordion")
), [oi, El] = _n(We), [ri, _l] = _n(
  We,
  { collapsible: !1 }
), Tl = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ _e(function(t, n) {
    const {
      value: o,
      defaultValue: r,
      onValueChange: a = /* @__PURE__ */ _e(() => {
      }, "onValueChange"),
      collapsible: i = !1,
      ...c
    } = t, [l, u] = Pe({
      prop: o,
      defaultProp: r ?? "",
      onChange: a,
      caller: We
    });
    return /* @__PURE__ */ d(
      oi,
      {
        scope: t.__scopeAccordion,
        value: s.useMemo(() => l ? [l] : [], [l]),
        onItemOpen: u,
        onItemClose: s.useCallback(() => i && u(""), [i, u]),
        children: /* @__PURE__ */ d(ri, { scope: t.__scopeAccordion, collapsible: i, children: /* @__PURE__ */ d(ai, { ...c, ref: n }) })
      }
    );
  }, "AccordionImplSingle")
), Il = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ _e(function(t, n) {
  const {
    value: o,
    defaultValue: r,
    onValueChange: a = /* @__PURE__ */ _e(() => {
    }, "onValueChange"),
    ...i
  } = t, [c, l] = Pe({
    prop: o,
    defaultProp: r ?? [],
    onChange: a,
    caller: We
  }), u = s.useCallback(
    (f) => l((p = []) => [...p, f]),
    [l]
  ), m = s.useCallback(
    (f) => l((p = []) => p.filter((h) => h !== f)),
    [l]
  );
  return /* @__PURE__ */ d(
    oi,
    {
      scope: t.__scopeAccordion,
      value: c,
      onItemOpen: u,
      onItemClose: m,
      children: /* @__PURE__ */ d(ri, { scope: t.__scopeAccordion, collapsible: !0, children: /* @__PURE__ */ d(ai, { ...i, ref: n }) })
    }
  );
}, "AccordionImplMultiple")), [Al, Tn] = _n(We), ai = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ _e(function(t, n) {
    const { __scopeAccordion: o, disabled: r, dir: a, orientation: i = "vertical", ...c } = t, l = s.useRef(null), u = H(l, n), m = Sl(o), p = gt(a) === "ltr", h = A(t.onKeyDown, (g) => {
      if (!Cl.includes(g.key)) return;
      const b = g.target, v = m().filter((I) => !I.ref.current?.disabled), x = v.findIndex((I) => I.ref.current === b), y = v.length;
      if (x === -1) return;
      g.preventDefault();
      let w = x;
      const C = 0, R = y - 1, P = /* @__PURE__ */ _e(() => {
        w = x + 1, w > R && (w = C);
      }, "moveNext"), E = /* @__PURE__ */ _e(() => {
        w = x - 1, w < C && (w = R);
      }, "movePrev");
      switch (g.key) {
        case "Home":
          w = C;
          break;
        case "End":
          w = R;
          break;
        case "ArrowRight":
          i === "horizontal" && (p ? P() : E());
          break;
        case "ArrowDown":
          i === "vertical" && P();
          break;
        case "ArrowLeft":
          i === "horizontal" && (p ? E() : P());
          break;
        case "ArrowUp":
          i === "vertical" && E();
          break;
      }
      const S = w % y;
      v[S].ref.current?.focus();
    });
    return /* @__PURE__ */ d(
      Al,
      {
        scope: o,
        disabled: r,
        direction: a,
        orientation: i,
        children: /* @__PURE__ */ d(Ko.Slot, { scope: o, children: /* @__PURE__ */ d(
          $.div,
          {
            ...c,
            "data-orientation": i,
            ref: u,
            onKeyDown: r ? void 0 : h
          }
        ) })
      }
    );
  }, "AccordionImpl")
), So = "AccordionItem", [kl, Xo] = _n(So), Ml = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ _e(function(t, n) {
    const { __scopeAccordion: o, value: r, ...a } = t, i = Tn(So, o), c = El(So, o), l = Yo(o), u = ve(), m = r && c.value.includes(r) || !1, f = i.disabled || t.disabled;
    return /* @__PURE__ */ d(
      kl,
      {
        scope: o,
        open: m,
        disabled: f,
        triggerId: u,
        children: /* @__PURE__ */ d(
          hl,
          {
            "data-orientation": i.orientation,
            "data-state": qo(m),
            ...l,
            ...a,
            ref: n,
            disabled: f,
            open: m,
            onOpenChange: (p) => {
              p ? c.onItemOpen(r) : c.onItemClose(r);
            }
          }
        )
      }
    );
  }, "AccordionItem")
), Ol = "AccordionHeader", Dl = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ _e(function(t, n) {
    const { __scopeAccordion: o, ...r } = t, a = Tn(We, o), i = Xo(Ol, o);
    return /* @__PURE__ */ d(
      $.h3,
      {
        "data-orientation": a.orientation,
        "data-state": qo(i.open),
        "data-disabled": i.disabled ? "" : void 0,
        ...r,
        ref: n
      }
    );
  }, "AccordionHeader")
), Xr = "AccordionTrigger", Nl = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ _e(function(t, n) {
    const { __scopeAccordion: o, ...r } = t, a = Tn(We, o), i = Xo(Xr, o), c = _l(Xr, o), l = Yo(o);
    return /* @__PURE__ */ d(Ko.ItemSlot, { scope: o, children: /* @__PURE__ */ d(
      gl,
      {
        "aria-disabled": i.open && !c.collapsible || void 0,
        "data-orientation": a.orientation,
        id: i.triggerId,
        ...l,
        ...r,
        ref: n
      }
    ) });
  }, "AccordionTrigger")
), Ll = "AccordionContent", $l = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ _e(function(t, n) {
    const { __scopeAccordion: o, ...r } = t, a = Tn(We, o), i = Xo(Ll, o), c = Yo(o);
    return /* @__PURE__ */ d(
      bl,
      {
        role: "region",
        "aria-labelledby": i.triggerId,
        "data-orientation": a.orientation,
        ...c,
        ...r,
        ref: n,
        style: {
          "--radix-accordion-content-height": "var(--radix-collapsible-content-height)",
          "--radix-accordion-content-width": "var(--radix-collapsible-content-width)",
          ...t.style
        }
      }
    );
  }, "AccordionContent")
);
function qo(e) {
  return e ? "open" : "closed";
}
_e(qo, "getState");
var Fl = Pl, zl = Ml, Bl = Dl, Vl = Nl, Wl = $l, Hl = Object.defineProperty, Gl = (e, t) => Hl(e, "name", { value: t, configurable: !0 });
function ie(e) {
  const t = s.useRef(e);
  return s.useEffect(() => {
    t.current = e;
  }), s.useMemo(() => ((...n) => t.current?.(...n)), []);
}
Gl(ie, "useCallbackRef");
var Ul = Object.defineProperty, pe = (e, t) => Ul(e, "name", { value: t, configurable: !0 }), Ro = "dismissableLayer.update", jl = "dismissableLayer.pointerDownOutside", Kl = "dismissableLayer.focusOutside", qr, ii = s.createContext({
  layers: /* @__PURE__ */ new Set(),
  layersWithOutsidePointerEventsDisabled: /* @__PURE__ */ new Set(),
  branches: /* @__PURE__ */ new Set(),
  // Outside elements that belong to a layer's own dismiss affordance (eg, a
  // dialog overlay). Pressing them should dismiss the layer regardless of
  // whether or not they stop propagation.
  //
  // See https://github.com/radix-ui/primitives/issues/3346
  dismissableSurfaces: /* @__PURE__ */ new Set()
}), In = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ pe(function(t, n) {
    const {
      disableOutsidePointerEvents: o = !1,
      deferPointerDownOutside: r = !1,
      onEscapeKeyDown: a,
      onPointerDownOutside: i,
      onFocusOutside: c,
      onInteractOutside: l,
      onDismiss: u,
      ...m
    } = t, f = s.useContext(ii), [p, h] = s.useState(null), g = p?.ownerDocument ?? globalThis?.document, [, b] = s.useState({}), v = H(n, h), x = Array.from(f.layers), [y] = [
      ...f.layersWithOutsidePointerEventsDisabled
    ].slice(-1), w = y ? x.indexOf(y) : -1, C = p ? x.indexOf(p) : -1, R = f.layersWithOutsidePointerEventsDisabled.size > 0, P = C >= w, E = s.useRef(!1), S = ci(
      (M) => {
        i?.(M), l?.(M), M.defaultPrevented || u?.();
      },
      {
        ownerDocument: g,
        deferPointerDownOutside: r,
        isDeferredPointerDownOutsideRef: E,
        dismissableSurfaces: f.dismissableSurfaces,
        shouldHandlePointerDownOutside: s.useCallback(
          (M) => {
            if (!(M instanceof Node))
              return !1;
            const F = [...f.branches].some(
              (V) => V.contains(M)
            );
            return P && !F;
          },
          [f.branches, P]
        )
      }
    ), I = li((M) => {
      if (r && E.current)
        return;
      const F = M.target;
      [...f.branches].some((j) => j.contains(F)) || (c?.(M), l?.(M), M.defaultPrevented || u?.());
    }, g), k = p ? C === x.length - 1 : !1, N = ie((M) => {
      M.key === "Escape" && (a?.(M), !M.defaultPrevented && u && (M.preventDefault(), u()));
    });
    return s.useEffect(() => {
      if (k)
        return g.addEventListener("keydown", N, { capture: !0 }), () => g.removeEventListener("keydown", N, { capture: !0 });
    }, [g, k, N]), s.useEffect(() => {
      if (p)
        return o && (f.layersWithOutsidePointerEventsDisabled.size === 0 && (qr = g.body.style.pointerEvents, g.body.style.pointerEvents = "none"), f.layersWithOutsidePointerEventsDisabled.add(p)), f.layers.add(p), Po(), () => {
          o && (f.layersWithOutsidePointerEventsDisabled.delete(p), f.layersWithOutsidePointerEventsDisabled.size === 0 && (g.body.style.pointerEvents = qr));
        };
    }, [p, g, o, f]), s.useEffect(() => () => {
      p && (f.layers.delete(p), f.layersWithOutsidePointerEventsDisabled.delete(p), Po());
    }, [p, f]), s.useEffect(() => {
      const M = /* @__PURE__ */ pe(() => b({}), "handleUpdate");
      return document.addEventListener(Ro, M), () => document.removeEventListener(Ro, M);
    }, []), /* @__PURE__ */ d(
      $.div,
      {
        ...m,
        ref: v,
        style: {
          pointerEvents: R ? P ? "auto" : "none" : void 0,
          ...t.style
        },
        onFocusCapture: A(t.onFocusCapture, I.onFocusCapture),
        onBlurCapture: A(t.onBlurCapture, I.onBlurCapture),
        onPointerDownCapture: A(
          t.onPointerDownCapture,
          S.onPointerDownCapture
        )
      }
    );
  }, "DismissableLayer")
);
function si() {
  const e = s.useContext(ii), [t, n] = s.useState(null);
  return s.useEffect(() => {
    if (t)
      return e.dismissableSurfaces.add(t), () => {
        e.dismissableSurfaces.delete(t);
      };
  }, [t, e.dismissableSurfaces]), n;
}
pe(si, "useDismissableLayerSurface");
var Yl = /* @__PURE__ */ pe(() => !0, "IS_TRUE");
function ci(e, t) {
  const {
    ownerDocument: n = globalThis?.document,
    deferPointerDownOutside: o = !1,
    isDeferredPointerDownOutsideRef: r,
    dismissableSurfaces: a,
    shouldHandlePointerDownOutside: i = Yl
  } = t, c = ie(e), l = s.useRef(!1), u = s.useRef(!1), m = s.useRef(/* @__PURE__ */ new Map()), f = s.useRef(() => {
  });
  return s.useEffect(() => {
    function p() {
      u.current = !1, r.current = !1, m.current.clear();
    }
    pe(p, "resetOutsideInteraction");
    function h() {
      return Array.from(m.current.values()).some(Boolean);
    }
    pe(h, "isOutsideInteractionIntercepted");
    function g(w) {
      if (!u.current)
        return;
      const C = w.target;
      C instanceof Node && [...a].some((P) => P.contains(C)) || m.current.set(w.type, !0), w.type === "click" && window.setTimeout(() => {
        u.current && f.current();
      }, 0);
    }
    pe(g, "handleInteractionCapture");
    function b(w) {
      u.current && m.current.set(w.type, !1);
    }
    pe(b, "handleInteractionBubble");
    const v = /* @__PURE__ */ pe((w) => {
      if (w.target && !l.current) {
        let C = function() {
          n.removeEventListener("click", f.current);
          const P = h();
          p(), P || Zo(
            jl,
            c,
            R,
            { discrete: !0 }
          );
        };
        if (pe(C, "handleAndDispatchPointerDownOutsideEvent"), !i(w.target)) {
          n.removeEventListener("click", f.current), p(), l.current = !1;
          return;
        }
        const R = { originalEvent: w };
        u.current = !0, r.current = o && w.button === 0, m.current.clear(), !o || w.button !== 0 ? C() : (n.removeEventListener("click", f.current), f.current = C, n.addEventListener("click", f.current, { once: !0 }));
      } else
        n.removeEventListener("click", f.current), p();
      l.current = !1;
    }, "handlePointerDown"), x = [
      "pointerup",
      "mousedown",
      "mouseup",
      "touchstart",
      "touchend",
      "click"
    ];
    for (const w of x)
      n.addEventListener(w, g, !0), n.addEventListener(w, b);
    const y = window.setTimeout(() => {
      n.addEventListener("pointerdown", v);
    }, 0);
    return () => {
      window.clearTimeout(y), n.removeEventListener("pointerdown", v), n.removeEventListener("click", f.current);
      for (const w of x)
        n.removeEventListener(w, g, !0), n.removeEventListener(w, b);
    };
  }, [
    n,
    c,
    o,
    r,
    a,
    i
  ]), {
    // ensures we check React component tree (not just DOM tree)
    onPointerDownCapture: /* @__PURE__ */ pe(() => l.current = !0, "onPointerDownCapture")
  };
}
pe(ci, "usePointerDownOutside");
function li(e, t = globalThis?.document) {
  const n = ie(e), o = s.useRef(!1);
  return s.useEffect(() => {
    const r = /* @__PURE__ */ pe((a) => {
      a.target && !o.current && Zo(Kl, n, { originalEvent: a }, {
        discrete: !1
      });
    }, "handleFocus");
    return t.addEventListener("focusin", r), () => t.removeEventListener("focusin", r);
  }, [t, n]), {
    onFocusCapture: /* @__PURE__ */ pe(() => o.current = !0, "onFocusCapture"),
    onBlurCapture: /* @__PURE__ */ pe(() => o.current = !1, "onBlurCapture")
  };
}
pe(li, "useFocusOutside");
function Po() {
  const e = new CustomEvent(Ro);
  document.dispatchEvent(e);
}
pe(Po, "dispatchUpdate");
function Zo(e, t, n, { discrete: o }) {
  const r = n.originalEvent.target, a = new CustomEvent(e, { bubbles: !1, cancelable: !0, detail: n });
  t && r.addEventListener(e, t, { once: !0 }), o ? Ho(r, a) : r.dispatchEvent(a);
}
pe(Zo, "handleAndDispatchCustomEvent");
var Xl = Object.defineProperty, xe = (e, t) => Xl(e, "name", { value: t, configurable: !0 }), oo = "focusScope.autoFocusOnMount", ro = "focusScope.autoFocusOnUnmount", Zr = { bubbles: !1, cancelable: !0 }, Qo = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ xe(function(t, n) {
    const {
      loop: o = !1,
      trapped: r = !1,
      onMountAutoFocus: a,
      onUnmountAutoFocus: i,
      ...c
    } = t, [l, u] = s.useState(null), m = ie(a), f = ie(i), p = s.useRef(null), h = H(n, u), g = s.useRef({
      paused: !1,
      pause() {
        this.paused = !0;
      },
      resume() {
        this.paused = !1;
      }
    }).current;
    s.useEffect(() => {
      if (r) {
        let v = function(C) {
          if (g.paused || !l) return;
          const R = C.target;
          l.contains(R) ? p.current = R : Ge(p.current, { select: !0 });
        }, x = function(C) {
          if (g.paused || !l) return;
          const R = C.relatedTarget;
          R !== null && (l.contains(R) || Ge(p.current, { select: !0 }));
        }, y = function(C) {
          if (document.activeElement === document.body)
            for (const P of C)
              P.removedNodes.length > 0 && Ge(l);
        };
        xe(v, "handleFocusIn"), xe(x, "handleFocusOut"), xe(y, "handleMutations"), document.addEventListener("focusin", v), document.addEventListener("focusout", x);
        const w = new MutationObserver(y);
        return l && w.observe(l, { childList: !0, subtree: !0 }), () => {
          document.removeEventListener("focusin", v), document.removeEventListener("focusout", x), w.disconnect();
        };
      }
    }, [r, l, g.paused]), s.useEffect(() => {
      if (l) {
        Qr.add(g);
        const v = document.activeElement;
        if (!l.contains(v)) {
          const y = new CustomEvent(oo, Zr);
          l.addEventListener(oo, m), l.dispatchEvent(y), y.defaultPrevented || (ui(hi(Jo(l)), { select: !0 }), document.activeElement === v && Ge(l));
        }
        return () => {
          l.removeEventListener(oo, m), setTimeout(() => {
            const y = new CustomEvent(ro, Zr);
            l.addEventListener(ro, f), l.dispatchEvent(y), y.defaultPrevented || Ge(v ?? document.body, { select: !0 }), l.removeEventListener(ro, f), Qr.remove(g);
          }, 0);
        };
      }
    }, [l, m, f, g]);
    const b = s.useCallback(
      (v) => {
        if (!o && !r || g.paused) return;
        const x = v.key === "Tab" && !v.altKey && !v.ctrlKey && !v.metaKey, y = document.activeElement;
        if (x && y) {
          const w = v.currentTarget, [C, R] = di(w);
          C && R ? !v.shiftKey && y === R ? (v.preventDefault(), o && Ge(C, { select: !0 })) : v.shiftKey && y === C && (v.preventDefault(), o && Ge(R, { select: !0 })) : y === w && v.preventDefault();
        }
      },
      [o, r, g.paused]
    );
    return /* @__PURE__ */ d($.div, { tabIndex: -1, ...c, ref: h, onKeyDown: b });
  }, "FocusScope")
);
function ui(e, { select: t = !1 } = {}) {
  const n = document.activeElement;
  for (const o of e)
    if (Ge(o, { select: t }), document.activeElement !== n) return;
}
xe(ui, "focusFirst");
function di(e) {
  const t = Jo(e), n = Eo(t, e), o = Eo(t.reverse(), e);
  return [n, o];
}
xe(di, "getTabbableEdges");
function Jo(e) {
  const t = [], n = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
    acceptNode: /* @__PURE__ */ xe((o) => {
      const r = o.tagName === "INPUT" && o.type === "hidden";
      return o.disabled || o.hidden || r ? NodeFilter.FILTER_SKIP : o.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
    }, "acceptNode")
  });
  for (; n.nextNode(); ) t.push(n.currentNode);
  return t;
}
xe(Jo, "getTabbableCandidates");
function Eo(e, t) {
  const n = typeof t.checkVisibility == "function" && t.checkVisibility({ checkVisibilityCSS: !0 });
  for (const o of e)
    if (!(n ? !o.checkVisibility({ checkVisibilityCSS: !0 }) : fi(o, { upTo: t })))
      return o;
}
xe(Eo, "findVisible");
function fi(e, { upTo: t }) {
  if (getComputedStyle(e).visibility === "hidden") return !0;
  for (; e; ) {
    if (t !== void 0 && e === t) return !1;
    if (getComputedStyle(e).display === "none") return !0;
    e = e.parentElement;
  }
  return !1;
}
xe(fi, "isHidden");
function pi(e) {
  return e instanceof HTMLInputElement && "select" in e;
}
xe(pi, "isSelectableInput");
function Ge(e, { select: t = !1 } = {}) {
  if (e && e.focus) {
    const n = document.activeElement;
    e.focus({ preventScroll: !0 }), e !== n && pi(e) && t && e.select();
  }
}
xe(Ge, "focus");
var Qr = mi();
function mi() {
  let e = [];
  return {
    add(t) {
      const n = e[0];
      t !== n && n?.pause(), e = _o(e, t), e.unshift(t);
    },
    remove(t) {
      e = _o(e, t), e[0]?.resume();
    }
  };
}
xe(mi, "createFocusScopesStack");
function _o(e, t) {
  const n = [...e], o = n.indexOf(t);
  return o !== -1 && n.splice(o, 1), n;
}
xe(_o, "arrayRemove");
function hi(e) {
  return e.filter((t) => t.tagName !== "A");
}
xe(hi, "removeLinks");
var ql = Object.defineProperty, Zl = (e, t) => ql(e, "name", { value: t, configurable: !0 }), An = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ Zl(function(t, n) {
    const { container: o, ...r } = t, [a, i] = s.useState(!1);
    re(() => i(!0), []);
    const c = o || a && globalThis?.document?.body;
    return c ? Ut.createPortal(/* @__PURE__ */ d($.div, { ...r, ref: n }), c) : null;
  }, "Portal")
), Ql = Object.defineProperty, er = (e, t) => Ql(e, "name", { value: t, configurable: !0 }), rn = 0, St = null;
function Jl(e) {
  return Xt(), e.children;
}
er(Jl, "FocusGuards");
function Xt() {
  s.useEffect(() => {
    St || (St = { start: To(), end: To() });
    const { start: e, end: t } = St;
    return document.body.firstElementChild !== e && document.body.insertAdjacentElement("afterbegin", e), document.body.lastElementChild !== t && document.body.insertAdjacentElement("beforeend", t), rn++, () => {
      rn === 1 && (St?.start.remove(), St?.end.remove(), St = null), rn = Math.max(0, rn - 1);
    };
  }, []);
}
er(Xt, "useFocusGuards");
function To() {
  const e = document.createElement("span");
  return e.setAttribute("data-radix-focus-guard", ""), e.tabIndex = 0, e.style.outline = "none", e.style.opacity = "0", e.style.position = "fixed", e.style.pointerEvents = "none", e;
}
er(To, "createFocusGuard");
var $e = function() {
  return $e = Object.assign || function(t) {
    for (var n, o = 1, r = arguments.length; o < r; o++) {
      n = arguments[o];
      for (var a in n) Object.prototype.hasOwnProperty.call(n, a) && (t[a] = n[a]);
    }
    return t;
  }, $e.apply(this, arguments);
};
function gi(e, t) {
  var n = {};
  for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && t.indexOf(o) < 0 && (n[o] = e[o]);
  if (e != null && typeof Object.getOwnPropertySymbols == "function")
    for (var r = 0, o = Object.getOwnPropertySymbols(e); r < o.length; r++)
      t.indexOf(o[r]) < 0 && Object.prototype.propertyIsEnumerable.call(e, o[r]) && (n[o[r]] = e[o[r]]);
  return n;
}
function eu(e, t, n) {
  if (n || arguments.length === 2) for (var o = 0, r = t.length, a; o < r; o++)
    (a || !(o in t)) && (a || (a = Array.prototype.slice.call(t, 0, o)), a[o] = t[o]);
  return e.concat(a || Array.prototype.slice.call(t));
}
var gn = "right-scroll-bar-position", bn = "width-before-scroll-bar", tu = "with-scroll-bars-hidden", nu = "--removed-body-scroll-bar-size";
function ao(e, t) {
  return typeof e == "function" ? e(t) : e && (e.current = t), e;
}
function ou(e, t) {
  var n = Tc(function() {
    return {
      // value
      value: e,
      // last callback
      callback: t,
      // "memoized" public interface
      facade: {
        get current() {
          return n.value;
        },
        set current(o) {
          var r = n.value;
          r !== o && (n.value = o, n.callback(o, r));
        }
      }
    };
  })[0];
  return n.callback = t, n.facade;
}
var ru = typeof window < "u" ? s.useLayoutEffect : s.useEffect, Jr = /* @__PURE__ */ new WeakMap();
function au(e, t) {
  var n = ou(null, function(o) {
    return e.forEach(function(r) {
      return ao(r, o);
    });
  });
  return ru(function() {
    var o = Jr.get(n);
    if (o) {
      var r = new Set(o), a = new Set(e), i = n.current;
      r.forEach(function(c) {
        a.has(c) || ao(c, null);
      }), a.forEach(function(c) {
        r.has(c) || ao(c, i);
      });
    }
    Jr.set(n, e);
  }, [e]), n;
}
function iu(e) {
  return e;
}
function su(e, t) {
  t === void 0 && (t = iu);
  var n = [], o = !1, r = {
    read: function() {
      if (o)
        throw new Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
      return n.length ? n[n.length - 1] : e;
    },
    useMedium: function(a) {
      var i = t(a, o);
      return n.push(i), function() {
        n = n.filter(function(c) {
          return c !== i;
        });
      };
    },
    assignSyncMedium: function(a) {
      for (o = !0; n.length; ) {
        var i = n;
        n = [], i.forEach(a);
      }
      n = {
        push: function(c) {
          return a(c);
        },
        filter: function() {
          return n;
        }
      };
    },
    assignMedium: function(a) {
      o = !0;
      var i = [];
      if (n.length) {
        var c = n;
        n = [], c.forEach(a), i = n;
      }
      var l = function() {
        var m = i;
        i = [], m.forEach(a);
      }, u = function() {
        return Promise.resolve().then(l);
      };
      u(), n = {
        push: function(m) {
          i.push(m), u();
        },
        filter: function(m) {
          return i = i.filter(m), n;
        }
      };
    }
  };
  return r;
}
function cu(e) {
  e === void 0 && (e = {});
  var t = su(null);
  return t.options = $e({ async: !0, ssr: !1 }, e), t;
}
var bi = function(e) {
  var t = e.sideCar, n = gi(e, ["sideCar"]);
  if (!t)
    throw new Error("Sidecar: please provide `sideCar` property to import the right car");
  var o = t.read();
  if (!o)
    throw new Error("Sidecar medium not found");
  return s.createElement(o, $e({}, n));
};
bi.isSideCarExport = !0;
function lu(e, t) {
  return e.useMedium(t), bi;
}
var vi = cu(), io = function() {
}, kn = s.forwardRef(function(e, t) {
  var n = s.useRef(null), o = s.useState({
    onScrollCapture: io,
    onWheelCapture: io,
    onTouchMoveCapture: io
  }), r = o[0], a = o[1], i = e.forwardProps, c = e.children, l = e.className, u = e.removeScrollBar, m = e.enabled, f = e.shards, p = e.sideCar, h = e.noRelative, g = e.noIsolation, b = e.inert, v = e.allowPinchZoom, x = e.as, y = x === void 0 ? "div" : x, w = e.gapMode, C = gi(e, ["forwardProps", "children", "className", "removeScrollBar", "enabled", "shards", "sideCar", "noRelative", "noIsolation", "inert", "allowPinchZoom", "as", "gapMode"]), R = p, P = au([n, t]), E = $e($e({}, C), r);
  return s.createElement(
    s.Fragment,
    null,
    m && s.createElement(R, { sideCar: vi, removeScrollBar: u, shards: f, noRelative: h, noIsolation: g, inert: b, setCallbacks: a, allowPinchZoom: !!v, lockRef: n, gapMode: w }),
    i ? s.cloneElement(s.Children.only(c), $e($e({}, E), { ref: P })) : s.createElement(y, $e({}, E, { className: l, ref: P }), c)
  );
});
kn.defaultProps = {
  enabled: !0,
  removeScrollBar: !0,
  inert: !1
};
kn.classNames = {
  fullWidth: bn,
  zeroRight: gn
};
var uu = function() {
  if (typeof __webpack_nonce__ < "u")
    return __webpack_nonce__;
};
function du() {
  if (!document)
    return null;
  var e = document.createElement("style");
  e.type = "text/css";
  var t = uu();
  return t && e.setAttribute("nonce", t), e;
}
function fu(e, t) {
  e.styleSheet ? e.styleSheet.cssText = t : e.appendChild(document.createTextNode(t));
}
function pu(e) {
  var t = document.head || document.getElementsByTagName("head")[0];
  t.appendChild(e);
}
var mu = function() {
  var e = 0, t = null;
  return {
    add: function(n) {
      e == 0 && (t = du()) && (fu(t, n), pu(t)), e++;
    },
    remove: function() {
      e--, !e && t && (t.parentNode && t.parentNode.removeChild(t), t = null);
    }
  };
}, hu = function() {
  var e = mu();
  return function(t, n) {
    s.useEffect(function() {
      return e.add(t), function() {
        e.remove();
      };
    }, [t && n]);
  };
}, wi = function() {
  var e = hu(), t = function(n) {
    var o = n.styles, r = n.dynamic;
    return e(o, r), null;
  };
  return t;
}, gu = {
  left: 0,
  top: 0,
  right: 0,
  gap: 0
}, so = function(e) {
  return parseInt(e || "", 10) || 0;
}, bu = function(e) {
  var t = window.getComputedStyle(document.body), n = t[e === "padding" ? "paddingLeft" : "marginLeft"], o = t[e === "padding" ? "paddingTop" : "marginTop"], r = t[e === "padding" ? "paddingRight" : "marginRight"];
  return [so(n), so(o), so(r)];
}, vu = function(e) {
  if (e === void 0 && (e = "margin"), typeof window > "u")
    return gu;
  var t = bu(e), n = document.documentElement.clientWidth, o = window.innerWidth;
  return {
    left: t[0],
    top: t[1],
    right: t[2],
    gap: Math.max(0, o - n + t[2] - t[0])
  };
}, wu = wi(), Tt = "data-scroll-locked", xu = function(e, t, n, o) {
  var r = e.left, a = e.top, i = e.right, c = e.gap;
  return n === void 0 && (n = "margin"), `
  .`.concat(tu, ` {
   overflow: hidden `).concat(o, `;
   padding-right: `).concat(c, "px ").concat(o, `;
  }
  body[`).concat(Tt, `] {
    overflow: hidden `).concat(o, `;
    overscroll-behavior: contain;
    `).concat([
    t && "position: relative ".concat(o, ";"),
    n === "margin" && `
    padding-left: `.concat(r, `px;
    padding-top: `).concat(a, `px;
    padding-right: `).concat(i, `px;
    margin-left:0;
    margin-top:0;
    margin-right: `).concat(c, "px ").concat(o, `;
    `),
    n === "padding" && "padding-right: ".concat(c, "px ").concat(o, ";")
  ].filter(Boolean).join(""), `
  }
  
  .`).concat(gn, ` {
    right: `).concat(c, "px ").concat(o, `;
  }
  
  .`).concat(bn, ` {
    margin-right: `).concat(c, "px ").concat(o, `;
  }
  
  .`).concat(gn, " .").concat(gn, ` {
    right: 0 `).concat(o, `;
  }
  
  .`).concat(bn, " .").concat(bn, ` {
    margin-right: 0 `).concat(o, `;
  }
  
  body[`).concat(Tt, `] {
    `).concat(nu, ": ").concat(c, `px;
  }
`);
}, ea = function() {
  var e = parseInt(document.body.getAttribute(Tt) || "0", 10);
  return isFinite(e) ? e : 0;
}, yu = function() {
  s.useEffect(function() {
    return document.body.setAttribute(Tt, (ea() + 1).toString()), function() {
      var e = ea() - 1;
      e <= 0 ? document.body.removeAttribute(Tt) : document.body.setAttribute(Tt, e.toString());
    };
  }, []);
}, Cu = function(e) {
  var t = e.noRelative, n = e.noImportant, o = e.gapMode, r = o === void 0 ? "margin" : o;
  yu();
  var a = s.useMemo(function() {
    return vu(r);
  }, [r]);
  return s.createElement(wu, { styles: xu(a, !t, r, n ? "" : "!important") });
}, Io = !1;
if (typeof window < "u")
  try {
    var an = Object.defineProperty({}, "passive", {
      get: function() {
        return Io = !0, !0;
      }
    });
    window.addEventListener("test", an, an), window.removeEventListener("test", an, an);
  } catch {
    Io = !1;
  }
var Rt = Io ? { passive: !1 } : !1, Su = function(e) {
  return e.tagName === "TEXTAREA";
}, xi = function(e, t) {
  if (!(e instanceof Element))
    return !1;
  var n = window.getComputedStyle(e);
  return (
    // not-not-scrollable
    n[t] !== "hidden" && // contains scroll inside self
    !(n.overflowY === n.overflowX && !Su(e) && n[t] === "visible")
  );
}, Ru = function(e) {
  return xi(e, "overflowY");
}, Pu = function(e) {
  return xi(e, "overflowX");
}, ta = function(e, t) {
  var n = t.ownerDocument, o = t;
  do {
    typeof ShadowRoot < "u" && o instanceof ShadowRoot && (o = o.host);
    var r = yi(e, o);
    if (r) {
      var a = Ci(e, o), i = a[1], c = a[2];
      if (i > c)
        return !0;
    }
    o = o.parentNode;
  } while (o && o !== n.body);
  return !1;
}, Eu = function(e) {
  var t = e.scrollTop, n = e.scrollHeight, o = e.clientHeight;
  return [
    t,
    n,
    o
  ];
}, _u = function(e) {
  var t = e.scrollLeft, n = e.scrollWidth, o = e.clientWidth;
  return [
    t,
    n,
    o
  ];
}, yi = function(e, t) {
  return e === "v" ? Ru(t) : Pu(t);
}, Ci = function(e, t) {
  return e === "v" ? Eu(t) : _u(t);
}, Tu = function(e, t) {
  return e === "h" && t === "rtl" ? -1 : 1;
}, Iu = function(e, t, n, o, r) {
  var a = Tu(e, window.getComputedStyle(t).direction), i = a * o, c = n.target, l = t.contains(c), u = !1, m = i > 0, f = 0, p = 0;
  do {
    if (!c)
      break;
    var h = Ci(e, c), g = h[0], b = h[1], v = h[2], x = b - v - a * g;
    (g || x) && yi(e, c) && (f += x, p += g);
    var y = c.parentNode;
    c = y && y.nodeType === Node.DOCUMENT_FRAGMENT_NODE ? y.host : y;
  } while (
    // portaled content
    !l && c !== document.body || // self content
    l && (t.contains(c) || t === c)
  );
  return (m && Math.abs(f) < 1 || !m && Math.abs(p) < 1) && (u = !0), u;
}, sn = function(e) {
  return "changedTouches" in e ? [e.changedTouches[0].clientX, e.changedTouches[0].clientY] : [0, 0];
}, na = function(e) {
  return [e.deltaX, e.deltaY];
}, oa = function(e) {
  return e && "current" in e ? e.current : e;
}, Au = function(e, t) {
  return e[0] === t[0] && e[1] === t[1];
}, ku = function(e) {
  return `
  .block-interactivity-`.concat(e, ` {pointer-events: none;}
  .allow-interactivity-`).concat(e, ` {pointer-events: all;}
`);
}, Mu = 0, Pt = [];
function Ou(e) {
  var t = s.useRef([]), n = s.useRef([0, 0]), o = s.useRef(), r = s.useState(Mu++)[0], a = s.useState(wi)[0], i = s.useRef(e);
  s.useEffect(function() {
    i.current = e;
  }, [e]), s.useEffect(function() {
    if (e.inert) {
      document.body.classList.add("block-interactivity-".concat(r));
      var b = eu([e.lockRef.current], (e.shards || []).map(oa), !0).filter(Boolean);
      return b.forEach(function(v) {
        return v.classList.add("allow-interactivity-".concat(r));
      }), function() {
        document.body.classList.remove("block-interactivity-".concat(r)), b.forEach(function(v) {
          return v.classList.remove("allow-interactivity-".concat(r));
        });
      };
    }
  }, [e.inert, e.lockRef.current, e.shards]);
  var c = s.useCallback(function(b, v) {
    if ("touches" in b && b.touches.length === 2 || b.type === "wheel" && b.ctrlKey)
      return !i.current.allowPinchZoom;
    var x = sn(b), y = n.current, w = "deltaX" in b ? b.deltaX : y[0] - x[0], C = "deltaY" in b ? b.deltaY : y[1] - x[1], R, P = b.target, E = Math.abs(w) > Math.abs(C) ? "h" : "v";
    if ("touches" in b && E === "h" && P.type === "range")
      return !1;
    var S = window.getSelection(), I = S && S.anchorNode, k = I ? I === P || I.contains(P) : !1;
    if (k)
      return !1;
    var N = ta(E, P);
    if (!N)
      return !0;
    if (N ? R = E : (R = E === "v" ? "h" : "v", N = ta(E, P)), !N)
      return !1;
    if (!o.current && "changedTouches" in b && (w || C) && (o.current = R), !R)
      return !0;
    var M = o.current || R;
    return Iu(M, v, b, M === "h" ? w : C);
  }, []), l = s.useCallback(function(b) {
    var v = b;
    if (!(!Pt.length || Pt[Pt.length - 1] !== a)) {
      var x = "deltaY" in v ? na(v) : sn(v), y = t.current.filter(function(R) {
        return R.name === v.type && (R.target === v.target || v.target === R.shadowParent) && Au(R.delta, x);
      })[0];
      if (y && y.should) {
        v.cancelable && v.preventDefault();
        return;
      }
      if (!y) {
        var w = (i.current.shards || []).map(oa).filter(Boolean).filter(function(R) {
          return R.contains(v.target);
        }), C = w.length > 0 ? c(v, w[0]) : !i.current.noIsolation;
        C && v.cancelable && v.preventDefault();
      }
    }
  }, []), u = s.useCallback(function(b, v, x, y) {
    var w = { name: b, delta: v, target: x, should: y, shadowParent: Du(x) };
    t.current.push(w), setTimeout(function() {
      t.current = t.current.filter(function(C) {
        return C !== w;
      });
    }, 1);
  }, []), m = s.useCallback(function(b) {
    n.current = sn(b), o.current = void 0;
  }, []), f = s.useCallback(function(b) {
    u(b.type, na(b), b.target, c(b, e.lockRef.current));
  }, []), p = s.useCallback(function(b) {
    u(b.type, sn(b), b.target, c(b, e.lockRef.current));
  }, []);
  s.useEffect(function() {
    return Pt.push(a), e.setCallbacks({
      onScrollCapture: f,
      onWheelCapture: f,
      onTouchMoveCapture: p
    }), document.addEventListener("wheel", l, Rt), document.addEventListener("touchmove", l, Rt), document.addEventListener("touchstart", m, Rt), function() {
      Pt = Pt.filter(function(b) {
        return b !== a;
      }), document.removeEventListener("wheel", l, Rt), document.removeEventListener("touchmove", l, Rt), document.removeEventListener("touchstart", m, Rt);
    };
  }, []);
  var h = e.removeScrollBar, g = e.inert;
  return s.createElement(
    s.Fragment,
    null,
    g ? s.createElement(a, { styles: ku(r) }) : null,
    h ? s.createElement(Cu, { noRelative: e.noRelative, gapMode: e.gapMode }) : null
  );
}
function Du(e) {
  for (var t = null; e !== null; )
    e instanceof ShadowRoot && (t = e.host, e = e.host), e = e.parentNode;
  return t;
}
const Nu = lu(vi, Ou);
var Mn = s.forwardRef(function(e, t) {
  return s.createElement(kn, $e({}, e, { ref: t, sideCar: Nu }));
});
Mn.classNames = kn.classNames;
var Lu = function(e) {
  if (typeof document > "u")
    return null;
  var t = Array.isArray(e) ? e[0] : e;
  return t.ownerDocument.body;
}, Et = /* @__PURE__ */ new WeakMap(), cn = /* @__PURE__ */ new WeakMap(), ln = {}, co = 0, Si = function(e) {
  return e && (e.host || Si(e.parentNode));
}, $u = function(e, t) {
  return t.map(function(n) {
    if (e.contains(n))
      return n;
    var o = Si(n);
    return o && e.contains(o) ? o : (console.error("aria-hidden", n, "in not contained inside", e, ". Doing nothing"), null);
  }).filter(function(n) {
    return !!n;
  });
}, Fu = function(e, t, n, o) {
  var r = $u(t, Array.isArray(e) ? e : [e]);
  ln[n] || (ln[n] = /* @__PURE__ */ new WeakMap());
  var a = ln[n], i = [], c = /* @__PURE__ */ new Set(), l = new Set(r), u = function(f) {
    !f || c.has(f) || (c.add(f), u(f.parentNode));
  };
  r.forEach(u);
  var m = function(f) {
    !f || l.has(f) || Array.prototype.forEach.call(f.children, function(p) {
      if (c.has(p))
        m(p);
      else
        try {
          var h = p.getAttribute(o), g = h !== null && h !== "false", b = (Et.get(p) || 0) + 1, v = (a.get(p) || 0) + 1;
          Et.set(p, b), a.set(p, v), i.push(p), b === 1 && g && cn.set(p, !0), v === 1 && p.setAttribute(n, "true"), g || p.setAttribute(o, "true");
        } catch (x) {
          console.error("aria-hidden: cannot operate on ", p, x);
        }
    });
  };
  return m(t), c.clear(), co++, function() {
    i.forEach(function(f) {
      var p = Et.get(f) - 1, h = a.get(f) - 1;
      Et.set(f, p), a.set(f, h), p || (cn.has(f) || f.removeAttribute(o), cn.delete(f)), h || f.removeAttribute(n);
    }), co--, co || (Et = /* @__PURE__ */ new WeakMap(), Et = /* @__PURE__ */ new WeakMap(), cn = /* @__PURE__ */ new WeakMap(), ln = {});
  };
}, tr = function(e, t, n) {
  n === void 0 && (n = "data-aria-hidden");
  var o = Array.from(Array.isArray(e) ? e : [e]), r = Lu(e);
  return r ? (o.push.apply(o, Array.from(r.querySelectorAll("[aria-live], script"))), Fu(o, r, n, "aria-hidden")) : function() {
    return null;
  };
}, zu = Object.defineProperty, Te = (e, t) => zu(e, "name", { value: t, configurable: !0 }), nr = "Dialog", [Ri, fv] = /* @__PURE__ */ we(nr), [Bu, Ne] = Ri(nr), Pi = /* @__PURE__ */ Te((e) => {
  const {
    __scopeDialog: t,
    children: n,
    open: o,
    defaultOpen: r,
    onOpenChange: a,
    modal: i = !0
  } = e, c = s.useRef(null), l = s.useRef(null), [u, m] = Pe({
    prop: o,
    defaultProp: r ?? !1,
    onChange: a,
    caller: nr
  }), [f, p] = s.useState(0), [h, g] = s.useState(0);
  return /* @__PURE__ */ d(
    Bu,
    {
      scope: t,
      triggerRef: c,
      contentRef: l,
      contentId: ve(),
      titleId: ve(),
      descriptionId: ve(),
      titlePresent: f > 0,
      descriptionPresent: h > 0,
      setTitleCount: p,
      setDescriptionCount: g,
      open: u,
      onOpenChange: m,
      onOpenToggle: s.useCallback(() => m((b) => !b), [m]),
      modal: i,
      children: n
    }
  );
}, "Dialog"), Vu = "DialogTrigger", Ei = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ Te(function(t, n) {
    const { __scopeDialog: o, ...r } = t, a = Ne(Vu, o), i = H(n, a.triggerRef);
    return /* @__PURE__ */ d(
      $.button,
      {
        type: "button",
        "aria-haspopup": "dialog",
        "aria-expanded": a.open,
        "aria-controls": a.open ? a.contentId : void 0,
        "data-state": On(a.open),
        ...r,
        ref: i,
        onClick: A(t.onClick, a.onOpenToggle)
      }
    );
  }, "DialogTrigger")
), _i = "DialogPortal", [Wu, Ti] = Ri(_i, {
  forceMount: void 0
}), Ii = /* @__PURE__ */ Te((e) => {
  const { __scopeDialog: t, forceMount: n, children: o, container: r } = e, a = Ne(_i, t);
  return /* @__PURE__ */ d(Wu, { scope: t, forceMount: n, children: s.Children.map(o, (i) => /* @__PURE__ */ d(he, { present: n || a.open, children: /* @__PURE__ */ d(An, { asChild: !0, container: r, children: i }) })) });
}, "DialogPortal"), Ao = "DialogOverlay", Ai = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ Te(function(t, n) {
    const o = Ti(Ao, t.__scopeDialog), { forceMount: r = o.forceMount, ...a } = t, i = Ne(Ao, t.__scopeDialog);
    return i.modal ? /* @__PURE__ */ d(he, { present: r || i.open, children: /* @__PURE__ */ d(Gu, { ...a, ref: n }) }) : null;
  }, "DialogOverlay")
), Hu = /* @__PURE__ */ ze("DialogOverlay.RemoveScroll"), Gu = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ Te(function(t, n) {
    const { __scopeDialog: o, ...r } = t, a = Ne(Ao, o), i = si(), c = H(n, i);
    return (
      // Make sure `Content` is scrollable even when it doesn't live inside `RemoveScroll`
      // ie. when `Overlay` and `Content` are siblings
      /* @__PURE__ */ d(Mn, { as: Hu, allowPinchZoom: !0, shards: [a.contentRef], children: /* @__PURE__ */ d(
        $.div,
        {
          "data-state": On(a.open),
          ...r,
          ref: c,
          style: { pointerEvents: "auto", ...r.style }
        }
      ) })
    );
  }, "DialogOverlayImpl")
), Ft = "DialogContent", ki = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ Te(function(t, n) {
    const o = Ti(Ft, t.__scopeDialog), { forceMount: r = o.forceMount, ...a } = t, i = Ne(Ft, t.__scopeDialog);
    return /* @__PURE__ */ d(he, { present: r || i.open, children: i.modal ? /* @__PURE__ */ d(Uu, { ...a, ref: n }) : /* @__PURE__ */ d(ju, { ...a, ref: n }) });
  }, "DialogContent")
), Uu = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ Te(function(t, n) {
    const o = Ne(Ft, t.__scopeDialog), r = s.useRef(null), a = H(n, o.contentRef, r);
    return s.useEffect(() => {
      const i = r.current;
      if (i) return tr(i);
    }, []), /* @__PURE__ */ d(
      Mi,
      {
        ...t,
        ref: a,
        trapFocus: o.open,
        disableOutsidePointerEvents: o.open,
        onCloseAutoFocus: A(t.onCloseAutoFocus, (i) => {
          i.preventDefault(), o.triggerRef.current?.focus();
        }),
        onPointerDownOutside: A(t.onPointerDownOutside, (i) => {
          const c = i.detail.originalEvent, l = c.button === 0 && c.ctrlKey === !0;
          (c.button === 2 || l) && i.preventDefault();
        }),
        onFocusOutside: A(
          t.onFocusOutside,
          (i) => i.preventDefault()
        )
      }
    );
  }, "DialogContentModal")
), ju = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ Te(function(t, n) {
    const o = Ne(Ft, t.__scopeDialog), r = s.useRef(!1), a = s.useRef(!1);
    return /* @__PURE__ */ d(
      Mi,
      {
        ...t,
        ref: n,
        trapFocus: !1,
        disableOutsidePointerEvents: !1,
        onCloseAutoFocus: (i) => {
          t.onCloseAutoFocus?.(i), i.defaultPrevented || (r.current || o.triggerRef.current?.focus(), i.preventDefault()), r.current = !1, a.current = !1;
        },
        onInteractOutside: (i) => {
          t.onInteractOutside?.(i), i.defaultPrevented || (r.current = !0, i.detail.originalEvent.type === "pointerdown" && (a.current = !0));
          const c = i.target;
          o.triggerRef.current?.contains(c) && i.preventDefault(), i.detail.originalEvent.type === "focusin" && a.current && i.preventDefault();
        }
      }
    );
  }, "DialogContentNonModal")
), Mi = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ Te(function(t, n) {
    const { __scopeDialog: o, trapFocus: r, onOpenAutoFocus: a, onCloseAutoFocus: i, ...c } = t, l = Ne(Ft, o);
    return Xt(), /* @__PURE__ */ d(Xe, { children: /* @__PURE__ */ d(
      Qo,
      {
        asChild: !0,
        loop: !0,
        trapped: r,
        onMountAutoFocus: a,
        onUnmountAutoFocus: i,
        children: /* @__PURE__ */ d(
          In,
          {
            role: "dialog",
            id: l.contentId,
            "aria-describedby": l.descriptionPresent ? l.descriptionId : void 0,
            "aria-labelledby": l.titlePresent ? l.titleId : void 0,
            "data-state": On(l.open),
            ...c,
            ref: n,
            deferPointerDownOutside: !0,
            onDismiss: () => l.onOpenChange(!1)
          }
        )
      }
    ) });
  }, "DialogContentImpl")
), Ku = "DialogTitle", Oi = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ Te(function(t, n) {
    const { __scopeDialog: o, ...r } = t, a = Ne(Ku, o), { setTitleCount: i } = a;
    return re(() => (i((c) => c + 1), () => i((c) => c - 1)), [i]), /* @__PURE__ */ d($.h2, { id: a.titleId, ...r, ref: n });
  }, "DialogTitle")
), Yu = "DialogDescription", Di = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ Te(function(t, n) {
    const { __scopeDialog: o, ...r } = t, a = Ne(Yu, o), { setDescriptionCount: i } = a;
    return re(() => (i((c) => c + 1), () => i((c) => c - 1)), [i]), /* @__PURE__ */ d($.p, { id: a.descriptionId, ...r, ref: n });
  }, "DialogDescription")
), Xu = "DialogClose", qt = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ Te(function(t, n) {
    const { __scopeDialog: o, ...r } = t, a = Ne(Xu, o);
    return /* @__PURE__ */ d(
      $.button,
      {
        type: "button",
        ...r,
        ref: n,
        onClick: A(t.onClick, () => a.onOpenChange(!1))
      }
    );
  }, "DialogClose")
);
function On(e) {
  return e ? "open" : "closed";
}
Te(On, "getState");
var qu = Object.defineProperty, Zu = (e, t) => qu(e, "name", { value: t, configurable: !0 });
function Dn(e) {
  const [t, n] = s.useState(void 0);
  return re(() => {
    if (e) {
      n({ width: e.offsetWidth, height: e.offsetHeight });
      const o = new ResizeObserver((r) => {
        if (!Array.isArray(r) || !r.length)
          return;
        const a = r[0];
        let i, c;
        if ("borderBoxSize" in a) {
          const l = a.borderBoxSize, u = Array.isArray(l) ? l[0] : l;
          i = u.inlineSize, c = u.blockSize;
        } else
          i = e.offsetWidth, c = e.offsetHeight;
        n({ width: i, height: c });
      });
      return o.observe(e, { box: "border-box" }), () => o.unobserve(e);
    } else
      n(void 0);
  }, [e]), t;
}
Zu(Dn, "useSize");
var Qu = Object.defineProperty, Ze = (e, t) => Qu(e, "name", { value: t, configurable: !0 }), or = "Checkbox", [Ju, pv] = /* @__PURE__ */ we(or), [ed, rr] = Ju(or);
function Ni(e) {
  const {
    __scopeCheckbox: t,
    checked: n,
    children: o,
    defaultChecked: r,
    disabled: a,
    form: i,
    name: c,
    onCheckedChange: l,
    required: u,
    value: m = "on",
    // @ts-expect-error
    internal_do_not_use_render: f
  } = e, [p, h] = Pe({
    prop: n,
    defaultProp: r ?? !1,
    onChange: l,
    caller: or
  }), [g, b] = s.useState(null), [v, x] = s.useState(null), y = s.useRef(!1), [w, C] = s.useReducer(
    (E) => E + 1,
    0
  ), R = g ? !!i || !!g.closest("form") : (
    // We set this to true by default so that events bubble to forms without JS (SSR)
    !0
  ), P = {
    checked: p,
    disabled: a,
    setChecked: h,
    control: g,
    setControl: b,
    name: c,
    form: i,
    value: m,
    hasConsumerStoppedPropagationRef: y,
    userInteractionCount: w,
    onUserInteraction: C,
    required: u,
    defaultChecked: Ue(r) ? !1 : r,
    isFormControl: R,
    bubbleInput: v,
    setBubbleInput: x
  };
  return /* @__PURE__ */ d(
    ed,
    {
      scope: t,
      ...P,
      children: Li(f) ? f(P) : o
    }
  );
}
Ze(Ni, "CheckboxProvider");
var td = "CheckboxTrigger", nd = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ Ze(function({ __scopeCheckbox: t, onKeyDown: n, onClick: o, ...r }, a) {
    const {
      control: i,
      value: c,
      disabled: l,
      checked: u,
      required: m,
      setControl: f,
      setChecked: p,
      hasConsumerStoppedPropagationRef: h,
      onUserInteraction: g,
      isFormControl: b,
      bubbleInput: v
    } = rr(td, t), x = H(a, f), y = s.useRef(u);
    return s.useEffect(() => {
      const w = i?.form;
      if (w) {
        const C = /* @__PURE__ */ Ze(() => p(y.current), "reset");
        return w.addEventListener("reset", C), () => w.removeEventListener("reset", C);
      }
    }, [i, p]), /* @__PURE__ */ d(
      $.button,
      {
        type: "button",
        role: "checkbox",
        "aria-checked": Ue(u) ? "mixed" : u,
        "aria-required": m,
        "data-state": ar(u),
        "data-disabled": l ? "" : void 0,
        disabled: l,
        value: c,
        ...r,
        ref: x,
        onKeyDown: A(n, (w) => {
          w.key === "Enter" && w.preventDefault();
        }),
        onClick: A(o, (w) => {
          g(), p((C) => Ue(C) ? !0 : !C), v && b && (h.current = w.isPropagationStopped(), h.current || w.stopPropagation());
        })
      }
    );
  }, "CheckboxTrigger")
), od = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ Ze(function(t, n) {
    const {
      __scopeCheckbox: o,
      name: r,
      checked: a,
      defaultChecked: i,
      required: c,
      disabled: l,
      value: u,
      onCheckedChange: m,
      form: f,
      ...p
    } = t;
    return /* @__PURE__ */ d(
      Ni,
      {
        __scopeCheckbox: o,
        checked: a,
        defaultChecked: i,
        disabled: l,
        required: c,
        onCheckedChange: m,
        name: r,
        form: f,
        value: u,
        internal_do_not_use_render: ({ isFormControl: h }) => /* @__PURE__ */ Z(Xe, { children: [
          /* @__PURE__ */ d(
            nd,
            {
              ...p,
              ref: n,
              __scopeCheckbox: o
            }
          ),
          h && /* @__PURE__ */ d(
            sd,
            {
              __scopeCheckbox: o
            }
          )
        ] })
      }
    );
  }, "Checkbox")
), rd = "CheckboxIndicator", ad = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ Ze(function(t, n) {
    const { __scopeCheckbox: o, forceMount: r, ...a } = t, i = rr(rd, o);
    return /* @__PURE__ */ d(
      he,
      {
        present: r || Ue(i.checked) || i.checked === !0,
        children: /* @__PURE__ */ d(
          $.span,
          {
            "data-state": ar(i.checked),
            "data-disabled": i.disabled ? "" : void 0,
            ...a,
            ref: n,
            style: { pointerEvents: "none", ...t.style }
          }
        )
      }
    );
  }, "CheckboxIndicator")
), id = "CheckboxBubbleInput", sd = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ Ze(function({ __scopeCheckbox: t, onClick: n, ...o }, r) {
    const {
      control: a,
      hasConsumerStoppedPropagationRef: i,
      userInteractionCount: c,
      checked: l,
      defaultChecked: u,
      required: m,
      disabled: f,
      name: p,
      value: h,
      form: g,
      bubbleInput: b,
      setBubbleInput: v
    } = rr(id, t), x = H(r, v), y = Dn(a), w = s.useRef(!1), C = s.useRef(l), R = s.useRef(c);
    s.useEffect(() => {
      const E = b;
      if (!E) return;
      const S = window.HTMLInputElement.prototype, k = Object.getOwnPropertyDescriptor(
        S,
        "checked"
      ).set, N = c !== R.current;
      R.current = c;
      const M = C.current !== l;
      C.current = l;
      const F = !(N && i.current);
      if (M && k) {
        w.current = !N;
        const V = new Event("click", { bubbles: F });
        E.indeterminate = Ue(l), k.call(E, Ue(l) ? !1 : l), E.dispatchEvent(V), w.current = !1;
      }
    }, [b, l, i, c]);
    const P = s.useRef(Ue(l) ? !1 : l);
    return /* @__PURE__ */ d(
      $.input,
      {
        type: "checkbox",
        "aria-hidden": !0,
        defaultChecked: u ?? P.current,
        required: m,
        disabled: f,
        name: p,
        value: h,
        form: g,
        ...o,
        tabIndex: -1,
        ref: x,
        onClick: A(n, (E) => {
          w.current && E.stopPropagation();
        }),
        style: {
          ...o.style,
          ...y,
          position: "absolute",
          pointerEvents: "none",
          opacity: 0,
          margin: 0,
          // We transform because the input is absolutely positioned but we have
          // rendered it **after** the button. This pulls it back to sit on top
          // of the button.
          transform: "translateX(-100%)"
        }
      }
    );
  }, "CheckboxBubbleInput")
);
function Li(e) {
  return typeof e == "function";
}
Ze(Li, "isFunction");
function Ue(e) {
  return e === "indeterminate";
}
Ze(Ue, "isIndeterminate");
function ar(e) {
  return Ue(e) ? "indeterminate" : e ? "checked" : "unchecked";
}
Ze(ar, "getState");
const cd = ["top", "right", "bottom", "left"], nt = Math.min, je = Math.max, xn = Math.round, un = Math.floor, Ke = (e) => ({
  x: e,
  y: e
}), ld = {
  left: "right",
  right: "left",
  bottom: "top",
  top: "bottom"
};
function $i(e, t, n) {
  return je(e, nt(t, n));
}
function Qe(e, t) {
  return typeof e == "function" ? e(t) : e;
}
function ot(e) {
  return e.split("-")[0];
}
function Ot(e) {
  return e.split("-")[1];
}
function ir(e) {
  return e === "x" ? "y" : "x";
}
function sr(e) {
  return e === "y" ? "height" : "width";
}
function Fe(e) {
  const t = e[0];
  return t === "t" || t === "b" ? "y" : "x";
}
function cr(e) {
  return ir(Fe(e));
}
function ud(e, t, n) {
  n === void 0 && (n = !1);
  const o = Ot(e), r = cr(e), a = sr(r);
  let i = r === "x" ? o === (n ? "end" : "start") ? "right" : "left" : o === "start" ? "bottom" : "top";
  return t.reference[a] > t.floating[a] && (i = yn(i)), [i, yn(i)];
}
function dd(e) {
  const t = yn(e);
  return [ko(e), t, ko(t)];
}
function ko(e) {
  return e.includes("start") ? e.replace("start", "end") : e.replace("end", "start");
}
const ra = ["left", "right"], aa = ["right", "left"], fd = ["top", "bottom"], pd = ["bottom", "top"];
function md(e, t, n) {
  switch (e) {
    case "top":
    case "bottom":
      return n ? t ? aa : ra : t ? ra : aa;
    case "left":
    case "right":
      return t ? fd : pd;
    default:
      return [];
  }
}
function hd(e, t, n, o) {
  const r = Ot(e);
  let a = md(ot(e), n === "start", o);
  return r && (a = a.map((i) => i + "-" + r), t && (a = a.concat(a.map(ko)))), a;
}
function yn(e) {
  const t = ot(e);
  return ld[t] + e.slice(t.length);
}
function gd(e) {
  var t, n, o, r;
  return {
    top: (t = e.top) != null ? t : 0,
    right: (n = e.right) != null ? n : 0,
    bottom: (o = e.bottom) != null ? o : 0,
    left: (r = e.left) != null ? r : 0
  };
}
function Fi(e) {
  return typeof e != "number" ? gd(e) : {
    top: e,
    right: e,
    bottom: e,
    left: e
  };
}
function Cn(e) {
  const {
    x: t,
    y: n,
    width: o,
    height: r
  } = e;
  return {
    width: o,
    height: r,
    top: n,
    left: t,
    right: t + o,
    bottom: n + r,
    x: t,
    y: n
  };
}
function ia(e, t, n) {
  let {
    reference: o,
    floating: r
  } = e;
  const a = Fe(t), i = cr(t), c = sr(i), l = ot(t), u = a === "y", m = o.x + o.width / 2 - r.width / 2, f = o.y + o.height / 2 - r.height / 2, p = o[c] / 2 - r[c] / 2;
  let h;
  switch (l) {
    case "top":
      h = {
        x: m,
        y: o.y - r.height
      };
      break;
    case "bottom":
      h = {
        x: m,
        y: o.y + o.height
      };
      break;
    case "right":
      h = {
        x: o.x + o.width,
        y: f
      };
      break;
    case "left":
      h = {
        x: o.x - r.width,
        y: f
      };
      break;
    default:
      h = {
        x: o.x,
        y: o.y
      };
  }
  const g = Ot(t);
  return g && (h[i] += p * (g === "end" ? 1 : -1) * (n && u ? -1 : 1)), h;
}
async function bd(e, t) {
  var n;
  t === void 0 && (t = {});
  const {
    x: o,
    y: r,
    platform: a,
    rects: i,
    elements: c,
    strategy: l
  } = e, {
    boundary: u = "clippingAncestors",
    rootBoundary: m = "viewport",
    elementContext: f = "floating",
    altBoundary: p = !1,
    padding: h = 0
  } = Qe(t, e), g = Fi(h), v = c[p ? f === "floating" ? "reference" : "floating" : f], x = Cn(await a.getClippingRect({
    element: (n = await (a.isElement == null ? void 0 : a.isElement(v))) == null || n ? v : v.contextElement || await (a.getDocumentElement == null ? void 0 : a.getDocumentElement(c.floating)),
    boundary: u,
    rootBoundary: m,
    strategy: l
  })), y = f === "floating" ? {
    x: o,
    y: r,
    width: i.floating.width,
    height: i.floating.height
  } : i.reference, w = await (a.getOffsetParent == null ? void 0 : a.getOffsetParent(c.floating)), C = await (a.isElement == null ? void 0 : a.isElement(w)) && await (a.getScale == null ? void 0 : a.getScale(w)) || {
    x: 1,
    y: 1
  }, R = Cn(a.convertOffsetParentRelativeRectToViewportRelativeRect ? await a.convertOffsetParentRelativeRectToViewportRelativeRect({
    elements: c,
    rect: y,
    offsetParent: w,
    strategy: l
  }) : y);
  return {
    top: (x.top - R.top + g.top) / C.y,
    bottom: (R.bottom - x.bottom + g.bottom) / C.y,
    left: (x.left - R.left + g.left) / C.x,
    right: (R.right - x.right + g.right) / C.x
  };
}
const vd = 50, wd = async (e, t, n) => {
  const {
    placement: o = "bottom",
    strategy: r = "absolute",
    middleware: a = [],
    platform: i
  } = n, c = i.detectOverflow ? i : {
    ...i,
    detectOverflow: bd
  }, l = await (i.isRTL == null ? void 0 : i.isRTL(t));
  let u = await i.getElementRects({
    reference: e,
    floating: t,
    strategy: r
  }), {
    x: m,
    y: f
  } = ia(u, o, l), p = o, h = 0;
  const g = {};
  for (let b = 0; b < a.length; b++) {
    const v = a[b];
    if (!v)
      continue;
    const {
      name: x,
      fn: y
    } = v, {
      x: w,
      y: C,
      data: R,
      reset: P
    } = await y({
      x: m,
      y: f,
      initialPlacement: o,
      placement: p,
      strategy: r,
      middlewareData: g,
      rects: u,
      platform: c,
      elements: {
        reference: e,
        floating: t
      }
    });
    m = w ?? m, f = C ?? f, g[x] = {
      ...g[x],
      ...R
    }, P && h < vd && (h++, typeof P == "object" && (P.placement && (p = P.placement), P.rects && (u = P.rects === !0 ? await i.getElementRects({
      reference: e,
      floating: t,
      strategy: r
    }) : P.rects), {
      x: m,
      y: f
    } = ia(u, p, l)), b = -1);
  }
  return {
    x: m,
    y: f,
    placement: p,
    strategy: r,
    middlewareData: g
  };
}, xd = (e) => ({
  name: "arrow",
  options: e,
  async fn(t) {
    const {
      x: n,
      y: o,
      placement: r,
      rects: a,
      platform: i,
      elements: c,
      middlewareData: l
    } = t, {
      element: u,
      padding: m = 0
    } = Qe(e, t) || {};
    if (u == null)
      return {};
    const f = Fi(m), p = {
      x: n,
      y: o
    }, h = cr(r), g = sr(h), b = await i.getDimensions(u), v = h === "y", x = v ? "top" : "left", y = v ? "bottom" : "right", w = v ? "clientHeight" : "clientWidth", C = a.reference[g] + a.reference[h] - p[h] - a.floating[g], R = p[h] - a.reference[h], P = await (i.getOffsetParent == null ? void 0 : i.getOffsetParent(u));
    let E = P ? P[w] : 0;
    (!E || !await (i.isElement == null ? void 0 : i.isElement(P))) && (E = c.floating[w] || a.floating[g]);
    const S = C / 2 - R / 2, I = E / 2 - b[g] / 2 - 1, k = nt(f[x], I), N = nt(f[y], I), M = E - b[g] - N, F = E / 2 - b[g] / 2 + S, V = $i(k, F, M), j = !l.arrow && Ot(r) != null && F !== V && a.reference[g] / 2 - (F < k ? k : N) - b[g] / 2 < 0, B = j ? F < k ? F - k : F - M : 0;
    return {
      [h]: p[h] + B,
      data: {
        [h]: V,
        centerOffset: F - V - B,
        ...j && {
          alignmentOffset: B
        }
      },
      reset: j
    };
  }
}), yd = function(e) {
  return e === void 0 && (e = {}), {
    name: "flip",
    options: e,
    async fn(t) {
      var n, o;
      const {
        placement: r,
        middlewareData: a,
        rects: i,
        initialPlacement: c,
        platform: l,
        elements: u
      } = t, {
        mainAxis: m = !0,
        crossAxis: f = !0,
        fallbackPlacements: p,
        fallbackStrategy: h = "bestFit",
        fallbackAxisSideDirection: g = "none",
        flipAlignment: b = !0,
        ...v
      } = Qe(e, t);
      if ((n = a.arrow) != null && n.alignmentOffset)
        return {};
      const x = ot(r), y = Fe(c), w = ot(c) === c, C = await (l.isRTL == null ? void 0 : l.isRTL(u.floating)), R = p || (w || !b ? [yn(c)] : dd(c)), P = g !== "none";
      !p && P && R.push(...hd(c, b, g, C));
      const E = [c, ...R], S = await l.detectOverflow(t, v), I = [];
      let k = ((o = a.flip) == null ? void 0 : o.overflows) || [];
      if (m && I.push(S[x]), f) {
        const V = ud(r, i, C);
        I.push(S[V[0]], S[V[1]]);
      }
      if (k = [...k, {
        placement: r,
        overflows: I
      }], !I.every((V) => V <= 0)) {
        var N, M;
        const V = (((N = a.flip) == null ? void 0 : N.index) || 0) + 1, j = E[V];
        if (j && (!(f === "alignment" ? y !== Fe(j) : !1) || // We leave the current main axis only if every placement on that axis
        // overflows the main axis.
        k.every((W) => Fe(W.placement) === y ? W.overflows[0] > 0 : !0)))
          return {
            data: {
              index: V,
              overflows: k
            },
            reset: {
              placement: j
            }
          };
        let B = (M = k.filter((z) => z.overflows[0] <= 0).sort((z, W) => z.overflows[1] - W.overflows[1])[0]) == null ? void 0 : M.placement;
        if (!B)
          switch (h) {
            case "bestFit": {
              var F;
              const z = (F = k.filter((W) => {
                if (P) {
                  const U = Fe(W.placement);
                  return U === y || // Create a bias to the `y` side axis due to horizontal
                  // reading directions favoring greater width.
                  U === "y";
                }
                return !0;
              }).map((W) => [W.placement, W.overflows.filter((U) => U > 0).reduce((U, _) => U + _, 0)]).sort((W, U) => W[1] - U[1])[0]) == null ? void 0 : F[0];
              z && (B = z);
              break;
            }
            case "initialPlacement":
              B = c;
              break;
          }
        if (r !== B)
          return {
            reset: {
              placement: B
            }
          };
      }
      return {};
    }
  };
};
function sa(e, t) {
  return {
    top: e.top - t.height,
    right: e.right - t.width,
    bottom: e.bottom - t.height,
    left: e.left - t.width
  };
}
function ca(e) {
  return cd.some((t) => e[t] >= 0);
}
const Cd = function(e) {
  return e === void 0 && (e = {}), {
    name: "hide",
    options: e,
    async fn(t) {
      const {
        rects: n,
        platform: o
      } = t, {
        strategy: r = "referenceHidden",
        ...a
      } = Qe(e, t);
      switch (r) {
        case "referenceHidden": {
          const i = await o.detectOverflow(t, {
            ...a,
            elementContext: "reference"
          }), c = sa(i, n.reference);
          return {
            data: {
              referenceHiddenOffsets: c,
              referenceHidden: ca(c)
            }
          };
        }
        case "escaped": {
          const i = await o.detectOverflow(t, {
            ...a,
            altBoundary: !0
          }), c = sa(i, n.floating);
          return {
            data: {
              escapedOffsets: c,
              escaped: ca(c)
            }
          };
        }
        default:
          return {};
      }
    }
  };
}, zi = /* @__PURE__ */ new Set(["left", "top"]);
async function Sd(e, t) {
  const {
    placement: n,
    platform: o,
    elements: r
  } = e, a = await (o.isRTL == null ? void 0 : o.isRTL(r.floating)), i = ot(n), c = Ot(n), l = Fe(n) === "y", u = zi.has(i) ? -1 : 1, m = a && l ? -1 : 1, f = Qe(t, e);
  let {
    mainAxis: p,
    crossAxis: h,
    alignmentAxis: g
  } = typeof f == "number" ? {
    mainAxis: f,
    crossAxis: 0,
    alignmentAxis: null
  } : {
    mainAxis: f.mainAxis || 0,
    crossAxis: f.crossAxis || 0,
    alignmentAxis: f.alignmentAxis
  };
  return c && typeof g == "number" && (h = c === "end" ? g * -1 : g), l ? {
    x: h * m,
    y: p * u
  } : {
    x: p * u,
    y: h * m
  };
}
const Rd = function(e) {
  return e === void 0 && (e = 0), {
    name: "offset",
    options: e,
    async fn(t) {
      var n, o;
      const {
        x: r,
        y: a,
        placement: i,
        middlewareData: c
      } = t, l = await Sd(t, e);
      return i === ((n = c.offset) == null ? void 0 : n.placement) && (o = c.arrow) != null && o.alignmentOffset ? {} : {
        x: r + l.x,
        y: a + l.y,
        data: {
          ...l,
          placement: i
        }
      };
    }
  };
}, Pd = function(e) {
  return e === void 0 && (e = {}), {
    name: "shift",
    options: e,
    async fn(t) {
      const {
        x: n,
        y: o,
        placement: r,
        platform: a
      } = t, {
        mainAxis: i = !0,
        crossAxis: c = !1,
        limiter: l = {
          fn: (y) => {
            let {
              x: w,
              y: C
            } = y;
            return {
              x: w,
              y: C
            };
          }
        },
        ...u
      } = Qe(e, t), m = {
        x: n,
        y: o
      }, f = await a.detectOverflow(t, u), p = Fe(r), h = ir(p);
      let g = m[h], b = m[p];
      const v = (y, w) => $i(w + f[y === "y" ? "top" : "left"], w, w - f[y === "y" ? "bottom" : "right"]);
      i && (g = v(h, g)), c && (b = v(p, b));
      const x = l.fn({
        ...t,
        [h]: g,
        [p]: b
      });
      return {
        ...x,
        data: {
          x: x.x - n,
          y: x.y - o,
          enabled: {
            [h]: i,
            [p]: c
          }
        }
      };
    }
  };
}, Ed = function(e) {
  return e === void 0 && (e = {}), {
    options: e,
    fn(t) {
      var n, o;
      const {
        x: r,
        y: a,
        placement: i,
        rects: c,
        middlewareData: l
      } = t, {
        offset: u = 0,
        mainAxis: m = !0,
        crossAxis: f = !0
      } = Qe(e, t), p = {
        x: r,
        y: a
      }, h = Fe(i), g = ir(h);
      let b = p[g], v = p[h];
      const x = Qe(u, t), y = typeof x == "number" ? {
        mainAxis: x,
        crossAxis: 0
      } : {
        mainAxis: (n = x.mainAxis) != null ? n : 0,
        crossAxis: (o = x.crossAxis) != null ? o : 0
      };
      if (m) {
        const R = g === "y" ? "height" : "width", P = c.reference[g] - c.floating[R] + y.mainAxis, E = c.reference[g] + c.reference[R] - y.mainAxis;
        b < P ? b = P : b > E && (b = E);
      }
      if (f) {
        var w, C;
        const R = g === "y" ? "width" : "height", P = zi.has(ot(i)), E = c.reference[h] - c.floating[R] + (P && ((w = l.offset) == null ? void 0 : w[h]) || 0) + (P ? 0 : y.crossAxis), S = c.reference[h] + c.reference[R] + (P ? 0 : ((C = l.offset) == null ? void 0 : C[h]) || 0) - (P ? y.crossAxis : 0);
        v < E ? v = E : v > S && (v = S);
      }
      return {
        [g]: b,
        [h]: v
      };
    }
  };
}, _d = function(e) {
  return e === void 0 && (e = {}), {
    name: "size",
    options: e,
    async fn(t) {
      const {
        placement: n,
        rects: o,
        platform: r,
        elements: a
      } = t, {
        apply: i = () => {
        },
        ...c
      } = Qe(e, t), l = await r.detectOverflow(t, c), u = ot(n), m = Ot(n), f = Fe(n) === "y", {
        width: p,
        height: h
      } = o.floating;
      let g, b;
      u === "top" || u === "bottom" ? (g = u, b = m === (await (r.isRTL == null ? void 0 : r.isRTL(a.floating)) ? "start" : "end") ? "left" : "right") : (b = u, g = m === "end" ? "top" : "bottom");
      const v = h - l.top - l.bottom, x = p - l.left - l.right, y = nt(h - l[g], v), w = nt(p - l[b], x), C = t.middlewareData.shift, R = !C;
      let P = y, E = w;
      C != null && C.enabled.x && (E = x), C != null && C.enabled.y && (P = v), R && !m && (f ? E = p - 2 * je(l.left, l.right) : P = h - 2 * je(l.top, l.bottom)), await i({
        ...t,
        availableWidth: E,
        availableHeight: P
      });
      const S = await r.getDimensions(a.floating);
      return p !== S.width || h !== S.height ? {
        reset: {
          rects: !0
        }
      } : {};
    }
  };
};
function Nn() {
  return typeof window < "u";
}
function Dt(e) {
  return Bi(e) ? (e.nodeName || "").toLowerCase() : "#document";
}
function Re(e) {
  var t;
  return (e == null || (t = e.ownerDocument) == null ? void 0 : t.defaultView) || window;
}
function Je(e) {
  var t;
  return (t = (Bi(e) ? e.ownerDocument : e.document) || window.document) == null ? void 0 : t.documentElement;
}
function Bi(e) {
  return Nn() ? e instanceof Node || e instanceof Re(e).Node : !1;
}
function Be(e) {
  return Nn() ? e instanceof Element || e instanceof Re(e).Element : !1;
}
function at(e) {
  return Nn() ? e instanceof HTMLElement || e instanceof Re(e).HTMLElement : !1;
}
function la(e) {
  return !Nn() || typeof ShadowRoot > "u" ? !1 : e instanceof ShadowRoot || e instanceof Re(e).ShadowRoot;
}
function Ln(e) {
  const {
    overflow: t,
    overflowX: n,
    overflowY: o,
    display: r
  } = Ve(e);
  return /auto|scroll|overlay|hidden|clip/.test(t + o + n) && r !== "inline" && r !== "contents";
}
function Td(e) {
  return /^(table|td|th)$/.test(Dt(e));
}
function $n(e) {
  try {
    if (e.matches(":popover-open"))
      return !0;
  } catch {
  }
  try {
    return e.matches(":modal");
  } catch {
    return !1;
  }
}
const Id = /transform|translate|scale|rotate|perspective|filter/, Ad = /paint|layout|strict|content/, lt = (e) => !!e && e !== "none";
let lo;
function lr(e) {
  const t = Be(e) ? Ve(e) : e;
  return lt(t.transform) || lt(t.translate) || lt(t.scale) || lt(t.rotate) || lt(t.perspective) || !ur() && (lt(t.backdropFilter) || lt(t.filter)) || Id.test(t.willChange || "") || Ad.test(t.contain || "");
}
function kd(e) {
  let t = dt(e);
  for (; at(t) && !zt(t); ) {
    if (lr(t))
      return t;
    if ($n(t))
      return null;
    t = dt(t);
  }
  return null;
}
function ur() {
  return lo == null && (lo = typeof CSS < "u" && CSS.supports && CSS.supports("-webkit-backdrop-filter", "none")), lo;
}
function zt(e) {
  return /^(html|body|#document)$/.test(Dt(e));
}
function Ve(e) {
  return Re(e).getComputedStyle(e);
}
function Fn(e) {
  return Be(e) ? {
    scrollLeft: e.scrollLeft,
    scrollTop: e.scrollTop
  } : {
    scrollLeft: e.scrollX,
    scrollTop: e.scrollY
  };
}
function dt(e) {
  if (Dt(e) === "html")
    return e;
  const t = (
    // Step into the shadow DOM of the parent of a slotted node.
    e.assignedSlot || // DOM Element detected.
    e.parentNode || // ShadowRoot detected.
    la(e) && e.host || // Fallback.
    Je(e)
  );
  return la(t) ? t.host : t;
}
function Vi(e) {
  const t = dt(e);
  return zt(t) ? (e.ownerDocument || e).body : at(t) && Ln(t) ? t : Vi(t);
}
function Bt(e, t, n) {
  var o;
  t === void 0 && (t = []), n === void 0 && (n = !0);
  const r = Vi(e), a = r === ((o = e.ownerDocument) == null ? void 0 : o.body), i = Re(r);
  if (a) {
    const c = Mo(i);
    return t.concat(i, i.visualViewport || [], Ln(r) ? r : [], c && n ? Bt(c) : []);
  } else
    return t.concat(r, Bt(r, [], n));
}
function Mo(e) {
  return e.parent && Object.getPrototypeOf(e.parent) ? e.frameElement : null;
}
function Wi(e) {
  const t = Ve(e);
  let n = parseFloat(t.width) || 0, o = parseFloat(t.height) || 0;
  const r = at(e), a = r ? e.offsetWidth : n, i = r ? e.offsetHeight : o, c = xn(n) !== a || xn(o) !== i;
  return c && (n = a, o = i), {
    width: n,
    height: o,
    $: c
  };
}
function dr(e) {
  return Be(e) ? e : e.contextElement;
}
function It(e) {
  const t = dr(e);
  if (!at(t))
    return Ke(1);
  const n = t.getBoundingClientRect(), {
    width: o,
    height: r,
    $: a
  } = Wi(t);
  let i = (a ? xn(n.width) : n.width) / o, c = (a ? xn(n.height) : n.height) / r;
  return (!i || !Number.isFinite(i)) && (i = 1), (!c || !Number.isFinite(c)) && (c = 1), {
    x: i,
    y: c
  };
}
const Md = /* @__PURE__ */ Ke(0);
function Hi(e) {
  const t = Re(e);
  return !ur() || !t.visualViewport ? Md : {
    x: t.visualViewport.offsetLeft,
    y: t.visualViewport.offsetTop
  };
}
function Od(e, t, n) {
  return t === void 0 && (t = !1), !!n && t && n === Re(e);
}
function ft(e, t, n, o) {
  t === void 0 && (t = !1), n === void 0 && (n = !1);
  const r = e.getBoundingClientRect(), a = dr(e);
  let i = Ke(1);
  t && (o ? Be(o) && (i = It(o)) : i = It(e));
  const c = Od(a, n, o) ? Hi(a) : Ke(0);
  let l = (r.left + c.x) / i.x, u = (r.top + c.y) / i.y, m = r.width / i.x, f = r.height / i.y;
  if (a && o) {
    const p = Re(a), h = Be(o) ? Re(o) : o;
    let g = p, b = Mo(g);
    for (; b && h !== g; ) {
      const v = It(b), x = b.getBoundingClientRect(), y = Ve(b), w = x.left + (b.clientLeft + parseFloat(y.paddingLeft)) * v.x, C = x.top + (b.clientTop + parseFloat(y.paddingTop)) * v.y;
      l *= v.x, u *= v.y, m *= v.x, f *= v.y, l += w, u += C, g = Re(b), b = Mo(g);
    }
  }
  return Cn({
    width: m,
    height: f,
    x: l,
    y: u
  });
}
function zn(e, t) {
  const n = Fn(e).scrollLeft;
  return t ? t.left + n : ft(Je(e)).left + n;
}
function Gi(e, t) {
  const n = e.getBoundingClientRect(), o = n.left + t.scrollLeft - zn(e, n), r = n.top + t.scrollTop;
  return {
    x: o,
    y: r
  };
}
function Dd(e) {
  let {
    elements: t,
    rect: n,
    offsetParent: o,
    strategy: r
  } = e;
  const a = r === "fixed", i = Je(o), c = t ? $n(t.floating) : !1;
  if (o === i || c && a)
    return n;
  let l = {
    scrollLeft: 0,
    scrollTop: 0
  }, u = Ke(1);
  const m = Ke(0), f = at(o);
  if ((f || !a) && ((Dt(o) !== "body" || Ln(i)) && (l = Fn(o)), f)) {
    const h = ft(o);
    u = It(o), m.x = h.x + o.clientLeft, m.y = h.y + o.clientTop;
  }
  const p = i && !f && !a ? Gi(i, l) : Ke(0);
  return {
    width: n.width * u.x,
    height: n.height * u.y,
    x: n.x * u.x - l.scrollLeft * u.x + m.x + p.x,
    y: n.y * u.y - l.scrollTop * u.y + m.y + p.y
  };
}
function Nd(e) {
  return e.getClientRects ? Array.from(e.getClientRects()) : [];
}
function Ld(e) {
  const t = Fn(e), n = e.ownerDocument.body, o = je(e.scrollWidth, e.clientWidth, n.scrollWidth, n.clientWidth), r = je(e.scrollHeight, e.clientHeight, n.scrollHeight, n.clientHeight);
  let a = -t.scrollLeft + zn(e);
  const i = -t.scrollTop;
  return Ve(n).direction === "rtl" && (a += je(e.clientWidth, n.clientWidth) - o), {
    width: o,
    height: r,
    x: a,
    y: i
  };
}
const $d = 25;
function Fd(e, t, n) {
  n === void 0 && (n = "viewport");
  const o = n === "layoutViewport", r = Re(e), a = Je(e), i = r.visualViewport;
  let c = a.clientWidth, l = a.clientHeight, u = 0, m = 0;
  if (i) {
    const p = !ur() || t === "fixed";
    o ? p || (u = -i.offsetLeft, m = -i.offsetTop) : (c = i.width, l = i.height, p && (u = i.offsetLeft, m = i.offsetTop));
  }
  if (zn(a) <= 0) {
    const p = a.ownerDocument, h = p.body, g = getComputedStyle(h), b = p.compatMode === "CSS1Compat" && parseFloat(g.marginLeft) + parseFloat(g.marginRight) || 0, v = Math.abs(a.clientWidth - h.clientWidth - b), x = getComputedStyle(a).scrollbarGutter === "stable both-edges" ? v / 2 : v;
    x <= $d && (c -= x);
  }
  return {
    width: c,
    height: l,
    x: u,
    y: m
  };
}
function zd(e, t) {
  const n = ft(e, !0, t === "fixed"), o = n.top + e.clientTop, r = n.left + e.clientLeft, a = It(e), i = e.clientWidth * a.x, c = e.clientHeight * a.y, l = r * a.x, u = o * a.y;
  return {
    width: i,
    height: c,
    x: l,
    y: u
  };
}
function ua(e, t, n) {
  let o;
  if (t === "viewport" || t === "layoutViewport")
    o = Fd(e, n, t);
  else if (t === "document")
    o = Ld(Je(e));
  else if (Be(t))
    o = zd(t, n);
  else {
    const r = Hi(e);
    o = {
      x: t.x - r.x,
      y: t.y - r.y,
      width: t.width,
      height: t.height
    };
  }
  return Cn(o);
}
function Bd(e, t) {
  const n = t.get(e);
  if (n)
    return n;
  let o = Bt(e, [], !1).filter((c) => Be(c) && Dt(c) !== "body"), r = null;
  const a = Ve(e).position === "fixed";
  let i = a ? dt(e) : e;
  for (; Be(i) && !zt(i); ) {
    const c = Ve(i), l = lr(i), u = r ? r.position : a ? "fixed" : "";
    !l && (u === "fixed" || u === "absolute" && c.position === "static") ? o = o.filter((f) => f !== i) : r = c, i = dt(i);
  }
  return t.set(e, o), o;
}
function Vd(e) {
  let {
    element: t,
    boundary: n,
    rootBoundary: o,
    strategy: r
  } = e;
  const i = [...n === "clippingAncestors" ? $n(t) ? [] : Bd(t, this._c) : [].concat(n), o], c = ua(t, i[0], r);
  let l = c.top, u = c.right, m = c.bottom, f = c.left;
  for (let p = 1; p < i.length; p++) {
    const h = ua(t, i[p], r);
    l = je(h.top, l), u = nt(h.right, u), m = nt(h.bottom, m), f = je(h.left, f);
  }
  return {
    width: u - f,
    height: m - l,
    x: f,
    y: l
  };
}
function Wd(e) {
  const {
    width: t,
    height: n
  } = Wi(e);
  return {
    width: t,
    height: n
  };
}
function Hd(e, t, n) {
  const o = at(t), r = Je(t), a = n === "fixed", i = ft(e, !0, a, t);
  let c = {
    scrollLeft: 0,
    scrollTop: 0
  };
  const l = Ke(0);
  if ((o || !a) && ((Dt(t) !== "body" || Ln(r)) && (c = Fn(t)), o)) {
    const p = ft(t, !0, a, t);
    l.x = p.x + t.clientLeft, l.y = p.y + t.clientTop;
  }
  !o && r && (l.x = zn(r));
  const u = r && !o && !a ? Gi(r, c) : Ke(0), m = i.left + c.scrollLeft - l.x - u.x, f = i.top + c.scrollTop - l.y - u.y;
  return {
    x: m,
    y: f,
    width: i.width,
    height: i.height
  };
}
function uo(e) {
  return Ve(e).position === "static";
}
function da(e, t) {
  if (!at(e) || Ve(e).position === "fixed")
    return null;
  if (t)
    return t(e);
  let n = e.offsetParent;
  return Je(e) === n && (n = n.ownerDocument.body), n;
}
function Ui(e, t) {
  const n = Re(e);
  if ($n(e))
    return n;
  if (!at(e)) {
    let r = dt(e);
    for (; r && !zt(r); ) {
      if (Be(r) && !uo(r))
        return r;
      r = dt(r);
    }
    return n;
  }
  let o = da(e, t);
  for (; o && Td(o) && uo(o); )
    o = da(o, t);
  return o && zt(o) && uo(o) && !lr(o) ? n : o || kd(e) || n;
}
const Gd = async function(e) {
  const t = this.getOffsetParent || Ui, n = this.getDimensions, o = await n(e.floating);
  return {
    reference: Hd(e.reference, await t(e.floating), e.strategy),
    floating: {
      x: 0,
      y: 0,
      width: o.width,
      height: o.height
    }
  };
};
function Ud(e) {
  return Ve(e).direction === "rtl";
}
const jd = {
  convertOffsetParentRelativeRectToViewportRelativeRect: Dd,
  getDocumentElement: Je,
  getClippingRect: Vd,
  getOffsetParent: Ui,
  getElementRects: Gd,
  getClientRects: Nd,
  getDimensions: Wd,
  getScale: It,
  isElement: Be,
  isRTL: Ud
};
function ji(e, t) {
  return e.x === t.x && e.y === t.y && e.width === t.width && e.height === t.height;
}
function Kd(e, t, n) {
  let o = null, r;
  const a = Je(e);
  function i() {
    var m;
    clearTimeout(r), (m = o) == null || m.disconnect(), o = null;
  }
  function c(m, f) {
    m === void 0 && (m = !1), f === void 0 && (f = 1), i();
    const p = e.getBoundingClientRect(), {
      left: h,
      top: g,
      width: b,
      height: v
    } = p;
    if (m || t(), !b || !v)
      return;
    const x = un(g), y = un(a.clientWidth - (h + b)), w = un(a.clientHeight - (g + v)), C = un(h), P = {
      rootMargin: -x + "px " + -y + "px " + -w + "px " + -C + "px",
      threshold: je(0, nt(1, f)) || 1
    };
    let E = !0;
    function S(I) {
      const k = I[0].intersectionRatio;
      if (!ji(p, e.getBoundingClientRect()))
        return c();
      if (k !== f) {
        if (!E)
          return c();
        k ? c(!1, k) : r = setTimeout(() => {
          c(!1, 1e-7);
        }, 1e3);
      }
      E = !1;
    }
    try {
      o = new IntersectionObserver(S, {
        ...P,
        // Handle <iframe>s
        root: a.ownerDocument
      });
    } catch {
      o = new IntersectionObserver(S, P);
    }
    o.observe(e);
  }
  const l = Re(e), u = () => c(n);
  return l.addEventListener("resize", u), c(!0), () => {
    l.removeEventListener("resize", u), i();
  };
}
function Yd(e, t, n, o) {
  o === void 0 && (o = {});
  const {
    ancestorScroll: r = !0,
    ancestorResize: a = !0,
    elementResize: i = typeof ResizeObserver == "function",
    layoutShift: c = typeof IntersectionObserver == "function",
    animationFrame: l = !1
  } = o, u = dr(e), m = r || a ? [...u ? Bt(u) : [], ...t ? Bt(t) : []] : [];
  m.forEach((x) => {
    r && x.addEventListener("scroll", n), a && x.addEventListener("resize", n);
  });
  const f = u && c ? Kd(u, n, a) : null;
  let p = -1, h = null;
  i && (h = new ResizeObserver((x) => {
    let [y] = x;
    y && y.target === u && h && t && (h.unobserve(t), cancelAnimationFrame(p), p = requestAnimationFrame(() => {
      var w;
      (w = h) == null || w.observe(t);
    })), n();
  }), u && !l && h.observe(u), t && h.observe(t));
  let g, b = l ? ft(e) : null;
  l && v();
  function v() {
    const x = ft(e);
    b && !ji(b, x) && n(), b = x, g = requestAnimationFrame(v);
  }
  return n(), () => {
    var x;
    m.forEach((y) => {
      r && y.removeEventListener("scroll", n), a && y.removeEventListener("resize", n);
    }), f?.(), (x = h) == null || x.disconnect(), h = null, l && cancelAnimationFrame(g);
  };
}
const Xd = Rd, qd = Pd, Zd = yd, Qd = _d, Jd = Cd, fa = xd, ef = Ed, tf = (e, t, n) => {
  const o = /* @__PURE__ */ new Map(), r = n ?? {}, a = {
    ...jd,
    ...r.platform,
    _c: o
  };
  return wd(e, t, {
    ...r,
    platform: a
  });
};
var nf = typeof document < "u", of = function() {
}, vn = nf ? Ic : of;
function Sn(e, t) {
  if (e === t)
    return !0;
  if (typeof e != typeof t)
    return !1;
  if (typeof e == "function" && e.toString() === t.toString())
    return !0;
  let n, o, r;
  if (e && t && typeof e == "object") {
    if (Array.isArray(e)) {
      if (n = e.length, n !== t.length) return !1;
      for (o = n; o-- !== 0; )
        if (!Sn(e[o], t[o]))
          return !1;
      return !0;
    }
    if (r = Object.keys(e), n = r.length, n !== Object.keys(t).length)
      return !1;
    for (o = n; o-- !== 0; )
      if (!{}.hasOwnProperty.call(t, r[o]))
        return !1;
    for (o = n; o-- !== 0; ) {
      const a = r[o];
      if (!(a === "_owner" && e.$$typeof) && !Sn(e[a], t[a]))
        return !1;
    }
    return !0;
  }
  return e !== e && t !== t;
}
function Ki(e) {
  return typeof window > "u" ? 1 : (e.ownerDocument.defaultView || window).devicePixelRatio || 1;
}
function pa(e, t) {
  const n = Ki(e);
  return Math.round(t * n) / n;
}
function fo(e) {
  const t = s.useRef(e);
  return vn(() => {
    t.current = e;
  }), t;
}
function rf(e) {
  e === void 0 && (e = {});
  const {
    placement: t = "bottom",
    strategy: n = "absolute",
    middleware: o = [],
    platform: r,
    elements: {
      reference: a,
      floating: i
    } = {},
    transform: c = !0,
    whileElementsMounted: l,
    open: u
  } = e, [m, f] = s.useState({
    x: 0,
    y: 0,
    strategy: n,
    placement: t,
    middlewareData: {},
    isPositioned: !1
  }), [p, h] = s.useState(o);
  Sn(p, o) || h(o);
  const [g, b] = s.useState(null), [v, x] = s.useState(null), y = s.useCallback((W) => {
    W !== P.current && (P.current = W, b(W));
  }, []), w = s.useCallback((W) => {
    W !== E.current && (E.current = W, x(W));
  }, []), C = a || g, R = i || v, P = s.useRef(null), E = s.useRef(null), S = s.useRef(m), I = l != null, k = fo(l), N = fo(r), M = fo(u), F = s.useCallback(() => {
    if (!P.current || !E.current)
      return;
    const W = {
      placement: t,
      strategy: n,
      middleware: p
    };
    N.current && (W.platform = N.current), tf(P.current, E.current, W).then((U) => {
      const _ = {
        ...U,
        // The floating element's position may be recomputed while it's closed
        // but still mounted (such as when transitioning out). To ensure
        // `isPositioned` will be `false` initially on the next open, avoid
        // setting it to `true` when `open === false` (must be specified).
        isPositioned: M.current !== !1
      };
      V.current && !Sn(S.current, _) && (S.current = _, Ut.flushSync(() => {
        f(_);
      }));
    });
  }, [p, t, n, N, M]);
  vn(() => {
    u === !1 && S.current.isPositioned && (S.current.isPositioned = !1, f((W) => ({
      ...W,
      isPositioned: !1
    })));
  }, [u]);
  const V = s.useRef(!1);
  vn(() => (V.current = !0, () => {
    V.current = !1;
  }), []), vn(() => {
    if (C && (P.current = C), R && (E.current = R), C && R) {
      if (k.current)
        return k.current(C, R, F);
      F();
    }
  }, [C, R, F, k, I]);
  const j = s.useMemo(() => ({
    reference: P,
    floating: E,
    setReference: y,
    setFloating: w
  }), [y, w]), B = s.useMemo(() => ({
    reference: C,
    floating: R
  }), [C, R]), z = s.useMemo(() => {
    const W = {
      position: n,
      left: 0,
      top: 0
    };
    if (!B.floating)
      return W;
    const U = pa(B.floating, m.x), _ = pa(B.floating, m.y);
    return c ? {
      ...W,
      transform: "translate(" + U + "px, " + _ + "px)",
      ...Ki(B.floating) >= 1.5 && {
        willChange: "transform"
      }
    } : {
      position: n,
      left: U,
      top: _
    };
  }, [n, c, B.floating, m.x, m.y]);
  return s.useMemo(() => ({
    ...m,
    update: F,
    refs: j,
    elements: B,
    floatingStyles: z
  }), [m, F, j, B, z]);
}
const af = (e) => {
  function t(n) {
    return {}.hasOwnProperty.call(n, "current");
  }
  return {
    name: "arrow",
    options: e,
    fn(n) {
      const {
        element: o,
        padding: r
      } = typeof e == "function" ? e(n) : e;
      return o && t(o) ? o.current != null ? fa({
        element: o.current,
        padding: r
      }).fn(n) : {} : o ? fa({
        element: o,
        padding: r
      }).fn(n) : {};
    }
  };
}, sf = (e, t) => {
  const n = Xd(e);
  return {
    name: n.name,
    fn: n.fn,
    options: [e, t]
  };
}, cf = (e, t) => {
  const n = qd(e);
  return {
    name: n.name,
    fn: n.fn,
    options: [e, t]
  };
}, lf = (e, t) => ({
  fn: ef(e).fn,
  options: [e, t]
}), uf = (e, t) => {
  const n = Zd(e);
  return {
    name: n.name,
    fn: n.fn,
    options: [e, t]
  };
}, df = (e, t) => {
  const n = Qd(e);
  return {
    name: n.name,
    fn: n.fn,
    options: [e, t]
  };
}, ff = (e, t) => {
  const n = Jd(e);
  return {
    name: n.name,
    fn: n.fn,
    options: [e, t]
  };
}, pf = (e, t) => {
  const n = af(e);
  return {
    name: n.name,
    fn: n.fn,
    options: [e, t]
  };
};
var mf = Object.defineProperty, hf = (e, t) => mf(e, "name", { value: t, configurable: !0 }), gf = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ hf(function(t, n) {
    const { children: o, width: r = 10, height: a = 5, ...i } = t;
    return /* @__PURE__ */ d(
      $.svg,
      {
        ...i,
        ref: n,
        width: r,
        height: a,
        viewBox: "0 0 30 10",
        preserveAspectRatio: "none",
        children: t.asChild ? o : /* @__PURE__ */ d("polygon", { points: "0,0 30,0 15,10" })
      }
    );
  }, "Arrow")
), bf = gf, vf = Object.defineProperty, Ye = (e, t) => vf(e, "name", { value: t, configurable: !0 }), Yi = "Popper", [Xi, Nt] = /* @__PURE__ */ we(Yi), [wf, qi] = Xi(Yi), xf = /* @__PURE__ */ Ye((e) => {
  const { __scopePopper: t, children: n } = e, [o, r] = s.useState(null), [a, i] = s.useState(void 0);
  return /* @__PURE__ */ d(
    wf,
    {
      scope: t,
      anchor: o,
      onAnchorChange: r,
      placementState: a,
      setPlacementState: i,
      children: n
    }
  );
}, "Popper"), yf = "PopperAnchor", Cf = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ Ye(function(t, n) {
    const { __scopePopper: o, virtualRef: r, ...a } = t, i = qi(yf, o), c = s.useRef(null), l = i.onAnchorChange, u = s.useCallback(
      (b) => {
        c.current = b, b && l(b);
      },
      [l]
    ), m = H(n, u), f = s.useRef(null);
    s.useEffect(() => {
      if (!r)
        return;
      const b = f.current;
      f.current = r.current, b !== f.current && l(f.current);
    });
    const p = i.placementState && Bn(i.placementState), h = p?.[0], g = p?.[1];
    return r ? null : /* @__PURE__ */ d(
      $.div,
      {
        "data-radix-popper-side": h,
        "data-radix-popper-align": g,
        ...a,
        ref: m
      }
    );
  }, "PopperAnchor")
), Zi = "PopperContent", [Sf, Rf] = Xi(Zi), Pf = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ Ye(function(t, n) {
    const {
      __scopePopper: o,
      side: r = "bottom",
      sideOffset: a = 0,
      align: i = "center",
      alignOffset: c = 0,
      arrowPadding: l = 0,
      avoidCollisions: u = !0,
      collisionBoundary: m = [],
      collisionPadding: f = 0,
      sticky: p = "partial",
      hideWhenDetached: h = !1,
      updatePositionStrategy: g = "optimized",
      onPlaced: b,
      ...v
    } = t, x = qi(Zi, o), [y, w] = s.useState(null), C = H(n, w), [R, P] = s.useState(null), E = Dn(R), S = E?.width ?? 0, I = E?.height ?? 0, k = r + (i !== "center" ? "-" + i : ""), N = typeof f == "number" ? f : { top: 0, right: 0, bottom: 0, left: 0, ...f }, M = Array.isArray(m) ? m : [m], F = M.length > 0, V = {
      padding: N,
      boundary: M.filter(Qi),
      // with `strategy: 'fixed'`, this is the only way to get it to respect boundaries
      altBoundary: F
    }, { refs: j, floatingStyles: B, placement: z, isPositioned: W, middlewareData: U } = rf({
      // default to `fixed` strategy so users don't have to pick and we also avoid focus scroll issues
      strategy: "fixed",
      placement: k,
      whileElementsMounted: /* @__PURE__ */ Ye((...G) => Yd(...G, {
        animationFrame: g === "always"
      }), "whileElementsMounted"),
      elements: {
        reference: x.anchor
      },
      middleware: [
        sf({ mainAxis: a + I, alignmentAxis: c }),
        u && cf({
          mainAxis: !0,
          crossAxis: !1,
          limiter: p === "partial" ? lf() : void 0,
          ...V
        }),
        u && uf({ ...V }),
        df({
          ...V,
          apply: /* @__PURE__ */ Ye(({ elements: G, rects: le, availableWidth: Q, availableHeight: J }) => {
            const { width: oe, height: Se } = le.reference, Ie = G.floating.style;
            Ie.setProperty("--radix-popper-available-width", `${Q}px`), Ie.setProperty("--radix-popper-available-height", `${J}px`), Ie.setProperty("--radix-popper-anchor-width", `${oe}px`), Ie.setProperty("--radix-popper-anchor-height", `${Se}px`);
          }, "apply")
        }),
        R && pf({ element: R, padding: l }),
        If({ arrowWidth: S, arrowHeight: I }),
        h && ff({
          strategy: "referenceHidden",
          ...V,
          // `hide` detects whether the anchor (reference) is clipped, so when
          // no explicit `collisionBoundary` is set we fall back to Floating
          // UI's default clipping ancestors (e.g. a scrollable menu). This
          // lets an occluded submenu hide once its anchor scrolls out of view
          // (#3237). The collision/size middlewares deliberately keep the
          // viewport-based default to avoid clamping content rendered inside
          // transformed or overflow-clipping portal containers.
          boundary: F ? V.boundary : void 0
        })
      ]
    }), _ = x.setPlacementState;
    re(() => (_(z), () => {
      _(void 0);
    }), [z, _]);
    const [ce, ee] = Bn(z), ae = ie(b);
    re(() => {
      W && ae?.();
    }, [W, ae]);
    const ge = U.arrow?.x, te = U.arrow?.y, ne = U.arrow?.centerOffset !== 0, [fe, L] = s.useState();
    return re(() => {
      y && L(window.getComputedStyle(y).zIndex);
    }, [y]), /* @__PURE__ */ d(
      "div",
      {
        ref: j.setFloating,
        "data-radix-popper-content-wrapper": "",
        style: {
          ...B,
          transform: W ? B.transform : "translate(0, -200%)",
          // keep off the page when measuring
          minWidth: "max-content",
          zIndex: fe,
          "--radix-popper-transform-origin": [
            U.transformOrigin?.x,
            U.transformOrigin?.y
          ].join(" "),
          // hide the content if using the hide middleware and should be hidden
          // set visibility to hidden and disable pointer events so the UI behaves
          // as if the PopperContent isn't there at all
          ...U.hide?.referenceHidden && {
            visibility: "hidden",
            pointerEvents: "none"
          }
        },
        dir: t.dir,
        children: /* @__PURE__ */ d(
          Sf,
          {
            scope: o,
            placedSide: ce,
            placedAlign: ee,
            onArrowChange: P,
            arrowX: ge,
            arrowY: te,
            shouldHideArrow: ne,
            children: /* @__PURE__ */ d(
              $.div,
              {
                "data-side": ce,
                "data-align": ee,
                ...v,
                ref: C,
                style: {
                  ...v.style,
                  // if the PopperContent hasn't been placed yet (not all
                  // measurements done) we prevent animations so that users'
                  // animations don't kick in too early from the wrong sides.
                  animation: W ? v.style?.animation : "none"
                }
              }
            )
          }
        )
      }
    );
  }, "PopperContent")
), Ef = "PopperArrow", _f = {
  top: "bottom",
  right: "left",
  bottom: "top",
  left: "right"
}, Tf = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ Ye(function(t, n) {
    const { __scopePopper: o, ...r } = t, a = Rf(Ef, o), i = _f[a.placedSide];
    return (
      // we have to use an extra wrapper because `ResizeObserver` (used by `useSize`)
      // doesn't report size as we'd expect on SVG elements.
      // it reports their bounding box which is effectively the largest path inside the SVG.
      /* @__PURE__ */ d(
        "span",
        {
          ref: a.onArrowChange,
          style: {
            position: "absolute",
            left: a.arrowX,
            top: a.arrowY,
            [i]: 0,
            transformOrigin: {
              top: "",
              right: "0 0",
              bottom: "center 0",
              left: "100% 0"
            }[a.placedSide],
            transform: {
              top: "translateY(100%)",
              right: "translateY(50%) rotate(90deg) translateX(-50%)",
              bottom: "rotate(180deg)",
              left: "translateY(50%) rotate(-90deg) translateX(50%)"
            }[a.placedSide],
            visibility: a.shouldHideArrow ? "hidden" : void 0
          },
          children: /* @__PURE__ */ d(
            bf,
            {
              ...r,
              ref: n,
              style: {
                ...r.style,
                // ensures the element can be measured correctly (mostly for if SVG)
                display: "block"
              }
            }
          )
        }
      )
    );
  }, "PopperArrow")
);
function Qi(e) {
  return e !== null;
}
Ye(Qi, "isNotNull");
var If = /* @__PURE__ */ Ye((e) => ({
  name: "transformOrigin",
  options: e,
  fn(t) {
    const { placement: n, rects: o, middlewareData: r } = t, i = r.arrow?.centerOffset !== 0, c = i ? 0 : e.arrowWidth, l = i ? 0 : e.arrowHeight, [u, m] = Bn(n), f = { start: "0%", center: "50%", end: "100%" }[m], p = (r.arrow?.x ?? 0) + c / 2, h = (r.arrow?.y ?? 0) + l / 2;
    let g = "", b = "";
    return u === "bottom" ? (g = i ? f : `${p}px`, b = `${-l}px`) : u === "top" ? (g = i ? f : `${p}px`, b = `${o.floating.height + l}px`) : u === "right" ? (g = `${-l}px`, b = i ? f : `${h}px`) : u === "left" && (g = `${o.floating.width + l}px`, b = i ? f : `${h}px`), { data: { x: g, y: b } };
  }
}), "transformOrigin");
function Bn(e) {
  const [t, n = "center"] = e.split("-");
  return [t, n];
}
Ye(Bn, "getSideAndAlignFromPlacement");
var Vn = xf, fr = Cf, pr = Pf, Af = Tf, kf = Object.defineProperty, mr = (e, t) => kf(e, "name", { value: t, configurable: !0 }), po = !1;
function Ji() {
  const [e, t] = s.useState(po);
  return s.useEffect(() => {
    po || (po = !0, t(!0));
  }, []), e;
}
mr(Ji, "useIsHydrated");
var es = s[" useSyncExternalStore ".trim().toString()];
function ts() {
  return () => {
  };
}
mr(ts, "subscribe");
function ns() {
  return es(
    ts,
    () => !0,
    () => !1
  );
}
mr(ns, "useIsHydratedModern");
var Mf = typeof es == "function" ? ns : Ji, Of = Object.defineProperty, bt = (e, t) => Of(e, "name", { value: t, configurable: !0 }), mo = "rovingFocusGroup.onEntryFocus", Df = { bubbles: !1, cancelable: !0 }, Wn = "RovingFocusGroup", [Oo, os, Nf] = /* @__PURE__ */ jt(Wn), [Lf, Hn] = /* @__PURE__ */ we(
  Wn,
  [Nf]
), [$f, Ff] = Lf(Wn), zf = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ bt(function(t, n) {
    return /* @__PURE__ */ d(Oo.Provider, { scope: t.__scopeRovingFocusGroup, children: /* @__PURE__ */ d(Oo.Slot, { scope: t.__scopeRovingFocusGroup, children: /* @__PURE__ */ d(Bf, { ...t, ref: n }) }) });
  }, "RovingFocusGroup")
), Bf = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ bt(function(t, n) {
  const {
    __scopeRovingFocusGroup: o,
    orientation: r,
    loop: a = !1,
    dir: i,
    currentTabStopId: c,
    defaultCurrentTabStopId: l,
    onCurrentTabStopIdChange: u,
    onEntryFocus: m,
    preventScrollOnEntryFocus: f = !1,
    ...p
  } = t, h = s.useRef(null), g = H(n, h), b = gt(i), [v, x] = Pe({
    prop: c,
    defaultProp: l ?? null,
    onChange: u,
    caller: Wn
  }), [y, w] = s.useState(!1), C = ie(m), R = os(o), P = s.useRef(!1), [E, S] = s.useState(0);
  return s.useEffect(() => {
    const I = h.current;
    if (I)
      return I.addEventListener(mo, C), () => I.removeEventListener(mo, C);
  }, [C]), /* @__PURE__ */ d(
    $f,
    {
      scope: o,
      orientation: r,
      dir: b,
      loop: a,
      currentTabStopId: v,
      onItemFocus: s.useCallback(
        (I) => x(I),
        [x]
      ),
      onItemShiftTab: s.useCallback(() => w(!0), []),
      onFocusableItemAdd: s.useCallback(
        () => S((I) => I + 1),
        []
      ),
      onFocusableItemRemove: s.useCallback(
        () => S((I) => I - 1),
        []
      ),
      children: /* @__PURE__ */ d(
        $.div,
        {
          tabIndex: y || E === 0 ? -1 : 0,
          "data-orientation": r,
          ...p,
          ref: g,
          style: { outline: "none", ...t.style },
          onMouseDown: A(t.onMouseDown, () => {
            P.current = !0;
          }),
          onFocus: A(t.onFocus, (I) => {
            const k = !P.current;
            if (I.target === I.currentTarget && k && !y) {
              const N = new CustomEvent(mo, Df);
              if (I.currentTarget.dispatchEvent(N), !N.defaultPrevented) {
                const M = R().filter((z) => z.focusable), F = M.find((z) => z.active), V = M.find((z) => z.id === v), B = [F, V, ...M].filter(
                  Boolean
                ).map((z) => z.ref.current);
                hr(B, f);
              }
            }
            P.current = !1;
          }),
          onBlur: A(t.onBlur, () => w(!1))
        }
      )
    }
  );
}, "RovingFocusGroupImpl")), Vf = "RovingFocusGroupItem", Wf = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ bt(function(t, n) {
    const {
      __scopeRovingFocusGroup: o,
      focusable: r = !0,
      active: a = !1,
      tabStopId: i,
      children: c,
      ...l
    } = t, u = ve(), m = i || u, f = Ff(Vf, o), p = f.currentTabStopId === m, h = os(o), { onFocusableItemAdd: g, onFocusableItemRemove: b, currentTabStopId: v } = f, x = Mf();
    return re(() => {
      if (!(!x || !r))
        return g(), () => b();
    }, [x, r, g, b]), s.useEffect(() => {
      if (!(x || !r))
        return g(), () => b();
    }, [x, r, g, b]), /* @__PURE__ */ d(
      Oo.ItemSlot,
      {
        scope: o,
        id: m,
        focusable: r,
        active: a,
        children: /* @__PURE__ */ d(
          $.span,
          {
            tabIndex: p ? 0 : -1,
            "data-orientation": f.orientation,
            ...l,
            ref: n,
            onMouseDown: A(t.onMouseDown, (y) => {
              r ? f.onItemFocus(m) : y.preventDefault();
            }),
            onFocus: A(t.onFocus, () => f.onItemFocus(m)),
            onKeyDown: A(t.onKeyDown, (y) => {
              if (y.key === "Tab" && y.shiftKey) {
                f.onItemShiftTab();
                return;
              }
              if (y.target !== y.currentTarget) return;
              const w = as(y, f.orientation, f.dir);
              if (w !== void 0) {
                if (y.metaKey || y.ctrlKey || y.altKey || y.shiftKey) return;
                y.preventDefault();
                let R = h().filter((P) => P.focusable).map((P) => P.ref.current);
                if (w === "last") R.reverse();
                else if (w === "prev" || w === "next") {
                  w === "prev" && R.reverse();
                  const P = R.indexOf(y.currentTarget);
                  R = f.loop ? is(R, P + 1) : R.slice(P + 1);
                }
                setTimeout(() => hr(R));
              }
            }),
            children: typeof c == "function" ? c({ isCurrentTabStop: p, hasTabStop: v != null }) : c
          }
        )
      }
    );
  }, "RovingFocusGroupItem")
), Hf = {
  ArrowLeft: "prev",
  ArrowUp: "prev",
  ArrowRight: "next",
  ArrowDown: "next",
  PageUp: "first",
  Home: "first",
  PageDown: "last",
  End: "last"
};
function rs(e, t) {
  return t !== "rtl" ? e : e === "ArrowLeft" ? "ArrowRight" : e === "ArrowRight" ? "ArrowLeft" : e;
}
bt(rs, "getDirectionAwareKey");
function as(e, t, n) {
  const o = rs(e.key, n);
  if (!(t === "vertical" && ["ArrowLeft", "ArrowRight"].includes(o)) && !(t === "horizontal" && ["ArrowUp", "ArrowDown"].includes(o)))
    return Hf[o];
}
bt(as, "getFocusIntent");
function hr(e, t = !1) {
  const n = document.activeElement;
  for (const o of e)
    if (o === n || (o.focus({ preventScroll: t }), document.activeElement !== n)) return;
}
bt(hr, "focusFirst");
function is(e, t) {
  return e.map((n, o) => e[(t + o) % e.length]);
}
bt(is, "wrapArray");
var ss = zf, cs = Wf, Gf = Object.defineProperty, q = (e, t) => Gf(e, "name", { value: t, configurable: !0 }), Do = ["Enter", " "], Uf = ["ArrowDown", "PageUp", "Home"], ls = ["ArrowUp", "PageDown", "End"], jf = [...Uf, ...ls], Kf = {
  ltr: [...Do, "ArrowRight"],
  rtl: [...Do, "ArrowLeft"]
}, Yf = {
  ltr: ["ArrowLeft"],
  rtl: ["ArrowRight"]
}, Gn = "Menu", [Vt, Xf, qf] = /* @__PURE__ */ jt(Gn), [vt, us] = /* @__PURE__ */ we(Gn, [
  qf,
  Nt,
  Hn
]), Un = Nt(), ds = Hn(), [fs, it] = vt(Gn), [Zf, Zt] = vt(Gn), Qf = /* @__PURE__ */ q((e) => {
  const { __scopeMenu: t, open: n = !1, children: o, dir: r, onOpenChange: a, modal: i = !0 } = e, c = Un(t), [l, u] = s.useState(null), m = s.useRef(!1), f = ie(a), p = gt(r);
  return s.useEffect(() => {
    const h = /* @__PURE__ */ q(() => {
      m.current = !0, document.addEventListener("pointerdown", g, { capture: !0, once: !0 }), document.addEventListener("pointermove", g, { capture: !0, once: !0 });
    }, "handleKeyDown"), g = /* @__PURE__ */ q(() => m.current = !1, "handlePointer");
    return document.addEventListener("keydown", h, { capture: !0 }), () => {
      document.removeEventListener("keydown", h, { capture: !0 }), document.removeEventListener("pointerdown", g, { capture: !0 }), document.removeEventListener("pointermove", g, { capture: !0 });
    };
  }, []), s.useEffect(() => {
    if (!n)
      return;
    const h = /* @__PURE__ */ q(() => f(!1), "handleBlur");
    return window.addEventListener("blur", h), () => window.removeEventListener("blur", h);
  }, [n, f]), /* @__PURE__ */ d(Vn, { ...c, children: /* @__PURE__ */ d(
    fs,
    {
      scope: t,
      open: n,
      onOpenChange: f,
      content: l,
      onContentChange: u,
      children: /* @__PURE__ */ d(
        Zf,
        {
          scope: t,
          onClose: s.useCallback(() => f(!1), [f]),
          isUsingKeyboardRef: m,
          dir: p,
          modal: i,
          children: o
        }
      )
    }
  ) });
}, "Menu"), ps = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ q(function(t, n) {
    const { __scopeMenu: o, ...r } = t, a = Un(o);
    return /* @__PURE__ */ d(fr, { ...a, ...r, ref: n });
  }, "MenuAnchor")
), ms = "MenuPortal", [Jf, hs] = vt(ms, {
  forceMount: void 0
}), ep = /* @__PURE__ */ q((e) => {
  const { __scopeMenu: t, forceMount: n, children: o, container: r } = e, a = it(ms, t);
  return /* @__PURE__ */ d(Jf, { scope: t, forceMount: n, children: /* @__PURE__ */ d(he, { present: n || a.open, children: /* @__PURE__ */ d(An, { asChild: !0, container: r, children: o }) }) });
}, "MenuPortal"), Oe = "MenuContent", [tp, gr] = vt(Oe), np = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ q(function(t, n) {
    const o = hs(Oe, t.__scopeMenu), { forceMount: r = o.forceMount, ...a } = t, i = it(Oe, t.__scopeMenu), c = Zt(Oe, t.__scopeMenu);
    return /* @__PURE__ */ d(Vt.Provider, { scope: t.__scopeMenu, children: /* @__PURE__ */ d(he, { present: r || i.open, children: /* @__PURE__ */ d(Vt.Slot, { scope: t.__scopeMenu, children: c.modal ? /* @__PURE__ */ d(op, { ...a, ref: n }) : /* @__PURE__ */ d(rp, { ...a, ref: n }) }) }) });
  }, "MenuContent")
), op = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ q(function(t, n) {
    const o = it(Oe, t.__scopeMenu), r = s.useRef(null), a = H(n, r);
    return s.useEffect(() => {
      const i = r.current;
      if (i) return tr(i);
    }, []), /* @__PURE__ */ d(
      br,
      {
        ...t,
        ref: a,
        trapFocus: o.open,
        disableOutsidePointerEvents: o.open,
        disableOutsideScroll: !0,
        onFocusOutside: A(
          t.onFocusOutside,
          (i) => i.preventDefault(),
          { checkForDefaultPrevented: !1 }
        ),
        onDismiss: () => o.onOpenChange(!1)
      }
    );
  }, "MenuRootContentModal")
), rp = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ q(function(t, n) {
  const o = it(Oe, t.__scopeMenu);
  return /* @__PURE__ */ d(
    br,
    {
      ...t,
      ref: n,
      trapFocus: !1,
      disableOutsidePointerEvents: !1,
      disableOutsideScroll: !1,
      onDismiss: () => o.onOpenChange(!1)
    }
  );
}, "MenuRootContentNonModal")), ap = /* @__PURE__ */ ze("MenuContent.ScrollLock"), br = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ q(function(t, n) {
    const {
      __scopeMenu: o,
      loop: r = !1,
      trapFocus: a,
      onOpenAutoFocus: i,
      onCloseAutoFocus: c,
      disableOutsidePointerEvents: l,
      onEntryFocus: u,
      onEscapeKeyDown: m,
      onPointerDownOutside: f,
      onFocusOutside: p,
      onInteractOutside: h,
      onDismiss: g,
      disableOutsideScroll: b,
      ...v
    } = t, x = it(Oe, o), y = Zt(Oe, o), w = Un(o), C = ds(o), R = Xf(o), [P, E] = s.useState(null), S = s.useRef(null), I = H(n, S, x.onContentChange), k = s.useRef(0), N = s.useRef(""), M = s.useRef(0), F = s.useRef(null), V = s.useRef("right"), j = s.useRef(0), B = b ? Mn : s.Fragment, z = b ? { as: ap, allowPinchZoom: !0 } : void 0, W = /* @__PURE__ */ q((_) => {
      const ce = N.current + _, ee = R().filter((L) => !L.disabled), ae = document.activeElement, ge = ee.find((L) => L.ref.current === ae)?.textValue, te = ee.map((L) => L.textValue), ne = Rs(te, ce, ge), fe = ee.find((L) => L.textValue === ne)?.ref.current;
      (/* @__PURE__ */ q((function L(G) {
        N.current = G, window.clearTimeout(k.current), G !== "" && (k.current = window.setTimeout(() => L(""), 1e3));
      }), "updateSearch"))(ce), fe && setTimeout(() => fe.focus());
    }, "handleTypeaheadSearch");
    s.useEffect(() => () => window.clearTimeout(k.current), []), Xt();
    const U = s.useCallback((_) => V.current === F.current?.side && Es(_, F.current?.area), []);
    return /* @__PURE__ */ d(
      tp,
      {
        scope: o,
        searchRef: N,
        onItemEnter: s.useCallback(
          (_) => {
            U(_) && _.preventDefault();
          },
          [U]
        ),
        onItemLeave: s.useCallback(
          (_) => {
            U(_) || (S.current?.focus(), E(null));
          },
          [U]
        ),
        onTriggerLeave: s.useCallback(
          (_) => {
            U(_) && _.preventDefault();
          },
          [U]
        ),
        pointerGraceTimerRef: M,
        onPointerGraceIntentChange: s.useCallback((_) => {
          F.current = _;
        }, []),
        children: /* @__PURE__ */ d(B, { ...z, children: /* @__PURE__ */ d(
          Qo,
          {
            asChild: !0,
            trapped: a,
            onMountAutoFocus: A(i, (_) => {
              _.preventDefault(), S.current?.focus({ preventScroll: !0 });
            }),
            onUnmountAutoFocus: c,
            children: /* @__PURE__ */ d(
              In,
              {
                asChild: !0,
                disableOutsidePointerEvents: l,
                onEscapeKeyDown: m,
                onPointerDownOutside: f,
                onFocusOutside: p,
                onInteractOutside: h,
                onDismiss: g,
                children: /* @__PURE__ */ d(
                  ss,
                  {
                    asChild: !0,
                    ...C,
                    dir: y.dir,
                    orientation: "vertical",
                    loop: r,
                    currentTabStopId: P,
                    onCurrentTabStopIdChange: E,
                    onEntryFocus: A(u, (_) => {
                      y.isUsingKeyboardRef.current || _.preventDefault();
                    }),
                    preventScrollOnEntryFocus: !0,
                    children: /* @__PURE__ */ d(
                      pr,
                      {
                        role: "menu",
                        "aria-orientation": "vertical",
                        "data-state": wr(x.open),
                        "data-radix-menu-content": "",
                        dir: y.dir,
                        ...w,
                        ...v,
                        ref: I,
                        style: { outline: "none", ...v.style },
                        onKeyDown: A(v.onKeyDown, (_) => {
                          const ee = _.target.closest("[data-radix-menu-content]") === _.currentTarget, ae = _.ctrlKey || _.altKey || _.metaKey, ge = _.key.length === 1;
                          ee && (_.key === "Tab" && _.preventDefault(), !ae && ge && W(_.key));
                          const te = S.current;
                          if (_.target !== te || !jf.includes(_.key)) return;
                          _.preventDefault();
                          const fe = R().filter((L) => !L.disabled).map((L) => L.ref.current);
                          ls.includes(_.key) && fe.reverse(), Cs(fe);
                        }),
                        onBlur: A(t.onBlur, (_) => {
                          _.currentTarget.contains(_.target) || (window.clearTimeout(k.current), N.current = "");
                        }),
                        onPointerMove: A(
                          t.onPointerMove,
                          At((_) => {
                            const ce = _.target, ee = j.current !== _.clientX;
                            if (_.currentTarget.contains(ce) && ee) {
                              const ae = _.clientX > j.current ? "right" : "left";
                              V.current = ae, j.current = _.clientX;
                            }
                          })
                        )
                      }
                    )
                  }
                )
              }
            )
          }
        ) })
      }
    );
  }, "MenuContentImpl")
), gs = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ q(function(t, n) {
    const { __scopeMenu: o, ...r } = t;
    return /* @__PURE__ */ d($.div, { role: "group", ...r, ref: n });
  }, "MenuGroup")
), ip = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ q(function(t, n) {
    const { __scopeMenu: o, ...r } = t;
    return /* @__PURE__ */ d($.div, { ...r, ref: n });
  }, "MenuLabel")
), No = "MenuItem", ma = "menu.itemSelect", vr = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ q(function(t, n) {
    const { disabled: o = !1, onSelect: r, ...a } = t, i = s.useRef(null), c = Zt(No, t.__scopeMenu), l = gr(No, t.__scopeMenu), u = H(n, i), m = s.useRef(!1), f = /* @__PURE__ */ q(() => {
      const p = i.current;
      if (!o && p) {
        const h = new CustomEvent(ma, { bubbles: !0, cancelable: !0 });
        p.addEventListener(ma, (g) => r?.(g), { once: !0 }), Ho(p, h), h.defaultPrevented ? m.current = !1 : c.onClose();
      }
    }, "handleSelect");
    return /* @__PURE__ */ d(
      bs,
      {
        ...a,
        ref: u,
        disabled: o,
        onClick: A(t.onClick, f),
        onPointerDown: (p) => {
          t.onPointerDown?.(p), m.current = !0;
        },
        onPointerUp: A(t.onPointerUp, (p) => {
          m.current || p.currentTarget?.click();
        }),
        onKeyDown: A(t.onKeyDown, (p) => {
          o || p.target !== p.currentTarget || l.searchRef.current !== "" && p.key === " " || Do.includes(p.key) && (p.currentTarget.click(), p.preventDefault());
        })
      }
    );
  }, "MenuItem")
), bs = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ q(function(t, n) {
    const { __scopeMenu: o, disabled: r = !1, textValue: a, ...i } = t, c = gr(No, o), l = ds(o), u = s.useRef(null), m = H(n, u), [f, p] = s.useState(!1), [h, g] = s.useState("");
    return s.useEffect(() => {
      const b = u.current;
      b && g((b.textContent ?? "").trim());
    }, [i.children]), /* @__PURE__ */ d(
      Vt.ItemSlot,
      {
        scope: o,
        disabled: r,
        textValue: a ?? h,
        children: /* @__PURE__ */ d(cs, { asChild: !0, ...l, focusable: !r, children: /* @__PURE__ */ d(
          $.div,
          {
            role: "menuitem",
            "data-highlighted": f ? "" : void 0,
            "aria-disabled": r || void 0,
            "data-disabled": r ? "" : void 0,
            ...i,
            ref: m,
            onPointerMove: A(
              t.onPointerMove,
              At((b) => {
                r ? c.onItemLeave(b) : (c.onItemEnter(b), b.defaultPrevented || b.currentTarget.focus({ preventScroll: !0 }));
              })
            ),
            onPointerLeave: A(
              t.onPointerLeave,
              At((b) => c.onItemLeave(b))
            ),
            onFocus: A(t.onFocus, () => p(!0)),
            onBlur: A(t.onBlur, () => p(!1))
          }
        ) })
      }
    );
  }, "MenuItemImpl")
), sp = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ q(function(t, n) {
    const { checked: o = !1, onCheckedChange: r, ...a } = t;
    return /* @__PURE__ */ d(ws, { scope: t.__scopeMenu, checked: o, children: /* @__PURE__ */ d(
      vr,
      {
        role: "menuitemcheckbox",
        "aria-checked": Wt(o) ? "mixed" : o,
        ...a,
        ref: n,
        "data-state": jn(o),
        onSelect: A(
          a.onSelect,
          () => r?.(Wt(o) ? !0 : !o),
          { checkForDefaultPrevented: !1 }
        )
      }
    ) });
  }, "MenuCheckboxItem")
), cp = "MenuRadioGroup", [lp, up] = vt(
  cp,
  { value: void 0, onValueChange: /* @__PURE__ */ q(() => {
  }, "onValueChange") }
), dp = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ q(function(t, n) {
    const { value: o, onValueChange: r, ...a } = t, i = ie(r);
    return /* @__PURE__ */ d(lp, { scope: t.__scopeMenu, value: o, onValueChange: i, children: /* @__PURE__ */ d(gs, { ...a, ref: n }) });
  }, "MenuRadioGroup")
), fp = "MenuRadioItem", pp = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ q(function(t, n) {
    const { value: o, ...r } = t, a = up(fp, t.__scopeMenu), i = o === a.value;
    return /* @__PURE__ */ d(ws, { scope: t.__scopeMenu, checked: i, children: /* @__PURE__ */ d(
      vr,
      {
        role: "menuitemradio",
        "aria-checked": i,
        ...r,
        ref: n,
        "data-state": jn(i),
        onSelect: A(
          r.onSelect,
          () => a.onValueChange?.(o),
          { checkForDefaultPrevented: !1 }
        )
      }
    ) });
  }, "MenuRadioItem")
), vs = "MenuItemIndicator", [ws, mp] = vt(
  vs,
  { checked: !1 }
), hp = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ q(function(t, n) {
    const { __scopeMenu: o, forceMount: r, ...a } = t, i = mp(vs, o);
    return /* @__PURE__ */ d(
      he,
      {
        present: r || Wt(i.checked) || i.checked === !0,
        children: /* @__PURE__ */ d(
          $.span,
          {
            ...a,
            ref: n,
            "data-state": jn(i.checked)
          }
        )
      }
    );
  }, "MenuItemIndicator")
), gp = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ q(function(t, n) {
    const { __scopeMenu: o, ...r } = t;
    return /* @__PURE__ */ d(
      $.div,
      {
        role: "separator",
        "aria-orientation": "horizontal",
        ...r,
        ref: n
      }
    );
  }, "MenuSeparator")
), xs = "MenuSub", [bp, ys] = vt(xs), vp = /* @__PURE__ */ q((e) => {
  const { __scopeMenu: t, children: n, open: o = !1, onOpenChange: r } = e, a = it(xs, t), i = Un(t), [c, l] = s.useState(null), [u, m] = s.useState(null), f = ie(r);
  return s.useEffect(() => (a.open === !1 && f(!1), () => f(!1)), [a.open, f]), /* @__PURE__ */ d(Vn, { ...i, children: /* @__PURE__ */ d(
    fs,
    {
      scope: t,
      open: o,
      onOpenChange: f,
      content: u,
      onContentChange: m,
      children: /* @__PURE__ */ d(
        bp,
        {
          scope: t,
          contentId: ve(),
          triggerId: ve(),
          trigger: c,
          onTriggerChange: l,
          children: n
        }
      )
    }
  ) });
}, "MenuSub"), dn = "MenuSubTrigger", wp = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ q(function(t, n) {
    const o = it(dn, t.__scopeMenu), r = Zt(dn, t.__scopeMenu), a = ys(dn, t.__scopeMenu), i = gr(dn, t.__scopeMenu), c = s.useRef(null), { pointerGraceTimerRef: l, onPointerGraceIntentChange: u } = i, m = { __scopeMenu: t.__scopeMenu }, f = s.useCallback(() => {
      c.current && window.clearTimeout(c.current), c.current = null;
    }, []);
    s.useEffect(() => f, [f]), s.useEffect(() => {
      const h = l.current;
      return () => {
        window.clearTimeout(h), u(null);
      };
    }, [l, u]);
    const p = H(n, a.onTriggerChange);
    return /* @__PURE__ */ d(ps, { asChild: !0, ...m, children: /* @__PURE__ */ d(
      bs,
      {
        id: a.triggerId,
        "aria-haspopup": "menu",
        "aria-expanded": o.open,
        "aria-controls": o.open ? a.contentId : void 0,
        "data-state": wr(o.open),
        ...t,
        ref: p,
        onClick: (h) => {
          t.onClick?.(h), !(t.disabled || h.defaultPrevented) && (h.currentTarget.focus(), o.open || o.onOpenChange(!0));
        },
        onPointerMove: A(
          t.onPointerMove,
          At((h) => {
            i.onItemEnter(h), !h.defaultPrevented && !t.disabled && !o.open && !c.current && (i.onPointerGraceIntentChange(null), c.current = window.setTimeout(() => {
              o.onOpenChange(!0), f();
            }, 100));
          })
        ),
        onPointerLeave: A(
          t.onPointerLeave,
          At((h) => {
            f();
            const g = o.content?.getBoundingClientRect();
            if (g) {
              const b = o.content?.dataset.side, v = b === "right", x = v ? -5 : 5, y = g[v ? "left" : "right"], w = g[v ? "right" : "left"];
              i.onPointerGraceIntentChange({
                area: [
                  // Apply a bleed on clientX to ensure that our exit point is
                  // consistently within polygon bounds
                  { x: h.clientX + x, y: h.clientY },
                  { x: y, y: g.top },
                  { x: w, y: g.top },
                  { x: w, y: g.bottom },
                  { x: y, y: g.bottom }
                ],
                side: b
              }), window.clearTimeout(l.current), l.current = window.setTimeout(
                () => i.onPointerGraceIntentChange(null),
                300
              );
            } else {
              if (i.onTriggerLeave(h), h.defaultPrevented) return;
              i.onPointerGraceIntentChange(null);
            }
          })
        ),
        onKeyDown: A(t.onKeyDown, (h) => {
          t.disabled || h.target !== h.currentTarget || i.searchRef.current !== "" && h.key === " " || Kf[r.dir].includes(h.key) && (o.onOpenChange(!0), o.content?.focus(), h.preventDefault());
        })
      }
    ) });
  }, "MenuSubTrigger")
), xp = "MenuSubContent", yp = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ q(function(t, n) {
    const o = hs(Oe, t.__scopeMenu), { forceMount: r = o.forceMount, align: a = "start", ...i } = t, c = it(Oe, t.__scopeMenu), l = Zt(Oe, t.__scopeMenu), u = ys(xp, t.__scopeMenu), m = s.useRef(null), f = H(n, m);
    return /* @__PURE__ */ d(Vt.Provider, { scope: t.__scopeMenu, children: /* @__PURE__ */ d(he, { present: r || c.open, children: /* @__PURE__ */ d(Vt.Slot, { scope: t.__scopeMenu, children: /* @__PURE__ */ d(
      br,
      {
        id: u.contentId,
        "aria-labelledby": u.triggerId,
        ...i,
        ref: f,
        align: a,
        side: l.dir === "rtl" ? "left" : "right",
        disableOutsidePointerEvents: !1,
        disableOutsideScroll: !1,
        trapFocus: !1,
        onOpenAutoFocus: (p) => {
          l.isUsingKeyboardRef.current && m.current?.focus(), p.preventDefault();
        },
        onCloseAutoFocus: (p) => p.preventDefault(),
        onFocusOutside: A(t.onFocusOutside, (p) => {
          p.target !== u.trigger && c.onOpenChange(!1);
        }),
        onEscapeKeyDown: A(t.onEscapeKeyDown, (p) => {
          l.onClose(), p.preventDefault();
        }),
        onKeyDown: A(t.onKeyDown, (p) => {
          const h = p.currentTarget.contains(p.target), g = Yf[l.dir].includes(p.key);
          h && g && (c.onOpenChange(!1), u.trigger?.focus(), p.preventDefault());
        })
      }
    ) }) }) });
  }, "MenuSubContent")
);
function wr(e) {
  return e ? "open" : "closed";
}
q(wr, "getOpenState");
function Wt(e) {
  return e === "indeterminate";
}
q(Wt, "isIndeterminate");
function jn(e) {
  return Wt(e) ? "indeterminate" : e ? "checked" : "unchecked";
}
q(jn, "getCheckedState");
function Cs(e) {
  const t = document.activeElement;
  for (const n of e)
    if (n === t || (n.focus(), document.activeElement !== t)) return;
}
q(Cs, "focusFirst");
function Ss(e, t) {
  return e.map((n, o) => e[(t + o) % e.length]);
}
q(Ss, "wrapArray");
function Rs(e, t, n) {
  const r = t.length > 1 && Array.from(t).every((u) => u === t[0]) ? t[0] : t, a = n ? e.indexOf(n) : -1;
  let i = Ss(e, Math.max(a, 0));
  r.length === 1 && (i = i.filter((u) => u !== n));
  const l = i.find(
    (u) => u.toLowerCase().startsWith(r.toLowerCase())
  );
  return l !== n ? l : void 0;
}
q(Rs, "getNextMatch");
function Ps(e, t) {
  const { x: n, y: o } = e;
  let r = !1;
  for (let a = 0, i = t.length - 1; a < t.length; i = a++) {
    const c = t[a], l = t[i], u = c.x, m = c.y, f = l.x, p = l.y;
    m > o != p > o && n < (f - u) * (o - m) / (p - m) + u && (r = !r);
  }
  return r;
}
q(Ps, "isPointInPolygon");
function Es(e, t) {
  if (!t) return !1;
  const n = { x: e.clientX, y: e.clientY };
  return Ps(n, t);
}
q(Es, "isPointerInGraceArea");
function At(e) {
  return (t) => t.pointerType === "mouse" ? e(t) : void 0;
}
q(At, "whenMouse");
var Cp = Qf, Sp = ps, Rp = ep, Pp = np, Ep = gs, _p = ip, Tp = vr, Ip = sp, Ap = dp, kp = pp, Mp = hp, Op = gp, Dp = vp, Np = wp, Lp = yp, $p = Object.defineProperty, ye = (e, t) => $p(e, "name", { value: t, configurable: !0 }), xr = "DropdownMenu", [Fp, mv] = /* @__PURE__ */ we(
  xr,
  [us]
), Ce = us(), [zp, _s] = Fp(xr), Bp = /* @__PURE__ */ ye((e) => {
  const {
    __scopeDropdownMenu: t,
    children: n,
    dir: o,
    open: r,
    defaultOpen: a,
    onOpenChange: i,
    modal: c = !0
  } = e, l = Ce(t), u = s.useRef(null), [m, f] = Pe({
    prop: r,
    defaultProp: a ?? !1,
    onChange: i,
    caller: xr
  });
  return /* @__PURE__ */ d(
    zp,
    {
      scope: t,
      triggerId: ve(),
      triggerRef: u,
      contentId: ve(),
      open: m,
      onOpenChange: f,
      onOpenToggle: s.useCallback(() => f((p) => !p), [f]),
      modal: c,
      children: /* @__PURE__ */ d(Cp, { ...l, open: m, onOpenChange: f, dir: o, modal: c, children: n })
    }
  );
}, "DropdownMenu"), Vp = "DropdownMenuTrigger", Wp = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ ye(function(t, n) {
    const { __scopeDropdownMenu: o, disabled: r = !1, ...a } = t, i = _s(Vp, o), c = Ce(o), l = H(n, i.triggerRef);
    return /* @__PURE__ */ d(Sp, { asChild: !0, ...c, children: /* @__PURE__ */ d(
      $.button,
      {
        type: "button",
        id: i.triggerId,
        "aria-haspopup": "menu",
        "aria-expanded": i.open,
        "aria-controls": i.open ? i.contentId : void 0,
        "data-state": i.open ? "open" : "closed",
        "data-disabled": r ? "" : void 0,
        disabled: r,
        ...a,
        ref: l,
        onPointerDown: A(t.onPointerDown, (u) => {
          !r && u.button === 0 && u.ctrlKey === !1 && (i.onOpenToggle(), i.open || u.preventDefault());
        }),
        onKeyDown: A(t.onKeyDown, (u) => {
          r || (["Enter", " "].includes(u.key) && i.onOpenToggle(), u.key === "ArrowDown" && i.onOpenChange(!0), ["Enter", " ", "ArrowDown"].includes(u.key) && u.preventDefault());
        })
      }
    ) });
  }, "DropdownMenuTrigger")
), Hp = /* @__PURE__ */ ye((e) => {
  const { __scopeDropdownMenu: t, ...n } = e, o = Ce(t);
  return /* @__PURE__ */ d(Rp, { ...o, ...n });
}, "DropdownMenuPortal"), Gp = "DropdownMenuContent", Up = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ ye(function(t, n) {
    const { __scopeDropdownMenu: o, ...r } = t, a = _s(Gp, o), i = Ce(o), c = s.useRef(!1);
    return /* @__PURE__ */ d(
      Pp,
      {
        id: a.contentId,
        "aria-labelledby": a.triggerId,
        ...i,
        ...r,
        ref: n,
        onCloseAutoFocus: A(t.onCloseAutoFocus, (l) => {
          c.current || a.triggerRef.current?.focus(), c.current = !1, l.preventDefault();
        }),
        onInteractOutside: A(t.onInteractOutside, (l) => {
          const u = l.detail.originalEvent, m = u.button === 0 && u.ctrlKey === !0, f = u.button === 2 || m;
          (!a.modal || f) && (c.current = !0);
        }),
        style: {
          ...t.style,
          "--radix-dropdown-menu-content-transform-origin": "var(--radix-popper-transform-origin)",
          "--radix-dropdown-menu-content-available-width": "var(--radix-popper-available-width)",
          "--radix-dropdown-menu-content-available-height": "var(--radix-popper-available-height)",
          "--radix-dropdown-menu-trigger-width": "var(--radix-popper-anchor-width)",
          "--radix-dropdown-menu-trigger-height": "var(--radix-popper-anchor-height)"
        }
      }
    );
  }, "DropdownMenuContent")
), jp = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ ye(function(t, n) {
    const { __scopeDropdownMenu: o, ...r } = t, a = Ce(o);
    return /* @__PURE__ */ d(Ep, { ...a, ...r, ref: n });
  }, "DropdownMenuGroup")
), Kp = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ ye(function(t, n) {
    const { __scopeDropdownMenu: o, ...r } = t, a = Ce(o);
    return /* @__PURE__ */ d(_p, { ...a, ...r, ref: n });
  }, "DropdownMenuLabel")
), Yp = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ ye(function(t, n) {
    const { __scopeDropdownMenu: o, ...r } = t, a = Ce(o);
    return /* @__PURE__ */ d(Tp, { ...a, ...r, ref: n });
  }, "DropdownMenuItem")
), Xp = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ ye(function(t, n) {
  const { __scopeDropdownMenu: o, ...r } = t, a = Ce(o);
  return /* @__PURE__ */ d(Ip, { ...a, ...r, ref: n });
}, "DropdownMenuCheckboxItem")), qp = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ ye(function(t, n) {
  const { __scopeDropdownMenu: o, ...r } = t, a = Ce(o);
  return /* @__PURE__ */ d(Ap, { ...a, ...r, ref: n });
}, "DropdownMenuRadioGroup")), Zp = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ ye(function(t, n) {
  const { __scopeDropdownMenu: o, ...r } = t, a = Ce(o);
  return /* @__PURE__ */ d(kp, { ...a, ...r, ref: n });
}, "DropdownMenuRadioItem")), Qp = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ ye(function(t, n) {
  const { __scopeDropdownMenu: o, ...r } = t, a = Ce(o);
  return /* @__PURE__ */ d(Mp, { ...a, ...r, ref: n });
}, "DropdownMenuItemIndicator")), Jp = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ ye(function(t, n) {
  const { __scopeDropdownMenu: o, ...r } = t, a = Ce(o);
  return /* @__PURE__ */ d(Op, { ...a, ...r, ref: n });
}, "DropdownMenuSeparator")), em = /* @__PURE__ */ ye((e) => {
  const { __scopeDropdownMenu: t, children: n, open: o, onOpenChange: r, defaultOpen: a } = e, i = Ce(t), [c, l] = Pe({
    prop: o,
    defaultProp: a ?? !1,
    onChange: r,
    caller: "DropdownMenuSub"
  });
  return /* @__PURE__ */ d(Dp, { ...i, open: c, onOpenChange: l, children: n });
}, "DropdownMenuSub"), tm = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ ye(function(t, n) {
  const { __scopeDropdownMenu: o, ...r } = t, a = Ce(o);
  return /* @__PURE__ */ d(Np, { ...a, ...r, ref: n });
}, "DropdownMenuSubTrigger")), nm = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ ye(function(t, n) {
  const { __scopeDropdownMenu: o, ...r } = t, a = Ce(o);
  return /* @__PURE__ */ d(
    Lp,
    {
      ...a,
      ...r,
      ref: n,
      style: {
        ...t.style,
        "--radix-dropdown-menu-content-transform-origin": "var(--radix-popper-transform-origin)",
        "--radix-dropdown-menu-content-available-width": "var(--radix-popper-available-width)",
        "--radix-dropdown-menu-content-available-height": "var(--radix-popper-available-height)",
        "--radix-dropdown-menu-trigger-width": "var(--radix-popper-anchor-width)",
        "--radix-dropdown-menu-trigger-height": "var(--radix-popper-anchor-height)"
      }
    }
  );
}, "DropdownMenuSubContent")), om = Bp, rm = Wp, am = Hp, im = Up, sm = jp, cm = Kp, lm = Yp, um = Xp, dm = qp, fm = Zp, Ts = Qp, pm = Jp, mm = em, hm = tm, gm = nm, bm = Object.defineProperty, vm = (e, t) => bm(e, "name", { value: t, configurable: !0 }), wm = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ vm(function(t, n) {
    return /* @__PURE__ */ d(
      $.label,
      {
        ...t,
        ref: n,
        onMouseDown: (o) => {
          o.target.closest("button, input, select, textarea") || (t.onMouseDown?.(o), !o.defaultPrevented && o.detail > 1 && o.preventDefault());
        }
      }
    );
  }, "Label")
), xm = wm, ym = Object.defineProperty, Cm = (e, t) => ym(e, "name", { value: t, configurable: !0 });
function Is(e) {
  const t = s.useRef({ value: e, previous: e });
  return s.useMemo(() => (t.current.value !== e && (t.current.previous = t.current.value, t.current.value = e), t.current.previous), [e]);
}
Cm(Is, "usePrevious");
var Sm = Object.defineProperty, Rm = (e, t) => Sm(e, "name", { value: t, configurable: !0 });
function Rn(e, [t, n]) {
  return Math.min(n, Math.max(t, e));
}
Rm(Rn, "clamp");
var Pm = Object.defineProperty, Y = (e, t) => Pm(e, "name", { value: t, configurable: !0 });
function As(e, t) {
  return s.useReducer((n, o) => t[n][o] ?? n, e);
}
Y(As, "useStateMachine");
var ks = "ScrollArea", [Ms, hv] = /* @__PURE__ */ we(ks), [Em, ke] = Ms(ks), _m = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ Y(function(t, n) {
    const {
      __scopeScrollArea: o,
      type: r = "hover",
      dir: a,
      scrollHideDelay: i = 600,
      ...c
    } = t, [l, u] = s.useState(null), [m, f] = s.useState(null), [p, h] = s.useState(null), [g, b] = s.useState(null), [v, x] = s.useState(null), [y, w] = s.useState(0), [C, R] = s.useState(0), [P, E] = s.useState(!1), [S, I] = s.useState(!1), k = H(n, u), N = gt(a);
    return /* @__PURE__ */ d(
      Em,
      {
        scope: o,
        type: r,
        dir: N,
        scrollHideDelay: i,
        scrollArea: l,
        viewport: m,
        onViewportChange: f,
        content: p,
        onContentChange: h,
        scrollbarX: g,
        onScrollbarXChange: b,
        scrollbarXEnabled: P,
        onScrollbarXEnabledChange: E,
        scrollbarY: v,
        onScrollbarYChange: x,
        scrollbarYEnabled: S,
        onScrollbarYEnabledChange: I,
        onCornerWidthChange: w,
        onCornerHeightChange: R,
        children: /* @__PURE__ */ d(
          $.div,
          {
            dir: N,
            ...c,
            ref: k,
            style: {
              position: "relative",
              // Pass corner sizes as CSS vars to reduce re-renders of context consumers
              "--radix-scroll-area-corner-width": y + "px",
              "--radix-scroll-area-corner-height": C + "px",
              ...t.style
            }
          }
        )
      }
    );
  }, "ScrollArea")
), Tm = "ScrollAreaViewport", Im = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ Y(function(t, n) {
    const { __scopeScrollArea: o, children: r, nonce: a, ...i } = t, c = ke(Tm, o), l = s.useRef(null), u = H(n, l, c.onViewportChange);
    return /* @__PURE__ */ Z(Xe, { children: [
      /* @__PURE__ */ d(Am, { nonce: a }),
      /* @__PURE__ */ d(
        $.div,
        {
          "data-radix-scroll-area-viewport": "",
          ...i,
          ref: u,
          style: {
            /**
             * We don't support `visible` because the intention is to have at least one scrollbar
             * if this component is used and `visible` will behave like `auto` in that case
             * https://developer.mozilla.org/en-US/docs/Web/CSS/overflow#description
             *
             * We don't handle `auto` because the intention is for the native implementation
             * to be hidden if using this component. We just want to ensure the node is scrollable
             * so could have used either `scroll` or `auto` here. We picked `scroll` to prevent
             * the browser from having to work out whether to render native scrollbars or not,
             * we tell it to with the intention of hiding them in CSS.
             */
            overflowX: c.scrollbarXEnabled ? "scroll" : "hidden",
            overflowY: c.scrollbarYEnabled ? "scroll" : "hidden",
            ...t.style
          },
          children: /* @__PURE__ */ d("div", { ref: c.onContentChange, style: { minWidth: "100%", display: "table" }, children: r })
        }
      )
    ] });
  }, "ScrollAreaViewport")
), Am = /* @__PURE__ */ s.memo(
  /* @__PURE__ */ Y(function({ nonce: t }) {
    return /* @__PURE__ */ d(
      "style",
      {
        dangerouslySetInnerHTML: {
          __html: "[data-radix-scroll-area-viewport]{scrollbar-width:none;-ms-overflow-style:none;-webkit-overflow-scrolling:touch;}[data-radix-scroll-area-viewport]::-webkit-scrollbar{display:none}"
        },
        nonce: t
      }
    );
  }, "ScrollAreaViewportStyle"),
  (e, t) => e.nonce === t.nonce
), et = "ScrollAreaScrollbar", km = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ Y(function(t, n) {
    const { forceMount: o, ...r } = t, a = ke(et, t.__scopeScrollArea), { onScrollbarXEnabledChange: i, onScrollbarYEnabledChange: c } = a, l = t.orientation === "horizontal";
    return s.useEffect(() => (l ? i(!0) : c(!0), () => {
      l ? i(!1) : c(!1);
    }), [l, i, c]), a.type === "hover" ? /* @__PURE__ */ d(Mm, { ...r, ref: n, forceMount: o }) : a.type === "scroll" ? /* @__PURE__ */ d(Om, { ...r, ref: n, forceMount: o }) : a.type === "auto" ? /* @__PURE__ */ d(Os, { ...r, ref: n, forceMount: o }) : a.type === "always" ? /* @__PURE__ */ d(yr, { ...r, ref: n, "data-state": "visible" }) : null;
  }, "ScrollAreaScrollbar")
), Mm = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ Y(function(t, n) {
  const { forceMount: o, ...r } = t, a = ke(et, t.__scopeScrollArea), [i, c] = s.useState(!1);
  return s.useEffect(() => {
    const l = a.scrollArea;
    let u = 0;
    if (l) {
      const m = /* @__PURE__ */ Y(() => {
        window.clearTimeout(u), c(!0);
      }, "handlePointerEnter"), f = /* @__PURE__ */ Y(() => {
        u = window.setTimeout(() => c(!1), a.scrollHideDelay);
      }, "handlePointerLeave");
      return l.addEventListener("pointerenter", m), l.addEventListener("pointerleave", f), () => {
        window.clearTimeout(u), l.removeEventListener("pointerenter", m), l.removeEventListener("pointerleave", f);
      };
    }
  }, [a.scrollArea, a.scrollHideDelay]), /* @__PURE__ */ d(he, { present: o || i, children: /* @__PURE__ */ d(
    Os,
    {
      "data-state": i ? "visible" : "hidden",
      ...r,
      ref: n
    }
  ) });
}, "ScrollAreaScrollbarHover")), Om = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ Y(function(t, n) {
  const { forceMount: o, ...r } = t, a = ke(et, t.__scopeScrollArea), i = t.orientation === "horizontal", c = Jt(() => u("SCROLL_END"), 100), [l, u] = As("hidden", {
    hidden: {
      SCROLL: "scrolling"
    },
    scrolling: {
      SCROLL_END: "idle",
      POINTER_ENTER: "interacting"
    },
    interacting: {
      SCROLL: "interacting",
      POINTER_LEAVE: "idle"
    },
    idle: {
      HIDE: "hidden",
      SCROLL: "scrolling",
      POINTER_ENTER: "interacting"
    }
  });
  return s.useEffect(() => {
    if (l === "idle") {
      const m = window.setTimeout(() => u("HIDE"), a.scrollHideDelay);
      return () => window.clearTimeout(m);
    }
  }, [l, a.scrollHideDelay, u]), s.useEffect(() => {
    const m = a.viewport, f = i ? "scrollLeft" : "scrollTop";
    if (m) {
      let p = m[f];
      const h = /* @__PURE__ */ Y(() => {
        const g = m[f];
        p !== g && (u("SCROLL"), c()), p = g;
      }, "handleScroll");
      return m.addEventListener("scroll", h), () => m.removeEventListener("scroll", h);
    }
  }, [a.viewport, i, u, c]), /* @__PURE__ */ d(he, { present: o || l !== "hidden", children: /* @__PURE__ */ d(
    yr,
    {
      "data-state": l === "hidden" ? "hidden" : "visible",
      ...r,
      ref: n,
      onPointerEnter: A(t.onPointerEnter, () => u("POINTER_ENTER")),
      onPointerLeave: A(t.onPointerLeave, () => u("POINTER_LEAVE"))
    }
  ) });
}, "ScrollAreaScrollbarScroll")), Os = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ Y(function(t, n) {
  const o = ke(et, t.__scopeScrollArea), { forceMount: r, ...a } = t, [i, c] = s.useState(!1), l = t.orientation === "horizontal", u = Jt(() => {
    if (o.viewport) {
      const m = o.viewport.offsetWidth < o.viewport.scrollWidth, f = o.viewport.offsetHeight < o.viewport.scrollHeight;
      c(l ? m : f);
    }
  }, 10);
  return pt(o.viewport, u), pt(o.content, u), /* @__PURE__ */ d(he, { present: r || i, children: /* @__PURE__ */ d(
    yr,
    {
      "data-state": i ? "visible" : "hidden",
      ...a,
      ref: n
    }
  ) });
}, "ScrollAreaScrollbarAuto")), yr = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ Y(function(t, n) {
  const { orientation: o = "vertical", ...r } = t, a = ke(et, t.__scopeScrollArea), i = s.useRef(null), c = s.useRef(0), [l, u] = s.useState({
    content: 0,
    viewport: 0,
    scrollbar: { size: 0, paddingStart: 0, paddingEnd: 0 }
  }), m = Cr(l.viewport, l.content), f = {
    ...r,
    sizes: l,
    onSizesChange: u,
    hasThumb: m > 0 && m < 1,
    onThumbChange: /* @__PURE__ */ Y((h) => i.current = h, "onThumbChange"),
    onThumbPointerUp: /* @__PURE__ */ Y(() => c.current = 0, "onThumbPointerUp"),
    onThumbPointerDown: /* @__PURE__ */ Y((h) => c.current = h, "onThumbPointerDown")
  };
  function p(h, g) {
    return $s(h, c.current, l, g);
  }
  return Y(p, "getScrollPosition"), o === "horizontal" ? /* @__PURE__ */ d(
    Dm,
    {
      ...f,
      ref: n,
      onThumbPositionChange: () => {
        if (a.viewport && i.current) {
          const h = a.viewport.scrollLeft, g = $o(h, l, a.dir);
          i.current.style.transform = `translate3d(${g}px, 0, 0)`;
        }
      },
      onWheelScroll: (h) => {
        a.viewport && (a.viewport.scrollLeft = h);
      },
      onDragScroll: (h) => {
        a.viewport && (a.viewport.scrollLeft = p(h, a.dir));
      }
    }
  ) : o === "vertical" ? /* @__PURE__ */ d(
    Nm,
    {
      ...f,
      ref: n,
      onThumbPositionChange: () => {
        if (a.viewport && i.current) {
          const h = a.viewport.scrollTop, g = $o(h, l);
          i.current.style.transform = `translate3d(0, ${g}px, 0)`;
        }
      },
      onWheelScroll: (h) => {
        a.viewport && (a.viewport.scrollTop = h);
      },
      onDragScroll: (h) => {
        a.viewport && (a.viewport.scrollTop = p(h));
      }
    }
  ) : null;
}, "ScrollAreaScrollbarVisible")), Dm = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ Y(function(t, n) {
  const { sizes: o, onSizesChange: r, ...a } = t, i = ke(et, t.__scopeScrollArea), [c, l] = s.useState(), u = s.useRef(null), m = H(n, u, i.onScrollbarXChange);
  return s.useEffect(() => {
    u.current && l(getComputedStyle(u.current));
  }, [u]), /* @__PURE__ */ d(
    Ns,
    {
      "data-orientation": "horizontal",
      ...a,
      ref: m,
      sizes: o,
      style: {
        bottom: 0,
        left: i.dir === "rtl" ? "var(--radix-scroll-area-corner-width)" : 0,
        right: i.dir === "ltr" ? "var(--radix-scroll-area-corner-width)" : 0,
        "--radix-scroll-area-thumb-width": Qt(o) + "px",
        ...t.style
      },
      onThumbPointerDown: (f) => t.onThumbPointerDown(f.x),
      onDragScroll: (f) => t.onDragScroll(f.x),
      onWheelScroll: (f, p) => {
        if (i.viewport) {
          const h = i.viewport.scrollLeft + f.deltaX;
          t.onWheelScroll(h), Rr(h, p) && f.preventDefault();
        }
      },
      onResize: () => {
        u.current && i.viewport && c && r({
          content: i.viewport.scrollWidth,
          viewport: i.viewport.offsetWidth,
          scrollbar: {
            size: u.current.clientWidth,
            paddingStart: Ht(c.paddingLeft),
            paddingEnd: Ht(c.paddingRight)
          }
        });
      }
    }
  );
}, "ScrollAreaScrollbarX")), Nm = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ Y(function(t, n) {
  const { sizes: o, onSizesChange: r, ...a } = t, i = ke(et, t.__scopeScrollArea), [c, l] = s.useState(), u = s.useRef(null), m = H(n, u, i.onScrollbarYChange);
  return s.useEffect(() => {
    u.current && l(getComputedStyle(u.current));
  }, [u]), /* @__PURE__ */ d(
    Ns,
    {
      "data-orientation": "vertical",
      ...a,
      ref: m,
      sizes: o,
      style: {
        top: 0,
        right: i.dir === "ltr" ? 0 : void 0,
        left: i.dir === "rtl" ? 0 : void 0,
        bottom: "var(--radix-scroll-area-corner-height)",
        "--radix-scroll-area-thumb-height": Qt(o) + "px",
        ...t.style
      },
      onThumbPointerDown: (f) => t.onThumbPointerDown(f.y),
      onDragScroll: (f) => t.onDragScroll(f.y),
      onWheelScroll: (f, p) => {
        if (i.viewport) {
          const h = i.viewport.scrollTop + f.deltaY;
          t.onWheelScroll(h), Rr(h, p) && f.preventDefault();
        }
      },
      onResize: () => {
        u.current && i.viewport && c && r({
          content: i.viewport.scrollHeight,
          viewport: i.viewport.offsetHeight,
          scrollbar: {
            size: u.current.clientHeight,
            paddingStart: Ht(c.paddingTop),
            paddingEnd: Ht(c.paddingBottom)
          }
        });
      }
    }
  );
}, "ScrollAreaScrollbarY")), [Lm, Ds] = Ms(et), Ns = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ Y(function(t, n) {
  const {
    __scopeScrollArea: o,
    sizes: r,
    hasThumb: a,
    onThumbChange: i,
    onThumbPointerUp: c,
    onThumbPointerDown: l,
    onThumbPositionChange: u,
    onDragScroll: m,
    onWheelScroll: f,
    onResize: p,
    ...h
  } = t, g = ke(et, o), [b, v] = s.useState(null), x = H(n, v), y = s.useRef(null), w = s.useRef(""), C = g.viewport, R = r.content - r.viewport, P = ie(f), E = ie(u), S = Jt(p, 10);
  function I(k) {
    if (y.current) {
      const N = k.clientX - y.current.left, M = k.clientY - y.current.top;
      m({ x: N, y: M });
    }
  }
  return Y(I, "handleDragScroll"), s.useEffect(() => {
    const k = /* @__PURE__ */ Y((N) => {
      const M = N.target;
      b?.contains(M) && P(N, R);
    }, "handleWheel");
    return document.addEventListener("wheel", k, { passive: !1 }), () => document.removeEventListener("wheel", k, { passive: !1 });
  }, [C, b, R, P]), s.useEffect(E, [r, E]), pt(b, S), pt(g.content, S), /* @__PURE__ */ d(
    Lm,
    {
      scope: o,
      scrollbar: b,
      hasThumb: a,
      onThumbChange: ie(i),
      onThumbPointerUp: ie(c),
      onThumbPositionChange: E,
      onThumbPointerDown: ie(l),
      children: /* @__PURE__ */ d(
        $.div,
        {
          ...h,
          ref: x,
          style: { position: "absolute", ...h.style },
          onPointerDown: A(t.onPointerDown, (k) => {
            k.button === 0 && (k.target.setPointerCapture(k.pointerId), y.current = b.getBoundingClientRect(), w.current = document.body.style.webkitUserSelect, document.body.style.webkitUserSelect = "none", g.viewport && (g.viewport.style.scrollBehavior = "auto"), I(k));
          }),
          onPointerMove: A(t.onPointerMove, I),
          onPointerUp: A(t.onPointerUp, (k) => {
            const N = k.target;
            N.hasPointerCapture(k.pointerId) && N.releasePointerCapture(k.pointerId), document.body.style.webkitUserSelect = w.current, g.viewport && (g.viewport.style.scrollBehavior = ""), y.current = null;
          })
        }
      )
    }
  );
}, "ScrollAreaScrollbarImpl")), Lo = "ScrollAreaThumb", $m = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ Y(function(t, n) {
    const { forceMount: o, ...r } = t, a = Ds(Lo, t.__scopeScrollArea);
    return /* @__PURE__ */ d(he, { present: o || a.hasThumb, children: /* @__PURE__ */ d(Fm, { ref: n, ...r }) });
  }, "ScrollAreaThumb")
), Fm = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ Y(function(t, n) {
    const { __scopeScrollArea: o, style: r, ...a } = t, i = ke(Lo, o), c = Ds(Lo, o), { onThumbPositionChange: l } = c, u = H(n, c.onThumbChange), m = s.useRef(void 0), f = Jt(() => {
      m.current && (m.current(), m.current = void 0);
    }, 100);
    return s.useEffect(() => {
      const p = i.viewport;
      if (p) {
        const h = /* @__PURE__ */ Y(() => {
          if (f(), !m.current) {
            const g = Vm(p, l);
            m.current = g, l();
          }
        }, "handleScroll");
        return l(), p.addEventListener("scroll", h), () => p.removeEventListener("scroll", h);
      }
    }, [i.viewport, f, l]), /* @__PURE__ */ d(
      $.div,
      {
        "data-state": c.hasThumb ? "visible" : "hidden",
        ...a,
        ref: u,
        style: {
          width: "var(--radix-scroll-area-thumb-width)",
          height: "var(--radix-scroll-area-thumb-height)",
          ...r
        },
        onPointerDownCapture: A(t.onPointerDownCapture, (p) => {
          const g = p.target.getBoundingClientRect(), b = p.clientX - g.left, v = p.clientY - g.top;
          c.onThumbPointerDown({ x: b, y: v });
        }),
        onPointerUp: A(t.onPointerUp, c.onThumbPointerUp)
      }
    );
  }, "ScrollAreaThumbImpl")
), Ls = "ScrollAreaCorner", zm = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ Y(function(t, n) {
    const o = ke(Ls, t.__scopeScrollArea), r = !!(o.scrollbarX && o.scrollbarY);
    return o.type !== "scroll" && r ? /* @__PURE__ */ d(Bm, { ...t, ref: n }) : null;
  }, "ScrollAreaCorner")
), Bm = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ Y(function(t, n) {
  const { __scopeScrollArea: o, ...r } = t, a = ke(Ls, o), [i, c] = s.useState(0), [l, u] = s.useState(0), m = !!(i && l), { onCornerWidthChange: f, onCornerHeightChange: p } = a;
  return pt(a.scrollbarX, () => {
    const h = a.scrollbarX?.offsetHeight || 0;
    a.onCornerHeightChange(h), u(h);
  }), pt(a.scrollbarY, () => {
    const h = a.scrollbarY?.offsetWidth || 0;
    a.onCornerWidthChange(h), c(h);
  }), s.useEffect(() => () => {
    f(0), p(0);
  }, [f, p]), m ? /* @__PURE__ */ d(
    $.div,
    {
      ...r,
      ref: n,
      style: {
        width: i,
        height: l,
        position: "absolute",
        right: a.dir === "ltr" ? 0 : void 0,
        left: a.dir === "rtl" ? 0 : void 0,
        bottom: 0,
        ...t.style
      }
    }
  ) : null;
}, "ScrollAreaCornerImpl"));
function Ht(e) {
  return e ? parseInt(e, 10) : 0;
}
Y(Ht, "toInt");
function Cr(e, t) {
  const n = e / t;
  return isNaN(n) ? 0 : n;
}
Y(Cr, "getThumbRatio");
function Qt(e) {
  const t = Cr(e.viewport, e.content), n = e.scrollbar.paddingStart + e.scrollbar.paddingEnd, o = (e.scrollbar.size - n) * t;
  return Math.max(o, 18);
}
Y(Qt, "getThumbSize");
function $s(e, t, n, o = "ltr") {
  const r = Qt(n), a = r / 2, i = t || a, c = r - i, l = n.scrollbar.paddingStart + i, u = n.scrollbar.size - n.scrollbar.paddingEnd - c, m = n.content - n.viewport, f = o === "ltr" ? [0, m] : [m * -1, 0];
  return Sr([l, u], f)(e);
}
Y($s, "getScrollPositionFromPointer");
function $o(e, t, n = "ltr") {
  const o = Qt(t), r = t.scrollbar.paddingStart + t.scrollbar.paddingEnd, a = t.scrollbar.size - r, i = t.content - t.viewport, c = a - o, l = n === "ltr" ? [0, i] : [i * -1, 0], u = Rn(e, l);
  return Sr([0, i], [0, c])(u);
}
Y($o, "getThumbOffsetFromScroll");
function Sr(e, t) {
  return (n) => {
    if (e[0] === e[1] || t[0] === t[1]) return t[0];
    const o = (t[1] - t[0]) / (e[1] - e[0]);
    return t[0] + o * (n - e[0]);
  };
}
Y(Sr, "linearScale");
function Rr(e, t) {
  return e > 0 && e < t;
}
Y(Rr, "isScrollingWithinScrollbarBounds");
var Vm = /* @__PURE__ */ Y((e, t = () => {
}) => {
  let n = { left: e.scrollLeft, top: e.scrollTop }, o = 0;
  return (/* @__PURE__ */ Y((function r() {
    const a = { left: e.scrollLeft, top: e.scrollTop }, i = n.left !== a.left, c = n.top !== a.top;
    (i || c) && t(), n = a, o = window.requestAnimationFrame(r);
  }), "loop"))(), () => window.cancelAnimationFrame(o);
}, "addUnlinkedScrollListener");
function Jt(e, t) {
  const n = ie(e), o = s.useRef(0);
  return s.useEffect(() => () => window.clearTimeout(o.current), []), s.useCallback(() => {
    window.clearTimeout(o.current), o.current = window.setTimeout(n, t);
  }, [n, t]);
}
Y(Jt, "useDebounceCallback");
function pt(e, t) {
  const n = ie(t);
  re(() => {
    let o = 0;
    if (e) {
      const r = new ResizeObserver(() => {
        cancelAnimationFrame(o), o = window.requestAnimationFrame(n);
      });
      return r.observe(e), () => {
        window.cancelAnimationFrame(o), r.unobserve(e);
      };
    }
  }, [e, n]);
}
Y(pt, "useResizeObserver");
var Wm = _m, Hm = Im, Gm = zm, Um = Object.defineProperty, X = (e, t) => Um(e, "name", { value: t, configurable: !0 }), jm = [" ", "Enter", "ArrowUp", "ArrowDown"], Km = [" ", "Enter"], kt = "Select", [Kn, Yn, Ym] = /* @__PURE__ */ jt(kt), [wt, gv] = /* @__PURE__ */ we(kt, [
  Ym,
  Nt
]), Pr = Nt(), [Xm, st] = wt(kt), [qm, Zm] = wt(kt);
function Fs(e) {
  const {
    __scopeSelect: t,
    children: n,
    open: o,
    defaultOpen: r,
    onOpenChange: a,
    value: i,
    defaultValue: c,
    onValueChange: l,
    dir: u,
    name: m,
    autoComplete: f,
    disabled: p,
    required: h,
    form: g,
    // @ts-expect-error internal render prop used by `Select` to compose its default parts
    internal_do_not_use_render: b
  } = e, v = Pr(t), [x, y] = s.useState(null), [w, C] = s.useState(null), [R, P] = s.useState(!1), E = gt(u), [S, I] = Pe({
    prop: o,
    defaultProp: r ?? !1,
    onChange: a,
    caller: kt
  }), [k, N] = Pe({
    prop: i,
    defaultProp: c,
    onChange: l,
    caller: kt
  }), M = s.useRef(null), F = s.useRef(k);
  s.useEffect(() => {
    const ee = g ? x?.ownerDocument.getElementById(g) : x?.form;
    if (ee instanceof HTMLFormElement) {
      const ae = /* @__PURE__ */ X(() => N(F.current), "reset");
      return ee.addEventListener("reset", ae), () => ee.removeEventListener("reset", ae);
    }
  }, [g, x, N]);
  const V = x ? !!g || !!x.closest("form") : !0, [j, B] = s.useState(/* @__PURE__ */ new Set()), z = ve(), W = Array.from(j).map((ee) => ee.props.value).join(";"), U = s.useCallback((ee) => {
    B((ae) => new Set(ae).add(ee));
  }, []), _ = s.useCallback((ee) => {
    B((ae) => {
      const ge = new Set(ae);
      return ge.delete(ee), ge;
    });
  }, []), ce = {
    required: h,
    trigger: x,
    onTriggerChange: y,
    valueNode: w,
    onValueNodeChange: C,
    valueNodeHasChildren: R,
    onValueNodeHasChildrenChange: P,
    contentId: z,
    value: k,
    onValueChange: N,
    open: S,
    onOpenChange: I,
    dir: E,
    triggerPointerDownPosRef: M,
    disabled: p,
    name: m,
    autoComplete: f,
    form: g,
    nativeOptions: j,
    nativeSelectKey: W,
    isFormControl: V
  };
  return /* @__PURE__ */ d(Vn, { ...v, children: /* @__PURE__ */ d(Xm, { scope: t, ...ce, children: /* @__PURE__ */ d(Kn.Provider, { scope: t, children: /* @__PURE__ */ d(
    qm,
    {
      scope: t,
      onNativeOptionAdd: U,
      onNativeOptionRemove: _,
      children: Ws(b) ? b(ce) : n
    }
  ) }) }) });
}
X(Fs, "SelectProvider");
var Qm = /* @__PURE__ */ X((e) => {
  const { __scopeSelect: t, children: n, ...o } = e;
  return /* @__PURE__ */ d(
    Fs,
    {
      __scopeSelect: t,
      ...o,
      internal_do_not_use_render: ({ isFormControl: r }) => /* @__PURE__ */ Z(Xe, { children: [
        n,
        r ? /* @__PURE__ */ d(
          Ah,
          {
            __scopeSelect: t
          }
        ) : null
      ] })
    }
  );
}, "Select"), Jm = "SelectTrigger", eh = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ X(function(t, n) {
    const { __scopeSelect: o, disabled: r = !1, ...a } = t, i = Pr(o), c = st(Jm, o), l = c.disabled || r, u = H(n, c.onTriggerChange), m = Yn(o), f = s.useRef("touch"), [p, h, g] = _r((v) => {
      const x = m().filter((C) => !C.disabled), y = x.find((C) => C.value === c.value), w = Tr(x, v, y);
      w !== void 0 && c.onValueChange(w.value);
    }), b = /* @__PURE__ */ X((v) => {
      l || (c.onOpenChange(!0), g()), v && (c.triggerPointerDownPosRef.current = {
        x: Math.round(v.pageX),
        y: Math.round(v.pageY)
      });
    }, "handleOpen");
    return /* @__PURE__ */ d(fr, { asChild: !0, ...i, children: /* @__PURE__ */ d(
      $.button,
      {
        type: "button",
        role: "combobox",
        "aria-controls": c.open ? c.contentId : void 0,
        "aria-expanded": c.open,
        "aria-required": c.required,
        "aria-autocomplete": "none",
        dir: c.dir,
        "data-state": c.open ? "open" : "closed",
        disabled: l,
        "data-disabled": l ? "" : void 0,
        "data-placeholder": en(c.value) ? "" : void 0,
        ...a,
        ref: u,
        onClick: A(a.onClick, (v) => {
          v.currentTarget.focus(), f.current !== "mouse" && b(v);
        }),
        onPointerDown: A(a.onPointerDown, (v) => {
          f.current = v.pointerType;
          const x = v.target;
          x.hasPointerCapture(v.pointerId) && x.releasePointerCapture(v.pointerId), v.button === 0 && v.ctrlKey === !1 && v.pointerType === "mouse" && (b(v), v.preventDefault());
        }),
        onKeyDown: A(a.onKeyDown, (v) => {
          const x = p.current !== "";
          !(v.ctrlKey || v.altKey || v.metaKey) && v.key.length === 1 && h(v.key), !(x && v.key === " ") && jm.includes(v.key) && (b(), v.preventDefault());
        })
      }
    ) });
  }, "SelectTrigger")
), th = "SelectValue", nh = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ X(function(t, n) {
    const { __scopeSelect: o, className: r, style: a, children: i, placeholder: c = "", ...l } = t, u = st(th, o), { onValueNodeHasChildrenChange: m } = u, f = i !== void 0, p = H(n, u.onValueNodeChange);
    re(() => {
      m(f);
    }, [m, f]);
    const h = en(u.value);
    return /* @__PURE__ */ d(
      $.span,
      {
        ...l,
        asChild: h ? !1 : l.asChild,
        ref: p,
        style: { pointerEvents: "none" },
        children: /* @__PURE__ */ d(s.Fragment, { children: h ? c : i }, h ? "placeholder" : "value")
      }
    );
  }, "SelectValue")
), oh = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ X(function(t, n) {
    const { __scopeSelect: o, children: r, ...a } = t;
    return /* @__PURE__ */ d($.span, { "aria-hidden": !0, ...a, ref: n, children: r || "▼" });
  }, "SelectIcon")
), rh = "SelectPortal", [ah, ih] = wt(rh, {
  forceMount: void 0
}), sh = /* @__PURE__ */ X((e) => {
  const { __scopeSelect: t, forceMount: n, ...o } = e;
  return /* @__PURE__ */ d(ah, { scope: e.__scopeSelect, forceMount: n, children: /* @__PURE__ */ d(An, { asChild: !0, ...o }) });
}, "SelectPortal"), mt = "SelectContent", ch = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ X(function(t, n) {
    const o = ih(mt, t.__scopeSelect), { forceMount: r = o.forceMount, ...a } = t, i = st(mt, t.__scopeSelect), [c, l] = s.useState();
    return re(() => {
      l(new DocumentFragment());
    }, []), /* @__PURE__ */ d(he, { present: r || i.open, children: ({ present: u }) => u ? /* @__PURE__ */ d(dh, { ...a, ref: n }) : /* @__PURE__ */ d(lh, { ...a, fragment: c }) });
  }, "SelectContent")
), lh = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ X(function(t, n) {
  const { __scopeSelect: o, children: r, fragment: a } = t;
  return a ? Ut.createPortal(
    /* @__PURE__ */ d(zs, { scope: o, children: /* @__PURE__ */ d(Kn.Slot, { scope: o, children: /* @__PURE__ */ d("div", { ref: n, children: r }) }) }),
    a
  ) : null;
}, "SelectContentFragment")), Me = 10, [zs, xt] = wt(mt), uh = /* @__PURE__ */ ze("SelectContent.RemoveScroll"), dh = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ X(function(t, n) {
    const { __scopeSelect: o } = t, {
      position: r = "item-aligned",
      onCloseAutoFocus: a,
      onEscapeKeyDown: i,
      onPointerDownOutside: c,
      //
      // PopperContent props
      side: l,
      sideOffset: u,
      align: m,
      alignOffset: f,
      arrowPadding: p,
      collisionBoundary: h,
      collisionPadding: g,
      sticky: b,
      hideWhenDetached: v,
      avoidCollisions: x,
      //
      ...y
    } = t, w = st(mt, o), [C, R] = s.useState(null), [P, E] = s.useState(null), S = H(n, R), [I, k] = s.useState(null), [N, M] = s.useState(
      null
    ), F = Yn(o), [V, j] = s.useState(!1), B = s.useRef(!1);
    s.useEffect(() => {
      if (C) return tr(C);
    }, [C]), Xt();
    const z = s.useCallback(
      (L) => {
        const [G, ...le] = F().map((oe) => oe.ref.current), [Q] = le.slice(-1), J = document.activeElement;
        for (const oe of L)
          if (oe === J || (oe?.scrollIntoView({ block: "nearest" }), oe === G && P && (P.scrollTop = 0), oe === Q && P && (P.scrollTop = P.scrollHeight), oe?.focus(), document.activeElement !== J)) return;
      },
      [F, P]
    ), W = s.useCallback(
      () => z([I, C]),
      [z, I, C]
    );
    s.useEffect(() => {
      V && W();
    }, [V, W]);
    const { onOpenChange: U, triggerPointerDownPosRef: _ } = w;
    s.useEffect(() => {
      if (C) {
        let L = { x: 0, y: 0 };
        const G = /* @__PURE__ */ X((Q) => {
          L = {
            x: Math.abs(Math.round(Q.pageX) - (_.current?.x ?? 0)),
            y: Math.abs(Math.round(Q.pageY) - (_.current?.y ?? 0))
          };
        }, "handlePointerMove"), le = /* @__PURE__ */ X((Q) => {
          L.x <= 10 && L.y <= 10 ? Q.preventDefault() : Q.composedPath().includes(C) || U(!1), document.removeEventListener("pointermove", G), _.current = null;
        }, "handlePointerUp");
        return _.current !== null && (document.addEventListener("pointermove", G), document.addEventListener("pointerup", le, { capture: !0, once: !0 })), () => {
          document.removeEventListener("pointermove", G), document.removeEventListener("pointerup", le, { capture: !0 });
        };
      }
    }, [C, U, _]), s.useEffect(() => {
      const L = /* @__PURE__ */ X(() => U(!1), "close");
      return window.addEventListener("blur", L), window.addEventListener("resize", L), () => {
        window.removeEventListener("blur", L), window.removeEventListener("resize", L);
      };
    }, [U]);
    const [ce, ee] = _r((L) => {
      const G = F().filter((J) => !J.disabled), le = G.find((J) => J.ref.current === document.activeElement), Q = Tr(G, L, le);
      Q && setTimeout(() => Q.ref.current?.focus());
    }), ae = s.useCallback(
      (L, G, le) => {
        const Q = !B.current && !le;
        (w.value !== void 0 && w.value === G || Q) && (k(L), Q && (B.current = !0));
      },
      [w.value]
    ), ge = s.useCallback(() => C?.focus(), [C]), te = s.useCallback(
      (L, G, le) => {
        const Q = !B.current && !le;
        (w.value !== void 0 && w.value === G || Q) && M(L);
      },
      [w.value]
    ), ne = r === "popper" ? ha : fh, fe = ne === ha ? {
      side: l,
      sideOffset: u,
      align: m,
      alignOffset: f,
      arrowPadding: p,
      collisionBoundary: h,
      collisionPadding: g,
      sticky: b,
      hideWhenDetached: v,
      avoidCollisions: x
    } : {};
    return /* @__PURE__ */ d(
      zs,
      {
        scope: o,
        content: C,
        viewport: P,
        onViewportChange: E,
        itemRefCallback: ae,
        selectedItem: I,
        onItemLeave: ge,
        itemTextRefCallback: te,
        focusSelectedItem: W,
        selectedItemText: N,
        position: r,
        isPositioned: V,
        searchRef: ce,
        children: /* @__PURE__ */ d(Mn, { as: uh, allowPinchZoom: !0, children: /* @__PURE__ */ d(
          Qo,
          {
            asChild: !0,
            trapped: w.open,
            onMountAutoFocus: (L) => {
              L.preventDefault();
            },
            onUnmountAutoFocus: A(a, (L) => {
              w.trigger?.focus({ preventScroll: !0 }), L.preventDefault();
            }),
            children: /* @__PURE__ */ d(
              In,
              {
                asChild: !0,
                disableOutsidePointerEvents: !0,
                onEscapeKeyDown: i,
                onPointerDownOutside: c,
                onFocusOutside: (L) => L.preventDefault(),
                onDismiss: () => w.onOpenChange(!1),
                children: /* @__PURE__ */ d(
                  ne,
                  {
                    role: "listbox",
                    id: w.contentId,
                    "data-state": w.open ? "open" : "closed",
                    dir: w.dir,
                    onContextMenu: (L) => L.preventDefault(),
                    ...y,
                    ...fe,
                    onPlaced: () => j(!0),
                    ref: S,
                    style: {
                      // flex layout so we can place the scroll buttons properly
                      display: "flex",
                      flexDirection: "column",
                      // reset the outline by default as the content MAY get focused
                      outline: "none",
                      ...y.style
                    },
                    onKeyDown: A(y.onKeyDown, (L) => {
                      const G = L.ctrlKey || L.altKey || L.metaKey;
                      if (L.key === "Tab" && L.preventDefault(), !G && L.key.length === 1 && ee(L.key), ["ArrowUp", "ArrowDown", "Home", "End"].includes(L.key)) {
                        let Q = F().filter((J) => !J.disabled).map((J) => J.ref.current);
                        if (["ArrowUp", "End"].includes(L.key) && (Q = Q.slice().reverse()), ["ArrowUp", "ArrowDown"].includes(L.key)) {
                          const J = L.target, oe = Q.indexOf(J);
                          Q = Q.slice(oe + 1);
                        }
                        setTimeout(() => z(Q)), L.preventDefault();
                      }
                    })
                  }
                )
              }
            )
          }
        ) })
      }
    );
  }, "SelectContentImpl")
), fh = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ X(function(t, n) {
  const { __scopeSelect: o, onPlaced: r, ...a } = t, i = st(mt, o), c = xt(mt, o), [l, u] = s.useState(null), [m, f] = s.useState(null), p = H(n, f), h = Yn(o), g = s.useRef(!1), b = s.useRef(!0), { viewport: v, selectedItem: x, selectedItemText: y, focusSelectedItem: w } = c, C = s.useCallback(() => {
    if (i.trigger && i.valueNode && l && m && v && x && y) {
      const S = i.trigger.getBoundingClientRect(), I = m.getBoundingClientRect(), k = i.valueNode.getBoundingClientRect(), N = y.getBoundingClientRect();
      if (i.dir !== "rtl") {
        const J = N.left - I.left, oe = k.left - J, Se = S.left - oe, Ie = S.width + Se, Qn = Math.max(Ie, I.width), Jn = window.innerWidth - Me, eo = Rn(oe, [
          Me,
          // Prevents the content from going off the starting edge of the
          // viewport. It may still go off the ending edge, but this can be
          // controlled by the user since they may want to manage overflow in a
          // specific way.
          // https://github.com/radix-ui/primitives/issues/2049
          Math.max(Me, Jn - Qn)
        ]);
        l.style.minWidth = Ie + "px", l.style.left = eo + "px";
      } else {
        const J = I.right - N.right, oe = window.innerWidth - k.right - J, Se = window.innerWidth - S.right - oe, Ie = S.width + Se, Qn = Math.max(Ie, I.width), Jn = window.innerWidth - Me, eo = Rn(oe, [
          Me,
          Math.max(Me, Jn - Qn)
        ]);
        l.style.minWidth = Ie + "px", l.style.right = eo + "px";
      }
      const M = h(), F = window.innerHeight - Me * 2, V = v.scrollHeight, j = window.getComputedStyle(m), B = parseInt(j.borderTopWidth, 10), z = parseInt(j.paddingTop, 10), W = parseInt(j.borderBottomWidth, 10), U = parseInt(j.paddingBottom, 10), _ = B + z + V + U + W, ce = Math.min(x.offsetHeight * 5, _), ee = window.getComputedStyle(v), ae = parseInt(ee.paddingTop, 10), ge = parseInt(ee.paddingBottom, 10), te = S.top + S.height / 2 - Me, ne = F - te, fe = x.offsetHeight / 2, L = x.offsetTop + fe, G = B + z + L, le = _ - G;
      if (G <= te) {
        const J = M.length > 0 && x === M[M.length - 1].ref.current;
        l.style.bottom = "0px";
        const oe = m.clientHeight - v.offsetTop - v.offsetHeight, Se = Math.max(
          ne,
          fe + // viewport might have padding bottom, include it to avoid a scrollable viewport
          (J ? ge : 0) + oe + W
        ), Ie = G + Se;
        l.style.height = Ie + "px";
      } else {
        const J = M.length > 0 && x === M[0].ref.current;
        l.style.top = "0px";
        const Se = Math.max(
          te,
          B + v.offsetTop + // viewport might have padding top, include it to avoid a scrollable viewport
          (J ? ae : 0) + fe
        ) + le;
        l.style.height = Se + "px", v.scrollTop = G - te + v.offsetTop;
      }
      l.style.margin = `${Me}px 0`, l.style.minHeight = ce + "px", l.style.maxHeight = F + "px", r?.(), requestAnimationFrame(() => g.current = !0);
    }
  }, [
    h,
    i.trigger,
    i.valueNode,
    l,
    m,
    v,
    x,
    y,
    i.dir,
    r
  ]);
  re(() => C(), [C]);
  const [R, P] = s.useState();
  re(() => {
    m && P(window.getComputedStyle(m).zIndex);
  }, [m]);
  const E = s.useCallback(
    (S) => {
      S && b.current === !0 && (C(), w?.(), b.current = !1);
    },
    [C, w]
  );
  return /* @__PURE__ */ d(
    ph,
    {
      scope: o,
      contentWrapper: l,
      shouldExpandOnScrollRef: g,
      onScrollButtonChange: E,
      children: /* @__PURE__ */ d(
        "div",
        {
          ref: u,
          style: {
            display: "flex",
            flexDirection: "column",
            position: "fixed",
            zIndex: R
          },
          children: /* @__PURE__ */ d(
            $.div,
            {
              ...a,
              ref: p,
              style: {
                // When we get the height of the content, it includes borders. If we were to set
                // the height without having `boxSizing: 'border-box'` it would be too big.
                boxSizing: "border-box",
                // We need to ensure the content doesn't get taller than the wrapper
                maxHeight: "100%",
                ...a.style
              }
            }
          )
        }
      )
    }
  );
}, "SelectItemAlignedPosition")), ha = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ X(function(t, n) {
  const {
    __scopeSelect: o,
    align: r = "start",
    collisionPadding: a = Me,
    ...i
  } = t, c = Pr(o);
  return /* @__PURE__ */ d(
    pr,
    {
      ...c,
      ...i,
      ref: n,
      align: r,
      collisionPadding: a,
      style: {
        // Ensure border-box for floating-ui calculations
        boxSizing: "border-box",
        ...i.style,
        "--radix-select-content-transform-origin": "var(--radix-popper-transform-origin)",
        "--radix-select-content-available-width": "var(--radix-popper-available-width)",
        "--radix-select-content-available-height": "var(--radix-popper-available-height)",
        "--radix-select-trigger-width": "var(--radix-popper-anchor-width)",
        "--radix-select-trigger-height": "var(--radix-popper-anchor-height)"
      }
    }
  );
}, "SelectPopperPosition")), [ph, Er] = wt(mt, {}), ga = "SelectViewport", mh = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ X(function(t, n) {
    const { __scopeSelect: o, nonce: r, ...a } = t, i = xt(ga, o), c = Er(ga, o), l = H(n, i.onViewportChange), u = s.useRef(0);
    return /* @__PURE__ */ Z(Xe, { children: [
      /* @__PURE__ */ d(
        "style",
        {
          dangerouslySetInnerHTML: {
            __html: "[data-radix-select-viewport]{scrollbar-width:none;-ms-overflow-style:none;-webkit-overflow-scrolling:touch;}[data-radix-select-viewport]::-webkit-scrollbar{display:none}"
          },
          nonce: r
        }
      ),
      /* @__PURE__ */ d(Kn.Slot, { scope: o, children: /* @__PURE__ */ d(
        $.div,
        {
          "data-radix-select-viewport": "",
          role: "presentation",
          ...a,
          ref: l,
          style: {
            // we use position: 'relative' here on the `viewport` so that when we call
            // `selectedItem.offsetTop` in calculations, the offset is relative to the viewport
            // (independent of the scrollUpButton).
            position: "relative",
            flex: 1,
            // Viewport should only be scrollable in the vertical direction.
            // This won't work in vertical writing modes, so we'll need to
            // revisit this if/when that is supported
            // https://developer.chrome.com/blog/vertical-form-controls
            overflow: "hidden auto",
            ...a.style
          },
          onScroll: A(a.onScroll, (m) => {
            const f = m.currentTarget, { contentWrapper: p, shouldExpandOnScrollRef: h } = c;
            if (h?.current && p) {
              const g = Math.abs(u.current - f.scrollTop);
              if (g > 0) {
                const b = window.innerHeight - Me * 2, v = parseFloat(p.style.minHeight), x = parseFloat(p.style.height), y = Math.max(v, x);
                if (y < b) {
                  const w = y + g, C = Math.min(b, w), R = w - C;
                  p.style.height = C + "px", p.style.bottom === "0px" && (f.scrollTop = R > 0 ? R : 0, p.style.justifyContent = "flex-end");
                }
              }
            }
            u.current = f.scrollTop;
          })
        }
      ) })
    ] });
  }, "SelectViewport")
), hh = "SelectGroup", [gh, bh] = wt(hh), vh = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ X(function(t, n) {
    const { __scopeSelect: o, ...r } = t, a = ve();
    return /* @__PURE__ */ d(gh, { scope: o, id: a, children: /* @__PURE__ */ d($.div, { role: "group", "aria-labelledby": a, ...r, ref: n }) });
  }, "SelectGroup")
), wh = "SelectLabel", xh = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ X(function(t, n) {
    const { __scopeSelect: o, ...r } = t, a = bh(wh, o);
    return /* @__PURE__ */ d($.div, { id: a.id, ...r, ref: n });
  }, "SelectLabel")
), Fo = "SelectItem", [yh, Bs] = wt(Fo), Ch = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ X(function(t, n) {
    const {
      __scopeSelect: o,
      value: r,
      disabled: a = !1,
      textValue: i,
      ...c
    } = t, l = st(Fo, o), u = xt(Fo, o), m = l.value === r, [f, p] = s.useState(i ?? ""), [h, g] = s.useState(!1), b = ie(
      (C) => u.itemRefCallback?.(C, r, a)
    ), v = H(n, b), x = ve(), y = s.useRef("touch"), w = /* @__PURE__ */ X(() => {
      a || (l.onValueChange(r), l.onOpenChange(!1));
    }, "handleSelect");
    return /* @__PURE__ */ d(
      yh,
      {
        scope: o,
        value: r,
        disabled: a,
        textId: x,
        isSelected: m,
        onItemTextChange: s.useCallback((C) => {
          p((R) => R || (C?.textContent ?? "").trim());
        }, []),
        children: /* @__PURE__ */ d(
          Kn.ItemSlot,
          {
            scope: o,
            value: r,
            disabled: a,
            textValue: f,
            children: /* @__PURE__ */ d(
              $.div,
              {
                role: "option",
                "aria-labelledby": x,
                "data-highlighted": h ? "" : void 0,
                "aria-selected": m && h,
                "data-state": m ? "checked" : "unchecked",
                "aria-disabled": a || void 0,
                "data-disabled": a ? "" : void 0,
                tabIndex: a ? void 0 : -1,
                ...c,
                ref: v,
                onFocus: A(c.onFocus, () => g(!0)),
                onBlur: A(c.onBlur, () => g(!1)),
                onClick: A(c.onClick, () => {
                  y.current !== "mouse" && w();
                }),
                onPointerUp: A(c.onPointerUp, () => {
                  y.current === "mouse" && w();
                }),
                onPointerDown: A(c.onPointerDown, (C) => {
                  y.current = C.pointerType;
                }),
                onPointerMove: A(c.onPointerMove, (C) => {
                  y.current = C.pointerType, a ? u.onItemLeave?.() : y.current === "mouse" && C.currentTarget.focus({ preventScroll: !0 });
                }),
                onPointerLeave: A(c.onPointerLeave, (C) => {
                  C.currentTarget === document.activeElement && u.onItemLeave?.();
                }),
                onKeyDown: A(c.onKeyDown, (C) => {
                  a || C.target !== C.currentTarget || u.searchRef?.current !== "" && C.key === " " || (Km.includes(C.key) && w(), C.key === " " && C.preventDefault());
                })
              }
            )
          }
        )
      }
    );
  }, "SelectItem")
), fn = "SelectItemText", Sh = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ X(function(t, n) {
    const { __scopeSelect: o, className: r, style: a, ...i } = t, c = st(fn, o), l = xt(fn, o), u = Bs(fn, o), m = Zm(fn, o), [f, p] = s.useState(null), h = ie(
      (w) => l.itemTextRefCallback?.(w, u.value, u.disabled)
    ), g = H(
      n,
      p,
      u.onItemTextChange,
      h
    ), b = f?.textContent, v = s.useMemo(
      () => /* @__PURE__ */ d("option", { value: u.value, disabled: u.disabled, children: b }, u.value),
      [u.disabled, u.value, b]
    ), { onNativeOptionAdd: x, onNativeOptionRemove: y } = m;
    return re(() => (x(v), () => y(v)), [x, y, v]), /* @__PURE__ */ Z(Xe, { children: [
      /* @__PURE__ */ d($.span, { id: u.textId, ...i, ref: g }),
      u.isSelected && c.valueNode && !c.valueNodeHasChildren && !en(c.value) ? Ut.createPortal(i.children, c.valueNode) : null
    ] });
  }, "SelectItemText")
), Rh = "SelectItemIndicator", Ph = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ X(function(t, n) {
    const { __scopeSelect: o, ...r } = t;
    return Bs(Rh, o).isSelected ? /* @__PURE__ */ d($.span, { "aria-hidden": !0, ...r, ref: n }) : null;
  }, "SelectItemIndicator")
), ba = "SelectScrollUpButton", Eh = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ X(function(t, n) {
  const o = xt(ba, t.__scopeSelect), r = Er(ba, t.__scopeSelect), [a, i] = s.useState(!1), c = H(n, r.onScrollButtonChange);
  return re(() => {
    if (o.viewport && o.isPositioned) {
      let l = function() {
        const m = u.scrollTop > 0;
        i(m);
      };
      X(l, "handleScroll");
      const u = o.viewport;
      return l(), u.addEventListener("scroll", l), () => u.removeEventListener("scroll", l);
    }
  }, [o.viewport, o.isPositioned]), a ? /* @__PURE__ */ d(
    Vs,
    {
      ...t,
      ref: c,
      onAutoScroll: () => {
        const { viewport: l, selectedItem: u } = o;
        l && u && (l.scrollTop = l.scrollTop - u.offsetHeight);
      }
    }
  ) : null;
}, "SelectScrollUpButton")), va = "SelectScrollDownButton", _h = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ X(function(t, n) {
  const o = xt(va, t.__scopeSelect), r = Er(va, t.__scopeSelect), [a, i] = s.useState(!1), c = H(n, r.onScrollButtonChange);
  return re(() => {
    if (o.viewport && o.isPositioned) {
      let l = function() {
        const m = u.scrollHeight - u.clientHeight, f = Math.ceil(u.scrollTop) < m;
        i(f);
      };
      X(l, "handleScroll");
      const u = o.viewport;
      return l(), u.addEventListener("scroll", l), () => u.removeEventListener("scroll", l);
    }
  }, [o.viewport, o.isPositioned]), a ? /* @__PURE__ */ d(
    Vs,
    {
      ...t,
      ref: c,
      onAutoScroll: () => {
        const { viewport: l, selectedItem: u } = o;
        l && u && (l.scrollTop = l.scrollTop + u.offsetHeight);
      }
    }
  ) : null;
}, "SelectScrollDownButton")), Vs = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ X(function(t, n) {
  const { __scopeSelect: o, onAutoScroll: r, ...a } = t, i = xt("SelectScrollButton", o), c = s.useRef(null), l = Yn(o), u = s.useCallback(() => {
    c.current !== null && (window.clearInterval(c.current), c.current = null);
  }, []);
  return s.useEffect(() => () => u(), [u]), re(() => {
    l().find((f) => f.ref.current === document.activeElement)?.ref.current?.scrollIntoView({ block: "nearest" });
  }, [l]), /* @__PURE__ */ d(
    $.div,
    {
      "aria-hidden": !0,
      ...a,
      ref: n,
      style: { flexShrink: 0, ...a.style },
      onPointerDown: A(a.onPointerDown, () => {
        c.current === null && (c.current = window.setInterval(r, 50));
      }),
      onPointerMove: A(a.onPointerMove, () => {
        i.onItemLeave?.(), c.current === null && (c.current = window.setInterval(r, 50));
      }),
      onPointerLeave: A(a.onPointerLeave, () => {
        u();
      })
    }
  );
}, "SelectScrollButtonImpl")), Th = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ X(function(t, n) {
    const { __scopeSelect: o, ...r } = t;
    return /* @__PURE__ */ d($.div, { "aria-hidden": !0, ...r, ref: n });
  }, "SelectSeparator")
), Ih = "SelectBubbleInput", Ah = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ X(function({ __scopeSelect: t, ...n }, o) {
    const r = st(Ih, t), { value: a, onValueChange: i, required: c, disabled: l, name: u, autoComplete: m, form: f } = r, { nativeOptions: p, nativeSelectKey: h } = r, g = s.useRef(null), b = H(o, g), v = a ?? "", x = Is(v), y = Array.from(p).some(
      (w) => (w.props.value ?? "") === ""
    );
    return s.useEffect(() => {
      const w = g.current;
      if (!w) return;
      const C = window.HTMLSelectElement.prototype, P = Object.getOwnPropertyDescriptor(
        C,
        "value"
      ).set;
      if (x !== v && P) {
        const E = new Event("change", { bubbles: !0 });
        P.call(w, v), w.dispatchEvent(E);
      }
    }, [x, v]), /* @__PURE__ */ Z(
      $.select,
      {
        "aria-hidden": !0,
        required: c,
        tabIndex: -1,
        name: u,
        autoComplete: m,
        disabled: l,
        form: f,
        onChange: (w) => i(w.target.value),
        ...n,
        style: { ...za, ...n.style },
        ref: b,
        defaultValue: v,
        children: [
          en(a) && !y ? /* @__PURE__ */ d("option", { value: "" }) : null,
          Array.from(p)
        ]
      },
      h
    );
  }, "SelectBubbleInput")
);
function Ws(e) {
  return typeof e == "function";
}
X(Ws, "isFunction");
function en(e) {
  return e === "" || e === void 0;
}
X(en, "shouldShowPlaceholder");
function _r(e) {
  const t = ie(e), n = s.useRef(""), o = s.useRef(0), r = s.useCallback(
    (i) => {
      const c = n.current + i;
      t(c), (/* @__PURE__ */ X((function l(u) {
        n.current = u, window.clearTimeout(o.current), u !== "" && (o.current = window.setTimeout(() => l(""), 1e3));
      }), "updateSearch"))(c);
    },
    [t]
  ), a = s.useCallback(() => {
    n.current = "", window.clearTimeout(o.current);
  }, []);
  return s.useEffect(() => () => window.clearTimeout(o.current), []), [n, r, a];
}
X(_r, "useTypeaheadSearch");
function Tr(e, t, n) {
  const r = t.length > 1 && Array.from(t).every((u) => u === t[0]) ? t[0] : t, a = n ? e.indexOf(n) : -1;
  let i = Hs(e, Math.max(a, 0));
  r.length === 1 && (i = i.filter((u) => u !== n));
  const l = i.find(
    (u) => u.textValue.toLowerCase().startsWith(r.toLowerCase())
  );
  return l !== n ? l : void 0;
}
X(Tr, "findNextItem");
function Hs(e, t) {
  return e.map((n, o) => e[(t + o) % e.length]);
}
X(Hs, "wrapArray");
var kh = Object.defineProperty, Gs = (e, t) => kh(e, "name", { value: t, configurable: !0 }), wa = "horizontal", Mh = ["horizontal", "vertical"], Oh = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ Gs(function(t, n) {
    const { decorative: o, orientation: r = wa, ...a } = t, i = Us(r) ? r : wa, l = o ? { role: "none" } : { "aria-orientation": i === "vertical" ? i : void 0, role: "separator" };
    return /* @__PURE__ */ d(
      $.div,
      {
        "data-orientation": i,
        ...l,
        ...a,
        ref: n
      }
    );
  }, "Separator")
);
function Us(e) {
  return Mh.includes(e);
}
Gs(Us, "isValidOrientation");
var Dh = Oh, Nh = Object.defineProperty, rt = (e, t) => Nh(e, "name", { value: t, configurable: !0 }), Ir = "Switch", [Lh, bv] = /* @__PURE__ */ we(Ir), [$h, Ar] = Lh(Ir);
function js(e) {
  const {
    __scopeSwitch: t,
    checked: n,
    children: o,
    defaultChecked: r,
    disabled: a,
    form: i,
    name: c,
    onCheckedChange: l,
    required: u,
    value: m = "on",
    // @ts-expect-error
    internal_do_not_use_render: f
  } = e, [p, h] = Pe({
    prop: n,
    defaultProp: r ?? !1,
    onChange: l,
    caller: Ir
  }), [g, b] = s.useState(null), [v, x] = s.useState(null), y = s.useRef(!1), [w, C] = s.useReducer(
    (E) => E + 1,
    0
  ), R = g ? !!i || !!g.closest("form") : (
    // We set this to true by default so that events bubble to forms without JS (SSR)
    !0
  ), P = {
    checked: p,
    setChecked: h,
    disabled: a,
    control: g,
    setControl: b,
    name: c,
    form: i,
    value: m,
    hasConsumerStoppedPropagationRef: y,
    userInteractionCount: w,
    onUserInteraction: C,
    required: u,
    defaultChecked: r,
    isFormControl: R,
    bubbleInput: v,
    setBubbleInput: x
  };
  return /* @__PURE__ */ d($h, { scope: t, ...P, children: Ks(f) ? f(P) : o });
}
rt(js, "SwitchProvider");
var Fh = "SwitchTrigger", zh = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ rt(function({ __scopeSwitch: t, onClick: n, ...o }, r) {
    const {
      control: a,
      form: i,
      value: c,
      disabled: l,
      checked: u,
      required: m,
      setControl: f,
      setChecked: p,
      hasConsumerStoppedPropagationRef: h,
      onUserInteraction: g,
      isFormControl: b,
      bubbleInput: v
    } = Ar(Fh, t), x = H(r, f), y = s.useRef(u);
    return s.useEffect(() => {
      const w = i ? a?.ownerDocument.getElementById(i) : a?.form;
      if (w instanceof HTMLFormElement) {
        const C = /* @__PURE__ */ rt(() => p(y.current), "reset");
        return w.addEventListener("reset", C), () => w.removeEventListener("reset", C);
      }
    }, [a, i, p]), /* @__PURE__ */ d(
      $.button,
      {
        type: "button",
        role: "switch",
        "aria-checked": u,
        "aria-required": m,
        "data-state": kr(u),
        "data-disabled": l ? "" : void 0,
        disabled: l,
        value: c,
        ...o,
        ref: x,
        onClick: A(n, (w) => {
          g(), p((C) => !C), v && b && (h.current = w.isPropagationStopped(), h.current || w.stopPropagation());
        })
      }
    );
  }, "SwitchTrigger")
), Bh = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ rt(function(t, n) {
    const {
      __scopeSwitch: o,
      name: r,
      checked: a,
      defaultChecked: i,
      required: c,
      disabled: l,
      value: u,
      onCheckedChange: m,
      form: f,
      ...p
    } = t;
    return /* @__PURE__ */ d(
      js,
      {
        __scopeSwitch: o,
        checked: a,
        defaultChecked: i,
        disabled: l,
        required: c,
        onCheckedChange: m,
        name: r,
        form: f,
        value: u,
        internal_do_not_use_render: ({ isFormControl: h }) => /* @__PURE__ */ Z(Xe, { children: [
          /* @__PURE__ */ d(
            zh,
            {
              ...p,
              ref: n,
              __scopeSwitch: o
            }
          ),
          h && /* @__PURE__ */ d(
            Gh,
            {
              __scopeSwitch: o
            }
          )
        ] })
      }
    );
  }, "Switch")
), Vh = "SwitchThumb", Wh = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ rt(function(t, n) {
    const { __scopeSwitch: o, ...r } = t, a = Ar(Vh, o);
    return /* @__PURE__ */ d(
      $.span,
      {
        "data-state": kr(a.checked),
        "data-disabled": a.disabled ? "" : void 0,
        ...r,
        ref: n
      }
    );
  }, "SwitchThumb")
), Hh = "SwitchBubbleInput", Gh = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ rt(function({ __scopeSwitch: t, onClick: n, ...o }, r) {
    const {
      control: a,
      hasConsumerStoppedPropagationRef: i,
      userInteractionCount: c,
      checked: l,
      defaultChecked: u,
      required: m,
      disabled: f,
      name: p,
      value: h,
      form: g,
      bubbleInput: b,
      setBubbleInput: v
    } = Ar(Hh, t), x = H(r, v), y = Dn(a), w = s.useRef(!1), C = s.useRef(l), R = s.useRef(c);
    s.useEffect(() => {
      const E = b;
      if (!E) return;
      const S = window.HTMLInputElement.prototype, k = Object.getOwnPropertyDescriptor(
        S,
        "checked"
      ).set, N = c !== R.current;
      R.current = c;
      const M = C.current !== l;
      C.current = l;
      const F = !(N && i.current);
      if (M && k) {
        w.current = !N;
        const V = new Event("click", { bubbles: F });
        k.call(E, l), E.dispatchEvent(V), w.current = !1;
      }
    }, [b, l, i, c]);
    const P = s.useRef(l);
    return /* @__PURE__ */ d(
      $.input,
      {
        type: "checkbox",
        "aria-hidden": !0,
        defaultChecked: u ?? P.current,
        required: m,
        disabled: f,
        name: p,
        value: h,
        form: g,
        ...o,
        tabIndex: -1,
        ref: x,
        onClick: A(n, (E) => {
          w.current && E.stopPropagation();
        }),
        style: {
          ...o.style,
          ...y,
          position: "absolute",
          pointerEvents: "none",
          opacity: 0,
          margin: 0,
          // We transform because the input is absolutely positioned but we have
          // rendered it **after** the button. This pulls it back to sit on top
          // of the button.
          transform: "translateX(-100%)"
        }
      }
    );
  }, "SwitchBubbleInput")
);
function Ks(e) {
  return typeof e == "function";
}
rt(Ks, "isFunction");
function kr(e) {
  return e ? "checked" : "unchecked";
}
rt(kr, "getState");
var Uh = Object.defineProperty, Lt = (e, t) => Uh(e, "name", { value: t, configurable: !0 }), Mr = "Tabs", [jh, vv] = /* @__PURE__ */ we(Mr, [
  Hn
]), Ys = Hn(), [Kh, Or] = jh(Mr), Yh = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ Lt(function(t, n) {
    const {
      __scopeTabs: o,
      value: r,
      onValueChange: a,
      defaultValue: i,
      orientation: c = "horizontal",
      dir: l,
      activationMode: u = "automatic",
      ...m
    } = t, f = gt(l), [p, h] = Pe({
      prop: r,
      onChange: a,
      defaultProp: i ?? "",
      caller: Mr
    });
    return /* @__PURE__ */ d(
      Kh,
      {
        scope: o,
        baseId: ve(),
        value: p,
        onValueChange: h,
        orientation: c,
        dir: f,
        activationMode: u,
        children: /* @__PURE__ */ d(
          $.div,
          {
            dir: f,
            "data-orientation": c,
            ...m,
            ref: n
          }
        )
      }
    );
  }, "Tabs")
), Xh = "TabsList", qh = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ Lt(function(t, n) {
    const { __scopeTabs: o, loop: r = !0, ...a } = t, i = Or(Xh, o), c = Ys(o);
    return /* @__PURE__ */ d(
      ss,
      {
        asChild: !0,
        ...c,
        orientation: i.orientation,
        dir: i.dir,
        loop: r,
        children: /* @__PURE__ */ d(
          $.div,
          {
            role: "tablist",
            "aria-orientation": i.orientation,
            ...a,
            ref: n
          }
        )
      }
    );
  }, "TabsList")
), Zh = "TabsTrigger", Qh = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ Lt(function(t, n) {
    const { __scopeTabs: o, value: r, disabled: a = !1, ...i } = t, c = Or(Zh, o), l = Ys(o), u = Dr(c.baseId, r), m = Nr(c.baseId, r), f = r === c.value;
    return /* @__PURE__ */ d(
      cs,
      {
        asChild: !0,
        ...l,
        focusable: !a,
        active: f,
        children: /* @__PURE__ */ d(
          $.button,
          {
            type: "button",
            role: "tab",
            "aria-selected": f,
            "aria-controls": m,
            "data-state": f ? "active" : "inactive",
            "data-disabled": a ? "" : void 0,
            disabled: a,
            id: u,
            ...i,
            ref: n,
            onMouseDown: A(t.onMouseDown, (p) => {
              !a && p.button === 0 && p.ctrlKey === !1 ? c.onValueChange(r) : p.preventDefault();
            }),
            onKeyDown: A(t.onKeyDown, (p) => {
              a || p.target !== p.currentTarget || [" ", "Enter"].includes(p.key) && c.onValueChange(r);
            }),
            onFocus: A(t.onFocus, () => {
              const p = c.activationMode !== "manual";
              !f && !a && p && c.onValueChange(r);
            })
          }
        )
      }
    );
  }, "TabsTrigger")
), Jh = "TabsContent", eg = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ Lt(function(t, n) {
    const { __scopeTabs: o, value: r, forceMount: a, children: i, ...c } = t, l = Or(Jh, o), u = Dr(l.baseId, r), m = Nr(l.baseId, r), f = r === l.value, p = s.useRef(f);
    return s.useEffect(() => {
      const h = requestAnimationFrame(() => p.current = !1);
      return () => cancelAnimationFrame(h);
    }, []), /* @__PURE__ */ d(he, { present: a || f, children: ({ present: h }) => /* @__PURE__ */ d(
      $.div,
      {
        "data-state": f ? "active" : "inactive",
        "data-orientation": l.orientation,
        role: "tabpanel",
        "aria-labelledby": u,
        hidden: !h,
        id: m,
        tabIndex: 0,
        ...c,
        ref: n,
        style: {
          ...t.style,
          animationDuration: p.current ? "0s" : void 0
        },
        children: h && i
      }
    ) });
  }, "TabsContent")
);
function Dr(e, t) {
  return `${e}-trigger-${t}`;
}
Lt(Dr, "makeTriggerId");
function Nr(e, t) {
  return `${e}-content-${t}`;
}
Lt(Nr, "makeContentId");
var tg = Yh, ng = qh, og = Qh, rg = eg, ag = Object.defineProperty, de = (e, t) => ag(e, "name", { value: t, configurable: !0 }), [Lr, wv] = /* @__PURE__ */ we("Tooltip", [
  Nt
]), Xn = Nt(), ig = "TooltipProvider", sg = 700, zo = "tooltip.open", [cg, $r] = Lr(ig), lg = /* @__PURE__ */ de((e) => {
  const {
    __scopeTooltip: t,
    delayDuration: n = sg,
    skipDelayDuration: o = 300,
    disableHoverableContent: r = !1,
    children: a
  } = e, i = s.useRef(!0), c = s.useRef(!1), l = s.useRef(0);
  return s.useEffect(() => {
    const u = l.current;
    return () => window.clearTimeout(u);
  }, []), /* @__PURE__ */ d(
    cg,
    {
      scope: t,
      isOpenDelayedRef: i,
      delayDuration: n,
      onOpen: s.useCallback(() => {
        o <= 0 || (window.clearTimeout(l.current), i.current = !1);
      }, [o]),
      onClose: s.useCallback(() => {
        o <= 0 || (window.clearTimeout(l.current), l.current = window.setTimeout(
          () => i.current = !0,
          o
        ));
      }, [o]),
      isPointerInTransitRef: c,
      onPointerInTransitChange: s.useCallback((u) => {
        c.current = u;
      }, []),
      disableHoverableContent: r,
      children: a
    }
  );
}, "TooltipProvider"), Bo = "Tooltip", [ug, tn] = Lr(Bo), dg = /* @__PURE__ */ de((e) => {
  const {
    __scopeTooltip: t,
    children: n,
    open: o,
    defaultOpen: r,
    onOpenChange: a,
    disableHoverableContent: i,
    delayDuration: c
  } = e, l = $r(Bo, e.__scopeTooltip), u = Xn(t), [m, f] = s.useState(null), [p, h] = s.useState(void 0), g = ve(), b = s.useRef(0), v = i ?? l.disableHoverableContent, x = c ?? l.delayDuration, y = s.useRef(!1), [w, C] = Pe({
    prop: o,
    defaultProp: r ?? !1,
    onChange: /* @__PURE__ */ de((k) => {
      k ? (l.onOpen(), document.dispatchEvent(new CustomEvent(zo))) : l.onClose(), a?.(k);
    }, "onChange"),
    caller: Bo
  }), R = s.useMemo(() => w ? y.current ? "delayed-open" : "instant-open" : "closed", [w]), P = s.useCallback(() => {
    window.clearTimeout(b.current), b.current = 0, y.current = !1, C(!0);
  }, [C]), E = s.useCallback(() => {
    window.clearTimeout(b.current), b.current = 0, C(!1);
  }, [C]), S = s.useCallback(() => {
    window.clearTimeout(b.current), b.current = window.setTimeout(() => {
      y.current = !0, C(!0), b.current = 0;
    }, x);
  }, [x, C]);
  return s.useEffect(() => () => {
    b.current && (window.clearTimeout(b.current), b.current = 0);
  }, []), /* @__PURE__ */ d(Vn, { ...u, children: /* @__PURE__ */ d(
    ug,
    {
      scope: t,
      contentId: p ?? g,
      setContentId: h,
      open: w,
      stateAttribute: R,
      trigger: m,
      onTriggerChange: f,
      onTriggerEnter: s.useCallback(() => {
        l.isOpenDelayedRef.current ? S() : P();
      }, [l.isOpenDelayedRef, S, P]),
      onTriggerLeave: s.useCallback(() => {
        v ? E() : (window.clearTimeout(b.current), b.current = 0);
      }, [E, v]),
      onOpen: P,
      onClose: E,
      disableHoverableContent: v,
      children: n
    }
  ) });
}, "Tooltip"), xa = "TooltipTrigger", fg = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ de(function(t, n) {
    const { __scopeTooltip: o, ...r } = t, a = tn(xa, o), i = $r(xa, o), c = Xn(o), l = s.useRef(null), u = H(n, l, a.onTriggerChange), m = s.useRef(!1), f = s.useRef(!1), p = s.useCallback(() => m.current = !1, []);
    return s.useEffect(() => () => document.removeEventListener("pointerup", p), [p]), /* @__PURE__ */ d(fr, { asChild: !0, ...c, children: /* @__PURE__ */ d(
      $.button,
      {
        "aria-describedby": a.open ? a.contentId : void 0,
        "data-state": a.stateAttribute,
        ...r,
        ref: u,
        onPointerMove: A(t.onPointerMove, (h) => {
          h.pointerType !== "touch" && !f.current && !i.isPointerInTransitRef.current && (a.onTriggerEnter(), f.current = !0);
        }),
        onPointerLeave: A(t.onPointerLeave, () => {
          a.onTriggerLeave(), f.current = !1;
        }),
        onPointerDown: A(t.onPointerDown, () => {
          a.open && a.onClose(), m.current = !0, document.addEventListener("pointerup", p, { once: !0 });
        }),
        onFocus: A(t.onFocus, () => {
          m.current || a.onOpen();
        }),
        onBlur: A(t.onBlur, a.onClose),
        onClick: A(t.onClick, a.onClose)
      }
    ) });
  }, "TooltipTrigger")
), Xs = "TooltipPortal", [pg, mg] = Lr(Xs, {
  forceMount: void 0
}), hg = /* @__PURE__ */ de((e) => {
  const { __scopeTooltip: t, forceMount: n, children: o, container: r } = e, a = tn(Xs, t);
  return /* @__PURE__ */ d(pg, { scope: t, forceMount: n, children: /* @__PURE__ */ d(he, { present: n || a.open, children: /* @__PURE__ */ d(An, { asChild: !0, container: r, children: o }) }) });
}, "TooltipPortal"), Gt = "TooltipContent", gg = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ de(function(t, n) {
    const o = mg(Gt, t.__scopeTooltip), { forceMount: r = o.forceMount, side: a = "top", ...i } = t, c = tn(Gt, t.__scopeTooltip);
    return /* @__PURE__ */ d(he, { present: r || c.open, children: c.disableHoverableContent ? /* @__PURE__ */ d(qs, { side: a, ...i, ref: n }) : /* @__PURE__ */ d(bg, { side: a, ...i, ref: n }) });
  }, "TooltipContent")
), bg = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ de(function(t, n) {
  const o = tn(Gt, t.__scopeTooltip), r = $r(Gt, t.__scopeTooltip), a = s.useRef(null), i = H(n, a), [c, l] = s.useState(null), { trigger: u, onClose: m } = o, f = a.current, { onPointerInTransitChange: p } = r, h = s.useCallback(() => {
    l(null), p(!1);
  }, [p]), g = s.useCallback(
    (b, v) => {
      const x = b.currentTarget, y = { x: b.clientX, y: b.clientY }, w = Zs(y, x.getBoundingClientRect()), C = Qs(y, w), R = Js(v.getBoundingClientRect()), P = tc([...C, ...R]);
      l(P), p(!0);
    },
    [p]
  );
  return s.useEffect(() => () => h(), [h]), s.useEffect(() => {
    if (u && f) {
      const b = /* @__PURE__ */ de((x) => g(x, f), "handleTriggerLeave"), v = /* @__PURE__ */ de((x) => g(x, u), "handleContentLeave");
      return u.addEventListener("pointerleave", b), f.addEventListener("pointerleave", v), () => {
        u.removeEventListener("pointerleave", b), f.removeEventListener("pointerleave", v);
      };
    }
  }, [u, f, g, h]), s.useEffect(() => {
    if (c) {
      const b = /* @__PURE__ */ de((v) => {
        const x = v.target, y = { x: v.clientX, y: v.clientY }, w = u?.contains(x) || f?.contains(x), C = !ec(y, c);
        w ? h() : C && (h(), m());
      }, "handleTrackPointerGrace");
      return document.addEventListener("pointermove", b), () => document.removeEventListener("pointermove", b);
    }
  }, [u, f, c, m, h]), /* @__PURE__ */ d(qs, { ...t, ref: i });
}, "TooltipContentHoverable")), vg = /* @__PURE__ */ Da("TooltipContent"), qs = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ de(function(t, n) {
    const {
      __scopeTooltip: o,
      children: r,
      "aria-label": a,
      id: i,
      onEscapeKeyDown: c,
      onPointerDownOutside: l,
      ...u
    } = t, m = tn(Gt, o), f = Xn(o), { onClose: p } = m;
    s.useEffect(() => (document.addEventListener(zo, p), () => document.removeEventListener(zo, p)), [p]), s.useEffect(() => {
      if (m.trigger) {
        const g = /* @__PURE__ */ de((b) => {
          b.target instanceof Node && b.target.contains(m.trigger) && p();
        }, "handleScroll");
        return window.addEventListener("scroll", g, { capture: !0 }), () => window.removeEventListener("scroll", g, { capture: !0 });
      }
    }, [m.trigger, p]);
    const { setContentId: h } = m;
    return re(() => (h(i), () => {
      h(void 0);
    }), [i, h]), /* @__PURE__ */ d(
      In,
      {
        asChild: !0,
        disableOutsidePointerEvents: !1,
        onEscapeKeyDown: c,
        onPointerDownOutside: l,
        onFocusOutside: (g) => g.preventDefault(),
        onDismiss: p,
        children: /* @__PURE__ */ Z(
          pr,
          {
            "data-state": m.stateAttribute,
            role: a ? void 0 : "tooltip",
            id: a ? void 0 : m.contentId,
            ...f,
            ...u,
            ref: n,
            style: {
              ...u.style,
              "--radix-tooltip-content-transform-origin": "var(--radix-popper-transform-origin)",
              "--radix-tooltip-content-available-width": "var(--radix-popper-available-width)",
              "--radix-tooltip-content-available-height": "var(--radix-popper-available-height)",
              "--radix-tooltip-trigger-width": "var(--radix-popper-anchor-width)",
              "--radix-tooltip-trigger-height": "var(--radix-popper-anchor-height)"
            },
            children: [
              /* @__PURE__ */ d(vg, { children: r }),
              a ? /* @__PURE__ */ d(Gc, { id: m.contentId, role: "tooltip", children: a }) : null
            ]
          }
        )
      }
    );
  }, "TooltipContentImpl")
), wg = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ de(function(t, n) {
    const { __scopeTooltip: o, ...r } = t, a = Xn(o);
    return /* @__PURE__ */ d(Af, { ...a, ...r, ref: n });
  }, "TooltipArrow")
);
function Zs(e, t) {
  const n = Math.abs(t.top - e.y), o = Math.abs(t.bottom - e.y), r = Math.abs(t.right - e.x), a = Math.abs(t.left - e.x);
  switch (Math.min(n, o, r, a)) {
    case a:
      return "left";
    case r:
      return "right";
    case n:
      return "top";
    case o:
      return "bottom";
    default:
      throw new Error("unreachable");
  }
}
de(Zs, "getExitSideFromRect");
function Qs(e, t, n = 5) {
  const o = [];
  switch (t) {
    case "top":
      o.push(
        { x: e.x - n, y: e.y + n },
        { x: e.x + n, y: e.y + n }
      );
      break;
    case "bottom":
      o.push(
        { x: e.x - n, y: e.y - n },
        { x: e.x + n, y: e.y - n }
      );
      break;
    case "left":
      o.push(
        { x: e.x + n, y: e.y - n },
        { x: e.x + n, y: e.y + n }
      );
      break;
    case "right":
      o.push(
        { x: e.x - n, y: e.y - n },
        { x: e.x - n, y: e.y + n }
      );
      break;
  }
  return o;
}
de(Qs, "getPaddedExitPoints");
function Js(e) {
  const { top: t, right: n, bottom: o, left: r } = e;
  return [
    { x: r, y: t },
    { x: n, y: t },
    { x: n, y: o },
    { x: r, y: o }
  ];
}
de(Js, "getPointsFromRect");
function ec(e, t) {
  const { x: n, y: o } = e;
  let r = !1;
  for (let a = 0, i = t.length - 1; a < t.length; i = a++) {
    const c = t[a], l = t[i], u = c.x, m = c.y, f = l.x, p = l.y;
    m > o != p > o && n < (f - u) * (o - m) / (p - m) + u && (r = !r);
  }
  return r;
}
de(ec, "isPointInPolygon");
function tc(e) {
  const t = e.slice();
  return t.sort((n, o) => n.x < o.x ? -1 : n.x > o.x ? 1 : n.y < o.y ? -1 : n.y > o.y ? 1 : 0), nc(t);
}
de(tc, "getHull");
function nc(e) {
  if (e.length <= 1) return e.slice();
  const t = [];
  for (let o = 0; o < e.length; o++) {
    const r = e[o];
    for (; t.length >= 2; ) {
      const a = t[t.length - 1], i = t[t.length - 2];
      if ((a.x - i.x) * (r.y - i.y) >= (a.y - i.y) * (r.x - i.x)) t.pop();
      else break;
    }
    t.push(r);
  }
  t.pop();
  const n = [];
  for (let o = e.length - 1; o >= 0; o--) {
    const r = e[o];
    for (; n.length >= 2; ) {
      const a = n[n.length - 1], i = n[n.length - 2];
      if ((a.x - i.x) * (r.y - i.y) >= (a.y - i.y) * (r.x - i.x)) n.pop();
      else break;
    }
    n.push(r);
  }
  return n.pop(), t.length === 1 && n.length === 1 && t[0].x === n[0].x && t[0].y === n[0].y ? t : t.concat(n);
}
de(nc, "getHullPresorted");
var xg = lg, yg = dg, Cg = fg, Sg = hg, Rg = gg, Pg = wg;
const oc = (...e) => e.filter((t, n, o) => !!t && t.trim() !== "" && o.indexOf(t) === n).join(" ").trim();
const Eg = (e) => e.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
const _g = (e) => e.replace(
  /^([A-Z])|[\s-_]+(\w)/g,
  (t, n, o) => o ? o.toUpperCase() : n.toLowerCase()
);
const ya = (e) => {
  const t = _g(e);
  return t.charAt(0).toUpperCase() + t.slice(1);
};
var ho = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round"
};
const Tg = (e) => {
  for (const t in e)
    if (t.startsWith("aria-") || t === "role" || t === "title")
      return !0;
  return !1;
}, Ig = kc({}), Ag = () => Ac(Ig), kg = ka(
  ({ color: e, size: t, strokeWidth: n, absoluteStrokeWidth: o, className: r = "", children: a, iconNode: i, ...c }, l) => {
    const {
      size: u = 24,
      strokeWidth: m = 2,
      absoluteStrokeWidth: f = !1,
      color: p = "currentColor",
      className: h = ""
    } = Ag() ?? {}, g = o ?? f ? Number(n ?? m) * 24 / Number(t ?? u) : n ?? m;
    return bo(
      "svg",
      {
        ref: l,
        ...ho,
        width: t ?? u ?? ho.width,
        height: t ?? u ?? ho.height,
        stroke: e ?? p,
        strokeWidth: g,
        className: oc("lucide", h, r),
        ...!a && !Tg(c) && { "aria-hidden": "true" },
        ...c
      },
      [
        ...i.map(([b, v]) => bo(b, v)),
        ...Array.isArray(a) ? a : [a]
      ]
    );
  }
);
const yt = (e, t) => {
  const n = ka(
    ({ className: o, ...r }, a) => bo(kg, {
      ref: a,
      iconNode: t,
      className: oc(
        `lucide-${Eg(ya(e))}`,
        `lucide-${e}`,
        o
      ),
      ...r
    })
  );
  return n.displayName = ya(e), n;
};
const Mg = [["path", { d: "M20 6 9 17l-5-5", key: "1gmf2c" }]], Fr = yt("check", Mg);
const Og = [["path", { d: "m6 9 6 6 6-6", key: "qrunsl" }]], zr = yt("chevron-down", Og);
const Dg = [["path", { d: "m9 18 6-6-6-6", key: "mthhwq" }]], Ng = yt("chevron-right", Dg);
const Lg = [["path", { d: "m18 15-6-6-6 6", key: "153udz" }]], $g = yt("chevron-up", Lg);
const Fg = [["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }]], zg = yt("circle", Fg);
const Bg = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M9 3v18", key: "fh3hqa" }]
], Vg = yt("panel-left", Bg);
const Wg = [
  ["path", { d: "M18 6 6 18", key: "1bl5f8" }],
  ["path", { d: "m6 6 12 12", key: "d8bk6v" }]
], rc = yt("x", Wg);
function ac(e) {
  var t, n, o = "";
  if (typeof e == "string" || typeof e == "number") o += e;
  else if (typeof e == "object") if (Array.isArray(e)) {
    var r = e.length;
    for (t = 0; t < r; t++) e[t] && (n = ac(e[t])) && (o && (o += " "), o += n);
  } else for (n in e) e[n] && (o && (o += " "), o += n);
  return o;
}
function ic() {
  for (var e, t, n = 0, o = "", r = arguments.length; n < r; n++) (e = arguments[n]) && (t = ac(e)) && (o && (o += " "), o += t);
  return o;
}
const Hg = (e, t) => {
  const n = new Array(e.length + t.length);
  for (let o = 0; o < e.length; o++)
    n[o] = e[o];
  for (let o = 0; o < t.length; o++)
    n[e.length + o] = t[o];
  return n;
}, Gg = (e, t) => ({
  classGroupId: e,
  validator: t
}), sc = (e = /* @__PURE__ */ new Map(), t = null, n) => ({
  nextPart: e,
  validators: t,
  classGroupId: n
}), Pn = "-", Ca = [], Ug = "arbitrary..", jg = (e) => {
  const t = Yg(e), {
    conflictingClassGroups: n,
    conflictingClassGroupModifiers: o
  } = e;
  return {
    getClassGroupId: (i) => {
      if (i.startsWith("[") && i.endsWith("]"))
        return Kg(i);
      const c = i.split(Pn), l = c[0] === "" && c.length > 1 ? 1 : 0;
      return cc(c, l, t);
    },
    getConflictingClassGroupIds: (i, c) => {
      if (c) {
        const l = o[i], u = n[i];
        return l ? u ? Hg(u, l) : l : u || Ca;
      }
      return n[i] || Ca;
    }
  };
}, cc = (e, t, n) => {
  if (e.length - t === 0)
    return n.classGroupId;
  const r = e[t], a = n.nextPart.get(r);
  if (a) {
    const u = cc(e, t + 1, a);
    if (u) return u;
  }
  const i = n.validators;
  if (i === null)
    return;
  const c = t === 0 ? e.join(Pn) : e.slice(t).join(Pn), l = i.length;
  for (let u = 0; u < l; u++) {
    const m = i[u];
    if (m.validator(c))
      return m.classGroupId;
  }
}, Kg = (e) => e.slice(1, -1).indexOf(":") === -1 ? void 0 : (() => {
  const t = e.slice(1, -1), n = t.indexOf(":"), o = t.slice(0, n);
  return o ? Ug + o : void 0;
})(), Yg = (e) => {
  const {
    theme: t,
    classGroups: n
  } = e;
  return Xg(n, t);
}, Xg = (e, t) => {
  const n = sc();
  for (const o in e) {
    const r = e[o];
    Br(r, n, o, t);
  }
  return n;
}, Br = (e, t, n, o) => {
  const r = e.length;
  for (let a = 0; a < r; a++) {
    const i = e[a];
    qg(i, t, n, o);
  }
}, qg = (e, t, n, o) => {
  if (typeof e == "string") {
    Zg(e, t, n);
    return;
  }
  if (typeof e == "function") {
    Qg(e, t, n, o);
    return;
  }
  Jg(e, t, n, o);
}, Zg = (e, t, n) => {
  const o = e === "" ? t : lc(t, e);
  o.classGroupId = n;
}, Qg = (e, t, n, o) => {
  if (eb(e)) {
    Br(e(o), t, n, o);
    return;
  }
  t.validators === null && (t.validators = []), t.validators.push(Gg(n, e));
}, Jg = (e, t, n, o) => {
  const r = Object.entries(e), a = r.length;
  for (let i = 0; i < a; i++) {
    const [c, l] = r[i];
    Br(l, lc(t, c), n, o);
  }
}, lc = (e, t) => {
  let n = e;
  const o = t.split(Pn), r = o.length;
  for (let a = 0; a < r; a++) {
    const i = o[a];
    let c = n.nextPart.get(i);
    c || (c = sc(), n.nextPart.set(i, c)), n = c;
  }
  return n;
}, eb = (e) => "isThemeGetter" in e && e.isThemeGetter === !0, tb = (e) => {
  if (e < 1)
    return {
      get: () => {
      },
      set: () => {
      }
    };
  let t = 0, n = /* @__PURE__ */ Object.create(null), o = /* @__PURE__ */ Object.create(null);
  const r = (a, i) => {
    n[a] = i, t++, t > e && (t = 0, o = n, n = /* @__PURE__ */ Object.create(null));
  };
  return {
    get(a) {
      let i = n[a];
      if (i !== void 0)
        return i;
      if ((i = o[a]) !== void 0)
        return r(a, i), i;
    },
    set(a, i) {
      a in n ? n[a] = i : r(a, i);
    }
  };
}, Vo = "!", Sa = ":", nb = [], Ra = (e, t, n, o, r) => ({
  modifiers: e,
  hasImportantModifier: t,
  baseClassName: n,
  maybePostfixModifierPosition: o,
  isExternal: r
}), ob = (e) => {
  const {
    prefix: t,
    experimentalParseClassName: n
  } = e;
  let o = (r) => {
    const a = [];
    let i = 0, c = 0, l = 0, u;
    const m = r.length;
    for (let b = 0; b < m; b++) {
      const v = r[b];
      if (i === 0 && c === 0) {
        if (v === Sa) {
          a.push(r.slice(l, b)), l = b + 1;
          continue;
        }
        if (v === "/") {
          u = b;
          continue;
        }
      }
      v === "[" ? i++ : v === "]" ? i-- : v === "(" ? c++ : v === ")" && c--;
    }
    const f = a.length === 0 ? r : r.slice(l);
    let p = f, h = !1;
    f.endsWith(Vo) ? (p = f.slice(0, -1), h = !0) : (
      /**
       * In Tailwind CSS v3 the important modifier was at the start of the base class name. This is still supported for legacy reasons.
       * @see https://github.com/dcastil/tailwind-merge/issues/513#issuecomment-2614029864
       */
      f.startsWith(Vo) && (p = f.slice(1), h = !0)
    );
    const g = u && u > l ? u - l : void 0;
    return Ra(a, h, p, g);
  };
  if (t) {
    const r = t + Sa, a = o;
    o = (i) => i.startsWith(r) ? a(i.slice(r.length)) : Ra(nb, !1, i, void 0, !0);
  }
  if (n) {
    const r = o;
    o = (a) => n({
      className: a,
      parseClassName: r
    });
  }
  return o;
}, rb = (e) => {
  const t = /* @__PURE__ */ new Map();
  return e.orderSensitiveModifiers.forEach((n, o) => {
    t.set(n, 1e6 + o);
  }), (n) => {
    const o = [];
    let r = [];
    for (let a = 0; a < n.length; a++) {
      const i = n[a], c = i[0] === "[", l = t.has(i);
      c || l ? (r.length > 0 && (r.sort(), o.push(...r), r = []), o.push(i)) : r.push(i);
    }
    return r.length > 0 && (r.sort(), o.push(...r)), o;
  };
}, ab = (e) => ({
  cache: tb(e.cacheSize),
  parseClassName: ob(e),
  sortModifiers: rb(e),
  postfixLookupClassGroupIds: ib(e),
  ...jg(e)
}), ib = (e) => {
  const t = /* @__PURE__ */ Object.create(null), n = e.postfixLookupClassGroups;
  if (n)
    for (let o = 0; o < n.length; o++)
      t[n[o]] = !0;
  return t;
}, sb = /\s+/, cb = (e, t) => {
  const {
    parseClassName: n,
    getClassGroupId: o,
    getConflictingClassGroupIds: r,
    sortModifiers: a,
    postfixLookupClassGroupIds: i
  } = t, c = [], l = e.trim().split(sb);
  let u = "";
  for (let m = l.length - 1; m >= 0; m -= 1) {
    const f = l[m], {
      isExternal: p,
      modifiers: h,
      hasImportantModifier: g,
      baseClassName: b,
      maybePostfixModifierPosition: v
    } = n(f);
    if (p) {
      u = f + (u.length > 0 ? " " + u : u);
      continue;
    }
    let x = !!v, y;
    if (x) {
      const E = b.substring(0, v);
      y = o(E);
      const S = y && i[y] ? o(b) : void 0;
      S && S !== y && (y = S, x = !1);
    } else
      y = o(b);
    if (!y) {
      if (!x) {
        u = f + (u.length > 0 ? " " + u : u);
        continue;
      }
      if (y = o(b), !y) {
        u = f + (u.length > 0 ? " " + u : u);
        continue;
      }
      x = !1;
    }
    const w = h.length === 0 ? "" : h.length === 1 ? h[0] : a(h).join(":"), C = g ? w + Vo : w, R = C + y;
    if (c.indexOf(R) > -1)
      continue;
    c.push(R);
    const P = r(y, x);
    for (let E = 0; E < P.length; ++E) {
      const S = P[E];
      c.push(C + S);
    }
    u = f + (u.length > 0 ? " " + u : u);
  }
  return u;
}, lb = (...e) => {
  let t = 0, n, o, r = "";
  for (; t < e.length; )
    (n = e[t++]) && (o = uc(n)) && (r && (r += " "), r += o);
  return r;
}, uc = (e) => {
  if (typeof e == "string")
    return e;
  let t, n = "";
  for (let o = 0; o < e.length; o++)
    e[o] && (t = uc(e[o])) && (n && (n += " "), n += t);
  return n;
}, ub = (e, ...t) => {
  let n, o, r, a;
  const i = (l) => {
    const u = t.reduce((m, f) => f(m), e());
    return n = ab(u), o = n.cache.get, r = n.cache.set, a = c, c(l);
  }, c = (l) => {
    const u = o(l);
    if (u)
      return u;
    const m = cb(l, n);
    return r(l, m), m;
  };
  return a = i, (...l) => a(lb(...l));
}, db = [], ue = (e) => {
  const t = (n) => n[e] || db;
  return t.isThemeGetter = !0, t;
}, dc = /^\[(?:(\w[\w-]*):)?(.+)\]$/i, fc = /^\((?:(\w[\w-]*):)?(.+)\)$/i, fb = /^\d+(?:\.\d+)?\/\d+(?:\.\d+)?$/, pb = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/, mb = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/, hb = /^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/, gb = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/, bb = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/, tt = (e) => fb.test(e), K = (e) => !!e && !Number.isNaN(Number(e)), Le = (e) => !!e && Number.isInteger(Number(e)), go = (e) => e.endsWith("%") && K(e.slice(0, -1)), He = (e) => pb.test(e), pc = () => !0, vb = (e) => (
  // `colorFunctionRegex` check is necessary because color functions can have percentages in them which which would be incorrectly classified as lengths.
  // For example, `hsl(0 0% 0%)` would be classified as a length without this check.
  // I could also use lookbehind assertion in `lengthUnitRegex` but that isn't supported widely enough.
  mb.test(e) && !hb.test(e)
), Vr = () => !1, wb = (e) => gb.test(e), xb = (e) => bb.test(e), yb = (e) => !O(e) && !D(e), Cb = (e) => e.startsWith("@container") && (e[10] === "/" && e[11] !== void 0 || e[11] === "s" && e[16] !== void 0 && e.startsWith("-size/", 10) || e[11] === "n" && e[18] !== void 0 && e.startsWith("-normal/", 10)), Sb = (e) => ct(e, gc, Vr), O = (e) => dc.test(e), ut = (e) => ct(e, bc, vb), Pa = (e) => ct(e, kb, K), Rb = (e) => ct(e, wc, pc), Pb = (e) => ct(e, vc, Vr), Ea = (e) => ct(e, mc, Vr), Eb = (e) => ct(e, hc, xb), pn = (e) => ct(e, xc, wb), D = (e) => fc.test(e), $t = (e) => Ct(e, bc), _b = (e) => Ct(e, vc), _a = (e) => Ct(e, mc), Tb = (e) => Ct(e, gc), Ib = (e) => Ct(e, hc), mn = (e) => Ct(e, xc, !0), Ab = (e) => Ct(e, wc, !0), ct = (e, t, n) => {
  const o = dc.exec(e);
  return o ? o[1] ? t(o[1]) : n(o[2]) : !1;
}, Ct = (e, t, n = !1) => {
  const o = fc.exec(e);
  return o ? o[1] ? t(o[1]) : n : !1;
}, mc = (e) => e === "position" || e === "percentage", hc = (e) => e === "image" || e === "url", gc = (e) => e === "length" || e === "size" || e === "bg-size", bc = (e) => e === "length", kb = (e) => e === "number", vc = (e) => e === "family-name", wc = (e) => e === "number" || e === "weight", xc = (e) => e === "shadow", Mb = () => {
  const e = ue("color"), t = ue("font"), n = ue("text"), o = ue("font-weight"), r = ue("tracking"), a = ue("leading"), i = ue("breakpoint"), c = ue("container"), l = ue("spacing"), u = ue("radius"), m = ue("shadow"), f = ue("inset-shadow"), p = ue("text-shadow"), h = ue("drop-shadow"), g = ue("blur"), b = ue("perspective"), v = ue("aspect"), x = ue("ease"), y = ue("animate"), w = () => ["auto", "avoid", "all", "avoid-page", "page", "left", "right", "column"], C = () => [
    "center",
    "top",
    "bottom",
    "left",
    "right",
    "top-left",
    // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
    "left-top",
    "top-right",
    // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
    "right-top",
    "bottom-right",
    // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
    "right-bottom",
    "bottom-left",
    // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
    "left-bottom"
  ], R = () => [...C(), D, O], P = () => ["auto", "hidden", "clip", "visible", "scroll"], E = () => ["auto", "contain", "none"], S = () => [D, O, l], I = () => [tt, "full", "auto", ...S()], k = () => [Le, "none", "subgrid", D, O], N = () => ["auto", {
    span: ["full", Le, D, O]
  }, Le, D, O], M = () => [Le, "auto", D, O], F = () => ["auto", "min", "max", "fr", D, O], V = () => ["start", "end", "center", "between", "around", "evenly", "stretch", "baseline", "center-safe", "end-safe"], j = () => ["start", "end", "center", "stretch", "center-safe", "end-safe"], B = () => ["auto", ...S()], z = () => [tt, "auto", "full", "dvw", "dvh", "lvw", "lvh", "svw", "svh", "min", "max", "fit", ...S()], W = () => [tt, "screen", "full", "dvw", "lvw", "svw", "min", "max", "fit", ...S()], U = () => [tt, "screen", "full", "lh", "dvh", "lvh", "svh", "min", "max", "fit", ...S()], _ = () => [e, D, O], ce = () => [...C(), _a, Ea, {
    position: [D, O]
  }], ee = () => ["no-repeat", {
    repeat: ["", "x", "y", "space", "round"]
  }], ae = () => ["auto", "cover", "contain", Tb, Sb, {
    size: [D, O]
  }], ge = () => [go, $t, ut], te = () => [
    // Deprecated since Tailwind CSS v4.0.0
    "",
    "none",
    "full",
    u,
    D,
    O
  ], ne = () => ["", K, $t, ut], fe = () => ["solid", "dashed", "dotted", "double"], L = () => ["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "hue", "saturation", "color", "luminosity"], G = () => [K, go, _a, Ea], le = () => [
    // Deprecated since Tailwind CSS v4.0.0
    "",
    "none",
    g,
    D,
    O
  ], Q = () => ["none", K, D, O], J = () => ["none", K, D, O], oe = () => [K, D, O], Se = () => [tt, "full", ...S()];
  return {
    cacheSize: 500,
    theme: {
      animate: ["spin", "ping", "pulse", "bounce"],
      aspect: ["video"],
      blur: [He],
      breakpoint: [He],
      color: [pc],
      container: [He],
      "drop-shadow": [He],
      ease: ["in", "out", "in-out"],
      font: [yb],
      "font-weight": ["thin", "extralight", "light", "normal", "medium", "semibold", "bold", "extrabold", "black"],
      "inset-shadow": [He],
      leading: ["none", "tight", "snug", "normal", "relaxed", "loose"],
      perspective: ["dramatic", "near", "normal", "midrange", "distant", "none"],
      radius: [He],
      shadow: [He],
      spacing: ["px", K],
      text: [He],
      "text-shadow": [He],
      tracking: ["tighter", "tight", "normal", "wide", "wider", "widest"]
    },
    classGroups: {
      // --------------
      // --- Layout ---
      // --------------
      /**
       * Aspect Ratio
       * @see https://tailwindcss.com/docs/aspect-ratio
       */
      aspect: [{
        aspect: ["auto", "square", tt, O, D, v]
      }],
      /**
       * Container
       * @see https://tailwindcss.com/docs/container
       * @deprecated since Tailwind CSS v4.0.0
       */
      container: ["container"],
      /**
       * Container Type
       * @see https://tailwindcss.com/docs/responsive-design#container-queries
       */
      "container-type": [{
        "@container": ["", "normal", "size", D, O]
      }],
      /**
       * Container Name
       * @see https://tailwindcss.com/docs/responsive-design#named-containers
       */
      "container-named": [Cb],
      /**
       * Columns
       * @see https://tailwindcss.com/docs/columns
       */
      columns: [{
        columns: [K, O, D, c]
      }],
      /**
       * Break After
       * @see https://tailwindcss.com/docs/break-after
       */
      "break-after": [{
        "break-after": w()
      }],
      /**
       * Break Before
       * @see https://tailwindcss.com/docs/break-before
       */
      "break-before": [{
        "break-before": w()
      }],
      /**
       * Break Inside
       * @see https://tailwindcss.com/docs/break-inside
       */
      "break-inside": [{
        "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"]
      }],
      /**
       * Box Decoration Break
       * @see https://tailwindcss.com/docs/box-decoration-break
       */
      "box-decoration": [{
        "box-decoration": ["slice", "clone"]
      }],
      /**
       * Box Sizing
       * @see https://tailwindcss.com/docs/box-sizing
       */
      box: [{
        box: ["border", "content"]
      }],
      /**
       * Display
       * @see https://tailwindcss.com/docs/display
       */
      display: ["block", "inline-block", "inline", "flex", "inline-flex", "table", "inline-table", "table-caption", "table-cell", "table-column", "table-column-group", "table-footer-group", "table-header-group", "table-row-group", "table-row", "flow-root", "grid", "inline-grid", "contents", "list-item", "hidden"],
      /**
       * Screen Reader Only
       * @see https://tailwindcss.com/docs/display#screen-reader-only
       */
      sr: ["sr-only", "not-sr-only"],
      /**
       * Floats
       * @see https://tailwindcss.com/docs/float
       */
      float: [{
        float: ["right", "left", "none", "start", "end"]
      }],
      /**
       * Clear
       * @see https://tailwindcss.com/docs/clear
       */
      clear: [{
        clear: ["left", "right", "both", "none", "start", "end"]
      }],
      /**
       * Isolation
       * @see https://tailwindcss.com/docs/isolation
       */
      isolation: ["isolate", "isolation-auto"],
      /**
       * Object Fit
       * @see https://tailwindcss.com/docs/object-fit
       */
      "object-fit": [{
        object: ["contain", "cover", "fill", "none", "scale-down"]
      }],
      /**
       * Object Position
       * @see https://tailwindcss.com/docs/object-position
       */
      "object-position": [{
        object: R()
      }],
      /**
       * Overflow
       * @see https://tailwindcss.com/docs/overflow
       */
      overflow: [{
        overflow: P()
      }],
      /**
       * Overflow X
       * @see https://tailwindcss.com/docs/overflow
       */
      "overflow-x": [{
        "overflow-x": P()
      }],
      /**
       * Overflow Y
       * @see https://tailwindcss.com/docs/overflow
       */
      "overflow-y": [{
        "overflow-y": P()
      }],
      /**
       * Overscroll Behavior
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      overscroll: [{
        overscroll: E()
      }],
      /**
       * Overscroll Behavior X
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      "overscroll-x": [{
        "overscroll-x": E()
      }],
      /**
       * Overscroll Behavior Y
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      "overscroll-y": [{
        "overscroll-y": E()
      }],
      /**
       * Position
       * @see https://tailwindcss.com/docs/position
       */
      position: ["static", "fixed", "absolute", "relative", "sticky"],
      /**
       * Inset
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      inset: [{
        inset: I()
      }],
      /**
       * Inset Inline
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      "inset-x": [{
        "inset-x": I()
      }],
      /**
       * Inset Block
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      "inset-y": [{
        "inset-y": I()
      }],
      /**
       * Inset Inline Start
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       * @todo class group will be renamed to `inset-s` in next major release
       */
      start: [{
        "inset-s": I(),
        /**
         * @deprecated since Tailwind CSS v4.2.0 in favor of `inset-s-*` utilities.
         * @see https://github.com/tailwindlabs/tailwindcss/pull/19613
         */
        start: I()
      }],
      /**
       * Inset Inline End
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       * @todo class group will be renamed to `inset-e` in next major release
       */
      end: [{
        "inset-e": I(),
        /**
         * @deprecated since Tailwind CSS v4.2.0 in favor of `inset-e-*` utilities.
         * @see https://github.com/tailwindlabs/tailwindcss/pull/19613
         */
        end: I()
      }],
      /**
       * Inset Block Start
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      "inset-bs": [{
        "inset-bs": I()
      }],
      /**
       * Inset Block End
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      "inset-be": [{
        "inset-be": I()
      }],
      /**
       * Top
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      top: [{
        top: I()
      }],
      /**
       * Right
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      right: [{
        right: I()
      }],
      /**
       * Bottom
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      bottom: [{
        bottom: I()
      }],
      /**
       * Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      left: [{
        left: I()
      }],
      /**
       * Visibility
       * @see https://tailwindcss.com/docs/visibility
       */
      visibility: ["visible", "invisible", "collapse"],
      /**
       * Z-Index
       * @see https://tailwindcss.com/docs/z-index
       */
      z: [{
        z: [Le, "auto", D, O]
      }],
      // ------------------------
      // --- Flexbox and Grid ---
      // ------------------------
      /**
       * Flex Basis
       * @see https://tailwindcss.com/docs/flex-basis
       */
      basis: [{
        basis: [tt, "full", "auto", c, ...S()]
      }],
      /**
       * Flex Direction
       * @see https://tailwindcss.com/docs/flex-direction
       */
      "flex-direction": [{
        flex: ["row", "row-reverse", "col", "col-reverse"]
      }],
      /**
       * Flex Wrap
       * @see https://tailwindcss.com/docs/flex-wrap
       */
      "flex-wrap": [{
        flex: ["nowrap", "wrap", "wrap-reverse"]
      }],
      /**
       * Flex
       * @see https://tailwindcss.com/docs/flex
       */
      flex: [{
        flex: [K, tt, "auto", "initial", "none", O]
      }],
      /**
       * Flex Grow
       * @see https://tailwindcss.com/docs/flex-grow
       */
      grow: [{
        grow: ["", K, D, O]
      }],
      /**
       * Flex Shrink
       * @see https://tailwindcss.com/docs/flex-shrink
       */
      shrink: [{
        shrink: ["", K, D, O]
      }],
      /**
       * Order
       * @see https://tailwindcss.com/docs/order
       */
      order: [{
        order: [Le, "first", "last", "none", D, O]
      }],
      /**
       * Grid Template Columns
       * @see https://tailwindcss.com/docs/grid-template-columns
       */
      "grid-cols": [{
        "grid-cols": k()
      }],
      /**
       * Grid Column Start / End
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-start-end": [{
        col: N()
      }],
      /**
       * Grid Column Start
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-start": [{
        "col-start": M()
      }],
      /**
       * Grid Column End
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-end": [{
        "col-end": M()
      }],
      /**
       * Grid Template Rows
       * @see https://tailwindcss.com/docs/grid-template-rows
       */
      "grid-rows": [{
        "grid-rows": k()
      }],
      /**
       * Grid Row Start / End
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-start-end": [{
        row: N()
      }],
      /**
       * Grid Row Start
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-start": [{
        "row-start": M()
      }],
      /**
       * Grid Row End
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-end": [{
        "row-end": M()
      }],
      /**
       * Grid Auto Flow
       * @see https://tailwindcss.com/docs/grid-auto-flow
       */
      "grid-flow": [{
        "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"]
      }],
      /**
       * Grid Auto Columns
       * @see https://tailwindcss.com/docs/grid-auto-columns
       */
      "auto-cols": [{
        "auto-cols": F()
      }],
      /**
       * Grid Auto Rows
       * @see https://tailwindcss.com/docs/grid-auto-rows
       */
      "auto-rows": [{
        "auto-rows": F()
      }],
      /**
       * Gap
       * @see https://tailwindcss.com/docs/gap
       */
      gap: [{
        gap: S()
      }],
      /**
       * Gap X
       * @see https://tailwindcss.com/docs/gap
       */
      "gap-x": [{
        "gap-x": S()
      }],
      /**
       * Gap Y
       * @see https://tailwindcss.com/docs/gap
       */
      "gap-y": [{
        "gap-y": S()
      }],
      /**
       * Justify Content
       * @see https://tailwindcss.com/docs/justify-content
       */
      "justify-content": [{
        justify: [...V(), "normal"]
      }],
      /**
       * Justify Items
       * @see https://tailwindcss.com/docs/justify-items
       */
      "justify-items": [{
        "justify-items": [...j(), "normal"]
      }],
      /**
       * Justify Self
       * @see https://tailwindcss.com/docs/justify-self
       */
      "justify-self": [{
        "justify-self": ["auto", ...j()]
      }],
      /**
       * Align Content
       * @see https://tailwindcss.com/docs/align-content
       */
      "align-content": [{
        content: ["normal", ...V()]
      }],
      /**
       * Align Items
       * @see https://tailwindcss.com/docs/align-items
       */
      "align-items": [{
        items: [...j(), {
          baseline: ["", "last"]
        }]
      }],
      /**
       * Align Self
       * @see https://tailwindcss.com/docs/align-self
       */
      "align-self": [{
        self: ["auto", ...j(), {
          baseline: ["", "last"]
        }]
      }],
      /**
       * Place Content
       * @see https://tailwindcss.com/docs/place-content
       */
      "place-content": [{
        "place-content": V()
      }],
      /**
       * Place Items
       * @see https://tailwindcss.com/docs/place-items
       */
      "place-items": [{
        "place-items": [...j(), "baseline"]
      }],
      /**
       * Place Self
       * @see https://tailwindcss.com/docs/place-self
       */
      "place-self": [{
        "place-self": ["auto", ...j()]
      }],
      // Spacing
      /**
       * Padding
       * @see https://tailwindcss.com/docs/padding
       */
      p: [{
        p: S()
      }],
      /**
       * Padding Inline
       * @see https://tailwindcss.com/docs/padding
       */
      px: [{
        px: S()
      }],
      /**
       * Padding Block
       * @see https://tailwindcss.com/docs/padding
       */
      py: [{
        py: S()
      }],
      /**
       * Padding Inline Start
       * @see https://tailwindcss.com/docs/padding
       */
      ps: [{
        ps: S()
      }],
      /**
       * Padding Inline End
       * @see https://tailwindcss.com/docs/padding
       */
      pe: [{
        pe: S()
      }],
      /**
       * Padding Block Start
       * @see https://tailwindcss.com/docs/padding
       */
      pbs: [{
        pbs: S()
      }],
      /**
       * Padding Block End
       * @see https://tailwindcss.com/docs/padding
       */
      pbe: [{
        pbe: S()
      }],
      /**
       * Padding Top
       * @see https://tailwindcss.com/docs/padding
       */
      pt: [{
        pt: S()
      }],
      /**
       * Padding Right
       * @see https://tailwindcss.com/docs/padding
       */
      pr: [{
        pr: S()
      }],
      /**
       * Padding Bottom
       * @see https://tailwindcss.com/docs/padding
       */
      pb: [{
        pb: S()
      }],
      /**
       * Padding Left
       * @see https://tailwindcss.com/docs/padding
       */
      pl: [{
        pl: S()
      }],
      /**
       * Margin
       * @see https://tailwindcss.com/docs/margin
       */
      m: [{
        m: B()
      }],
      /**
       * Margin Inline
       * @see https://tailwindcss.com/docs/margin
       */
      mx: [{
        mx: B()
      }],
      /**
       * Margin Block
       * @see https://tailwindcss.com/docs/margin
       */
      my: [{
        my: B()
      }],
      /**
       * Margin Inline Start
       * @see https://tailwindcss.com/docs/margin
       */
      ms: [{
        ms: B()
      }],
      /**
       * Margin Inline End
       * @see https://tailwindcss.com/docs/margin
       */
      me: [{
        me: B()
      }],
      /**
       * Margin Block Start
       * @see https://tailwindcss.com/docs/margin
       */
      mbs: [{
        mbs: B()
      }],
      /**
       * Margin Block End
       * @see https://tailwindcss.com/docs/margin
       */
      mbe: [{
        mbe: B()
      }],
      /**
       * Margin Top
       * @see https://tailwindcss.com/docs/margin
       */
      mt: [{
        mt: B()
      }],
      /**
       * Margin Right
       * @see https://tailwindcss.com/docs/margin
       */
      mr: [{
        mr: B()
      }],
      /**
       * Margin Bottom
       * @see https://tailwindcss.com/docs/margin
       */
      mb: [{
        mb: B()
      }],
      /**
       * Margin Left
       * @see https://tailwindcss.com/docs/margin
       */
      ml: [{
        ml: B()
      }],
      /**
       * Space Between X
       * @see https://tailwindcss.com/docs/margin#adding-space-between-children
       */
      "space-x": [{
        "space-x": S()
      }],
      /**
       * Space Between X Reverse
       * @see https://tailwindcss.com/docs/margin#adding-space-between-children
       */
      "space-x-reverse": ["space-x-reverse"],
      /**
       * Space Between Y
       * @see https://tailwindcss.com/docs/margin#adding-space-between-children
       */
      "space-y": [{
        "space-y": S()
      }],
      /**
       * Space Between Y Reverse
       * @see https://tailwindcss.com/docs/margin#adding-space-between-children
       */
      "space-y-reverse": ["space-y-reverse"],
      // --------------
      // --- Sizing ---
      // --------------
      /**
       * Size
       * @see https://tailwindcss.com/docs/width#setting-both-width-and-height
       */
      size: [{
        size: z()
      }],
      /**
       * Inline Size
       * @see https://tailwindcss.com/docs/width
       */
      "inline-size": [{
        inline: ["auto", ...W()]
      }],
      /**
       * Min-Inline Size
       * @see https://tailwindcss.com/docs/min-width
       */
      "min-inline-size": [{
        "min-inline": ["auto", ...W()]
      }],
      /**
       * Max-Inline Size
       * @see https://tailwindcss.com/docs/max-width
       */
      "max-inline-size": [{
        "max-inline": ["none", ...W()]
      }],
      /**
       * Block Size
       * @see https://tailwindcss.com/docs/height
       */
      "block-size": [{
        block: ["auto", ...U()]
      }],
      /**
       * Min-Block Size
       * @see https://tailwindcss.com/docs/min-height
       */
      "min-block-size": [{
        "min-block": ["auto", ...U()]
      }],
      /**
       * Max-Block Size
       * @see https://tailwindcss.com/docs/max-height
       */
      "max-block-size": [{
        "max-block": ["none", ...U()]
      }],
      /**
       * Width
       * @see https://tailwindcss.com/docs/width
       */
      w: [{
        w: [c, "screen", ...z()]
      }],
      /**
       * Min-Width
       * @see https://tailwindcss.com/docs/min-width
       */
      "min-w": [{
        "min-w": [
          c,
          "screen",
          /** Deprecated. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */
          "none",
          ...z()
        ]
      }],
      /**
       * Max-Width
       * @see https://tailwindcss.com/docs/max-width
       */
      "max-w": [{
        "max-w": [
          c,
          "screen",
          "none",
          /** Deprecated since Tailwind CSS v4.0.0. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */
          "prose",
          /** Deprecated since Tailwind CSS v4.0.0. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */
          {
            screen: [i]
          },
          ...z()
        ]
      }],
      /**
       * Height
       * @see https://tailwindcss.com/docs/height
       */
      h: [{
        h: ["screen", "lh", ...z()]
      }],
      /**
       * Min-Height
       * @see https://tailwindcss.com/docs/min-height
       */
      "min-h": [{
        "min-h": ["screen", "lh", "none", ...z()]
      }],
      /**
       * Max-Height
       * @see https://tailwindcss.com/docs/max-height
       */
      "max-h": [{
        "max-h": ["screen", "lh", ...z()]
      }],
      // ------------------
      // --- Typography ---
      // ------------------
      /**
       * Font Size
       * @see https://tailwindcss.com/docs/font-size
       */
      "font-size": [{
        text: ["base", n, $t, ut]
      }],
      /**
       * Font Smoothing
       * @see https://tailwindcss.com/docs/font-smoothing
       */
      "font-smoothing": ["antialiased", "subpixel-antialiased"],
      /**
       * Font Style
       * @see https://tailwindcss.com/docs/font-style
       */
      "font-style": ["italic", "not-italic"],
      /**
       * Font Weight
       * @see https://tailwindcss.com/docs/font-weight
       */
      "font-weight": [{
        font: [o, Ab, Rb]
      }],
      /**
       * Font Stretch
       * @see https://tailwindcss.com/docs/font-stretch
       */
      "font-stretch": [{
        "font-stretch": ["ultra-condensed", "extra-condensed", "condensed", "semi-condensed", "normal", "semi-expanded", "expanded", "extra-expanded", "ultra-expanded", go, O]
      }],
      /**
       * Font Family
       * @see https://tailwindcss.com/docs/font-family
       */
      "font-family": [{
        font: [_b, Pb, t]
      }],
      /**
       * Font Feature Settings
       * @see https://tailwindcss.com/docs/font-feature-settings
       */
      "font-features": [{
        "font-features": [O]
      }],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-normal": ["normal-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-ordinal": ["ordinal"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-slashed-zero": ["slashed-zero"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-figure": ["lining-nums", "oldstyle-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-spacing": ["proportional-nums", "tabular-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-fraction": ["diagonal-fractions", "stacked-fractions"],
      /**
       * Letter Spacing
       * @see https://tailwindcss.com/docs/letter-spacing
       */
      tracking: [{
        tracking: [r, D, O]
      }],
      /**
       * Line Clamp
       * @see https://tailwindcss.com/docs/line-clamp
       */
      "line-clamp": [{
        "line-clamp": [K, "none", D, Pa]
      }],
      /**
       * Line Height
       * @see https://tailwindcss.com/docs/line-height
       */
      leading: [{
        leading: [
          /** Deprecated since Tailwind CSS v4.0.0. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */
          a,
          ...S()
        ]
      }],
      /**
       * List Style Image
       * @see https://tailwindcss.com/docs/list-style-image
       */
      "list-image": [{
        "list-image": ["none", D, O]
      }],
      /**
       * List Style Position
       * @see https://tailwindcss.com/docs/list-style-position
       */
      "list-style-position": [{
        list: ["inside", "outside"]
      }],
      /**
       * List Style Type
       * @see https://tailwindcss.com/docs/list-style-type
       */
      "list-style-type": [{
        list: ["disc", "decimal", "none", D, O]
      }],
      /**
       * Text Alignment
       * @see https://tailwindcss.com/docs/text-align
       */
      "text-alignment": [{
        text: ["left", "center", "right", "justify", "start", "end"]
      }],
      /**
       * Placeholder Color
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://v3.tailwindcss.com/docs/placeholder-color
       */
      "placeholder-color": [{
        placeholder: _()
      }],
      /**
       * Text Color
       * @see https://tailwindcss.com/docs/text-color
       */
      "text-color": [{
        text: _()
      }],
      /**
       * Text Decoration
       * @see https://tailwindcss.com/docs/text-decoration
       */
      "text-decoration": ["underline", "overline", "line-through", "no-underline"],
      /**
       * Text Decoration Style
       * @see https://tailwindcss.com/docs/text-decoration-style
       */
      "text-decoration-style": [{
        decoration: [...fe(), "wavy"]
      }],
      /**
       * Text Decoration Thickness
       * @see https://tailwindcss.com/docs/text-decoration-thickness
       */
      "text-decoration-thickness": [{
        decoration: [K, "from-font", "auto", D, ut]
      }],
      /**
       * Text Decoration Color
       * @see https://tailwindcss.com/docs/text-decoration-color
       */
      "text-decoration-color": [{
        decoration: _()
      }],
      /**
       * Text Underline Offset
       * @see https://tailwindcss.com/docs/text-underline-offset
       */
      "underline-offset": [{
        "underline-offset": [K, "auto", D, O]
      }],
      /**
       * Text Transform
       * @see https://tailwindcss.com/docs/text-transform
       */
      "text-transform": ["uppercase", "lowercase", "capitalize", "normal-case"],
      /**
       * Text Overflow
       * @see https://tailwindcss.com/docs/text-overflow
       */
      "text-overflow": ["truncate", "text-ellipsis", "text-clip"],
      /**
       * Text Wrap
       * @see https://tailwindcss.com/docs/text-wrap
       */
      "text-wrap": [{
        text: ["wrap", "nowrap", "balance", "pretty"]
      }],
      /**
       * Text Indent
       * @see https://tailwindcss.com/docs/text-indent
       */
      indent: [{
        indent: S()
      }],
      /**
       * Tab Size
       * @see https://tailwindcss.com/docs/tab-size
       */
      "tab-size": [{
        tab: [Le, D, O]
      }],
      /**
       * Vertical Alignment
       * @see https://tailwindcss.com/docs/vertical-align
       */
      "vertical-align": [{
        align: ["baseline", "top", "middle", "bottom", "text-top", "text-bottom", "sub", "super", D, O]
      }],
      /**
       * Whitespace
       * @see https://tailwindcss.com/docs/whitespace
       */
      whitespace: [{
        whitespace: ["normal", "nowrap", "pre", "pre-line", "pre-wrap", "break-spaces"]
      }],
      /**
       * Word Break
       * @see https://tailwindcss.com/docs/word-break
       */
      break: [{
        break: ["normal", "words", "all", "keep"]
      }],
      /**
       * Overflow Wrap
       * @see https://tailwindcss.com/docs/overflow-wrap
       */
      wrap: [{
        wrap: ["break-word", "anywhere", "normal"]
      }],
      /**
       * Hyphens
       * @see https://tailwindcss.com/docs/hyphens
       */
      hyphens: [{
        hyphens: ["none", "manual", "auto"]
      }],
      /**
       * Content
       * @see https://tailwindcss.com/docs/content
       */
      content: [{
        content: ["none", D, O]
      }],
      // -------------------
      // --- Backgrounds ---
      // -------------------
      /**
       * Background Attachment
       * @see https://tailwindcss.com/docs/background-attachment
       */
      "bg-attachment": [{
        bg: ["fixed", "local", "scroll"]
      }],
      /**
       * Background Clip
       * @see https://tailwindcss.com/docs/background-clip
       */
      "bg-clip": [{
        "bg-clip": ["border", "padding", "content", "text"]
      }],
      /**
       * Background Origin
       * @see https://tailwindcss.com/docs/background-origin
       */
      "bg-origin": [{
        "bg-origin": ["border", "padding", "content"]
      }],
      /**
       * Background Position
       * @see https://tailwindcss.com/docs/background-position
       */
      "bg-position": [{
        bg: ce()
      }],
      /**
       * Background Repeat
       * @see https://tailwindcss.com/docs/background-repeat
       */
      "bg-repeat": [{
        bg: ee()
      }],
      /**
       * Background Size
       * @see https://tailwindcss.com/docs/background-size
       */
      "bg-size": [{
        bg: ae()
      }],
      /**
       * Background Image
       * @see https://tailwindcss.com/docs/background-image
       */
      "bg-image": [{
        bg: ["none", {
          linear: [{
            to: ["t", "tr", "r", "br", "b", "bl", "l", "tl"]
          }, Le, D, O],
          radial: ["", D, O],
          conic: [Le, D, O]
        }, Ib, Eb]
      }],
      /**
       * Background Color
       * @see https://tailwindcss.com/docs/background-color
       */
      "bg-color": [{
        bg: _()
      }],
      /**
       * Gradient Color Stops From Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-from-pos": [{
        from: ge()
      }],
      /**
       * Gradient Color Stops Via Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-via-pos": [{
        via: ge()
      }],
      /**
       * Gradient Color Stops To Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-to-pos": [{
        to: ge()
      }],
      /**
       * Gradient Color Stops From
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-from": [{
        from: _()
      }],
      /**
       * Gradient Color Stops Via
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-via": [{
        via: _()
      }],
      /**
       * Gradient Color Stops To
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-to": [{
        to: _()
      }],
      // ---------------
      // --- Borders ---
      // ---------------
      /**
       * Border Radius
       * @see https://tailwindcss.com/docs/border-radius
       */
      rounded: [{
        rounded: te()
      }],
      /**
       * Border Radius Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-s": [{
        "rounded-s": te()
      }],
      /**
       * Border Radius End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-e": [{
        "rounded-e": te()
      }],
      /**
       * Border Radius Top
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-t": [{
        "rounded-t": te()
      }],
      /**
       * Border Radius Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-r": [{
        "rounded-r": te()
      }],
      /**
       * Border Radius Bottom
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-b": [{
        "rounded-b": te()
      }],
      /**
       * Border Radius Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-l": [{
        "rounded-l": te()
      }],
      /**
       * Border Radius Start Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-ss": [{
        "rounded-ss": te()
      }],
      /**
       * Border Radius Start End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-se": [{
        "rounded-se": te()
      }],
      /**
       * Border Radius End End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-ee": [{
        "rounded-ee": te()
      }],
      /**
       * Border Radius End Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-es": [{
        "rounded-es": te()
      }],
      /**
       * Border Radius Top Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-tl": [{
        "rounded-tl": te()
      }],
      /**
       * Border Radius Top Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-tr": [{
        "rounded-tr": te()
      }],
      /**
       * Border Radius Bottom Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-br": [{
        "rounded-br": te()
      }],
      /**
       * Border Radius Bottom Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-bl": [{
        "rounded-bl": te()
      }],
      /**
       * Border Width
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w": [{
        border: ne()
      }],
      /**
       * Border Width Inline
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-x": [{
        "border-x": ne()
      }],
      /**
       * Border Width Block
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-y": [{
        "border-y": ne()
      }],
      /**
       * Border Width Inline Start
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-s": [{
        "border-s": ne()
      }],
      /**
       * Border Width Inline End
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-e": [{
        "border-e": ne()
      }],
      /**
       * Border Width Block Start
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-bs": [{
        "border-bs": ne()
      }],
      /**
       * Border Width Block End
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-be": [{
        "border-be": ne()
      }],
      /**
       * Border Width Top
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-t": [{
        "border-t": ne()
      }],
      /**
       * Border Width Right
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-r": [{
        "border-r": ne()
      }],
      /**
       * Border Width Bottom
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-b": [{
        "border-b": ne()
      }],
      /**
       * Border Width Left
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-l": [{
        "border-l": ne()
      }],
      /**
       * Divide Width X
       * @see https://tailwindcss.com/docs/border-width#between-children
       */
      "divide-x": [{
        "divide-x": ne()
      }],
      /**
       * Divide Width X Reverse
       * @see https://tailwindcss.com/docs/border-width#between-children
       */
      "divide-x-reverse": ["divide-x-reverse"],
      /**
       * Divide Width Y
       * @see https://tailwindcss.com/docs/border-width#between-children
       */
      "divide-y": [{
        "divide-y": ne()
      }],
      /**
       * Divide Width Y Reverse
       * @see https://tailwindcss.com/docs/border-width#between-children
       */
      "divide-y-reverse": ["divide-y-reverse"],
      /**
       * Border Style
       * @see https://tailwindcss.com/docs/border-style
       */
      "border-style": [{
        border: [...fe(), "hidden", "none"]
      }],
      /**
       * Divide Style
       * @see https://tailwindcss.com/docs/border-style#setting-the-divider-style
       */
      "divide-style": [{
        divide: [...fe(), "hidden", "none"]
      }],
      /**
       * Border Color
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color": [{
        border: _()
      }],
      /**
       * Border Color Inline
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-x": [{
        "border-x": _()
      }],
      /**
       * Border Color Block
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-y": [{
        "border-y": _()
      }],
      /**
       * Border Color Inline Start
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-s": [{
        "border-s": _()
      }],
      /**
       * Border Color Inline End
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-e": [{
        "border-e": _()
      }],
      /**
       * Border Color Block Start
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-bs": [{
        "border-bs": _()
      }],
      /**
       * Border Color Block End
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-be": [{
        "border-be": _()
      }],
      /**
       * Border Color Top
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-t": [{
        "border-t": _()
      }],
      /**
       * Border Color Right
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-r": [{
        "border-r": _()
      }],
      /**
       * Border Color Bottom
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-b": [{
        "border-b": _()
      }],
      /**
       * Border Color Left
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-l": [{
        "border-l": _()
      }],
      /**
       * Divide Color
       * @see https://tailwindcss.com/docs/divide-color
       */
      "divide-color": [{
        divide: _()
      }],
      /**
       * Outline Style
       * @see https://tailwindcss.com/docs/outline-style
       */
      "outline-style": [{
        outline: [...fe(), "none", "hidden"]
      }],
      /**
       * Outline Offset
       * @see https://tailwindcss.com/docs/outline-offset
       */
      "outline-offset": [{
        "outline-offset": [K, D, O]
      }],
      /**
       * Outline Width
       * @see https://tailwindcss.com/docs/outline-width
       */
      "outline-w": [{
        outline: ["", K, $t, ut]
      }],
      /**
       * Outline Color
       * @see https://tailwindcss.com/docs/outline-color
       */
      "outline-color": [{
        outline: _()
      }],
      // ---------------
      // --- Effects ---
      // ---------------
      /**
       * Box Shadow
       * @see https://tailwindcss.com/docs/box-shadow
       */
      shadow: [{
        shadow: [
          // Deprecated since Tailwind CSS v4.0.0
          "",
          "none",
          m,
          mn,
          pn
        ]
      }],
      /**
       * Box Shadow Color
       * @see https://tailwindcss.com/docs/box-shadow#setting-the-shadow-color
       */
      "shadow-color": [{
        shadow: _()
      }],
      /**
       * Inset Box Shadow
       * @see https://tailwindcss.com/docs/box-shadow#adding-an-inset-shadow
       */
      "inset-shadow": [{
        "inset-shadow": ["none", f, mn, pn]
      }],
      /**
       * Inset Box Shadow Color
       * @see https://tailwindcss.com/docs/box-shadow#setting-the-inset-shadow-color
       */
      "inset-shadow-color": [{
        "inset-shadow": _()
      }],
      /**
       * Ring Width
       * @see https://tailwindcss.com/docs/box-shadow#adding-a-ring
       */
      "ring-w": [{
        ring: ne()
      }],
      /**
       * Ring Width Inset
       * @see https://v3.tailwindcss.com/docs/ring-width#inset-rings
       * @deprecated since Tailwind CSS v4.0.0
       * @see https://github.com/tailwindlabs/tailwindcss/blob/v4.0.0/packages/tailwindcss/src/utilities.ts#L4158
       */
      "ring-w-inset": ["ring-inset"],
      /**
       * Ring Color
       * @see https://tailwindcss.com/docs/box-shadow#setting-the-ring-color
       */
      "ring-color": [{
        ring: _()
      }],
      /**
       * Ring Offset Width
       * @see https://v3.tailwindcss.com/docs/ring-offset-width
       * @deprecated since Tailwind CSS v4.0.0
       * @see https://github.com/tailwindlabs/tailwindcss/blob/v4.0.0/packages/tailwindcss/src/utilities.ts#L4158
       */
      "ring-offset-w": [{
        "ring-offset": [K, ut]
      }],
      /**
       * Ring Offset Color
       * @see https://v3.tailwindcss.com/docs/ring-offset-color
       * @deprecated since Tailwind CSS v4.0.0
       * @see https://github.com/tailwindlabs/tailwindcss/blob/v4.0.0/packages/tailwindcss/src/utilities.ts#L4158
       */
      "ring-offset-color": [{
        "ring-offset": _()
      }],
      /**
       * Inset Ring Width
       * @see https://tailwindcss.com/docs/box-shadow#adding-an-inset-ring
       */
      "inset-ring-w": [{
        "inset-ring": ne()
      }],
      /**
       * Inset Ring Color
       * @see https://tailwindcss.com/docs/box-shadow#setting-the-inset-ring-color
       */
      "inset-ring-color": [{
        "inset-ring": _()
      }],
      /**
       * Text Shadow
       * @see https://tailwindcss.com/docs/text-shadow
       */
      "text-shadow": [{
        "text-shadow": ["none", p, mn, pn]
      }],
      /**
       * Text Shadow Color
       * @see https://tailwindcss.com/docs/text-shadow#setting-the-shadow-color
       */
      "text-shadow-color": [{
        "text-shadow": _()
      }],
      /**
       * Opacity
       * @see https://tailwindcss.com/docs/opacity
       */
      opacity: [{
        opacity: [K, D, O]
      }],
      /**
       * Mix Blend Mode
       * @see https://tailwindcss.com/docs/mix-blend-mode
       */
      "mix-blend": [{
        "mix-blend": [...L(), "plus-darker", "plus-lighter"]
      }],
      /**
       * Background Blend Mode
       * @see https://tailwindcss.com/docs/background-blend-mode
       */
      "bg-blend": [{
        "bg-blend": L()
      }],
      /**
       * Mask Clip
       * @see https://tailwindcss.com/docs/mask-clip
       */
      "mask-clip": [{
        "mask-clip": ["border", "padding", "content", "fill", "stroke", "view"]
      }, "mask-no-clip"],
      /**
       * Mask Composite
       * @see https://tailwindcss.com/docs/mask-composite
       */
      "mask-composite": [{
        mask: ["add", "subtract", "intersect", "exclude"]
      }],
      /**
       * Mask Image
       * @see https://tailwindcss.com/docs/mask-image
       */
      "mask-image-linear-pos": [{
        "mask-linear": [K]
      }],
      "mask-image-linear-from-pos": [{
        "mask-linear-from": G()
      }],
      "mask-image-linear-to-pos": [{
        "mask-linear-to": G()
      }],
      "mask-image-linear-from-color": [{
        "mask-linear-from": _()
      }],
      "mask-image-linear-to-color": [{
        "mask-linear-to": _()
      }],
      "mask-image-t-from-pos": [{
        "mask-t-from": G()
      }],
      "mask-image-t-to-pos": [{
        "mask-t-to": G()
      }],
      "mask-image-t-from-color": [{
        "mask-t-from": _()
      }],
      "mask-image-t-to-color": [{
        "mask-t-to": _()
      }],
      "mask-image-r-from-pos": [{
        "mask-r-from": G()
      }],
      "mask-image-r-to-pos": [{
        "mask-r-to": G()
      }],
      "mask-image-r-from-color": [{
        "mask-r-from": _()
      }],
      "mask-image-r-to-color": [{
        "mask-r-to": _()
      }],
      "mask-image-b-from-pos": [{
        "mask-b-from": G()
      }],
      "mask-image-b-to-pos": [{
        "mask-b-to": G()
      }],
      "mask-image-b-from-color": [{
        "mask-b-from": _()
      }],
      "mask-image-b-to-color": [{
        "mask-b-to": _()
      }],
      "mask-image-l-from-pos": [{
        "mask-l-from": G()
      }],
      "mask-image-l-to-pos": [{
        "mask-l-to": G()
      }],
      "mask-image-l-from-color": [{
        "mask-l-from": _()
      }],
      "mask-image-l-to-color": [{
        "mask-l-to": _()
      }],
      "mask-image-x-from-pos": [{
        "mask-x-from": G()
      }],
      "mask-image-x-to-pos": [{
        "mask-x-to": G()
      }],
      "mask-image-x-from-color": [{
        "mask-x-from": _()
      }],
      "mask-image-x-to-color": [{
        "mask-x-to": _()
      }],
      "mask-image-y-from-pos": [{
        "mask-y-from": G()
      }],
      "mask-image-y-to-pos": [{
        "mask-y-to": G()
      }],
      "mask-image-y-from-color": [{
        "mask-y-from": _()
      }],
      "mask-image-y-to-color": [{
        "mask-y-to": _()
      }],
      "mask-image-radial": [{
        "mask-radial": [D, O]
      }],
      "mask-image-radial-from-pos": [{
        "mask-radial-from": G()
      }],
      "mask-image-radial-to-pos": [{
        "mask-radial-to": G()
      }],
      "mask-image-radial-from-color": [{
        "mask-radial-from": _()
      }],
      "mask-image-radial-to-color": [{
        "mask-radial-to": _()
      }],
      "mask-image-radial-shape": [{
        "mask-radial": ["circle", "ellipse"]
      }],
      "mask-image-radial-size": [{
        "mask-radial": [{
          closest: ["side", "corner"],
          farthest: ["side", "corner"]
        }]
      }],
      "mask-image-radial-pos": [{
        "mask-radial-at": C()
      }],
      "mask-image-conic-pos": [{
        "mask-conic": [K]
      }],
      "mask-image-conic-from-pos": [{
        "mask-conic-from": G()
      }],
      "mask-image-conic-to-pos": [{
        "mask-conic-to": G()
      }],
      "mask-image-conic-from-color": [{
        "mask-conic-from": _()
      }],
      "mask-image-conic-to-color": [{
        "mask-conic-to": _()
      }],
      /**
       * Mask Mode
       * @see https://tailwindcss.com/docs/mask-mode
       */
      "mask-mode": [{
        mask: ["alpha", "luminance", "match"]
      }],
      /**
       * Mask Origin
       * @see https://tailwindcss.com/docs/mask-origin
       */
      "mask-origin": [{
        "mask-origin": ["border", "padding", "content", "fill", "stroke", "view"]
      }],
      /**
       * Mask Position
       * @see https://tailwindcss.com/docs/mask-position
       */
      "mask-position": [{
        mask: ce()
      }],
      /**
       * Mask Repeat
       * @see https://tailwindcss.com/docs/mask-repeat
       */
      "mask-repeat": [{
        mask: ee()
      }],
      /**
       * Mask Size
       * @see https://tailwindcss.com/docs/mask-size
       */
      "mask-size": [{
        mask: ae()
      }],
      /**
       * Mask Type
       * @see https://tailwindcss.com/docs/mask-type
       */
      "mask-type": [{
        "mask-type": ["alpha", "luminance"]
      }],
      /**
       * Mask Image
       * @see https://tailwindcss.com/docs/mask-image
       */
      "mask-image": [{
        mask: ["none", D, O]
      }],
      // ---------------
      // --- Filters ---
      // ---------------
      /**
       * Filter
       * @see https://tailwindcss.com/docs/filter
       */
      filter: [{
        filter: [
          // Deprecated since Tailwind CSS v3.0.0
          "",
          "none",
          D,
          O
        ]
      }],
      /**
       * Blur
       * @see https://tailwindcss.com/docs/blur
       */
      blur: [{
        blur: le()
      }],
      /**
       * Brightness
       * @see https://tailwindcss.com/docs/brightness
       */
      brightness: [{
        brightness: [K, D, O]
      }],
      /**
       * Contrast
       * @see https://tailwindcss.com/docs/contrast
       */
      contrast: [{
        contrast: [K, D, O]
      }],
      /**
       * Drop Shadow
       * @see https://tailwindcss.com/docs/drop-shadow
       */
      "drop-shadow": [{
        "drop-shadow": [
          // Deprecated since Tailwind CSS v4.0.0
          "",
          "none",
          h,
          mn,
          pn
        ]
      }],
      /**
       * Drop Shadow Color
       * @see https://tailwindcss.com/docs/filter-drop-shadow#setting-the-shadow-color
       */
      "drop-shadow-color": [{
        "drop-shadow": _()
      }],
      /**
       * Grayscale
       * @see https://tailwindcss.com/docs/grayscale
       */
      grayscale: [{
        grayscale: ["", K, D, O]
      }],
      /**
       * Hue Rotate
       * @see https://tailwindcss.com/docs/hue-rotate
       */
      "hue-rotate": [{
        "hue-rotate": [K, D, O]
      }],
      /**
       * Invert
       * @see https://tailwindcss.com/docs/invert
       */
      invert: [{
        invert: ["", K, D, O]
      }],
      /**
       * Saturate
       * @see https://tailwindcss.com/docs/saturate
       */
      saturate: [{
        saturate: [K, D, O]
      }],
      /**
       * Sepia
       * @see https://tailwindcss.com/docs/sepia
       */
      sepia: [{
        sepia: ["", K, D, O]
      }],
      /**
       * Backdrop Filter
       * @see https://tailwindcss.com/docs/backdrop-filter
       */
      "backdrop-filter": [{
        "backdrop-filter": [
          // Deprecated since Tailwind CSS v3.0.0
          "",
          "none",
          D,
          O
        ]
      }],
      /**
       * Backdrop Blur
       * @see https://tailwindcss.com/docs/backdrop-blur
       */
      "backdrop-blur": [{
        "backdrop-blur": le()
      }],
      /**
       * Backdrop Brightness
       * @see https://tailwindcss.com/docs/backdrop-brightness
       */
      "backdrop-brightness": [{
        "backdrop-brightness": [K, D, O]
      }],
      /**
       * Backdrop Contrast
       * @see https://tailwindcss.com/docs/backdrop-contrast
       */
      "backdrop-contrast": [{
        "backdrop-contrast": [K, D, O]
      }],
      /**
       * Backdrop Grayscale
       * @see https://tailwindcss.com/docs/backdrop-grayscale
       */
      "backdrop-grayscale": [{
        "backdrop-grayscale": ["", K, D, O]
      }],
      /**
       * Backdrop Hue Rotate
       * @see https://tailwindcss.com/docs/backdrop-hue-rotate
       */
      "backdrop-hue-rotate": [{
        "backdrop-hue-rotate": [K, D, O]
      }],
      /**
       * Backdrop Invert
       * @see https://tailwindcss.com/docs/backdrop-invert
       */
      "backdrop-invert": [{
        "backdrop-invert": ["", K, D, O]
      }],
      /**
       * Backdrop Opacity
       * @see https://tailwindcss.com/docs/backdrop-opacity
       */
      "backdrop-opacity": [{
        "backdrop-opacity": [K, D, O]
      }],
      /**
       * Backdrop Saturate
       * @see https://tailwindcss.com/docs/backdrop-saturate
       */
      "backdrop-saturate": [{
        "backdrop-saturate": [K, D, O]
      }],
      /**
       * Backdrop Sepia
       * @see https://tailwindcss.com/docs/backdrop-sepia
       */
      "backdrop-sepia": [{
        "backdrop-sepia": ["", K, D, O]
      }],
      // --------------
      // --- Tables ---
      // --------------
      /**
       * Border Collapse
       * @see https://tailwindcss.com/docs/border-collapse
       */
      "border-collapse": [{
        border: ["collapse", "separate"]
      }],
      /**
       * Border Spacing
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing": [{
        "border-spacing": S()
      }],
      /**
       * Border Spacing X
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing-x": [{
        "border-spacing-x": S()
      }],
      /**
       * Border Spacing Y
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing-y": [{
        "border-spacing-y": S()
      }],
      /**
       * Table Layout
       * @see https://tailwindcss.com/docs/table-layout
       */
      "table-layout": [{
        table: ["auto", "fixed"]
      }],
      /**
       * Caption Side
       * @see https://tailwindcss.com/docs/caption-side
       */
      caption: [{
        caption: ["top", "bottom"]
      }],
      // ---------------------------------
      // --- Transitions and Animation ---
      // ---------------------------------
      /**
       * Transition Property
       * @see https://tailwindcss.com/docs/transition-property
       */
      transition: [{
        transition: ["", "all", "colors", "opacity", "shadow", "transform", "none", D, O]
      }],
      /**
       * Transition Behavior
       * @see https://tailwindcss.com/docs/transition-behavior
       */
      "transition-behavior": [{
        transition: ["normal", "discrete"]
      }],
      /**
       * Transition Duration
       * @see https://tailwindcss.com/docs/transition-duration
       */
      duration: [{
        duration: [K, "initial", D, O]
      }],
      /**
       * Transition Timing Function
       * @see https://tailwindcss.com/docs/transition-timing-function
       */
      ease: [{
        ease: ["linear", "initial", x, D, O]
      }],
      /**
       * Transition Delay
       * @see https://tailwindcss.com/docs/transition-delay
       */
      delay: [{
        delay: [K, D, O]
      }],
      /**
       * Animation
       * @see https://tailwindcss.com/docs/animation
       */
      animate: [{
        animate: ["none", y, D, O]
      }],
      // ------------------
      // --- Transforms ---
      // ------------------
      /**
       * Backface Visibility
       * @see https://tailwindcss.com/docs/backface-visibility
       */
      backface: [{
        backface: ["hidden", "visible"]
      }],
      /**
       * Perspective
       * @see https://tailwindcss.com/docs/perspective
       */
      perspective: [{
        perspective: [b, D, O]
      }],
      /**
       * Perspective Origin
       * @see https://tailwindcss.com/docs/perspective-origin
       */
      "perspective-origin": [{
        "perspective-origin": R()
      }],
      /**
       * Rotate
       * @see https://tailwindcss.com/docs/rotate
       */
      rotate: [{
        rotate: Q()
      }],
      /**
       * Rotate X
       * @see https://tailwindcss.com/docs/rotate
       */
      "rotate-x": [{
        "rotate-x": Q()
      }],
      /**
       * Rotate Y
       * @see https://tailwindcss.com/docs/rotate
       */
      "rotate-y": [{
        "rotate-y": Q()
      }],
      /**
       * Rotate Z
       * @see https://tailwindcss.com/docs/rotate
       */
      "rotate-z": [{
        "rotate-z": Q()
      }],
      /**
       * Scale
       * @see https://tailwindcss.com/docs/scale
       */
      scale: [{
        scale: J()
      }],
      /**
       * Scale X
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-x": [{
        "scale-x": J()
      }],
      /**
       * Scale Y
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-y": [{
        "scale-y": J()
      }],
      /**
       * Scale Z
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-z": [{
        "scale-z": J()
      }],
      /**
       * Scale 3D
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-3d": ["scale-3d"],
      /**
       * Skew
       * @see https://tailwindcss.com/docs/skew
       */
      skew: [{
        skew: oe()
      }],
      /**
       * Skew X
       * @see https://tailwindcss.com/docs/skew
       */
      "skew-x": [{
        "skew-x": oe()
      }],
      /**
       * Skew Y
       * @see https://tailwindcss.com/docs/skew
       */
      "skew-y": [{
        "skew-y": oe()
      }],
      /**
       * Transform
       * @see https://tailwindcss.com/docs/transform
       */
      transform: [{
        transform: [D, O, "", "none", "gpu", "cpu"]
      }],
      /**
       * Transform Origin
       * @see https://tailwindcss.com/docs/transform-origin
       */
      "transform-origin": [{
        origin: R()
      }],
      /**
       * Transform Style
       * @see https://tailwindcss.com/docs/transform-style
       */
      "transform-style": [{
        transform: ["3d", "flat"]
      }],
      /**
       * Translate
       * @see https://tailwindcss.com/docs/translate
       */
      translate: [{
        translate: Se()
      }],
      /**
       * Translate X
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-x": [{
        "translate-x": Se()
      }],
      /**
       * Translate Y
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-y": [{
        "translate-y": Se()
      }],
      /**
       * Translate Z
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-z": [{
        "translate-z": Se()
      }],
      /**
       * Translate None
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-none": ["translate-none"],
      /**
       * Zoom
       * @see https://tailwindcss.com/docs/zoom
       */
      zoom: [{
        zoom: [Le, D, O]
      }],
      // ---------------------
      // --- Interactivity ---
      // ---------------------
      /**
       * Accent Color
       * @see https://tailwindcss.com/docs/accent-color
       */
      accent: [{
        accent: _()
      }],
      /**
       * Appearance
       * @see https://tailwindcss.com/docs/appearance
       */
      appearance: [{
        appearance: ["none", "auto"]
      }],
      /**
       * Caret Color
       * @see https://tailwindcss.com/docs/just-in-time-mode#caret-color-utilities
       */
      "caret-color": [{
        caret: _()
      }],
      /**
       * Color Scheme
       * @see https://tailwindcss.com/docs/color-scheme
       */
      "color-scheme": [{
        scheme: ["normal", "dark", "light", "light-dark", "only-dark", "only-light"]
      }],
      /**
       * Cursor
       * @see https://tailwindcss.com/docs/cursor
       */
      cursor: [{
        cursor: ["auto", "default", "pointer", "wait", "text", "move", "help", "not-allowed", "none", "context-menu", "progress", "cell", "crosshair", "vertical-text", "alias", "copy", "no-drop", "grab", "grabbing", "all-scroll", "col-resize", "row-resize", "n-resize", "e-resize", "s-resize", "w-resize", "ne-resize", "nw-resize", "se-resize", "sw-resize", "ew-resize", "ns-resize", "nesw-resize", "nwse-resize", "zoom-in", "zoom-out", D, O]
      }],
      /**
       * Field Sizing
       * @see https://tailwindcss.com/docs/field-sizing
       */
      "field-sizing": [{
        "field-sizing": ["fixed", "content"]
      }],
      /**
       * Pointer Events
       * @see https://tailwindcss.com/docs/pointer-events
       */
      "pointer-events": [{
        "pointer-events": ["auto", "none"]
      }],
      /**
       * Resize
       * @see https://tailwindcss.com/docs/resize
       */
      resize: [{
        resize: ["none", "", "y", "x"]
      }],
      /**
       * Scroll Behavior
       * @see https://tailwindcss.com/docs/scroll-behavior
       */
      "scroll-behavior": [{
        scroll: ["auto", "smooth"]
      }],
      /**
       * Scrollbar Thumb Color
       * @see https://tailwindcss.com/docs/scrollbar-color
       */
      "scrollbar-thumb-color": [{
        "scrollbar-thumb": _()
      }],
      /**
       * Scrollbar Track Color
       * @see https://tailwindcss.com/docs/scrollbar-color
       */
      "scrollbar-track-color": [{
        "scrollbar-track": _()
      }],
      /**
       * Scrollbar Gutter
       * @see https://tailwindcss.com/docs/scrollbar-gutter
       */
      "scrollbar-gutter": [{
        "scrollbar-gutter": ["auto", "stable", "both"]
      }],
      /**
       * Scrollbar Width
       * @see https://tailwindcss.com/docs/scrollbar-width
       */
      "scrollbar-w": [{
        scrollbar: ["auto", "thin", "none"]
      }],
      /**
       * Scroll Margin
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-m": [{
        "scroll-m": S()
      }],
      /**
       * Scroll Margin Inline
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mx": [{
        "scroll-mx": S()
      }],
      /**
       * Scroll Margin Block
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-my": [{
        "scroll-my": S()
      }],
      /**
       * Scroll Margin Inline Start
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-ms": [{
        "scroll-ms": S()
      }],
      /**
       * Scroll Margin Inline End
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-me": [{
        "scroll-me": S()
      }],
      /**
       * Scroll Margin Block Start
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mbs": [{
        "scroll-mbs": S()
      }],
      /**
       * Scroll Margin Block End
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mbe": [{
        "scroll-mbe": S()
      }],
      /**
       * Scroll Margin Top
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mt": [{
        "scroll-mt": S()
      }],
      /**
       * Scroll Margin Right
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mr": [{
        "scroll-mr": S()
      }],
      /**
       * Scroll Margin Bottom
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mb": [{
        "scroll-mb": S()
      }],
      /**
       * Scroll Margin Left
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-ml": [{
        "scroll-ml": S()
      }],
      /**
       * Scroll Padding
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-p": [{
        "scroll-p": S()
      }],
      /**
       * Scroll Padding Inline
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-px": [{
        "scroll-px": S()
      }],
      /**
       * Scroll Padding Block
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-py": [{
        "scroll-py": S()
      }],
      /**
       * Scroll Padding Inline Start
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-ps": [{
        "scroll-ps": S()
      }],
      /**
       * Scroll Padding Inline End
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pe": [{
        "scroll-pe": S()
      }],
      /**
       * Scroll Padding Block Start
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pbs": [{
        "scroll-pbs": S()
      }],
      /**
       * Scroll Padding Block End
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pbe": [{
        "scroll-pbe": S()
      }],
      /**
       * Scroll Padding Top
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pt": [{
        "scroll-pt": S()
      }],
      /**
       * Scroll Padding Right
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pr": [{
        "scroll-pr": S()
      }],
      /**
       * Scroll Padding Bottom
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pb": [{
        "scroll-pb": S()
      }],
      /**
       * Scroll Padding Left
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pl": [{
        "scroll-pl": S()
      }],
      /**
       * Scroll Snap Align
       * @see https://tailwindcss.com/docs/scroll-snap-align
       */
      "snap-align": [{
        snap: ["start", "end", "center", "align-none"]
      }],
      /**
       * Scroll Snap Stop
       * @see https://tailwindcss.com/docs/scroll-snap-stop
       */
      "snap-stop": [{
        snap: ["normal", "always"]
      }],
      /**
       * Scroll Snap Type
       * @see https://tailwindcss.com/docs/scroll-snap-type
       */
      "snap-type": [{
        snap: ["none", "x", "y", "both"]
      }],
      /**
       * Scroll Snap Type Strictness
       * @see https://tailwindcss.com/docs/scroll-snap-type
       */
      "snap-strictness": [{
        snap: ["mandatory", "proximity"]
      }],
      /**
       * Touch Action
       * @see https://tailwindcss.com/docs/touch-action
       */
      touch: [{
        touch: ["auto", "none", "manipulation"]
      }],
      /**
       * Touch Action X
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-x": [{
        "touch-pan": ["x", "left", "right"]
      }],
      /**
       * Touch Action Y
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-y": [{
        "touch-pan": ["y", "up", "down"]
      }],
      /**
       * Touch Action Pinch Zoom
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-pz": ["touch-pinch-zoom"],
      /**
       * User Select
       * @see https://tailwindcss.com/docs/user-select
       */
      select: [{
        select: ["none", "text", "all", "auto"]
      }],
      /**
       * Will Change
       * @see https://tailwindcss.com/docs/will-change
       */
      "will-change": [{
        "will-change": ["auto", "scroll", "contents", "transform", D, O]
      }],
      // -----------
      // --- SVG ---
      // -----------
      /**
       * Fill
       * @see https://tailwindcss.com/docs/fill
       */
      fill: [{
        fill: ["none", ..._()]
      }],
      /**
       * Stroke Width
       * @see https://tailwindcss.com/docs/stroke-width
       */
      "stroke-w": [{
        stroke: [K, $t, ut, Pa]
      }],
      /**
       * Stroke
       * @see https://tailwindcss.com/docs/stroke
       */
      stroke: [{
        stroke: ["none", ..._()]
      }],
      // ---------------------
      // --- Accessibility ---
      // ---------------------
      /**
       * Forced Color Adjust
       * @see https://tailwindcss.com/docs/forced-color-adjust
       */
      "forced-color-adjust": [{
        "forced-color-adjust": ["auto", "none"]
      }]
    },
    conflictingClassGroups: {
      "container-named": ["container-type"],
      overflow: ["overflow-x", "overflow-y"],
      overscroll: ["overscroll-x", "overscroll-y"],
      inset: ["inset-x", "inset-y", "inset-bs", "inset-be", "start", "end", "top", "right", "bottom", "left"],
      "inset-x": ["right", "left"],
      "inset-y": ["top", "bottom"],
      flex: ["basis", "grow", "shrink"],
      gap: ["gap-x", "gap-y"],
      p: ["px", "py", "ps", "pe", "pbs", "pbe", "pt", "pr", "pb", "pl"],
      px: ["pr", "pl"],
      py: ["pt", "pb"],
      m: ["mx", "my", "ms", "me", "mbs", "mbe", "mt", "mr", "mb", "ml"],
      mx: ["mr", "ml"],
      my: ["mt", "mb"],
      size: ["w", "h"],
      "font-size": ["leading"],
      "fvn-normal": ["fvn-ordinal", "fvn-slashed-zero", "fvn-figure", "fvn-spacing", "fvn-fraction"],
      "fvn-ordinal": ["fvn-normal"],
      "fvn-slashed-zero": ["fvn-normal"],
      "fvn-figure": ["fvn-normal"],
      "fvn-spacing": ["fvn-normal"],
      "fvn-fraction": ["fvn-normal"],
      "line-clamp": ["display", "overflow"],
      rounded: ["rounded-s", "rounded-e", "rounded-t", "rounded-r", "rounded-b", "rounded-l", "rounded-ss", "rounded-se", "rounded-ee", "rounded-es", "rounded-tl", "rounded-tr", "rounded-br", "rounded-bl"],
      "rounded-s": ["rounded-ss", "rounded-es"],
      "rounded-e": ["rounded-se", "rounded-ee"],
      "rounded-t": ["rounded-tl", "rounded-tr"],
      "rounded-r": ["rounded-tr", "rounded-br"],
      "rounded-b": ["rounded-br", "rounded-bl"],
      "rounded-l": ["rounded-tl", "rounded-bl"],
      "border-spacing": ["border-spacing-x", "border-spacing-y"],
      "border-w": ["border-w-x", "border-w-y", "border-w-s", "border-w-e", "border-w-bs", "border-w-be", "border-w-t", "border-w-r", "border-w-b", "border-w-l"],
      "border-w-x": ["border-w-r", "border-w-l"],
      "border-w-y": ["border-w-t", "border-w-b"],
      "border-color": ["border-color-x", "border-color-y", "border-color-s", "border-color-e", "border-color-bs", "border-color-be", "border-color-t", "border-color-r", "border-color-b", "border-color-l"],
      "border-color-x": ["border-color-r", "border-color-l"],
      "border-color-y": ["border-color-t", "border-color-b"],
      translate: ["translate-x", "translate-y", "translate-none"],
      "translate-none": ["translate", "translate-x", "translate-y", "translate-z"],
      "scroll-m": ["scroll-mx", "scroll-my", "scroll-ms", "scroll-me", "scroll-mbs", "scroll-mbe", "scroll-mt", "scroll-mr", "scroll-mb", "scroll-ml"],
      "scroll-mx": ["scroll-mr", "scroll-ml"],
      "scroll-my": ["scroll-mt", "scroll-mb"],
      "scroll-p": ["scroll-px", "scroll-py", "scroll-ps", "scroll-pe", "scroll-pbs", "scroll-pbe", "scroll-pt", "scroll-pr", "scroll-pb", "scroll-pl"],
      "scroll-px": ["scroll-pr", "scroll-pl"],
      "scroll-py": ["scroll-pt", "scroll-pb"],
      touch: ["touch-x", "touch-y", "touch-pz"],
      "touch-x": ["touch"],
      "touch-y": ["touch"],
      "touch-pz": ["touch"]
    },
    conflictingClassGroupModifiers: {
      "font-size": ["leading"]
    },
    postfixLookupClassGroups: ["container-type"],
    orderSensitiveModifiers: ["*", "**", "after", "backdrop", "before", "details-content", "file", "first-letter", "first-line", "marker", "placeholder", "selection"]
  };
}, Ob = /* @__PURE__ */ ub(Mb);
function T(...e) {
  return Ob(ic(e));
}
function xv({ className: e, ...t }) {
  return /* @__PURE__ */ d(Fl, { "data-slot": "accordion", className: T("flex w-full flex-col", e), ...t });
}
function yv({ className: e, ...t }) {
  return /* @__PURE__ */ d(zl, { "data-slot": "accordion-item", className: T("border-b", e), ...t });
}
function Cv({ className: e, children: t, ...n }) {
  return /* @__PURE__ */ d(Bl, { className: "flex", children: /* @__PURE__ */ Z(Vl, { "data-slot": "accordion-trigger", className: T("flex flex-1 items-center justify-between py-3 text-sm font-medium outline-none transition-all hover:underline focus-visible:ring-3 focus-visible:ring-ring/50 disabled:pointer-events-none disabled:opacity-50 [&[data-state=open]>svg]:rotate-180", e), ...n, children: [
    t,
    /* @__PURE__ */ d(zr, { "data-slot": "accordion-trigger-icon", className: "size-4 shrink-0 transition-transform duration-200" })
  ] }) });
}
function Sv({ className: e, children: t, ...n }) {
  return /* @__PURE__ */ d(Wl, { "data-slot": "accordion-content", className: "overflow-hidden text-sm data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down", ...n, children: /* @__PURE__ */ d("div", { className: T("pb-3 text-muted-foreground", e), children: t }) });
}
const Ta = (e) => typeof e == "boolean" ? `${e}` : e === 0 ? "0" : e, Ia = ic, qn = (e, t) => (n) => {
  var o;
  if (t?.variants == null) return Ia(e, n?.class, n?.className);
  const { variants: r, defaultVariants: a } = t, i = Object.keys(r).map((u) => {
    const m = n?.[u], f = a?.[u];
    if (m === null) return null;
    const p = Ta(m) || Ta(f);
    return r[u][p];
  }), c = n && Object.entries(n).reduce((u, m) => {
    let [f, p] = m;
    return p === void 0 || (u[f] = p), u;
  }, {}), l = t == null || (o = t.compoundVariants) === null || o === void 0 ? void 0 : o.reduce((u, m) => {
    let { class: f, className: p, ...h } = m;
    return Object.entries(h).every((g) => {
      let [b, v] = g;
      return Array.isArray(v) ? v.includes({
        ...a,
        ...c
      }[b]) : {
        ...a,
        ...c
      }[b] === v;
    }) ? [
      ...u,
      f,
      p
    ] : u;
  }, []);
  return Ia(e, i, l, n?.class, n?.className);
}, Db = qn(
  "group/badge inline-flex h-5 w-fit shrink-0 items-center justify-center gap-1 overflow-hidden rounded-full border border-transparent px-2 py-0.5 text-xs font-medium whitespace-nowrap transition-all focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5 aria-invalid:border-destructive aria-invalid:ring-destructive/20 [&>svg]:pointer-events-none [&>svg]:size-3!",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground [a]:hover:bg-primary/80",
        secondary: "bg-secondary text-secondary-foreground [a]:hover:bg-secondary/80",
        destructive: "bg-destructive text-background focus-visible:ring-destructive/20 [a]:hover:bg-destructive/95",
        outline: "border-border text-foreground [a]:hover:bg-accent [a]:hover:text-accent-foreground",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline"
      }
    },
    defaultVariants: {
      variant: "default"
    }
  }
);
function Rv({
  className: e,
  variant: t = "default",
  asChild: n = !1,
  ...o
}) {
  return /* @__PURE__ */ d(
    n ? ht : "span",
    {
      "data-slot": "badge",
      "data-variant": t,
      className: T(Db({ variant: t }), e),
      ...o
    }
  );
}
const Nb = qn(
  "group/button inline-flex shrink-0 items-center justify-center rounded-md border border-transparent bg-clip-padding text-sm font-medium whitespace-nowrap transition-all outline-none select-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 active:not-aria-[haspopup]:translate-y-px disabled:pointer-events-none disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-3 aria-invalid:ring-destructive/20 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-primary/80",
        outline: "border-border bg-background hover:bg-accent hover:text-accent-foreground aria-expanded:bg-accent aria-expanded:text-accent-foreground",
        secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80 aria-expanded:bg-secondary aria-expanded:text-secondary-foreground",
        ghost: "hover:bg-accent hover:text-accent-foreground aria-expanded:bg-accent aria-expanded:text-accent-foreground",
        destructive: "bg-destructive text-background hover:bg-destructive/95 focus-visible:border-destructive/40 focus-visible:ring-destructive/20",
        link: "text-primary underline-offset-4 hover:underline"
      },
      size: {
        default: "h-8 gap-1.5 px-2.5 has-data-[icon=inline-end]:pr-2 has-data-[icon=inline-start]:pl-2",
        xs: "h-6 gap-1 rounded-sm px-2 text-xs in-data-[slot=button-group]:rounded-md has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5 [&_svg:not([class*='size-'])]:size-3",
        sm: "h-7 gap-1 rounded-sm px-2.5 text-xs in-data-[slot=button-group]:rounded-md has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5 [&_svg:not([class*='size-'])]:size-3.5",
        lg: "h-9 gap-1.5 px-2.5 has-data-[icon=inline-end]:pr-2 has-data-[icon=inline-start]:pl-2",
        icon: "size-8",
        "icon-xs": "size-6 rounded-sm in-data-[slot=button-group]:rounded-md [&_svg:not([class*='size-'])]:size-3",
        "icon-sm": "size-7 rounded-sm in-data-[slot=button-group]:rounded-md",
        "icon-lg": "size-9"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
), nn = s.forwardRef(({
  className: e,
  variant: t = "default",
  size: n = "default",
  asChild: o = !1,
  ...r
}, a) => /* @__PURE__ */ d(
  o ? ht : "button",
  {
    ref: a,
    "data-slot": "button",
    "data-variant": t,
    "data-size": n,
    className: T(Nb({ variant: t, size: n, className: e })),
    ...r
  }
));
nn.displayName = "Button";
function Pv({ className: e, size: t = "default", ...n }) {
  return /* @__PURE__ */ d("div", { "data-slot": "card", "data-size": t, className: T("group/card flex flex-col overflow-hidden rounded-xl border bg-card text-card-foreground", e), ...n });
}
function Ev({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-slot": "card-header", className: T("grid gap-1.5 p-4 group-data-[size=sm]/card:p-3", e), ...t });
}
function _v({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-slot": "card-title", className: T("font-heading text-base font-medium group-data-[size=sm]/card:text-sm", e), ...t });
}
function Tv({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-slot": "card-description", className: T("text-sm text-muted-foreground", e), ...t });
}
function Iv({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-slot": "card-action", className: T("col-start-2 row-span-2 row-start-1 self-start justify-self-end", e), ...t });
}
function Av({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-slot": "card-content", className: T("px-4 pb-4 group-data-[size=sm]/card:px-3 group-data-[size=sm]/card:pb-3", e), ...t });
}
function kv({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-slot": "card-footer", className: T("flex items-center border-t bg-muted/50 p-4 group-data-[size=sm]/card:p-3", e), ...t });
}
function Mv({ className: e, ...t }) {
  return /* @__PURE__ */ d(od, { "data-slot": "checkbox", className: T("peer size-4 shrink-0 rounded-[4px] border border-input outline-none transition-colors focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 data-[state=checked]:border-primary data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground disabled:cursor-not-allowed disabled:opacity-50", e), ...t, children: /* @__PURE__ */ d(ad, { "data-slot": "checkbox-indicator", className: "grid place-content-center text-current", children: /* @__PURE__ */ d(Fr, { className: "size-3.5" }) }) });
}
function Ov({ ...e }) {
  return /* @__PURE__ */ d(Pi, { "data-slot": "dialog", ...e });
}
const Lb = s.forwardRef(({ ...e }, t) => /* @__PURE__ */ d(Ei, { ref: t, "data-slot": "dialog-trigger", ...e }));
Lb.displayName = "DialogTrigger";
function $b({ ...e }) {
  return /* @__PURE__ */ d(Ii, { "data-slot": "dialog-portal", ...e });
}
function Dv({ ...e }) {
  return /* @__PURE__ */ d(qt, { "data-slot": "dialog-close", ...e });
}
const yc = s.forwardRef(({ className: e, ...t }, n) => /* @__PURE__ */ d(Ai, { ref: n, "data-slot": "dialog-overlay", className: T("fixed inset-0 z-50 bg-black/50 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:animate-in data-[state=open]:fade-in-0", e), ...t }));
yc.displayName = "DialogOverlay";
const Fb = s.forwardRef(({ className: e, children: t, showCloseButton: n = !0, portalContainer: o, ...r }, a) => /* @__PURE__ */ Z($b, { container: o, children: [
  /* @__PURE__ */ d(yc, {}),
  /* @__PURE__ */ Z(ki, { ref: a, "data-slot": "dialog-content", className: T("fixed top-1/2 left-1/2 z-50 grid w-full max-w-lg -translate-x-1/2 -translate-y-1/2 gap-4 rounded-lg border bg-background p-6 text-foreground shadow-lg", e), ...r, children: [
    t,
    n && /* @__PURE__ */ d(qt, { "data-slot": "dialog-close", asChild: !0, children: /* @__PURE__ */ Z(nn, { variant: "ghost", size: "icon-sm", className: "absolute top-4 right-4", children: [
      /* @__PURE__ */ d(rc, { className: "size-4" }),
      /* @__PURE__ */ d("span", { className: "sr-only", children: "Close" })
    ] }) })
  ] })
] }));
Fb.displayName = "DialogContent";
function Nv({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-slot": "dialog-header", className: T("flex flex-col gap-2 text-center sm:text-left", e), ...t });
}
function Lv({ className: e, showCloseButton: t = !1, children: n, ...o }) {
  return /* @__PURE__ */ Z("div", { "data-slot": "dialog-footer", className: T("flex flex-col-reverse gap-2 sm:flex-row sm:justify-end", e), ...o, children: [
    n,
    t && /* @__PURE__ */ d(qt, { asChild: !0, children: /* @__PURE__ */ d(nn, { variant: "outline", children: "Close" }) })
  ] });
}
function $v({ className: e, ...t }) {
  return /* @__PURE__ */ d(Oi, { "data-slot": "dialog-title", className: T("font-heading text-lg font-semibold", e), ...t });
}
function Fv({ className: e, ...t }) {
  return /* @__PURE__ */ d(Di, { "data-slot": "dialog-description", className: T("text-sm text-muted-foreground", e), ...t });
}
function zv({ ...e }) {
  return /* @__PURE__ */ d(om, { "data-slot": "dropdown-menu", ...e });
}
function zb({ ...e }) {
  return /* @__PURE__ */ d(am, { "data-slot": "dropdown-menu-portal", ...e });
}
const Bb = s.forwardRef(({ ...e }, t) => /* @__PURE__ */ d(rm, { ref: t, "data-slot": "dropdown-menu-trigger", ...e }));
Bb.displayName = "DropdownMenuTrigger";
function Bv({ className: e, align: t = "start", sideOffset: n = 4, portalContainer: o, ...r }) {
  return /* @__PURE__ */ d(zb, { container: o, children: /* @__PURE__ */ d(im, { "data-slot": "dropdown-menu-content", sideOffset: n, align: t, className: T("z-50 max-h-[var(--radix-dropdown-menu-content-available-height)] min-w-32 overflow-x-hidden overflow-y-auto rounded-md border bg-popover p-1 text-popover-foreground shadow-md data-[state=closed]:overflow-hidden", e), ...r }) });
}
function Vv({ ...e }) {
  return /* @__PURE__ */ d(sm, { "data-slot": "dropdown-menu-group", ...e });
}
function Wv({ className: e, inset: t, variant: n = "default", ...o }) {
  return /* @__PURE__ */ d(lm, { "data-slot": "dropdown-menu-item", "data-inset": t, "data-variant": n, className: T("relative flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none data-[highlighted]:bg-accent data-[highlighted]:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", n === "destructive" && "text-destructive", t && "pl-8", e), ...o });
}
function Hv({ className: e, children: t, checked: n, inset: o, ...r }) {
  return /* @__PURE__ */ Z(um, { "data-slot": "dropdown-menu-checkbox-item", "data-inset": o, checked: n, className: T("relative flex cursor-default select-none items-center rounded-sm py-1.5 pr-2 text-sm outline-none data-[highlighted]:bg-accent data-[disabled]:pointer-events-none data-[disabled]:opacity-50", o ? "pl-8" : "pl-2", e), ...r, children: [
    /* @__PURE__ */ d("span", { className: "absolute left-2 flex size-3.5 items-center justify-center", children: /* @__PURE__ */ d(Ts, { children: /* @__PURE__ */ d(Fr, { className: "size-4" }) }) }),
    t
  ] });
}
function Gv({ ...e }) {
  return /* @__PURE__ */ d(dm, { "data-slot": "dropdown-menu-radio-group", ...e });
}
function Uv({ className: e, children: t, inset: n, ...o }) {
  return /* @__PURE__ */ Z(fm, { "data-slot": "dropdown-menu-radio-item", "data-inset": n, className: T("relative flex cursor-default select-none items-center rounded-sm py-1.5 pr-2 text-sm outline-none data-[highlighted]:bg-accent data-[disabled]:pointer-events-none data-[disabled]:opacity-50", n ? "pl-8" : "pl-2", e), ...o, children: [
    /* @__PURE__ */ d("span", { className: "absolute left-2 flex size-3.5 items-center justify-center", children: /* @__PURE__ */ d(Ts, { children: /* @__PURE__ */ d(zg, { className: "size-2 fill-current" }) }) }),
    t
  ] });
}
function jv({ className: e, inset: t, ...n }) {
  return /* @__PURE__ */ d(cm, { "data-slot": "dropdown-menu-label", "data-inset": t, className: T("px-2 py-1.5 text-xs font-medium text-muted-foreground", t && "pl-8", e), ...n });
}
function Kv({ className: e, ...t }) {
  return /* @__PURE__ */ d(pm, { "data-slot": "dropdown-menu-separator", className: T("-mx-1 my-1 h-px bg-muted", e), ...t });
}
function Yv({ className: e, ...t }) {
  return /* @__PURE__ */ d("span", { "data-slot": "dropdown-menu-shortcut", className: T("ml-auto text-xs tracking-widest text-muted-foreground", e), ...t });
}
function Xv({ ...e }) {
  return /* @__PURE__ */ d(mm, { "data-slot": "dropdown-menu-sub", ...e });
}
function qv({ className: e, children: t, inset: n, ...o }) {
  return /* @__PURE__ */ Z(hm, { "data-slot": "dropdown-menu-sub-trigger", "data-inset": n, className: T("flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none data-[state=open]:bg-accent", n && "pl-8", e), ...o, children: [
    t,
    /* @__PURE__ */ d(Ng, { className: "ml-auto size-4" })
  ] });
}
function Zv({ className: e, ...t }) {
  return /* @__PURE__ */ d(gm, { "data-slot": "dropdown-menu-sub-content", className: T("z-50 min-w-32 overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-lg", e), ...t });
}
function Vb({ className: e, type: t, ...n }) {
  return /* @__PURE__ */ d(
    "input",
    {
      type: t,
      "data-slot": "input",
      className: T(
        "h-8 w-full min-w-0 rounded-md border border-input bg-transparent px-2.5 py-1 text-base transition-colors outline-none file:inline-flex file:h-6 file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 disabled:pointer-events-none disabled:cursor-not-allowed disabled:bg-input/50 disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-3 aria-invalid:ring-destructive/20 md:text-sm",
        e
      ),
      ...n
    }
  );
}
function Qv({ className: e, ...t }) {
  return /* @__PURE__ */ d(xm, { "data-slot": "label", className: T("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70", e), ...t });
}
function Jv({ className: e, children: t, ...n }) {
  return /* @__PURE__ */ Z(Wm, { "data-slot": "scroll-area", className: T("relative overflow-hidden", e), ...n, children: [
    /* @__PURE__ */ d(Hm, { "data-slot": "scroll-area-viewport", tabIndex: 0, className: "size-full rounded-[inherit] outline-none focus-visible:ring-3 focus-visible:ring-ring/50", children: t }),
    /* @__PURE__ */ d(Wb, {}),
    /* @__PURE__ */ d(Gm, {})
  ] });
}
function Wb({ className: e, orientation: t = "vertical", ...n }) {
  return /* @__PURE__ */ d(km, { "data-slot": "scroll-area-scrollbar", "data-orientation": t, orientation: t, className: T("flex touch-none select-none p-px transition-colors", t === "vertical" ? "h-full w-2.5 border-l border-l-transparent" : "h-2.5 w-full flex-col border-t border-t-transparent", e), ...n, children: /* @__PURE__ */ d($m, { "data-slot": "scroll-area-thumb", className: "relative flex-1 rounded-full bg-border" }) });
}
function ew({ ...e }) {
  return /* @__PURE__ */ d(Qm, { "data-slot": "select", ...e });
}
function tw({ className: e, ...t }) {
  return /* @__PURE__ */ d(vh, { "data-slot": "select-group", className: T("p-1", e), ...t });
}
function nw({ ...e }) {
  return /* @__PURE__ */ d(nh, { "data-slot": "select-value", ...e });
}
function ow({ className: e, size: t = "default", children: n, ...o }) {
  return /* @__PURE__ */ Z(eh, { "data-slot": "select-trigger", "data-size": t, className: T("flex h-8 w-fit min-w-28 items-center justify-between gap-2 rounded-md border border-input bg-transparent px-2.5 text-sm outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 disabled:cursor-not-allowed disabled:opacity-50 *:data-[slot=select-value]:line-clamp-1 *:data-[slot=select-value]:flex *:data-[slot=select-value]:items-center", t === "sm" && "h-7 text-xs", e), ...o, children: [
    n,
    /* @__PURE__ */ d(oh, { asChild: !0, children: /* @__PURE__ */ d(zr, { className: "size-4 opacity-50" }) })
  ] });
}
function rw({ className: e, children: t, position: n = "item-aligned", align: o = "center", portalContainer: r, ...a }) {
  return /* @__PURE__ */ d(sh, { container: r, children: /* @__PURE__ */ Z(ch, { "data-slot": "select-content", "data-align-trigger": n === "item-aligned", position: n, align: o, className: T("relative z-50 max-h-96 min-w-32 overflow-x-hidden overflow-y-auto rounded-md border bg-popover text-popover-foreground shadow-md data-[align-trigger=true]:animate-none", n === "popper" && "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1", e), ...a, children: [
    /* @__PURE__ */ d(Hb, {}),
    /* @__PURE__ */ d(mh, { "data-position": n, className: T("p-1", n === "popper" && "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]"), children: t }),
    /* @__PURE__ */ d(Gb, {})
  ] }) });
}
function aw({ className: e, ...t }) {
  return /* @__PURE__ */ d(xh, { "data-slot": "select-label", className: T("px-2 py-1.5 text-xs text-muted-foreground", e), ...t });
}
function iw({ className: e, children: t, ...n }) {
  return /* @__PURE__ */ Z(Ch, { "data-slot": "select-item", className: T("relative flex w-full cursor-default items-center rounded-sm py-1.5 pr-8 pl-2 text-sm outline-none data-[highlighted]:bg-accent data-[highlighted]:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", e), ...n, children: [
    /* @__PURE__ */ d("span", { className: "absolute right-2 flex size-3.5 items-center justify-center", children: /* @__PURE__ */ d(Ph, { children: /* @__PURE__ */ d(Fr, { className: "size-4" }) }) }),
    /* @__PURE__ */ d(Sh, { children: t })
  ] });
}
function sw({ className: e, ...t }) {
  return /* @__PURE__ */ d(Th, { "data-slot": "select-separator", className: T("-mx-1 my-1 h-px bg-muted", e), ...t });
}
function Hb({ className: e, ...t }) {
  return /* @__PURE__ */ d(Eh, { "data-slot": "select-scroll-up-button", className: T("flex cursor-default items-center justify-center py-1", e), ...t, children: /* @__PURE__ */ d($g, { className: "size-4" }) });
}
function Gb({ className: e, ...t }) {
  return /* @__PURE__ */ d(_h, { "data-slot": "select-scroll-down-button", className: T("flex cursor-default items-center justify-center py-1", e), ...t, children: /* @__PURE__ */ d(zr, { className: "size-4" }) });
}
function Ub({
  className: e,
  orientation: t = "horizontal",
  decorative: n = !0,
  ...o
}) {
  return /* @__PURE__ */ d(
    Dh,
    {
      "data-slot": "separator",
      decorative: n,
      orientation: t,
      className: T(
        "shrink-0 bg-border data-horizontal:h-px data-horizontal:w-full data-vertical:w-px data-vertical:self-stretch",
        e
      ),
      ...o
    }
  );
}
function jb({ ...e }) {
  return /* @__PURE__ */ d(Pi, { "data-slot": "sheet", ...e });
}
const Kb = s.forwardRef(({ ...e }, t) => /* @__PURE__ */ d(Ei, { ref: t, "data-slot": "sheet-trigger", ...e }));
Kb.displayName = "SheetTrigger";
function cw({ ...e }) {
  return /* @__PURE__ */ d(qt, { "data-slot": "sheet-close", ...e });
}
function Yb({ ...e }) {
  return /* @__PURE__ */ d(Ii, { "data-slot": "sheet-portal", ...e });
}
const Cc = s.forwardRef(({ className: e, ...t }, n) => /* @__PURE__ */ d(Ai, { ref: n, "data-slot": "sheet-overlay", className: T("fixed inset-0 z-50 bg-black/50", e), ...t }));
Cc.displayName = "SheetOverlay";
const Sc = s.forwardRef(({ className: e, children: t, side: n = "right", showCloseButton: o = !0, portalContainer: r, ...a }, i) => /* @__PURE__ */ Z(Yb, { container: r, children: [
  /* @__PURE__ */ d(Cc, {}),
  /* @__PURE__ */ Z(ki, { ref: i, "data-slot": "sheet-content", "data-side": n, className: T("fixed z-50 flex flex-col gap-4 border bg-background p-6 shadow-lg", n === "right" && "inset-y-0 right-0 h-full w-3/4 max-w-sm border-l", n === "left" && "inset-y-0 left-0 h-full w-3/4 max-w-sm border-r", n === "top" && "inset-x-0 top-0 border-b", n === "bottom" && "inset-x-0 bottom-0 border-t", e), ...a, children: [
    t,
    o && /* @__PURE__ */ d(qt, { "data-slot": "sheet-close", asChild: !0, children: /* @__PURE__ */ Z(nn, { variant: "ghost", size: "icon-sm", className: "absolute top-4 right-4", children: [
      /* @__PURE__ */ d(rc, { className: "size-4" }),
      /* @__PURE__ */ d("span", { className: "sr-only", children: "Close" })
    ] }) })
  ] })
] }));
Sc.displayName = "SheetContent";
function Xb({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-slot": "sheet-header", className: T("flex flex-col gap-2", e), ...t });
}
function lw({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-slot": "sheet-footer", className: T("mt-auto flex flex-col gap-2", e), ...t });
}
function qb({ className: e, ...t }) {
  return /* @__PURE__ */ d(Oi, { "data-slot": "sheet-title", className: T("font-heading text-lg font-semibold", e), ...t });
}
function Zb({ className: e, ...t }) {
  return /* @__PURE__ */ d(Di, { "data-slot": "sheet-description", className: T("text-sm text-muted-foreground", e), ...t });
}
function Aa({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-slot": "skeleton", className: T("animate-pulse rounded-md bg-muted", e), ...t });
}
function uw({ delayDuration: e = 0, ...t }) {
  return /* @__PURE__ */ d(xg, { "data-slot": "tooltip-provider", delayDuration: e, ...t });
}
function Qb({ ...e }) {
  return /* @__PURE__ */ d(yg, { "data-slot": "tooltip", ...e });
}
const Rc = s.forwardRef(({ ...e }, t) => /* @__PURE__ */ d(Cg, { ref: t, "data-slot": "tooltip-trigger", ...e }));
Rc.displayName = "TooltipTrigger";
function Jb({ className: e, sideOffset: t = 0, children: n, portalContainer: o, ...r }) {
  return /* @__PURE__ */ d(Sg, { container: o, children: /* @__PURE__ */ Z(Rg, { "data-slot": "tooltip-content", sideOffset: t, className: T("z-50 rounded-md bg-foreground px-3 py-1.5 text-xs text-background shadow-md", e), ...r, children: [
    n,
    /* @__PURE__ */ d(Pg, { className: "fill-foreground" })
  ] }) });
}
const ev = "16rem", tv = "18rem", nv = "3rem", Pc = s.createContext(null), Ec = s.createContext(null), wn = s.createContext({ side: "left", state: "expanded" });
function Zn() {
  const e = s.useContext(Pc);
  if (!e) throw new Error("useSidebar must be used within a SidebarProvider.");
  return e;
}
function _c() {
  const e = s.useContext(Ec);
  if (!e) throw new Error("Sidebar runtime must be used within a SidebarProvider.");
  return e;
}
function dw({
  isMobile: e = !1,
  defaultOpen: t = !0,
  open: n,
  onOpenChange: o,
  defaultOpenMobile: r = !1,
  openMobile: a,
  onOpenMobileChange: i,
  className: c,
  style: l,
  children: u,
  ...m
}) {
  const f = s.useRef(null), [p, h] = s.useState(r), [g, b] = s.useState(t), v = n !== void 0 ? n : g, x = a !== void 0 ? a : p, y = s.useCallback(
    (E) => {
      const S = typeof E == "function" ? E(v) : E;
      n === void 0 && b(S), o?.(S);
    },
    [o, v, n]
  ), w = s.useCallback(
    (E) => {
      const S = typeof E == "function" ? E(x) : E;
      a === void 0 && h(S), i?.(S);
    },
    [i, x, a]
  ), C = s.useCallback(() => e ? w((E) => !E) : y((E) => !E), [e, y, w]), R = v ? "expanded" : "collapsed", P = s.useMemo(
    () => ({ state: R, open: v, setOpen: y, isMobile: e, openMobile: x, setOpenMobile: w, toggleSidebar: C }),
    [R, v, y, e, x, w, C]
  );
  return /* @__PURE__ */ d(Pc.Provider, { value: P, children: /* @__PURE__ */ d(Ec.Provider, { value: f, children: /* @__PURE__ */ d(
    "div",
    {
      "data-slot": "sidebar-wrapper",
      "data-mobile": e || void 0,
      style: { "--sidebar-width": ev, "--sidebar-width-icon": nv, ...l },
      className: T("group/sidebar-wrapper relative flex h-full min-h-0 w-full has-data-[variant=inset]:bg-sidebar", c),
      ...m,
      children: u
    }
  ) }) });
}
function fw({
  side: e = "left",
  variant: t = "sidebar",
  collapsible: n = "offcanvas",
  portalContainer: o,
  className: r,
  children: a,
  dir: i,
  style: c,
  ...l
}) {
  const { isMobile: u, state: m, openMobile: f, setOpenMobile: p } = Zn(), h = _c(), g = n === "none" ? "expanded" : m, b = /* @__PURE__ */ d("div", { "data-slot": "sidebar-flow-spacer", "data-state": g, "data-collapsible": g === "collapsed" ? n : "", "data-side": e, className: T("h-full shrink-0 w-(--sidebar-width) data-[collapsible=offcanvas]:w-0 data-[collapsible=icon]:w-(--sidebar-width-icon) data-[side=left]:order-first rtl:data-[side=left]:order-last data-[side=right]:order-last rtl:data-[side=right]:order-first", (t === "floating" || t === "inset") && "data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)+--spacing(4))]") });
  return n === "none" ? /* @__PURE__ */ d(wn.Provider, { value: { side: e, state: g }, children: /* @__PURE__ */ Z(Xe, { children: [
    b,
    /* @__PURE__ */ d("div", { dir: i, "data-slot": "sidebar", "data-state": g, "data-collapsible": "", "data-variant": t, "data-side": e, className: T("absolute inset-y-0 flex h-full w-(--sidebar-width) flex-col bg-sidebar text-sidebar-foreground data-[side=left]:left-0 data-[side=right]:right-0", r), style: c, ...l, children: a })
  ] }) }) : u ? /* @__PURE__ */ d(wn.Provider, { value: { side: e, state: f ? "expanded" : "collapsed" }, children: /* @__PURE__ */ d(jb, { open: f, onOpenChange: p, children: /* @__PURE__ */ Z(
    Sc,
    {
      dir: i,
      "data-sidebar": "sidebar",
      "data-slot": "sidebar",
      "data-mobile": "true",
      "data-state": f ? "expanded" : "collapsed",
      "data-collapsible": f ? "" : n,
      "data-variant": t,
      className: T("w-(--sidebar-width) bg-sidebar p-0 text-sidebar-foreground [&>button]:hidden", r),
      style: { "--sidebar-width": tv, ...c },
      side: e,
      portalContainer: o,
      onCloseAutoFocus: (v) => {
        const x = h.current, y = x?.checkVisibility;
        x?.isConnected && !x.hidden && !x.disabled && x.tabIndex >= 0 && x.getAttribute("aria-hidden") !== "true" && x.getClientRects().length > 0 && (!y || y.call(x, { checkOpacity: !0, checkVisibilityCSS: !0 })) && (v.preventDefault(), x.focus());
      },
      ...l,
      children: [
        /* @__PURE__ */ Z(Xb, { className: "sr-only", children: [
          /* @__PURE__ */ d(qb, { children: "Sidebar" }),
          /* @__PURE__ */ d(Zb, { children: "Displays the mobile sidebar." })
        ] }),
        /* @__PURE__ */ d("div", { className: "flex h-full w-full flex-col", children: a })
      ]
    }
  ) }) }) : /* @__PURE__ */ d(wn.Provider, { value: { side: e, state: g }, children: /* @__PURE__ */ Z(Xe, { children: [
    b,
    /* @__PURE__ */ Z("div", { dir: i, className: "group peer absolute inset-y-0 flex h-full w-(--sidebar-width) text-sidebar-foreground data-[side=left]:left-0 data-[side=right]:right-0", "data-state": g, "data-collapsible": g === "collapsed" ? n : "", "data-variant": t, "data-side": e, "data-slot": "sidebar", children: [
      /* @__PURE__ */ d("div", { "data-slot": "sidebar-gap", className: T("relative w-(--sidebar-width) bg-transparent", "group-data-[collapsible=offcanvas]:w-0", "group-data-[side=right]:rotate-180", t === "floating" || t === "inset" ? "group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)+--spacing(4))]" : "group-data-[collapsible=icon]:w-(--sidebar-width-icon)") }),
      /* @__PURE__ */ d("div", { "data-slot": "sidebar-container", "data-side": e, className: T("absolute inset-y-0 z-10 flex h-full w-(--sidebar-width) transition-[left,right,width,transform] duration-200 ease-linear data-[side=left]:left-0 data-[side=left]:group-data-[collapsible=offcanvas]:-translate-x-full data-[side=right]:right-0 data-[side=right]:group-data-[collapsible=offcanvas]:translate-x-full", t === "floating" || t === "inset" ? "p-2 group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)+--spacing(4)+2px)]" : "group-data-[collapsible=icon]:w-(--sidebar-width-icon) group-data-[side=left]:border-r group-data-[side=right]:border-l", r), style: c, ...l, children: /* @__PURE__ */ d("div", { "data-sidebar": "sidebar", "data-slot": "sidebar-inner", className: "flex size-full flex-col", children: a }) })
    ] })
  ] }) });
}
const ov = s.forwardRef(({ className: e, onClick: t, ...n }, o) => {
  const { toggleSidebar: r } = Zn(), a = _c();
  return /* @__PURE__ */ Z(nn, { ref: o, "data-sidebar": "trigger", "data-slot": "sidebar-trigger", variant: "ghost", size: "icon-sm", className: e, onClick: (i) => {
    t?.(i), !i.defaultPrevented && (a.current = i.currentTarget, r());
  }, ...n, children: [
    /* @__PURE__ */ d(Vg, { className: "size-4" }),
    /* @__PURE__ */ d("span", { className: "sr-only", children: "Toggle Sidebar" })
  ] });
});
ov.displayName = "SidebarTrigger";
function pw({ className: e, ...t }) {
  const { isMobile: n, toggleSidebar: o } = Zn();
  return n ? null : /* @__PURE__ */ d("button", { "data-sidebar": "rail", "data-slot": "sidebar-rail", "aria-label": "Toggle Sidebar", tabIndex: -1, onClick: o, title: "Toggle Sidebar", className: T("absolute inset-y-0 z-20 flex w-4 transition-all ease-linear group-data-[side=left]:-right-4 group-data-[side=right]:left-0 after:absolute after:inset-y-0 after:start-1/2 after:w-[2px] ltr:-translate-x-1/2 rtl:-translate-x-1/2 in-data-[side=left]:cursor-w-resize in-data-[side=right]:cursor-e-resize [[data-side=left][data-state=collapsed]_&]:cursor-e-resize [[data-side=right][data-state=collapsed]_&]:cursor-w-resize group-data-[collapsible=offcanvas]:translate-x-0 group-data-[collapsible=offcanvas]:after:left-full hover:group-data-[collapsible=offcanvas]:bg-sidebar [[data-side=left][data-collapsible=offcanvas]_&]:-right-2 [[data-side=right][data-collapsible=offcanvas]_&]:-left-2", e), ...t });
}
function mw({ className: e, ...t }) {
  return /* @__PURE__ */ d("main", { "data-slot": "sidebar-inset", className: T("relative flex w-full flex-1 flex-col bg-background", e), ...t });
}
function hw({ className: e, ...t }) {
  return /* @__PURE__ */ d(Vb, { "data-sidebar": "input", "data-slot": "sidebar-input", className: T("h-8 w-full rounded-md bg-background shadow-none", e), ...t });
}
function gw({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-sidebar": "header", "data-slot": "sidebar-header", className: T("flex flex-col gap-2 p-2", e), ...t });
}
function bw({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-sidebar": "footer", "data-slot": "sidebar-footer", className: T("flex flex-col gap-2 p-2", e), ...t });
}
function vw({ className: e, ...t }) {
  return /* @__PURE__ */ d(Ub, { "data-sidebar": "separator", "data-slot": "sidebar-separator", className: T("mx-2 w-auto", e), ...t });
}
function ww({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-sidebar": "content", "data-slot": "sidebar-content", className: T("flex min-h-0 flex-1 flex-col gap-2 overflow-auto group-data-[collapsible=icon]:overflow-hidden", e), ...t });
}
function xw({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-sidebar": "group", "data-slot": "sidebar-group", className: T("relative flex w-full min-w-0 flex-col p-2", e), ...t });
}
function yw({ className: e, asChild: t = !1, ...n }) {
  return /* @__PURE__ */ d(t ? ht : "div", { "data-sidebar": "group-label", "data-slot": "sidebar-group-label", className: T("flex h-8 shrink-0 items-center rounded-md px-2 text-xs font-medium text-sidebar-foreground/70", e), ...n });
}
function Cw({ className: e, asChild: t = !1, ...n }) {
  return /* @__PURE__ */ d(t ? ht : "button", { "data-sidebar": "group-action", "data-slot": "sidebar-group-action", className: T("flex aspect-square items-center justify-center rounded-md outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 transition-transform group-data-[collapsible=icon]:hidden after:absolute after:-inset-2 [&>svg]:shrink-0", e), ...n });
}
function Sw({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-sidebar": "group-content", "data-slot": "sidebar-group-content", className: T("w-full text-sm", e), ...t });
}
function Rw({ className: e, ...t }) {
  return /* @__PURE__ */ d("ul", { "data-sidebar": "menu", "data-slot": "sidebar-menu", className: T("flex w-full min-w-0 flex-col gap-1", e), ...t });
}
function Pw({ className: e, ...t }) {
  return /* @__PURE__ */ d("li", { "data-sidebar": "menu-item", "data-slot": "sidebar-menu-item", className: T("group/menu-item relative", e), ...t });
}
const rv = qn(
  "peer/menu-button group/menu-button flex w-full items-center overflow-hidden rounded-md px-2 py-1.5 text-left text-sm outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 transition-colors disabled:pointer-events-none disabled:opacity-50 aria-disabled:pointer-events-none aria-disabled:opacity-50 [&_svg]:size-4 [&_svg]:shrink-0 [&>span:last-child]:truncate",
  {
    variants: {
      variant: {
        default: "hover:bg-sidebar-accent hover:text-sidebar-accent-foreground data-[active=true]:bg-sidebar-accent data-[active=true]:font-medium",
        outline: "border border-sidebar-border shadow-[0_0_0_1px_var(--sidebar-border)] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground hover:shadow-[0_0_0_1px_var(--sidebar-accent)]"
      },
      size: { default: "h-8", sm: "h-7 text-xs", lg: "h-12 text-sm" }
    },
    defaultVariants: { variant: "default", size: "default" }
  }
), av = s.forwardRef(({
  asChild: e = !1,
  isActive: t = !1,
  variant: n = "default",
  size: o = "default",
  tooltip: r,
  className: a,
  ...i
}, c) => {
  const l = e ? ht : "button", { isMobile: u, state: m } = Zn(), { side: f, state: p } = s.useContext(wn), h = /* @__PURE__ */ d(l, { ref: c, "data-sidebar": "menu-button", "data-slot": "sidebar-menu-button", "data-size": o, "data-active": t, "data-state": p, className: T(rv({ variant: n, size: o }), a), ...i });
  return r ? /* @__PURE__ */ Z(Qb, { children: [
    /* @__PURE__ */ d(Rc, { asChild: !0, children: h }),
    /* @__PURE__ */ d(Jb, { side: f === "left" ? "right" : "left", align: "center", hidden: p !== "collapsed" || u, ...typeof r == "string" ? { children: r } : r })
  ] }) : h;
});
av.displayName = "SidebarMenuButton";
const iv = s.forwardRef(({ className: e, asChild: t = !1, showOnHover: n = !1, ...o }, r) => /* @__PURE__ */ d(t ? ht : "button", { ref: r, "data-sidebar": "menu-action", "data-slot": "sidebar-menu-action", className: T("absolute right-1 top-1.5 flex size-5 items-center justify-center rounded-md outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 transition-transform group-data-[collapsible=icon]:hidden after:absolute after:-inset-2 [&>svg]:shrink-0", n && "opacity-0 group-focus-within/menu-item:opacity-100 group-hover/menu-item:opacity-100 peer-data-active/menu-button:text-sidebar-accent-foreground aria-expanded:opacity-100", e), ...o }));
iv.displayName = "SidebarMenuAction";
function Ew({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-sidebar": "menu-badge", "data-slot": "sidebar-menu-badge", className: T("flex items-center justify-center tabular-nums select-none group-data-[collapsible=icon]:hidden", e), ...t });
}
function _w({ className: e, showIcon: t = !1, width: n = "70%", style: o, ...r }) {
  return /* @__PURE__ */ Z("div", { "data-sidebar": "menu-skeleton", "data-slot": "sidebar-menu-skeleton", className: T("flex items-center gap-2 rounded-md px-2 py-1.5", e), style: o, ...r, children: [
    t && /* @__PURE__ */ d(Aa, { "data-sidebar": "menu-skeleton-icon", "data-slot": "sidebar-menu-skeleton-icon", className: "size-4 rounded-md" }),
    /* @__PURE__ */ d(Aa, { "data-sidebar": "menu-skeleton-text", "data-slot": "sidebar-menu-skeleton-text", className: "h-4 max-w-(--skeleton-width) flex-1", style: { "--skeleton-width": n } })
  ] });
}
function Tw({ className: e, ...t }) {
  return /* @__PURE__ */ d("ul", { "data-sidebar": "menu-sub", "data-slot": "sidebar-menu-sub", className: T("mx-3.5 flex min-w-0 translate-x-px flex-col gap-1 border-l border-sidebar-border px-2.5 py-0.5", e), ...t });
}
function Iw({ className: e, ...t }) {
  return /* @__PURE__ */ d("li", { "data-sidebar": "menu-sub-item", "data-slot": "sidebar-menu-sub-item", className: T("group/menu-sub-item relative", e), ...t });
}
function Aw({ asChild: e = !1, size: t = "md", isActive: n = !1, className: o, ...r }) {
  return /* @__PURE__ */ d(e ? ht : "a", { "data-sidebar": "menu-sub-button", "data-slot": "sidebar-menu-sub-button", "data-size": t, "data-active": n, className: T("flex min-w-0 -translate-x-px items-center gap-2 overflow-hidden rounded-md px-2 py-1.5 text-left text-sm outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground data-[active=true]:bg-sidebar-accent data-[active=true]:font-medium group-data-[collapsible=icon]:hidden disabled:pointer-events-none disabled:opacity-50 aria-disabled:pointer-events-none aria-disabled:opacity-50 [&>span:last-child]:truncate [&>svg]:size-4 [&>svg]:shrink-0", t === "sm" && "text-xs", o), ...r });
}
function kw({ className: e, size: t = "default", ...n }) {
  return /* @__PURE__ */ d(
    Bh,
    {
      "data-slot": "switch",
      "data-size": t,
      className: T(
        "peer inline-flex shrink-0 items-center rounded-full border border-transparent outline-none transition-colors focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=unchecked]:bg-input",
        t === "sm" ? "h-3.5 w-6" : "h-[18.4px] w-8",
        e
      ),
      ...n,
      children: /* @__PURE__ */ d(
        Wh,
        {
          "data-slot": "switch-thumb",
          className: T(
            "pointer-events-none block rounded-full bg-background ring-0 transition-transform data-[state=unchecked]:translate-x-0 data-[state=checked]:translate-x-[calc(100%-2px)]",
            t === "sm" ? "size-3" : "size-4"
          )
        }
      )
    }
  );
}
function Mw({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-slot": "table-container", className: "relative w-full overflow-auto", children: /* @__PURE__ */ d("table", { "data-slot": "table", className: T("w-full caption-bottom text-sm", e), ...t }) });
}
function Ow({ className: e, ...t }) {
  return /* @__PURE__ */ d("thead", { "data-slot": "table-header", className: T("[&_tr]:border-b", e), ...t });
}
function Dw({ className: e, ...t }) {
  return /* @__PURE__ */ d("tbody", { "data-slot": "table-body", className: T("[&_tr:last-child]:border-0", e), ...t });
}
function Nw({ className: e, ...t }) {
  return /* @__PURE__ */ d("tfoot", { "data-slot": "table-footer", className: T("border-t bg-muted/50 font-medium", e), ...t });
}
function Lw({ className: e, ...t }) {
  return /* @__PURE__ */ d("tr", { "data-slot": "table-row", className: T("border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted", e), ...t });
}
function $w({ className: e, ...t }) {
  return /* @__PURE__ */ d("th", { "data-slot": "table-head", className: T("h-10 px-2 text-left align-middle font-medium text-muted-foreground", e), ...t });
}
function Fw({ className: e, ...t }) {
  return /* @__PURE__ */ d("td", { "data-slot": "table-cell", className: T("p-2 align-middle", e), ...t });
}
function zw({ className: e, ...t }) {
  return /* @__PURE__ */ d("caption", { "data-slot": "table-caption", className: T("mt-4 text-sm text-muted-foreground", e), ...t });
}
function Bw({ className: e, orientation: t = "horizontal", ...n }) {
  return /* @__PURE__ */ d(tg, { "data-slot": "tabs", "data-orientation": t, className: T("group/tabs flex data-[orientation=horizontal]:flex-col has-[>[data-slot=tabs-list][data-variant=line]]:gap-2", e), ...n });
}
const sv = qn("group/tabs-list inline-flex w-fit items-center justify-center text-muted-foreground group-data-[orientation=vertical]/tabs:h-fit group-data-[orientation=vertical]/tabs:flex-col", { variants: { variant: { default: "rounded-lg bg-muted p-1", line: "gap-1 border-b bg-transparent" } }, defaultVariants: { variant: "default" } });
function Vw({ className: e, variant: t = "default", ...n }) {
  return /* @__PURE__ */ d(ng, { "data-slot": "tabs-list", "data-variant": t, className: T(sv({ variant: t }), e), ...n });
}
function Ww({ className: e, ...t }) {
  return /* @__PURE__ */ d(og, { "data-slot": "tabs-trigger", className: T(
    "relative inline-flex h-[calc(100%-1px)] flex-1 items-center justify-center whitespace-nowrap rounded-md px-3 text-sm font-medium text-foreground/60 transition-all group-data-[orientation=vertical]/tabs:w-full group-data-[orientation=vertical]/tabs:justify-start hover:text-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow-sm",
    "group-data-[variant=line]/tabs-list:bg-transparent group-data-[variant=line]/tabs-list:data-[state=active]:bg-transparent group-data-[variant=line]/tabs-list:data-[state=active]:shadow-none",
    "after:absolute after:bg-foreground after:opacity-0 after:transition-opacity group-data-[orientation=horizontal]/tabs:after:inset-x-0 group-data-[orientation=horizontal]/tabs:after:bottom-[-5px] group-data-[orientation=horizontal]/tabs:after:h-0.5 group-data-[orientation=vertical]/tabs:after:inset-y-0 group-data-[orientation=vertical]/tabs:after:-right-1 group-data-[orientation=vertical]/tabs:after:w-0.5 group-data-[variant=line]/tabs-list:data-[state=active]:after:opacity-100",
    e
  ), ...t });
}
function Hw({ className: e, ...t }) {
  return /* @__PURE__ */ d(rg, { "data-slot": "tabs-content", className: T("flex-1 outline-none", e), ...t });
}
function Gw({ className: e, ...t }) {
  return /* @__PURE__ */ d("textarea", { "data-slot": "textarea", className: T("min-h-16 w-full rounded-md border border-input bg-transparent px-2.5 py-2 text-sm outline-none placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 disabled:cursor-not-allowed disabled:opacity-50", e), ...t });
}
export {
  xv as Accordion,
  Sv as AccordionContent,
  yv as AccordionItem,
  Cv as AccordionTrigger,
  Rv as Badge,
  nn as Button,
  Pv as Card,
  Iv as CardAction,
  Av as CardContent,
  Tv as CardDescription,
  kv as CardFooter,
  Ev as CardHeader,
  _v as CardTitle,
  Mv as Checkbox,
  Ov as Dialog,
  Dv as DialogClose,
  Fb as DialogContent,
  Fv as DialogDescription,
  Lv as DialogFooter,
  Nv as DialogHeader,
  yc as DialogOverlay,
  $b as DialogPortal,
  $v as DialogTitle,
  Lb as DialogTrigger,
  zv as DropdownMenu,
  Hv as DropdownMenuCheckboxItem,
  Bv as DropdownMenuContent,
  Vv as DropdownMenuGroup,
  Wv as DropdownMenuItem,
  jv as DropdownMenuLabel,
  zb as DropdownMenuPortal,
  Gv as DropdownMenuRadioGroup,
  Uv as DropdownMenuRadioItem,
  Kv as DropdownMenuSeparator,
  Yv as DropdownMenuShortcut,
  Xv as DropdownMenuSub,
  Zv as DropdownMenuSubContent,
  qv as DropdownMenuSubTrigger,
  Bb as DropdownMenuTrigger,
  Vb as Input,
  Qv as Label,
  Jv as ScrollArea,
  Wb as ScrollBar,
  ew as Select,
  rw as SelectContent,
  tw as SelectGroup,
  iw as SelectItem,
  aw as SelectLabel,
  Gb as SelectScrollDownButton,
  Hb as SelectScrollUpButton,
  sw as SelectSeparator,
  ow as SelectTrigger,
  nw as SelectValue,
  Ub as Separator,
  jb as Sheet,
  cw as SheetClose,
  Sc as SheetContent,
  Zb as SheetDescription,
  lw as SheetFooter,
  Xb as SheetHeader,
  qb as SheetTitle,
  Kb as SheetTrigger,
  fw as Sidebar,
  ww as SidebarContent,
  bw as SidebarFooter,
  xw as SidebarGroup,
  Cw as SidebarGroupAction,
  Sw as SidebarGroupContent,
  yw as SidebarGroupLabel,
  gw as SidebarHeader,
  hw as SidebarInput,
  mw as SidebarInset,
  Rw as SidebarMenu,
  iv as SidebarMenuAction,
  Ew as SidebarMenuBadge,
  av as SidebarMenuButton,
  Pw as SidebarMenuItem,
  _w as SidebarMenuSkeleton,
  Tw as SidebarMenuSub,
  Aw as SidebarMenuSubButton,
  Iw as SidebarMenuSubItem,
  dw as SidebarProvider,
  pw as SidebarRail,
  vw as SidebarSeparator,
  ov as SidebarTrigger,
  Aa as Skeleton,
  kw as Switch,
  Mw as Table,
  Dw as TableBody,
  zw as TableCaption,
  Fw as TableCell,
  Nw as TableFooter,
  $w as TableHead,
  Ow as TableHeader,
  Lw as TableRow,
  Bw as Tabs,
  Hw as TabsContent,
  Vw as TabsList,
  Ww as TabsTrigger,
  Gw as Textarea,
  Qb as Tooltip,
  Jb as TooltipContent,
  uw as TooltipProvider,
  Rc as TooltipTrigger,
  Db as badgeVariants,
  Nb as buttonVariants,
  sv as tabsListVariants,
  Zn as useSidebar
};

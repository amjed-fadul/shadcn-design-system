import type { ComponentContractSet, ComponentDefinition, ComponentFamilyContract, ComponentInvariantAuthority, EffectiveComponentApiShape, InheritedInterfaceContract, StructuredPropType } from "./types";
export declare function isStructuredPropTypeAssignable(source: StructuredPropType, target: StructuredPropType): boolean;
/** Resolves only factual branch shape; it does not validate authored runtime props. */
export declare function resolveConditionalApiShape(component: ComponentDefinition, selection: {
    propName: string;
    equals: string | number | boolean;
}, authority: ComponentInvariantAuthority): EffectiveComponentApiShape;
export declare function validateComponentFamilyInvariants(family: ComponentFamilyContract, authority: ComponentInvariantAuthority): string[];
export declare function assertComponentFamilyInvariants(family: ComponentFamilyContract, authority: ComponentInvariantAuthority): void;
export declare function validateInheritedInterfaceInvariants(contract: InheritedInterfaceContract): string[];
export declare function assertInheritedInterfaceInvariants(contract: InheritedInterfaceContract): void;
export declare function validateComponentContractSetInvariants(contract: ComponentContractSet): string[];
export declare function assertComponentContractSetInvariants(contract: ComponentContractSet): void;

import type { ComponentFamilyContract, SourceExpressionIdentity } from "./types";
export type SourceUnresolvedFinding = SourceExpressionIdentity & {
    reason: string;
};
export type SourceEvidenceResult = {
    topic: string;
    scope: string;
    unresolved: readonly SourceUnresolvedFinding[];
};
/** Source-owned facts are supplied by a configured source adapter. */
export type SourceOwnedSlotFact = {
    propName: string;
    replacesHost: boolean;
    forwardsProps: boolean;
    childCardinality: {
        min: number;
        max: number;
    };
    /** Source-specific exception requirements, when the cardinality has one. */
    childRequires?: string[];
};
/** Turns source-analyzer disagreement into a stable production rejection. */
export declare function reconcileSourceFacts(label: string, contracted: unknown, source: unknown): string[];
/** Preserves source-analyzer failures as a contract rejection rather than a test-only assertion. */
export declare function reconcileSourceAnalyzerErrors(label: string, errors: readonly string[]): string[];
/**
 * Refuses to treat an artifact as complete when source analysis recorded
 * evidence that the artifact does not explicitly carry as unresolved.
 */
export declare function reconcileSourceEvidenceCompleteness(family: ComponentFamilyContract, analyses: readonly SourceEvidenceResult[]): string[];
/** Reconciles source-owned delegated-host facts supplied by a source adapter. */
export declare function reconcileSourceOwnedSlotCardinality(family: ComponentFamilyContract, exportName: string, sourceFacts: readonly SourceOwnedSlotFact[], sourceOwnedPropNames?: readonly string[]): string[];

import type { ComponentContractSet, ComponentFamilyContract, ComponentInvariantAuthority, InheritedInterfaceContract } from "./types";
export type ComponentContractArtifactSource = {
    readJson(path: string): unknown;
};
export type ComponentContractIndexFamily = {
    familyId: string;
    components: string[];
    hooks: string[];
    helpers: string[];
};
export type ComponentContractIndex = {
    schemaVersion: 1;
    contractSetId: string;
    familyCount: number;
    families: ComponentContractIndexFamily[];
};
export type ComponentContractSourceReconciliationContext = Readonly<{
    contractSet: ComponentContractSet;
    families: readonly ComponentFamilyContract[];
    interfaces: readonly InheritedInterfaceContract[];
}>;
export type ComponentContractSourceReconciler = (context: ComponentContractSourceReconciliationContext) => readonly string[];
export type ComponentContractLoaderOptions = Readonly<{
    source: ComponentContractArtifactSource;
    contractSetPath?: string;
    indexPath?: string;
    tokenIds?: ReadonlySet<string>;
    derivedTokenRuleIds?: ReadonlySet<string>;
    capabilityIds?: ReadonlySet<string>;
    sourceReconciler?: ComponentContractSourceReconciler;
    contractSetReconciler?: (contractSet: ComponentContractSet) => readonly string[];
    sourceIdentityForFamily?: (familyId: string) => ComponentInvariantAuthority["sourceIdentity"] | undefined;
    requireSourceIdentity?: boolean;
}>;
export type DeepReadonly<T> = T extends (...args: never[]) => unknown ? T : T extends readonly (infer U)[] ? readonly DeepReadonly<U>[] : T extends object ? {
    readonly [K in keyof T]: DeepReadonly<T[K]>;
} : T;
export type LoadedComponentContracts = DeepReadonly<{
    contractSet: ComponentContractSet;
    families: ComponentFamilyContract[];
    interfaces: InheritedInterfaceContract[];
}>;
export type ComponentContractLoadErrorCode = "COMPONENT_CONTRACT_ARTIFACT_NOT_FOUND" | "COMPONENT_CONTRACT_ARTIFACT_INVALID" | "COMPONENT_CONTRACT_SCHEMA_INVALID" | "COMPONENT_CONTRACT_INDEX_DRIFT";
export declare class ComponentContractLoadError extends Error {
    readonly code: ComponentContractLoadErrorCode;
    readonly artifactPath?: string | undefined;
    constructor(code: ComponentContractLoadErrorCode, message: string, artifactPath?: string | undefined);
}
/** Builds a design-system-neutral immutable loader; source ownership is configured at the boundary. */
export declare function createComponentContractLoader(options: ComponentContractLoaderOptions): () => LoadedComponentContracts;

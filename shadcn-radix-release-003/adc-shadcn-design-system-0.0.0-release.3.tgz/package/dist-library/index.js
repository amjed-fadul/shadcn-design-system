var Wr = (e) => {
  throw TypeError(e);
};
var Hr = (e, t, n) => t.has(e) || Wr("Cannot " + n);
var be = (e, t, n) => (Hr(e, t, "read from private field"), n ? n.call(e) : t.get(e)), Gr = (e, t, n) => t.has(e) ? Wr("Cannot add the same private member more than once") : t instanceof WeakSet ? t.add(e) : t.set(e, n), eo = (e, t, n, o) => (Hr(e, t, "write to private field"), o ? o.call(e, n) : t.set(e, n), n);
import { jsx as d, Fragment as mt, jsxs as Q } from "react/jsx-runtime";
import * as s from "react";
import { useState as Ec, useLayoutEffect as _c, useContext as Tc, createContext as Ic, forwardRef as ka, createElement as bo } from "react";
import * as Ut from "react-dom";
var Ac = Object.defineProperty, Wo = (e, t) => Ac(e, "name", { value: t, configurable: !0 });
function vo(e, t) {
  if (typeof e == "function")
    return e(t);
  e != null && (e.current = t);
}
Wo(vo, "setRef");
function Ma(...e) {
  return (t) => {
    let n = !1;
    const o = e.map((r) => {
      const a = vo(r, t);
      return !n && typeof a == "function" && (n = !0), a;
    });
    if (n)
      return () => {
        for (let r = 0; r < o.length; r++) {
          const a = o[r];
          typeof a == "function" ? a() : vo(e[r], null);
        }
      };
  };
}
Wo(Ma, "composeRefs");
function H(...e) {
  return s.useCallback(Ma(...e), e);
}
Wo(H, "useComposedRefs");
var kc = Object.defineProperty, De = (e, t) => kc(e, "name", { value: t, configurable: !0 });
// @__NO_SIDE_EFFECTS__
function ze(e) {
  const t = s.forwardRef((n, o) => {
    let { children: r, ...a } = n, i = null, c = !1;
    const l = [];
    wo(r) && typeof on == "function" && (r = on(r._payload)), s.Children.forEach(r, (p) => {
      if ($a(p)) {
        c = !0;
        const h = p;
        let g = "child" in h.props ? h.props.child : h.props.children;
        wo(g) && typeof on == "function" && (g = on(g._payload)), i = Mc(h, g), l.push(i?.props?.children);
      } else
        l.push(p);
    }), i ? i = s.cloneElement(i, void 0, l) : (
      // A `Slottable` was found but it didn't resolve to a single element (e.g.
      // it wrapped multiple elements, text, or a render-prop `child` that
      // wasn't an element). Don't fall back to treating the `Slottable` wrapper
      // itself as the slot target — throw a descriptive error below instead.
      !c && s.Children.count(r) === 1 && s.isValidElement(r) && (i = r)
    );
    const u = i ? La(i) : void 0, m = H(o, u);
    if (!i) {
      if (r || r === 0)
        throw new Error(
          c ? Nc(e) : Dc(e)
        );
      return r;
    }
    const f = Na(a, i.props ?? {});
    return i.type !== s.Fragment && (f.ref = o ? m : u), s.cloneElement(i, f);
  });
  return t.displayName = `${e}.Slot`, t;
}
De(ze, "createSlot");
var ht = /* @__PURE__ */ ze("Slot"), Oa = /* @__PURE__ */ Symbol.for("radix.slottable");
// @__NO_SIDE_EFFECTS__
function Da(e) {
  const t = /* @__PURE__ */ De((n) => "child" in n ? n.children(n.child) : n.children, "Slottable");
  return t.displayName = `${e}.Slottable`, t.__radixId = Oa, t;
}
De(Da, "createSlottable");
var Mc = /* @__PURE__ */ De((e, t) => {
  if ("child" in e.props) {
    const n = e.props.child;
    return s.isValidElement(n) ? s.cloneElement(n, void 0, e.props.children(n.props.children)) : null;
  }
  return s.isValidElement(t) ? t : null;
}, "getSlottableElementFromSlottable");
function Na(e, t) {
  const n = { ...t };
  for (const o in t) {
    const r = e[o], a = t[o];
    /^on[A-Z]/.test(o) ? r && a ? n[o] = (...c) => {
      const l = a(...c);
      return r(...c), l;
    } : r && (n[o] = r) : o === "style" ? n[o] = { ...r, ...a } : o === "className" && (n[o] = [r, a].filter(Boolean).join(" "));
  }
  return { ...e, ...n };
}
De(Na, "mergeProps");
function La(e) {
  let t = Object.getOwnPropertyDescriptor(e.props, "ref")?.get, n = t && "isReactWarning" in t && t.isReactWarning;
  return n ? e.ref : (t = Object.getOwnPropertyDescriptor(e, "ref")?.get, n = t && "isReactWarning" in t && t.isReactWarning, n ? e.props.ref : e.props.ref || e.ref);
}
De(La, "getElementRef");
function $a(e) {
  return s.isValidElement(e) && typeof e.type == "function" && "__radixId" in e.type && e.type.__radixId === Oa;
}
De($a, "isSlottable");
var Oc = /* @__PURE__ */ Symbol.for("react.lazy");
function wo(e) {
  return e != null && typeof e == "object" && "$$typeof" in e && e.$$typeof === Oc && "_payload" in e && Fa(e._payload);
}
De(wo, "isLazyComponent");
function Fa(e) {
  return typeof e == "object" && e !== null && "then" in e;
}
De(Fa, "isPromiseLike");
var Dc = /* @__PURE__ */ De((e) => `${e} failed to slot onto its children. Expected a single React element child or \`Slottable\`.`, "createSlotError"), Nc = /* @__PURE__ */ De((e) => `${e} failed to slot onto its \`Slottable\`. Expected \`Slottable\` to receive a single React element child.`, "createSlottableError"), on = s[" use ".trim().toString()], Lc = Object.defineProperty, $c = (e, t) => Lc(e, "name", { value: t, configurable: !0 }), Fc = [
  "a",
  "button",
  "div",
  "form",
  "h2",
  "h3",
  "img",
  "input",
  "label",
  "li",
  "nav",
  "ol",
  "p",
  "select",
  "span",
  "svg",
  "ul"
], $ = Fc.reduce((e, t) => {
  const n = /* @__PURE__ */ ze(`Primitive.${t}`), o = s.forwardRef((r, a) => {
    const { asChild: i, ...c } = r, l = i ? n : t;
    return typeof window < "u" && (window[/* @__PURE__ */ Symbol.for("radix-ui")] = !0), /* @__PURE__ */ d(l, { ...c, ref: a });
  });
  return o.displayName = `Primitive.${t}`, { ...e, [t]: o };
}, {});
function Ho(e, t) {
  e && Ut.flushSync(() => e.dispatchEvent(t));
}
$c(Ho, "dispatchDiscreteCustomEvent");
var zc = Object.defineProperty, Bc = (e, t) => zc(e, "name", { value: t, configurable: !0 }), za = Object.freeze({
  // See: https://github.com/twbs/bootstrap/blob/main/scss/mixins/_visually-hidden.scss
  position: "absolute",
  border: 0,
  width: 1,
  height: 1,
  padding: 0,
  margin: -1,
  overflow: "hidden",
  clip: "rect(0, 0, 0, 0)",
  whiteSpace: "nowrap",
  wordWrap: "normal"
}), Vc = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ Bc(function(t, n) {
    return /* @__PURE__ */ d(
      $.span,
      {
        ...t,
        ref: n,
        style: { ...za, ...t.style }
      }
    );
  }, "VisuallyHidden")
), Wc = Vc, Hc = Object.defineProperty, Ae = (e, t) => Hc(e, "name", { value: t, configurable: !0 });
// @__NO_SIDE_EFFECTS__
function Gc(e, t) {
  const n = s.createContext(t);
  n.displayName = e + "Context";
  const o = /* @__PURE__ */ Ae((a) => {
    const { children: i, ...c } = a, l = s.useMemo(() => c, Object.values(c));
    return /* @__PURE__ */ d(n.Provider, { value: l, children: i });
  }, "Provider");
  o.displayName = e + "Provider";
  function r(a, i = {}) {
    const { optional: c = !1 } = i, l = s.useContext(n);
    if (l) return l;
    if (t !== void 0) return t;
    if (!c)
      throw new Error(`\`${a}\` must be used within \`${e}\``);
  }
  return Ae(r, "useContext"), [o, r];
}
Ae(Gc, "createContext");
// @__NO_SIDE_EFFECTS__
function we(e, t = []) {
  let n = [];
  function o(a, i) {
    const c = s.createContext(i);
    c.displayName = a + "Context";
    const l = n.length;
    n = [...n, i];
    const u = /* @__PURE__ */ Ae((f) => {
      const { scope: p, children: h, ...g } = f, b = p?.[e]?.[l] || c, v = s.useMemo(() => g, Object.values(g));
      return /* @__PURE__ */ d(b.Provider, { value: v, children: h });
    }, "Provider");
    u.displayName = a + "Provider";
    function m(f, p, h = {}) {
      const { optional: g = !1 } = h, b = p?.[e]?.[l] || c, v = s.useContext(b);
      if (v) return v;
      if (i !== void 0) return i;
      if (!g)
        throw new Error(`\`${f}\` must be used within \`${a}\``);
    }
    return Ae(m, "useContext"), [u, m];
  }
  Ae(o, "createContext");
  const r = /* @__PURE__ */ Ae(() => {
    const a = n.map((i) => s.createContext(i));
    return /* @__PURE__ */ Ae(function(c) {
      const l = c?.[e] || a;
      return s.useMemo(
        () => ({ [`__scope${e}`]: { ...c, [e]: l } }),
        [c, l]
      );
    }, "useScope");
  }, "createScope");
  return r.scopeName = e, [o, Ba(r, ...t)];
}
Ae(we, "createContextScope");
function Ba(...e) {
  const t = e[0];
  if (e.length === 1) return t;
  const n = /* @__PURE__ */ Ae(() => {
    const o = e.map((r) => ({
      useScope: r(),
      scopeName: r.scopeName
    }));
    return /* @__PURE__ */ Ae(function(a) {
      const i = o.reduce((c, { useScope: l, scopeName: u }) => {
        const f = l(a)[`__scope${u}`];
        return { ...c, ...f };
      }, {});
      return s.useMemo(() => ({ [`__scope${t.scopeName}`]: i }), [i]);
    }, "useComposedScopes");
  }, "createScope");
  return n.scopeName = t.scopeName, n;
}
Ae(Ba, "composeContextScopes");
var Uc = Object.defineProperty, me = (e, t) => Uc(e, "name", { value: t, configurable: !0 });
// @__NO_SIDE_EFFECTS__
function jt(e) {
  const t = e + "CollectionProvider", [n, o] = /* @__PURE__ */ we(t), [r, a] = n(
    t,
    { collectionRef: { current: null }, itemMap: /* @__PURE__ */ new Map() }
  ), i = /* @__PURE__ */ me((b) => {
    const { scope: v, children: y } = b, x = s.useRef(null), w = s.useRef(/* @__PURE__ */ new Map()).current;
    return /* @__PURE__ */ d(r, { scope: v, itemMap: w, collectionRef: x, children: y });
  }, "CollectionProvider");
  i.displayName = t;
  const c = e + "CollectionSlot", l = /* @__PURE__ */ ze(c), u = s.forwardRef(
    (b, v) => {
      const { scope: y, children: x } = b, w = a(c, y), C = H(v, w.collectionRef);
      return /* @__PURE__ */ d(l, { ref: C, children: x });
    }
  );
  u.displayName = c;
  const m = e + "CollectionItemSlot", f = "data-radix-collection-item", p = /* @__PURE__ */ ze(m), h = s.forwardRef(
    (b, v) => {
      const { scope: y, children: x, ...w } = b, C = s.useRef(null), P = H(v, C), S = a(m, y);
      return s.useEffect(() => (S.itemMap.set(C, { ref: C, ...w }), () => {
        S.itemMap.delete(C);
      })), /* @__PURE__ */ d(p, { [f]: "", ref: P, children: x });
    }
  );
  h.displayName = m;
  function g(b) {
    const v = a(e + "CollectionConsumer", b);
    return s.useCallback(() => {
      const x = v.collectionRef.current;
      if (!x) return [];
      const w = Array.from(x.querySelectorAll(`[${f}]`));
      return Array.from(v.itemMap.values()).sort(
        (S, _) => w.indexOf(S.ref.current) - w.indexOf(_.ref.current)
      );
    }, [v.collectionRef, v.itemMap]);
  }
  return me(g, "useCollection"), [
    { Provider: i, Slot: u, ItemSlot: h },
    g,
    o
  ];
}
me(jt, "createCollection");
var Ur = /* @__PURE__ */ new WeakMap(), se, Ee, to = (Ee = class extends Map {
  constructor(n) {
    super(n);
    Gr(this, se);
    eo(this, se, [...super.keys()]), Ur.set(this, !0);
  }
  set(n, o) {
    return Ur.get(this) && (this.has(n) ? be(this, se)[be(this, se).indexOf(n)] = n : be(this, se).push(n)), super.set(n, o), this;
  }
  insert(n, o, r) {
    const a = this.has(o), i = be(this, se).length, c = Go(n);
    let l = c >= 0 ? c : i + c;
    const u = l < 0 || l >= i ? -1 : l;
    if (u === this.size || a && u === this.size - 1 || u === -1)
      return this.set(o, r), this;
    const m = this.size + (a ? 0 : 1);
    c < 0 && l++;
    const f = [...be(this, se)];
    let p, h = !1;
    for (let g = l; g < m; g++)
      if (l === g) {
        let b = f[g];
        f[g] === o && (b = f[g + 1]), a && this.delete(o), p = this.get(b), this.set(o, r);
      } else {
        !h && f[g - 1] === o && (h = !0);
        const b = f[h ? g : g - 1], v = p;
        p = this.get(b), this.delete(b), this.set(b, v);
      }
    return this;
  }
  with(n, o, r) {
    const a = new Ee(this);
    return a.insert(n, o, r), a;
  }
  before(n) {
    const o = be(this, se).indexOf(n) - 1;
    if (!(o < 0))
      return this.entryAt(o);
  }
  /**
   * Sets a new key-value pair at the position before the given key.
   */
  setBefore(n, o, r) {
    const a = be(this, se).indexOf(n);
    return a === -1 ? this : this.insert(a, o, r);
  }
  after(n) {
    let o = be(this, se).indexOf(n);
    if (o = o === -1 || o === this.size - 1 ? -1 : o + 1, o !== -1)
      return this.entryAt(o);
  }
  /**
   * Sets a new key-value pair at the position after the given key.
   */
  setAfter(n, o, r) {
    const a = be(this, se).indexOf(n);
    return a === -1 ? this : this.insert(a + 1, o, r);
  }
  first() {
    return this.entryAt(0);
  }
  last() {
    return this.entryAt(-1);
  }
  clear() {
    return eo(this, se, []), super.clear();
  }
  delete(n) {
    const o = super.delete(n);
    return o && be(this, se).splice(be(this, se).indexOf(n), 1), o;
  }
  deleteAt(n) {
    const o = this.keyAt(n);
    return o !== void 0 ? this.delete(o) : !1;
  }
  at(n) {
    const o = hn(be(this, se), n);
    if (o !== void 0)
      return this.get(o);
  }
  entryAt(n) {
    const o = hn(be(this, se), n);
    if (o !== void 0)
      return [o, this.get(o)];
  }
  indexOf(n) {
    return be(this, se).indexOf(n);
  }
  keyAt(n) {
    return hn(be(this, se), n);
  }
  from(n, o) {
    const r = this.indexOf(n);
    if (r === -1)
      return;
    let a = r + o;
    return a < 0 && (a = 0), a >= this.size && (a = this.size - 1), this.at(a);
  }
  keyFrom(n, o) {
    const r = this.indexOf(n);
    if (r === -1)
      return;
    let a = r + o;
    return a < 0 && (a = 0), a >= this.size && (a = this.size - 1), this.keyAt(a);
  }
  find(n, o) {
    let r = 0;
    for (const a of this) {
      if (Reflect.apply(n, o, [a, r, this]))
        return a;
      r++;
    }
  }
  findIndex(n, o) {
    let r = 0;
    for (const a of this) {
      if (Reflect.apply(n, o, [a, r, this]))
        return r;
      r++;
    }
    return -1;
  }
  filter(n, o) {
    const r = [];
    let a = 0;
    for (const i of this)
      Reflect.apply(n, o, [i, a, this]) && r.push(i), a++;
    return new Ee(r);
  }
  map(n, o) {
    const r = [];
    let a = 0;
    for (const i of this)
      r.push([i[0], Reflect.apply(n, o, [i, a, this])]), a++;
    return new Ee(r);
  }
  reduce(...n) {
    const [o, r] = n;
    let a = 0, i = r ?? this.at(0);
    for (const c of this)
      a === 0 && n.length === 1 ? i = c : i = Reflect.apply(o, this, [i, c, a, this]), a++;
    return i;
  }
  reduceRight(...n) {
    const [o, r] = n;
    let a = r ?? this.at(-1);
    for (let i = this.size - 1; i >= 0; i--) {
      const c = this.at(i);
      i === this.size - 1 && n.length === 1 ? a = c : a = Reflect.apply(o, this, [a, c, i, this]);
    }
    return a;
  }
  toSorted(n) {
    const o = [...this.entries()].sort(n);
    return new Ee(o);
  }
  toReversed() {
    const n = new Ee();
    for (let o = this.size - 1; o >= 0; o--) {
      const r = this.keyAt(o), a = this.get(r);
      n.set(r, a);
    }
    return n;
  }
  toSpliced(...n) {
    const o = [...this.entries()];
    return o.splice(...n), new Ee(o);
  }
  slice(n, o) {
    const r = new Ee();
    let a = this.size - 1;
    if (n === void 0)
      return r;
    n < 0 && (n = n + this.size), o !== void 0 && o > 0 && (a = o - 1);
    for (let i = n; i <= a; i++) {
      const c = this.keyAt(i), l = this.get(c);
      r.set(c, l);
    }
    return r;
  }
  every(n, o) {
    let r = 0;
    for (const a of this) {
      if (!Reflect.apply(n, o, [a, r, this]))
        return !1;
      r++;
    }
    return !0;
  }
  some(n, o) {
    let r = 0;
    for (const a of this) {
      if (Reflect.apply(n, o, [a, r, this]))
        return !0;
      r++;
    }
    return !1;
  }
}, se = new WeakMap(), me(Ee, "OrderedDict"), Ee);
function hn(e, t) {
  if ("at" in Array.prototype)
    return Array.prototype.at.call(e, t);
  const n = Va(e, t);
  return n === -1 ? void 0 : e[n];
}
me(hn, "at");
function Va(e, t) {
  const n = e.length, o = Go(t), r = o >= 0 ? o : n + o;
  return r < 0 || r >= n ? -1 : r;
}
me(Va, "toSafeIndex");
function Go(e) {
  return e !== e || e === 0 ? 0 : Math.trunc(e);
}
me(Go, "toSafeInteger");
// @__NO_SIDE_EFFECTS__
function jc(e) {
  const t = e + "CollectionProvider", [n, o] = /* @__PURE__ */ we(t), [r, a] = n(
    t,
    {
      collectionElement: null,
      collectionRef: { current: null },
      collectionRefObject: { current: null },
      itemMap: new to(),
      setItemMap: /* @__PURE__ */ me(() => {
      }, "setItemMap")
    }
  ), i = /* @__PURE__ */ me(({ state: w, ...C }) => w ? /* @__PURE__ */ d(l, { ...C, state: w }) : /* @__PURE__ */ d(c, { ...C }), "CollectionProvider");
  i.displayName = t;
  const c = /* @__PURE__ */ me((w) => {
    const C = v();
    return /* @__PURE__ */ d(l, { ...w, state: C });
  }, "CollectionInit");
  c.displayName = t + "Init";
  const l = /* @__PURE__ */ me((w) => {
    const { scope: C, children: P, state: S } = w, _ = s.useRef(null), [R, I] = s.useState(
      null
    ), k = H(_, I), [N, M] = S;
    return s.useEffect(() => {
      if (!R) return;
      const F = Ga(() => {
      });
      return F.observe(R, {
        childList: !0,
        subtree: !0
      }), () => {
        F.disconnect();
      };
    }, [R]), /* @__PURE__ */ d(
      r,
      {
        scope: C,
        itemMap: N,
        setItemMap: M,
        collectionRef: k,
        collectionRefObject: _,
        collectionElement: R,
        children: P
      }
    );
  }, "CollectionProviderImpl");
  l.displayName = t + "Impl";
  const u = e + "CollectionSlot", m = /* @__PURE__ */ ze(u), f = s.forwardRef(
    (w, C) => {
      const { scope: P, children: S } = w, _ = a(u, P), R = H(C, _.collectionRef);
      return /* @__PURE__ */ d(m, { ref: R, children: S });
    }
  );
  f.displayName = u;
  const p = e + "CollectionItemSlot", h = "data-radix-collection-item", g = /* @__PURE__ */ ze(p), b = s.forwardRef(
    (w, C) => {
      const { scope: P, children: S, ..._ } = w, R = s.useRef(null), [I, k] = s.useState(null), N = H(C, R, k), M = a(p, P), { setItemMap: F } = M, V = s.useRef(_);
      Wa(V.current, _) || (V.current = _);
      const j = V.current;
      return s.useEffect(() => {
        const B = j;
        return F((z) => I ? z.has(I) ? z.set(I, { ...B, element: I }).toSorted(xo) : (z.set(I, { ...B, element: I }), z.toSorted(xo)) : z), () => {
          F((z) => !I || !z.has(I) ? z : (z.delete(I), new to(z)));
        };
      }, [I, j, F]), /* @__PURE__ */ d(g, { [h]: "", ref: N, children: S });
    }
  );
  b.displayName = p;
  function v() {
    return s.useState(new to());
  }
  me(v, "useInitCollection");
  function y(w) {
    const { itemMap: C } = a(e + "CollectionConsumer", w);
    return C;
  }
  return me(y, "useCollection"), [
    { Provider: i, Slot: f, ItemSlot: b },
    {
      createCollectionScope: o,
      useCollection: y,
      useInitCollection: v
    }
  ];
}
me(jc, "createCollection");
function Wa(e, t) {
  if (e === t) return !0;
  if (typeof e != "object" || typeof t != "object" || e == null || t == null) return !1;
  const n = Object.keys(e), o = Object.keys(t);
  if (n.length !== o.length) return !1;
  for (const r of n)
    if (!Object.prototype.hasOwnProperty.call(t, r) || e[r] !== t[r]) return !1;
  return !0;
}
me(Wa, "shallowEqual");
function Ha(e, t) {
  return !!(t.compareDocumentPosition(e) & Node.DOCUMENT_POSITION_PRECEDING);
}
me(Ha, "isElementPreceding");
function xo(e, t) {
  return !e[1].element || !t[1].element ? 0 : Ha(e[1].element, t[1].element) ? -1 : 1;
}
me(xo, "sortByDocumentPosition");
function Ga(e) {
  return new MutationObserver((n) => {
    for (const o of n)
      if (o.type === "childList") {
        e();
        return;
      }
  });
}
me(Ga, "getChildListObserver");
var Kc = Object.defineProperty, Mt = (e, t) => Kc(e, "name", { value: t, configurable: !0 }), Ua = !!(typeof window < "u" && window.document && window.document.createElement);
function A(e, t, { checkForDefaultPrevented: n = !0 } = {}) {
  return /* @__PURE__ */ Mt(function(r) {
    if (e?.(r), n === !1 || !r || !r.defaultPrevented)
      return t?.(r);
  }, "handleEvent");
}
Mt(A, "composeEventHandlers");
function Yc(e) {
  if (!Ua)
    throw new Error("Cannot access window outside of the DOM");
  return e?.ownerDocument?.defaultView ?? window;
}
Mt(Yc, "getOwnerWindow");
function yo(e) {
  if (!Ua)
    throw new Error("Cannot access document outside of the DOM");
  return e?.ownerDocument ?? document;
}
Mt(yo, "getOwnerDocument");
function ja(e, t = !1) {
  const { activeElement: n } = yo(e);
  if (!n?.nodeName)
    return null;
  if (Ka(n) && n.contentDocument)
    return ja(n.contentDocument.body, t);
  if (t) {
    const o = n.getAttribute("aria-activedescendant");
    if (o) {
      const r = yo(n).getElementById(o);
      if (r)
        return r;
    }
  }
  return n;
}
Mt(ja, "getActiveElement");
function Ka(e) {
  return e.tagName === "IFRAME";
}
Mt(Ka, "isFrame");
var re = globalThis?.document ? s.useLayoutEffect : () => {
}, Xc = Object.defineProperty, qc = (e, t) => Xc(e, "name", { value: t, configurable: !0 }), jr = s[" useEffectEvent ".trim().toString()], Kr = s[" useInsertionEffect ".trim().toString()];
function Ya(e) {
  if (typeof jr == "function")
    return jr(e);
  const t = s.useRef(() => {
    throw new Error("Cannot call an event handler while rendering.");
  });
  return typeof Kr == "function" ? Kr(() => {
    t.current = e;
  }) : re(() => {
    t.current = e;
  }), s.useMemo(() => ((...n) => t.current?.(...n)), []);
}
qc(Ya, "useEffectEvent");
var Zc = Object.defineProperty, Kt = (e, t) => Zc(e, "name", { value: t, configurable: !0 }), Qc = s[" useInsertionEffect ".trim().toString()] || re;
function Re({
  prop: e,
  defaultProp: t,
  onChange: n = /* @__PURE__ */ Kt(() => {
  }, "onChange"),
  caller: o
}) {
  const [r, a, i] = Xa({
    defaultProp: t,
    onChange: n
  }), c = e !== void 0, l = c ? e : r, u = s.useCallback(
    (m) => {
      if (c) {
        const f = qa(m) ? m(e) : m;
        f !== e && i.current?.(f);
      } else
        a(m);
    },
    [c, e, a, i]
  );
  return [l, u];
}
Kt(Re, "useControllableState");
function Xa({
  defaultProp: e,
  onChange: t
}) {
  const [n, o] = s.useState(e), r = s.useRef(n), a = s.useRef(t);
  return Qc(() => {
    a.current = t;
  }, [t]), s.useEffect(() => {
    r.current !== n && (a.current?.(n), r.current = n);
  }, [n, r]), [n, o, a];
}
Kt(Xa, "useUncontrolledState");
function qa(e) {
  return typeof e == "function";
}
Kt(qa, "isFunction");
var Yr = /* @__PURE__ */ Symbol("RADIX:SYNC_STATE");
function Jc(e, t, n, o) {
  const { prop: r, defaultProp: a, onChange: i, caller: c } = t, l = r !== void 0, u = Ya(i), m = [{ ...n, state: a }];
  o && m.push(o);
  const [f, p] = s.useReducer(
    (v, y) => {
      if (y.type === Yr)
        return { ...v, state: y.state };
      const x = e(v, y);
      return l && !Object.is(x.state, v.state) && u(x.state), x;
    },
    ...m
  ), h = f.state, g = s.useRef(h);
  s.useEffect(() => {
    g.current !== h && (g.current = h, l || u(h));
  }, [h, g, l]);
  const b = s.useMemo(() => r !== void 0 ? { ...f, state: r } : f, [f, r]);
  return s.useEffect(() => {
    l && !Object.is(r, f.state) && p({ type: Yr, state: r });
  }, [r, f.state, l]), [b, p];
}
Kt(Jc, "useControllableStateReducer");
var el = Object.defineProperty, Xe = (e, t) => el(e, "name", { value: t, configurable: !0 });
function Za(e, t) {
  return s.useReducer((n, o) => t[n][o] ?? n, e);
}
Xe(Za, "useStateMachine");
var he = /* @__PURE__ */ Xe((e) => {
  const { present: t, children: n } = e, o = Qa(t), r = typeof n == "function" ? n({ present: o.isPresent }) : s.Children.only(n), a = Ja(o.ref, ei(r));
  return typeof n == "function" || o.isPresent ? s.cloneElement(r, { ref: a }) : null;
}, "Presence");
function Qa(e) {
  const [t, n] = s.useState(), o = s.useRef(null), r = s.useRef(e), a = s.useRef("none"), i = s.useRef(void 0), c = e ? "mounted" : "unmounted", [l, u] = Za(c, {
    mounted: {
      UNMOUNT: "unmounted",
      ANIMATION_OUT: "unmountSuspended"
    },
    unmountSuspended: {
      MOUNT: "mounted",
      ANIMATION_END: "unmounted"
    },
    unmounted: {
      MOUNT: "mounted"
    }
  });
  return s.useEffect(() => {
    l === "mounted" ? (a.current = i.current ?? _t(o.current), i.current = void 0) : a.current = "none";
  }, [l]), re(() => {
    const m = o.current, f = r.current;
    if (f !== e) {
      const h = a.current, g = _t(m);
      e ? (i.current = g, u("MOUNT")) : g === "none" || m?.display === "none" ? u("UNMOUNT") : u(f && h !== g ? "ANIMATION_OUT" : "UNMOUNT"), r.current = e;
    }
  }, [e, u]), re(() => {
    if (t) {
      let m;
      const f = t.ownerDocument.defaultView ?? window, p = /* @__PURE__ */ Xe((g) => {
        const v = _t(o.current).includes(CSS.escape(g.animationName));
        if (g.target === t && v && (u("ANIMATION_END"), !r.current)) {
          const y = t.style.animationFillMode;
          t.style.animationFillMode = "forwards", m = f.setTimeout(() => {
            t.style.animationFillMode === "forwards" && (t.style.animationFillMode = y);
          });
        }
      }, "handleAnimationEnd"), h = /* @__PURE__ */ Xe((g) => {
        g.target === t && (a.current = _t(o.current));
      }, "handleAnimationStart");
      return t.addEventListener("animationstart", h), t.addEventListener("animationcancel", p), t.addEventListener("animationend", p), () => {
        f.clearTimeout(m), t.removeEventListener("animationstart", h), t.removeEventListener("animationcancel", p), t.removeEventListener("animationend", p);
      };
    } else
      u("ANIMATION_END");
  }, [t, u]), {
    isPresent: ["mounted", "unmountSuspended"].includes(l),
    ref: s.useCallback((m) => {
      if (m) {
        const f = getComputedStyle(m);
        o.current = f, i.current = _t(f);
      } else
        o.current = null;
      n(m);
    }, [])
  };
}
Xe(Qa, "usePresence");
function Co(e, t) {
  if (typeof e == "function")
    return e(t);
  e != null && (e.current = t);
}
Xe(Co, "setRef");
function Ja(...e) {
  const t = s.useRef(e);
  return t.current = e, s.useCallback((n) => {
    const o = t.current;
    let r = !1;
    const a = o.map((i) => {
      const c = Co(i, n);
      return !r && typeof c == "function" && (r = !0), c;
    });
    if (r)
      return () => {
        for (let i = 0; i < a.length; i++) {
          const c = a[i];
          typeof c == "function" ? c() : Co(o[i], null);
        }
      };
  }, []);
}
Xe(Ja, "useStableComposedRefs");
function _t(e) {
  return e?.animationName || "none";
}
Xe(_t, "getAnimationName");
function ei(e) {
  let t = Object.getOwnPropertyDescriptor(e.props, "ref")?.get, n = t && "isReactWarning" in t && t.isReactWarning;
  return n ? e.ref : (t = Object.getOwnPropertyDescriptor(e, "ref")?.get, n = t && "isReactWarning" in t && t.isReactWarning, n ? e.props.ref : e.props.ref || e.ref);
}
Xe(ei, "getElementRef");
var tl = Object.defineProperty, nl = (e, t) => tl(e, "name", { value: t, configurable: !0 }), ol = s[" useId ".trim().toString()] || (() => {
}), rl = 0;
function ve(e) {
  const [t, n] = s.useState(ol());
  return re(() => {
    e || n((o) => o ?? String(rl++));
  }, [e]), e || (t ? `radix-${t}` : "");
}
nl(ve, "useId");
var al = Object.defineProperty, Yt = (e, t) => al(e, "name", { value: t, configurable: !0 }), Uo = "Collapsible", [il, ti] = /* @__PURE__ */ we(Uo), [sl, jo] = il(Uo), cl = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ Yt(function(t, n) {
    const {
      __scopeCollapsible: o,
      open: r,
      defaultOpen: a,
      disabled: i,
      onOpenChange: c,
      ...l
    } = t, [u, m] = Re({
      prop: r,
      defaultProp: a ?? !1,
      onChange: c,
      caller: Uo
    });
    return /* @__PURE__ */ d(
      sl,
      {
        scope: o,
        disabled: i,
        contentId: ve(),
        open: u,
        onOpenToggle: s.useCallback(() => m((f) => !f), [m]),
        children: /* @__PURE__ */ d(
          $.div,
          {
            "data-state": Rn(u),
            "data-disabled": i ? "" : void 0,
            ...l,
            ref: n
          }
        )
      }
    );
  }, "Collapsible")
), ll = "CollapsibleTrigger", ul = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ Yt(function(t, n) {
    const { __scopeCollapsible: o, ...r } = t, a = jo(ll, o);
    return /* @__PURE__ */ d(
      $.button,
      {
        type: "button",
        "aria-controls": a.open ? a.contentId : void 0,
        "aria-expanded": a.open || !1,
        "data-state": Rn(a.open),
        "data-disabled": a.disabled ? "" : void 0,
        disabled: a.disabled,
        ...r,
        ref: n,
        onClick: A(t.onClick, a.onOpenToggle)
      }
    );
  }, "CollapsibleTrigger")
), ni = "CollapsibleContent", dl = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ Yt(function(t, n) {
    const { forceMount: o, ...r } = t, a = jo(ni, t.__scopeCollapsible);
    return /* @__PURE__ */ d(he, { present: o || a.open, children: ({ present: i }) => /* @__PURE__ */ d(fl, { ...r, ref: n, present: i }) });
  }, "CollapsibleContent")
), fl = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ Yt(function(t, n) {
  const { __scopeCollapsible: o, present: r, children: a, ...i } = t, c = jo(ni, o), [l, u] = s.useState(r), m = s.useRef(null), f = H(n, m), p = s.useRef(0), h = p.current, g = s.useRef(0), b = g.current, v = c.open || l, y = s.useRef(v), x = s.useRef(void 0);
  return s.useEffect(() => {
    const w = requestAnimationFrame(() => y.current = !1);
    return () => cancelAnimationFrame(w);
  }, []), re(() => {
    const w = m.current;
    if (w) {
      x.current = x.current || {
        transitionDuration: w.style.transitionDuration,
        animationName: w.style.animationName
      }, w.style.transitionDuration = "0s", w.style.animationName = "none";
      const C = w.getBoundingClientRect();
      p.current = C.height, g.current = C.width, y.current || (w.style.transitionDuration = x.current.transitionDuration, w.style.animationName = x.current.animationName), u(r);
    }
  }, [c.open, r]), /* @__PURE__ */ d(
    $.div,
    {
      "data-state": Rn(c.open),
      "data-disabled": c.disabled ? "" : void 0,
      id: c.contentId,
      hidden: !v,
      ...i,
      ref: f,
      style: {
        "--radix-collapsible-content-height": h ? `${h}px` : void 0,
        "--radix-collapsible-content-width": b ? `${b}px` : void 0,
        ...t.style
      },
      children: v && a
    }
  );
}, "CollapsibleContentImpl"));
function Rn(e) {
  return e ? "open" : "closed";
}
Yt(Rn, "getState");
var pl = cl, ml = ul, hl = dl, gl = Object.defineProperty, bl = (e, t) => gl(e, "name", { value: t, configurable: !0 }), vl = s.createContext(void 0);
function gt(e) {
  const t = s.useContext(vl);
  return e || t || "ltr";
}
bl(gt, "useDirection");
var wl = Object.defineProperty, _e = (e, t) => wl(e, "name", { value: t, configurable: !0 }), We = "Accordion", xl = ["Home", "End", "ArrowDown", "ArrowUp", "ArrowLeft", "ArrowRight"], [Ko, yl, Cl] = /* @__PURE__ */ jt(We), [En, fv] = /* @__PURE__ */ we(We, [
  Cl,
  ti
]), Yo = ti(), Sl = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ _e(function(t, n) {
    const { type: o, ...r } = t, a = r, i = r;
    return /* @__PURE__ */ d(Ko.Provider, { scope: t.__scopeAccordion, children: o === "multiple" ? /* @__PURE__ */ d(_l, { ...i, ref: n }) : /* @__PURE__ */ d(El, { ...a, ref: n }) });
  }, "Accordion")
), [oi, Pl] = En(We), [ri, Rl] = En(
  We,
  { collapsible: !1 }
), El = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ _e(function(t, n) {
    const {
      value: o,
      defaultValue: r,
      onValueChange: a = /* @__PURE__ */ _e(() => {
      }, "onValueChange"),
      collapsible: i = !1,
      ...c
    } = t, [l, u] = Re({
      prop: o,
      defaultProp: r ?? "",
      onChange: a,
      caller: We
    });
    return /* @__PURE__ */ d(
      oi,
      {
        scope: t.__scopeAccordion,
        value: s.useMemo(() => l ? [l] : [], [l]),
        onItemOpen: u,
        onItemClose: s.useCallback(() => i && u(""), [i, u]),
        children: /* @__PURE__ */ d(ri, { scope: t.__scopeAccordion, collapsible: i, children: /* @__PURE__ */ d(ai, { ...c, ref: n }) })
      }
    );
  }, "AccordionImplSingle")
), _l = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ _e(function(t, n) {
  const {
    value: o,
    defaultValue: r,
    onValueChange: a = /* @__PURE__ */ _e(() => {
    }, "onValueChange"),
    ...i
  } = t, [c, l] = Re({
    prop: o,
    defaultProp: r ?? [],
    onChange: a,
    caller: We
  }), u = s.useCallback(
    (f) => l((p = []) => [...p, f]),
    [l]
  ), m = s.useCallback(
    (f) => l((p = []) => p.filter((h) => h !== f)),
    [l]
  );
  return /* @__PURE__ */ d(
    oi,
    {
      scope: t.__scopeAccordion,
      value: c,
      onItemOpen: u,
      onItemClose: m,
      children: /* @__PURE__ */ d(ri, { scope: t.__scopeAccordion, collapsible: !0, children: /* @__PURE__ */ d(ai, { ...i, ref: n }) })
    }
  );
}, "AccordionImplMultiple")), [Tl, _n] = En(We), ai = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ _e(function(t, n) {
    const { __scopeAccordion: o, disabled: r, dir: a, orientation: i = "vertical", ...c } = t, l = s.useRef(null), u = H(l, n), m = yl(o), p = gt(a) === "ltr", h = A(t.onKeyDown, (g) => {
      if (!xl.includes(g.key)) return;
      const b = g.target, v = m().filter((I) => !I.ref.current?.disabled), y = v.findIndex((I) => I.ref.current === b), x = v.length;
      if (y === -1) return;
      g.preventDefault();
      let w = y;
      const C = 0, P = x - 1, S = /* @__PURE__ */ _e(() => {
        w = y + 1, w > P && (w = C);
      }, "moveNext"), _ = /* @__PURE__ */ _e(() => {
        w = y - 1, w < C && (w = P);
      }, "movePrev");
      switch (g.key) {
        case "Home":
          w = C;
          break;
        case "End":
          w = P;
          break;
        case "ArrowRight":
          i === "horizontal" && (p ? S() : _());
          break;
        case "ArrowDown":
          i === "vertical" && S();
          break;
        case "ArrowLeft":
          i === "horizontal" && (p ? _() : S());
          break;
        case "ArrowUp":
          i === "vertical" && _();
          break;
      }
      const R = w % x;
      v[R].ref.current?.focus();
    });
    return /* @__PURE__ */ d(
      Tl,
      {
        scope: o,
        disabled: r,
        direction: a,
        orientation: i,
        children: /* @__PURE__ */ d(Ko.Slot, { scope: o, children: /* @__PURE__ */ d(
          $.div,
          {
            ...c,
            "data-orientation": i,
            ref: u,
            onKeyDown: r ? void 0 : h
          }
        ) })
      }
    );
  }, "AccordionImpl")
), So = "AccordionItem", [Il, Xo] = En(So), Al = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ _e(function(t, n) {
    const { __scopeAccordion: o, value: r, ...a } = t, i = _n(So, o), c = Pl(So, o), l = Yo(o), u = ve(), m = r && c.value.includes(r) || !1, f = i.disabled || t.disabled;
    return /* @__PURE__ */ d(
      Il,
      {
        scope: o,
        open: m,
        disabled: f,
        triggerId: u,
        children: /* @__PURE__ */ d(
          pl,
          {
            "data-orientation": i.orientation,
            "data-state": qo(m),
            ...l,
            ...a,
            ref: n,
            disabled: f,
            open: m,
            onOpenChange: (p) => {
              p ? c.onItemOpen(r) : c.onItemClose(r);
            }
          }
        )
      }
    );
  }, "AccordionItem")
), kl = "AccordionHeader", Ml = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ _e(function(t, n) {
    const { __scopeAccordion: o, ...r } = t, a = _n(We, o), i = Xo(kl, o);
    return /* @__PURE__ */ d(
      $.h3,
      {
        "data-orientation": a.orientation,
        "data-state": qo(i.open),
        "data-disabled": i.disabled ? "" : void 0,
        ...r,
        ref: n
      }
    );
  }, "AccordionHeader")
), Xr = "AccordionTrigger", Ol = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ _e(function(t, n) {
    const { __scopeAccordion: o, ...r } = t, a = _n(We, o), i = Xo(Xr, o), c = Rl(Xr, o), l = Yo(o);
    return /* @__PURE__ */ d(Ko.ItemSlot, { scope: o, children: /* @__PURE__ */ d(
      ml,
      {
        "aria-disabled": i.open && !c.collapsible || void 0,
        "data-orientation": a.orientation,
        id: i.triggerId,
        ...l,
        ...r,
        ref: n
      }
    ) });
  }, "AccordionTrigger")
), Dl = "AccordionContent", Nl = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ _e(function(t, n) {
    const { __scopeAccordion: o, ...r } = t, a = _n(We, o), i = Xo(Dl, o), c = Yo(o);
    return /* @__PURE__ */ d(
      hl,
      {
        role: "region",
        "aria-labelledby": i.triggerId,
        "data-orientation": a.orientation,
        ...c,
        ...r,
        ref: n,
        style: {
          "--radix-accordion-content-height": "var(--radix-collapsible-content-height)",
          "--radix-accordion-content-width": "var(--radix-collapsible-content-width)",
          ...t.style
        }
      }
    );
  }, "AccordionContent")
);
function qo(e) {
  return e ? "open" : "closed";
}
_e(qo, "getState");
var Ll = Sl, $l = Al, Fl = Ml, zl = Ol, Bl = Nl, Vl = Object.defineProperty, Wl = (e, t) => Vl(e, "name", { value: t, configurable: !0 });
function ie(e) {
  const t = s.useRef(e);
  return s.useEffect(() => {
    t.current = e;
  }), s.useMemo(() => ((...n) => t.current?.(...n)), []);
}
Wl(ie, "useCallbackRef");
var Hl = Object.defineProperty, pe = (e, t) => Hl(e, "name", { value: t, configurable: !0 }), Po = "dismissableLayer.update", Gl = "dismissableLayer.pointerDownOutside", Ul = "dismissableLayer.focusOutside", qr, ii = s.createContext({
  layers: /* @__PURE__ */ new Set(),
  layersWithOutsidePointerEventsDisabled: /* @__PURE__ */ new Set(),
  branches: /* @__PURE__ */ new Set(),
  // Outside elements that belong to a layer's own dismiss affordance (eg, a
  // dialog overlay). Pressing them should dismiss the layer regardless of
  // whether or not they stop propagation.
  //
  // See https://github.com/radix-ui/primitives/issues/3346
  dismissableSurfaces: /* @__PURE__ */ new Set()
}), Tn = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ pe(function(t, n) {
    const {
      disableOutsidePointerEvents: o = !1,
      deferPointerDownOutside: r = !1,
      onEscapeKeyDown: a,
      onPointerDownOutside: i,
      onFocusOutside: c,
      onInteractOutside: l,
      onDismiss: u,
      ...m
    } = t, f = s.useContext(ii), [p, h] = s.useState(null), g = p?.ownerDocument ?? globalThis?.document, [, b] = s.useState({}), v = H(n, h), y = Array.from(f.layers), [x] = [
      ...f.layersWithOutsidePointerEventsDisabled
    ].slice(-1), w = x ? y.indexOf(x) : -1, C = p ? y.indexOf(p) : -1, P = f.layersWithOutsidePointerEventsDisabled.size > 0, S = C >= w, _ = s.useRef(!1), R = ci(
      (M) => {
        i?.(M), l?.(M), M.defaultPrevented || u?.();
      },
      {
        ownerDocument: g,
        deferPointerDownOutside: r,
        isDeferredPointerDownOutsideRef: _,
        dismissableSurfaces: f.dismissableSurfaces,
        shouldHandlePointerDownOutside: s.useCallback(
          (M) => {
            if (!(M instanceof Node))
              return !1;
            const F = [...f.branches].some(
              (V) => V.contains(M)
            );
            return S && !F;
          },
          [f.branches, S]
        )
      }
    ), I = li((M) => {
      if (r && _.current)
        return;
      const F = M.target;
      [...f.branches].some((j) => j.contains(F)) || (c?.(M), l?.(M), M.defaultPrevented || u?.());
    }, g), k = p ? C === y.length - 1 : !1, N = ie((M) => {
      M.key === "Escape" && (a?.(M), !M.defaultPrevented && u && (M.preventDefault(), u()));
    });
    return s.useEffect(() => {
      if (k)
        return g.addEventListener("keydown", N, { capture: !0 }), () => g.removeEventListener("keydown", N, { capture: !0 });
    }, [g, k, N]), s.useEffect(() => {
      if (p)
        return o && (f.layersWithOutsidePointerEventsDisabled.size === 0 && (qr = g.body.style.pointerEvents, g.body.style.pointerEvents = "none"), f.layersWithOutsidePointerEventsDisabled.add(p)), f.layers.add(p), Ro(), () => {
          o && (f.layersWithOutsidePointerEventsDisabled.delete(p), f.layersWithOutsidePointerEventsDisabled.size === 0 && (g.body.style.pointerEvents = qr));
        };
    }, [p, g, o, f]), s.useEffect(() => () => {
      p && (f.layers.delete(p), f.layersWithOutsidePointerEventsDisabled.delete(p), Ro());
    }, [p, f]), s.useEffect(() => {
      const M = /* @__PURE__ */ pe(() => b({}), "handleUpdate");
      return document.addEventListener(Po, M), () => document.removeEventListener(Po, M);
    }, []), /* @__PURE__ */ d(
      $.div,
      {
        ...m,
        ref: v,
        style: {
          pointerEvents: P ? S ? "auto" : "none" : void 0,
          ...t.style
        },
        onFocusCapture: A(t.onFocusCapture, I.onFocusCapture),
        onBlurCapture: A(t.onBlurCapture, I.onBlurCapture),
        onPointerDownCapture: A(
          t.onPointerDownCapture,
          R.onPointerDownCapture
        )
      }
    );
  }, "DismissableLayer")
);
function si() {
  const e = s.useContext(ii), [t, n] = s.useState(null);
  return s.useEffect(() => {
    if (t)
      return e.dismissableSurfaces.add(t), () => {
        e.dismissableSurfaces.delete(t);
      };
  }, [t, e.dismissableSurfaces]), n;
}
pe(si, "useDismissableLayerSurface");
var jl = /* @__PURE__ */ pe(() => !0, "IS_TRUE");
function ci(e, t) {
  const {
    ownerDocument: n = globalThis?.document,
    deferPointerDownOutside: o = !1,
    isDeferredPointerDownOutsideRef: r,
    dismissableSurfaces: a,
    shouldHandlePointerDownOutside: i = jl
  } = t, c = ie(e), l = s.useRef(!1), u = s.useRef(!1), m = s.useRef(/* @__PURE__ */ new Map()), f = s.useRef(() => {
  });
  return s.useEffect(() => {
    function p() {
      u.current = !1, r.current = !1, m.current.clear();
    }
    pe(p, "resetOutsideInteraction");
    function h() {
      return Array.from(m.current.values()).some(Boolean);
    }
    pe(h, "isOutsideInteractionIntercepted");
    function g(w) {
      if (!u.current)
        return;
      const C = w.target;
      C instanceof Node && [...a].some((S) => S.contains(C)) || m.current.set(w.type, !0), w.type === "click" && window.setTimeout(() => {
        u.current && f.current();
      }, 0);
    }
    pe(g, "handleInteractionCapture");
    function b(w) {
      u.current && m.current.set(w.type, !1);
    }
    pe(b, "handleInteractionBubble");
    const v = /* @__PURE__ */ pe((w) => {
      if (w.target && !l.current) {
        let C = function() {
          n.removeEventListener("click", f.current);
          const S = h();
          p(), S || Zo(
            Gl,
            c,
            P,
            { discrete: !0 }
          );
        };
        if (pe(C, "handleAndDispatchPointerDownOutsideEvent"), !i(w.target)) {
          n.removeEventListener("click", f.current), p(), l.current = !1;
          return;
        }
        const P = { originalEvent: w };
        u.current = !0, r.current = o && w.button === 0, m.current.clear(), !o || w.button !== 0 ? C() : (n.removeEventListener("click", f.current), f.current = C, n.addEventListener("click", f.current, { once: !0 }));
      } else
        n.removeEventListener("click", f.current), p();
      l.current = !1;
    }, "handlePointerDown"), y = [
      "pointerup",
      "mousedown",
      "mouseup",
      "touchstart",
      "touchend",
      "click"
    ];
    for (const w of y)
      n.addEventListener(w, g, !0), n.addEventListener(w, b);
    const x = window.setTimeout(() => {
      n.addEventListener("pointerdown", v);
    }, 0);
    return () => {
      window.clearTimeout(x), n.removeEventListener("pointerdown", v), n.removeEventListener("click", f.current);
      for (const w of y)
        n.removeEventListener(w, g, !0), n.removeEventListener(w, b);
    };
  }, [
    n,
    c,
    o,
    r,
    a,
    i
  ]), {
    // ensures we check React component tree (not just DOM tree)
    onPointerDownCapture: /* @__PURE__ */ pe(() => l.current = !0, "onPointerDownCapture")
  };
}
pe(ci, "usePointerDownOutside");
function li(e, t = globalThis?.document) {
  const n = ie(e), o = s.useRef(!1);
  return s.useEffect(() => {
    const r = /* @__PURE__ */ pe((a) => {
      a.target && !o.current && Zo(Ul, n, { originalEvent: a }, {
        discrete: !1
      });
    }, "handleFocus");
    return t.addEventListener("focusin", r), () => t.removeEventListener("focusin", r);
  }, [t, n]), {
    onFocusCapture: /* @__PURE__ */ pe(() => o.current = !0, "onFocusCapture"),
    onBlurCapture: /* @__PURE__ */ pe(() => o.current = !1, "onBlurCapture")
  };
}
pe(li, "useFocusOutside");
function Ro() {
  const e = new CustomEvent(Po);
  document.dispatchEvent(e);
}
pe(Ro, "dispatchUpdate");
function Zo(e, t, n, { discrete: o }) {
  const r = n.originalEvent.target, a = new CustomEvent(e, { bubbles: !1, cancelable: !0, detail: n });
  t && r.addEventListener(e, t, { once: !0 }), o ? Ho(r, a) : r.dispatchEvent(a);
}
pe(Zo, "handleAndDispatchCustomEvent");
var Kl = Object.defineProperty, xe = (e, t) => Kl(e, "name", { value: t, configurable: !0 }), no = "focusScope.autoFocusOnMount", oo = "focusScope.autoFocusOnUnmount", Zr = { bubbles: !1, cancelable: !0 }, Qo = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ xe(function(t, n) {
    const {
      loop: o = !1,
      trapped: r = !1,
      onMountAutoFocus: a,
      onUnmountAutoFocus: i,
      ...c
    } = t, [l, u] = s.useState(null), m = ie(a), f = ie(i), p = s.useRef(null), h = H(n, u), g = s.useRef({
      paused: !1,
      pause() {
        this.paused = !0;
      },
      resume() {
        this.paused = !1;
      }
    }).current;
    s.useEffect(() => {
      if (r) {
        let v = function(C) {
          if (g.paused || !l) return;
          const P = C.target;
          l.contains(P) ? p.current = P : Ge(p.current, { select: !0 });
        }, y = function(C) {
          if (g.paused || !l) return;
          const P = C.relatedTarget;
          P !== null && (l.contains(P) || Ge(p.current, { select: !0 }));
        }, x = function(C) {
          if (document.activeElement === document.body)
            for (const S of C)
              S.removedNodes.length > 0 && Ge(l);
        };
        xe(v, "handleFocusIn"), xe(y, "handleFocusOut"), xe(x, "handleMutations"), document.addEventListener("focusin", v), document.addEventListener("focusout", y);
        const w = new MutationObserver(x);
        return l && w.observe(l, { childList: !0, subtree: !0 }), () => {
          document.removeEventListener("focusin", v), document.removeEventListener("focusout", y), w.disconnect();
        };
      }
    }, [r, l, g.paused]), s.useEffect(() => {
      if (l) {
        Qr.add(g);
        const v = document.activeElement;
        if (!l.contains(v)) {
          const x = new CustomEvent(no, Zr);
          l.addEventListener(no, m), l.dispatchEvent(x), x.defaultPrevented || (ui(hi(Jo(l)), { select: !0 }), document.activeElement === v && Ge(l));
        }
        return () => {
          l.removeEventListener(no, m), setTimeout(() => {
            const x = new CustomEvent(oo, Zr);
            l.addEventListener(oo, f), l.dispatchEvent(x), x.defaultPrevented || Ge(v ?? document.body, { select: !0 }), l.removeEventListener(oo, f), Qr.remove(g);
          }, 0);
        };
      }
    }, [l, m, f, g]);
    const b = s.useCallback(
      (v) => {
        if (!o && !r || g.paused) return;
        const y = v.key === "Tab" && !v.altKey && !v.ctrlKey && !v.metaKey, x = document.activeElement;
        if (y && x) {
          const w = v.currentTarget, [C, P] = di(w);
          C && P ? !v.shiftKey && x === P ? (v.preventDefault(), o && Ge(C, { select: !0 })) : v.shiftKey && x === C && (v.preventDefault(), o && Ge(P, { select: !0 })) : x === w && v.preventDefault();
        }
      },
      [o, r, g.paused]
    );
    return /* @__PURE__ */ d($.div, { tabIndex: -1, ...c, ref: h, onKeyDown: b });
  }, "FocusScope")
);
function ui(e, { select: t = !1 } = {}) {
  const n = document.activeElement;
  for (const o of e)
    if (Ge(o, { select: t }), document.activeElement !== n) return;
}
xe(ui, "focusFirst");
function di(e) {
  const t = Jo(e), n = Eo(t, e), o = Eo(t.reverse(), e);
  return [n, o];
}
xe(di, "getTabbableEdges");
function Jo(e) {
  const t = [], n = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
    acceptNode: /* @__PURE__ */ xe((o) => {
      const r = o.tagName === "INPUT" && o.type === "hidden";
      return o.disabled || o.hidden || r ? NodeFilter.FILTER_SKIP : o.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
    }, "acceptNode")
  });
  for (; n.nextNode(); ) t.push(n.currentNode);
  return t;
}
xe(Jo, "getTabbableCandidates");
function Eo(e, t) {
  const n = typeof t.checkVisibility == "function" && t.checkVisibility({ checkVisibilityCSS: !0 });
  for (const o of e)
    if (!(n ? !o.checkVisibility({ checkVisibilityCSS: !0 }) : fi(o, { upTo: t })))
      return o;
}
xe(Eo, "findVisible");
function fi(e, { upTo: t }) {
  if (getComputedStyle(e).visibility === "hidden") return !0;
  for (; e; ) {
    if (t !== void 0 && e === t) return !1;
    if (getComputedStyle(e).display === "none") return !0;
    e = e.parentElement;
  }
  return !1;
}
xe(fi, "isHidden");
function pi(e) {
  return e instanceof HTMLInputElement && "select" in e;
}
xe(pi, "isSelectableInput");
function Ge(e, { select: t = !1 } = {}) {
  if (e && e.focus) {
    const n = document.activeElement;
    e.focus({ preventScroll: !0 }), e !== n && pi(e) && t && e.select();
  }
}
xe(Ge, "focus");
var Qr = mi();
function mi() {
  let e = [];
  return {
    add(t) {
      const n = e[0];
      t !== n && n?.pause(), e = _o(e, t), e.unshift(t);
    },
    remove(t) {
      e = _o(e, t), e[0]?.resume();
    }
  };
}
xe(mi, "createFocusScopesStack");
function _o(e, t) {
  const n = [...e], o = n.indexOf(t);
  return o !== -1 && n.splice(o, 1), n;
}
xe(_o, "arrayRemove");
function hi(e) {
  return e.filter((t) => t.tagName !== "A");
}
xe(hi, "removeLinks");
var Yl = Object.defineProperty, Xl = (e, t) => Yl(e, "name", { value: t, configurable: !0 }), In = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ Xl(function(t, n) {
    const { container: o, ...r } = t, [a, i] = s.useState(!1);
    re(() => i(!0), []);
    const c = o || a && globalThis?.document?.body;
    return c ? Ut.createPortal(/* @__PURE__ */ d($.div, { ...r, ref: n }), c) : null;
  }, "Portal")
), ql = Object.defineProperty, er = (e, t) => ql(e, "name", { value: t, configurable: !0 }), rn = 0, St = null;
function Zl(e) {
  return Xt(), e.children;
}
er(Zl, "FocusGuards");
function Xt() {
  s.useEffect(() => {
    St || (St = { start: To(), end: To() });
    const { start: e, end: t } = St;
    return document.body.firstElementChild !== e && document.body.insertAdjacentElement("afterbegin", e), document.body.lastElementChild !== t && document.body.insertAdjacentElement("beforeend", t), rn++, () => {
      rn === 1 && (St?.start.remove(), St?.end.remove(), St = null), rn = Math.max(0, rn - 1);
    };
  }, []);
}
er(Xt, "useFocusGuards");
function To() {
  const e = document.createElement("span");
  return e.setAttribute("data-radix-focus-guard", ""), e.tabIndex = 0, e.style.outline = "none", e.style.opacity = "0", e.style.position = "fixed", e.style.pointerEvents = "none", e;
}
er(To, "createFocusGuard");
var $e = function() {
  return $e = Object.assign || function(t) {
    for (var n, o = 1, r = arguments.length; o < r; o++) {
      n = arguments[o];
      for (var a in n) Object.prototype.hasOwnProperty.call(n, a) && (t[a] = n[a]);
    }
    return t;
  }, $e.apply(this, arguments);
};
function gi(e, t) {
  var n = {};
  for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && t.indexOf(o) < 0 && (n[o] = e[o]);
  if (e != null && typeof Object.getOwnPropertySymbols == "function")
    for (var r = 0, o = Object.getOwnPropertySymbols(e); r < o.length; r++)
      t.indexOf(o[r]) < 0 && Object.prototype.propertyIsEnumerable.call(e, o[r]) && (n[o[r]] = e[o[r]]);
  return n;
}
function Ql(e, t, n) {
  if (n || arguments.length === 2) for (var o = 0, r = t.length, a; o < r; o++)
    (a || !(o in t)) && (a || (a = Array.prototype.slice.call(t, 0, o)), a[o] = t[o]);
  return e.concat(a || Array.prototype.slice.call(t));
}
var gn = "right-scroll-bar-position", bn = "width-before-scroll-bar", Jl = "with-scroll-bars-hidden", eu = "--removed-body-scroll-bar-size";
function ro(e, t) {
  return typeof e == "function" ? e(t) : e && (e.current = t), e;
}
function tu(e, t) {
  var n = Ec(function() {
    return {
      // value
      value: e,
      // last callback
      callback: t,
      // "memoized" public interface
      facade: {
        get current() {
          return n.value;
        },
        set current(o) {
          var r = n.value;
          r !== o && (n.value = o, n.callback(o, r));
        }
      }
    };
  })[0];
  return n.callback = t, n.facade;
}
var nu = typeof window < "u" ? s.useLayoutEffect : s.useEffect, Jr = /* @__PURE__ */ new WeakMap();
function ou(e, t) {
  var n = tu(null, function(o) {
    return e.forEach(function(r) {
      return ro(r, o);
    });
  });
  return nu(function() {
    var o = Jr.get(n);
    if (o) {
      var r = new Set(o), a = new Set(e), i = n.current;
      r.forEach(function(c) {
        a.has(c) || ro(c, null);
      }), a.forEach(function(c) {
        r.has(c) || ro(c, i);
      });
    }
    Jr.set(n, e);
  }, [e]), n;
}
function ru(e) {
  return e;
}
function au(e, t) {
  t === void 0 && (t = ru);
  var n = [], o = !1, r = {
    read: function() {
      if (o)
        throw new Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
      return n.length ? n[n.length - 1] : e;
    },
    useMedium: function(a) {
      var i = t(a, o);
      return n.push(i), function() {
        n = n.filter(function(c) {
          return c !== i;
        });
      };
    },
    assignSyncMedium: function(a) {
      for (o = !0; n.length; ) {
        var i = n;
        n = [], i.forEach(a);
      }
      n = {
        push: function(c) {
          return a(c);
        },
        filter: function() {
          return n;
        }
      };
    },
    assignMedium: function(a) {
      o = !0;
      var i = [];
      if (n.length) {
        var c = n;
        n = [], c.forEach(a), i = n;
      }
      var l = function() {
        var m = i;
        i = [], m.forEach(a);
      }, u = function() {
        return Promise.resolve().then(l);
      };
      u(), n = {
        push: function(m) {
          i.push(m), u();
        },
        filter: function(m) {
          return i = i.filter(m), n;
        }
      };
    }
  };
  return r;
}
function iu(e) {
  e === void 0 && (e = {});
  var t = au(null);
  return t.options = $e({ async: !0, ssr: !1 }, e), t;
}
var bi = function(e) {
  var t = e.sideCar, n = gi(e, ["sideCar"]);
  if (!t)
    throw new Error("Sidecar: please provide `sideCar` property to import the right car");
  var o = t.read();
  if (!o)
    throw new Error("Sidecar medium not found");
  return s.createElement(o, $e({}, n));
};
bi.isSideCarExport = !0;
function su(e, t) {
  return e.useMedium(t), bi;
}
var vi = iu(), ao = function() {
}, An = s.forwardRef(function(e, t) {
  var n = s.useRef(null), o = s.useState({
    onScrollCapture: ao,
    onWheelCapture: ao,
    onTouchMoveCapture: ao
  }), r = o[0], a = o[1], i = e.forwardProps, c = e.children, l = e.className, u = e.removeScrollBar, m = e.enabled, f = e.shards, p = e.sideCar, h = e.noRelative, g = e.noIsolation, b = e.inert, v = e.allowPinchZoom, y = e.as, x = y === void 0 ? "div" : y, w = e.gapMode, C = gi(e, ["forwardProps", "children", "className", "removeScrollBar", "enabled", "shards", "sideCar", "noRelative", "noIsolation", "inert", "allowPinchZoom", "as", "gapMode"]), P = p, S = ou([n, t]), _ = $e($e({}, C), r);
  return s.createElement(
    s.Fragment,
    null,
    m && s.createElement(P, { sideCar: vi, removeScrollBar: u, shards: f, noRelative: h, noIsolation: g, inert: b, setCallbacks: a, allowPinchZoom: !!v, lockRef: n, gapMode: w }),
    i ? s.cloneElement(s.Children.only(c), $e($e({}, _), { ref: S })) : s.createElement(x, $e({}, _, { className: l, ref: S }), c)
  );
});
An.defaultProps = {
  enabled: !0,
  removeScrollBar: !0,
  inert: !1
};
An.classNames = {
  fullWidth: bn,
  zeroRight: gn
};
var cu = function() {
  if (typeof __webpack_nonce__ < "u")
    return __webpack_nonce__;
};
function lu() {
  if (!document)
    return null;
  var e = document.createElement("style");
  e.type = "text/css";
  var t = cu();
  return t && e.setAttribute("nonce", t), e;
}
function uu(e, t) {
  e.styleSheet ? e.styleSheet.cssText = t : e.appendChild(document.createTextNode(t));
}
function du(e) {
  var t = document.head || document.getElementsByTagName("head")[0];
  t.appendChild(e);
}
var fu = function() {
  var e = 0, t = null;
  return {
    add: function(n) {
      e == 0 && (t = lu()) && (uu(t, n), du(t)), e++;
    },
    remove: function() {
      e--, !e && t && (t.parentNode && t.parentNode.removeChild(t), t = null);
    }
  };
}, pu = function() {
  var e = fu();
  return function(t, n) {
    s.useEffect(function() {
      return e.add(t), function() {
        e.remove();
      };
    }, [t && n]);
  };
}, wi = function() {
  var e = pu(), t = function(n) {
    var o = n.styles, r = n.dynamic;
    return e(o, r), null;
  };
  return t;
}, mu = {
  left: 0,
  top: 0,
  right: 0,
  gap: 0
}, io = function(e) {
  return parseInt(e || "", 10) || 0;
}, hu = function(e) {
  var t = window.getComputedStyle(document.body), n = t[e === "padding" ? "paddingLeft" : "marginLeft"], o = t[e === "padding" ? "paddingTop" : "marginTop"], r = t[e === "padding" ? "paddingRight" : "marginRight"];
  return [io(n), io(o), io(r)];
}, gu = function(e) {
  if (e === void 0 && (e = "margin"), typeof window > "u")
    return mu;
  var t = hu(e), n = document.documentElement.clientWidth, o = window.innerWidth;
  return {
    left: t[0],
    top: t[1],
    right: t[2],
    gap: Math.max(0, o - n + t[2] - t[0])
  };
}, bu = wi(), Tt = "data-scroll-locked", vu = function(e, t, n, o) {
  var r = e.left, a = e.top, i = e.right, c = e.gap;
  return n === void 0 && (n = "margin"), `
  .`.concat(Jl, ` {
   overflow: hidden `).concat(o, `;
   padding-right: `).concat(c, "px ").concat(o, `;
  }
  body[`).concat(Tt, `] {
    overflow: hidden `).concat(o, `;
    overscroll-behavior: contain;
    `).concat([
    t && "position: relative ".concat(o, ";"),
    n === "margin" && `
    padding-left: `.concat(r, `px;
    padding-top: `).concat(a, `px;
    padding-right: `).concat(i, `px;
    margin-left:0;
    margin-top:0;
    margin-right: `).concat(c, "px ").concat(o, `;
    `),
    n === "padding" && "padding-right: ".concat(c, "px ").concat(o, ";")
  ].filter(Boolean).join(""), `
  }
  
  .`).concat(gn, ` {
    right: `).concat(c, "px ").concat(o, `;
  }
  
  .`).concat(bn, ` {
    margin-right: `).concat(c, "px ").concat(o, `;
  }
  
  .`).concat(gn, " .").concat(gn, ` {
    right: 0 `).concat(o, `;
  }
  
  .`).concat(bn, " .").concat(bn, ` {
    margin-right: 0 `).concat(o, `;
  }
  
  body[`).concat(Tt, `] {
    `).concat(eu, ": ").concat(c, `px;
  }
`);
}, ea = function() {
  var e = parseInt(document.body.getAttribute(Tt) || "0", 10);
  return isFinite(e) ? e : 0;
}, wu = function() {
  s.useEffect(function() {
    return document.body.setAttribute(Tt, (ea() + 1).toString()), function() {
      var e = ea() - 1;
      e <= 0 ? document.body.removeAttribute(Tt) : document.body.setAttribute(Tt, e.toString());
    };
  }, []);
}, xu = function(e) {
  var t = e.noRelative, n = e.noImportant, o = e.gapMode, r = o === void 0 ? "margin" : o;
  wu();
  var a = s.useMemo(function() {
    return gu(r);
  }, [r]);
  return s.createElement(bu, { styles: vu(a, !t, r, n ? "" : "!important") });
}, Io = !1;
if (typeof window < "u")
  try {
    var an = Object.defineProperty({}, "passive", {
      get: function() {
        return Io = !0, !0;
      }
    });
    window.addEventListener("test", an, an), window.removeEventListener("test", an, an);
  } catch {
    Io = !1;
  }
var Pt = Io ? { passive: !1 } : !1, yu = function(e) {
  return e.tagName === "TEXTAREA";
}, xi = function(e, t) {
  if (!(e instanceof Element))
    return !1;
  var n = window.getComputedStyle(e);
  return (
    // not-not-scrollable
    n[t] !== "hidden" && // contains scroll inside self
    !(n.overflowY === n.overflowX && !yu(e) && n[t] === "visible")
  );
}, Cu = function(e) {
  return xi(e, "overflowY");
}, Su = function(e) {
  return xi(e, "overflowX");
}, ta = function(e, t) {
  var n = t.ownerDocument, o = t;
  do {
    typeof ShadowRoot < "u" && o instanceof ShadowRoot && (o = o.host);
    var r = yi(e, o);
    if (r) {
      var a = Ci(e, o), i = a[1], c = a[2];
      if (i > c)
        return !0;
    }
    o = o.parentNode;
  } while (o && o !== n.body);
  return !1;
}, Pu = function(e) {
  var t = e.scrollTop, n = e.scrollHeight, o = e.clientHeight;
  return [
    t,
    n,
    o
  ];
}, Ru = function(e) {
  var t = e.scrollLeft, n = e.scrollWidth, o = e.clientWidth;
  return [
    t,
    n,
    o
  ];
}, yi = function(e, t) {
  return e === "v" ? Cu(t) : Su(t);
}, Ci = function(e, t) {
  return e === "v" ? Pu(t) : Ru(t);
}, Eu = function(e, t) {
  return e === "h" && t === "rtl" ? -1 : 1;
}, _u = function(e, t, n, o, r) {
  var a = Eu(e, window.getComputedStyle(t).direction), i = a * o, c = n.target, l = t.contains(c), u = !1, m = i > 0, f = 0, p = 0;
  do {
    if (!c)
      break;
    var h = Ci(e, c), g = h[0], b = h[1], v = h[2], y = b - v - a * g;
    (g || y) && yi(e, c) && (f += y, p += g);
    var x = c.parentNode;
    c = x && x.nodeType === Node.DOCUMENT_FRAGMENT_NODE ? x.host : x;
  } while (
    // portaled content
    !l && c !== document.body || // self content
    l && (t.contains(c) || t === c)
  );
  return (m && Math.abs(f) < 1 || !m && Math.abs(p) < 1) && (u = !0), u;
}, sn = function(e) {
  return "changedTouches" in e ? [e.changedTouches[0].clientX, e.changedTouches[0].clientY] : [0, 0];
}, na = function(e) {
  return [e.deltaX, e.deltaY];
}, oa = function(e) {
  return e && "current" in e ? e.current : e;
}, Tu = function(e, t) {
  return e[0] === t[0] && e[1] === t[1];
}, Iu = function(e) {
  return `
  .block-interactivity-`.concat(e, ` {pointer-events: none;}
  .allow-interactivity-`).concat(e, ` {pointer-events: all;}
`);
}, Au = 0, Rt = [];
function ku(e) {
  var t = s.useRef([]), n = s.useRef([0, 0]), o = s.useRef(), r = s.useState(Au++)[0], a = s.useState(wi)[0], i = s.useRef(e);
  s.useEffect(function() {
    i.current = e;
  }, [e]), s.useEffect(function() {
    if (e.inert) {
      document.body.classList.add("block-interactivity-".concat(r));
      var b = Ql([e.lockRef.current], (e.shards || []).map(oa), !0).filter(Boolean);
      return b.forEach(function(v) {
        return v.classList.add("allow-interactivity-".concat(r));
      }), function() {
        document.body.classList.remove("block-interactivity-".concat(r)), b.forEach(function(v) {
          return v.classList.remove("allow-interactivity-".concat(r));
        });
      };
    }
  }, [e.inert, e.lockRef.current, e.shards]);
  var c = s.useCallback(function(b, v) {
    if ("touches" in b && b.touches.length === 2 || b.type === "wheel" && b.ctrlKey)
      return !i.current.allowPinchZoom;
    var y = sn(b), x = n.current, w = "deltaX" in b ? b.deltaX : x[0] - y[0], C = "deltaY" in b ? b.deltaY : x[1] - y[1], P, S = b.target, _ = Math.abs(w) > Math.abs(C) ? "h" : "v";
    if ("touches" in b && _ === "h" && S.type === "range")
      return !1;
    var R = window.getSelection(), I = R && R.anchorNode, k = I ? I === S || I.contains(S) : !1;
    if (k)
      return !1;
    var N = ta(_, S);
    if (!N)
      return !0;
    if (N ? P = _ : (P = _ === "v" ? "h" : "v", N = ta(_, S)), !N)
      return !1;
    if (!o.current && "changedTouches" in b && (w || C) && (o.current = P), !P)
      return !0;
    var M = o.current || P;
    return _u(M, v, b, M === "h" ? w : C);
  }, []), l = s.useCallback(function(b) {
    var v = b;
    if (!(!Rt.length || Rt[Rt.length - 1] !== a)) {
      var y = "deltaY" in v ? na(v) : sn(v), x = t.current.filter(function(P) {
        return P.name === v.type && (P.target === v.target || v.target === P.shadowParent) && Tu(P.delta, y);
      })[0];
      if (x && x.should) {
        v.cancelable && v.preventDefault();
        return;
      }
      if (!x) {
        var w = (i.current.shards || []).map(oa).filter(Boolean).filter(function(P) {
          return P.contains(v.target);
        }), C = w.length > 0 ? c(v, w[0]) : !i.current.noIsolation;
        C && v.cancelable && v.preventDefault();
      }
    }
  }, []), u = s.useCallback(function(b, v, y, x) {
    var w = { name: b, delta: v, target: y, should: x, shadowParent: Mu(y) };
    t.current.push(w), setTimeout(function() {
      t.current = t.current.filter(function(C) {
        return C !== w;
      });
    }, 1);
  }, []), m = s.useCallback(function(b) {
    n.current = sn(b), o.current = void 0;
  }, []), f = s.useCallback(function(b) {
    u(b.type, na(b), b.target, c(b, e.lockRef.current));
  }, []), p = s.useCallback(function(b) {
    u(b.type, sn(b), b.target, c(b, e.lockRef.current));
  }, []);
  s.useEffect(function() {
    return Rt.push(a), e.setCallbacks({
      onScrollCapture: f,
      onWheelCapture: f,
      onTouchMoveCapture: p
    }), document.addEventListener("wheel", l, Pt), document.addEventListener("touchmove", l, Pt), document.addEventListener("touchstart", m, Pt), function() {
      Rt = Rt.filter(function(b) {
        return b !== a;
      }), document.removeEventListener("wheel", l, Pt), document.removeEventListener("touchmove", l, Pt), document.removeEventListener("touchstart", m, Pt);
    };
  }, []);
  var h = e.removeScrollBar, g = e.inert;
  return s.createElement(
    s.Fragment,
    null,
    g ? s.createElement(a, { styles: Iu(r) }) : null,
    h ? s.createElement(xu, { noRelative: e.noRelative, gapMode: e.gapMode }) : null
  );
}
function Mu(e) {
  for (var t = null; e !== null; )
    e instanceof ShadowRoot && (t = e.host, e = e.host), e = e.parentNode;
  return t;
}
const Ou = su(vi, ku);
var kn = s.forwardRef(function(e, t) {
  return s.createElement(An, $e({}, e, { ref: t, sideCar: Ou }));
});
kn.classNames = An.classNames;
var Du = function(e) {
  if (typeof document > "u")
    return null;
  var t = Array.isArray(e) ? e[0] : e;
  return t.ownerDocument.body;
}, Et = /* @__PURE__ */ new WeakMap(), cn = /* @__PURE__ */ new WeakMap(), ln = {}, so = 0, Si = function(e) {
  return e && (e.host || Si(e.parentNode));
}, Nu = function(e, t) {
  return t.map(function(n) {
    if (e.contains(n))
      return n;
    var o = Si(n);
    return o && e.contains(o) ? o : (console.error("aria-hidden", n, "in not contained inside", e, ". Doing nothing"), null);
  }).filter(function(n) {
    return !!n;
  });
}, Lu = function(e, t, n, o) {
  var r = Nu(t, Array.isArray(e) ? e : [e]);
  ln[n] || (ln[n] = /* @__PURE__ */ new WeakMap());
  var a = ln[n], i = [], c = /* @__PURE__ */ new Set(), l = new Set(r), u = function(f) {
    !f || c.has(f) || (c.add(f), u(f.parentNode));
  };
  r.forEach(u);
  var m = function(f) {
    !f || l.has(f) || Array.prototype.forEach.call(f.children, function(p) {
      if (c.has(p))
        m(p);
      else
        try {
          var h = p.getAttribute(o), g = h !== null && h !== "false", b = (Et.get(p) || 0) + 1, v = (a.get(p) || 0) + 1;
          Et.set(p, b), a.set(p, v), i.push(p), b === 1 && g && cn.set(p, !0), v === 1 && p.setAttribute(n, "true"), g || p.setAttribute(o, "true");
        } catch (y) {
          console.error("aria-hidden: cannot operate on ", p, y);
        }
    });
  };
  return m(t), c.clear(), so++, function() {
    i.forEach(function(f) {
      var p = Et.get(f) - 1, h = a.get(f) - 1;
      Et.set(f, p), a.set(f, h), p || (cn.has(f) || f.removeAttribute(o), cn.delete(f)), h || f.removeAttribute(n);
    }), so--, so || (Et = /* @__PURE__ */ new WeakMap(), Et = /* @__PURE__ */ new WeakMap(), cn = /* @__PURE__ */ new WeakMap(), ln = {});
  };
}, tr = function(e, t, n) {
  n === void 0 && (n = "data-aria-hidden");
  var o = Array.from(Array.isArray(e) ? e : [e]), r = Du(e);
  return r ? (o.push.apply(o, Array.from(r.querySelectorAll("[aria-live], script"))), Lu(o, r, n, "aria-hidden")) : function() {
    return null;
  };
}, $u = Object.defineProperty, Te = (e, t) => $u(e, "name", { value: t, configurable: !0 }), nr = "Dialog", [Pi, pv] = /* @__PURE__ */ we(nr), [Fu, Ne] = Pi(nr), Ri = /* @__PURE__ */ Te((e) => {
  const {
    __scopeDialog: t,
    children: n,
    open: o,
    defaultOpen: r,
    onOpenChange: a,
    modal: i = !0
  } = e, c = s.useRef(null), l = s.useRef(null), [u, m] = Re({
    prop: o,
    defaultProp: r ?? !1,
    onChange: a,
    caller: nr
  }), [f, p] = s.useState(0), [h, g] = s.useState(0);
  return /* @__PURE__ */ d(
    Fu,
    {
      scope: t,
      triggerRef: c,
      contentRef: l,
      contentId: ve(),
      titleId: ve(),
      descriptionId: ve(),
      titlePresent: f > 0,
      descriptionPresent: h > 0,
      setTitleCount: p,
      setDescriptionCount: g,
      open: u,
      onOpenChange: m,
      onOpenToggle: s.useCallback(() => m((b) => !b), [m]),
      modal: i,
      children: n
    }
  );
}, "Dialog"), zu = "DialogTrigger", Ei = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ Te(function(t, n) {
    const { __scopeDialog: o, ...r } = t, a = Ne(zu, o), i = H(n, a.triggerRef);
    return /* @__PURE__ */ d(
      $.button,
      {
        type: "button",
        "aria-haspopup": "dialog",
        "aria-expanded": a.open,
        "aria-controls": a.open ? a.contentId : void 0,
        "data-state": Mn(a.open),
        ...r,
        ref: i,
        onClick: A(t.onClick, a.onOpenToggle)
      }
    );
  }, "DialogTrigger")
), _i = "DialogPortal", [Bu, Ti] = Pi(_i, {
  forceMount: void 0
}), Ii = /* @__PURE__ */ Te((e) => {
  const { __scopeDialog: t, forceMount: n, children: o, container: r } = e, a = Ne(_i, t);
  return /* @__PURE__ */ d(Bu, { scope: t, forceMount: n, children: s.Children.map(o, (i) => /* @__PURE__ */ d(he, { present: n || a.open, children: /* @__PURE__ */ d(In, { asChild: !0, container: r, children: i }) })) });
}, "DialogPortal"), Ao = "DialogOverlay", Ai = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ Te(function(t, n) {
    const o = Ti(Ao, t.__scopeDialog), { forceMount: r = o.forceMount, ...a } = t, i = Ne(Ao, t.__scopeDialog);
    return i.modal ? /* @__PURE__ */ d(he, { present: r || i.open, children: /* @__PURE__ */ d(Wu, { ...a, ref: n }) }) : null;
  }, "DialogOverlay")
), Vu = /* @__PURE__ */ ze("DialogOverlay.RemoveScroll"), Wu = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ Te(function(t, n) {
    const { __scopeDialog: o, ...r } = t, a = Ne(Ao, o), i = si(), c = H(n, i);
    return (
      // Make sure `Content` is scrollable even when it doesn't live inside `RemoveScroll`
      // ie. when `Overlay` and `Content` are siblings
      /* @__PURE__ */ d(kn, { as: Vu, allowPinchZoom: !0, shards: [a.contentRef], children: /* @__PURE__ */ d(
        $.div,
        {
          "data-state": Mn(a.open),
          ...r,
          ref: c,
          style: { pointerEvents: "auto", ...r.style }
        }
      ) })
    );
  }, "DialogOverlayImpl")
), Ft = "DialogContent", ki = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ Te(function(t, n) {
    const o = Ti(Ft, t.__scopeDialog), { forceMount: r = o.forceMount, ...a } = t, i = Ne(Ft, t.__scopeDialog);
    return /* @__PURE__ */ d(he, { present: r || i.open, children: i.modal ? /* @__PURE__ */ d(Hu, { ...a, ref: n }) : /* @__PURE__ */ d(Gu, { ...a, ref: n }) });
  }, "DialogContent")
), Hu = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ Te(function(t, n) {
    const o = Ne(Ft, t.__scopeDialog), r = s.useRef(null), a = H(n, o.contentRef, r);
    return s.useEffect(() => {
      const i = r.current;
      if (i) return tr(i);
    }, []), /* @__PURE__ */ d(
      Mi,
      {
        ...t,
        ref: a,
        trapFocus: o.open,
        disableOutsidePointerEvents: o.open,
        onCloseAutoFocus: A(t.onCloseAutoFocus, (i) => {
          i.preventDefault(), o.triggerRef.current?.focus();
        }),
        onPointerDownOutside: A(t.onPointerDownOutside, (i) => {
          const c = i.detail.originalEvent, l = c.button === 0 && c.ctrlKey === !0;
          (c.button === 2 || l) && i.preventDefault();
        }),
        onFocusOutside: A(
          t.onFocusOutside,
          (i) => i.preventDefault()
        )
      }
    );
  }, "DialogContentModal")
), Gu = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ Te(function(t, n) {
    const o = Ne(Ft, t.__scopeDialog), r = s.useRef(!1), a = s.useRef(!1);
    return /* @__PURE__ */ d(
      Mi,
      {
        ...t,
        ref: n,
        trapFocus: !1,
        disableOutsidePointerEvents: !1,
        onCloseAutoFocus: (i) => {
          t.onCloseAutoFocus?.(i), i.defaultPrevented || (r.current || o.triggerRef.current?.focus(), i.preventDefault()), r.current = !1, a.current = !1;
        },
        onInteractOutside: (i) => {
          t.onInteractOutside?.(i), i.defaultPrevented || (r.current = !0, i.detail.originalEvent.type === "pointerdown" && (a.current = !0));
          const c = i.target;
          o.triggerRef.current?.contains(c) && i.preventDefault(), i.detail.originalEvent.type === "focusin" && a.current && i.preventDefault();
        }
      }
    );
  }, "DialogContentNonModal")
), Mi = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ Te(function(t, n) {
    const { __scopeDialog: o, trapFocus: r, onOpenAutoFocus: a, onCloseAutoFocus: i, ...c } = t, l = Ne(Ft, o);
    return Xt(), /* @__PURE__ */ d(mt, { children: /* @__PURE__ */ d(
      Qo,
      {
        asChild: !0,
        loop: !0,
        trapped: r,
        onMountAutoFocus: a,
        onUnmountAutoFocus: i,
        children: /* @__PURE__ */ d(
          Tn,
          {
            role: "dialog",
            id: l.contentId,
            "aria-describedby": l.descriptionPresent ? l.descriptionId : void 0,
            "aria-labelledby": l.titlePresent ? l.titleId : void 0,
            "data-state": Mn(l.open),
            ...c,
            ref: n,
            deferPointerDownOutside: !0,
            onDismiss: () => l.onOpenChange(!1)
          }
        )
      }
    ) });
  }, "DialogContentImpl")
), Uu = "DialogTitle", Oi = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ Te(function(t, n) {
    const { __scopeDialog: o, ...r } = t, a = Ne(Uu, o), { setTitleCount: i } = a;
    return re(() => (i((c) => c + 1), () => i((c) => c - 1)), [i]), /* @__PURE__ */ d($.h2, { id: a.titleId, ...r, ref: n });
  }, "DialogTitle")
), ju = "DialogDescription", Di = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ Te(function(t, n) {
    const { __scopeDialog: o, ...r } = t, a = Ne(ju, o), { setDescriptionCount: i } = a;
    return re(() => (i((c) => c + 1), () => i((c) => c - 1)), [i]), /* @__PURE__ */ d($.p, { id: a.descriptionId, ...r, ref: n });
  }, "DialogDescription")
), Ku = "DialogClose", qt = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ Te(function(t, n) {
    const { __scopeDialog: o, ...r } = t, a = Ne(Ku, o);
    return /* @__PURE__ */ d(
      $.button,
      {
        type: "button",
        ...r,
        ref: n,
        onClick: A(t.onClick, () => a.onOpenChange(!1))
      }
    );
  }, "DialogClose")
);
function Mn(e) {
  return e ? "open" : "closed";
}
Te(Mn, "getState");
var Yu = Object.defineProperty, Xu = (e, t) => Yu(e, "name", { value: t, configurable: !0 });
function On(e) {
  const [t, n] = s.useState(void 0);
  return re(() => {
    if (e) {
      n({ width: e.offsetWidth, height: e.offsetHeight });
      const o = new ResizeObserver((r) => {
        if (!Array.isArray(r) || !r.length)
          return;
        const a = r[0];
        let i, c;
        if ("borderBoxSize" in a) {
          const l = a.borderBoxSize, u = Array.isArray(l) ? l[0] : l;
          i = u.inlineSize, c = u.blockSize;
        } else
          i = e.offsetWidth, c = e.offsetHeight;
        n({ width: i, height: c });
      });
      return o.observe(e, { box: "border-box" }), () => o.unobserve(e);
    } else
      n(void 0);
  }, [e]), t;
}
Xu(On, "useSize");
var qu = Object.defineProperty, qe = (e, t) => qu(e, "name", { value: t, configurable: !0 }), or = "Checkbox", [Zu, mv] = /* @__PURE__ */ we(or), [Qu, rr] = Zu(or);
function Ni(e) {
  const {
    __scopeCheckbox: t,
    checked: n,
    children: o,
    defaultChecked: r,
    disabled: a,
    form: i,
    name: c,
    onCheckedChange: l,
    required: u,
    value: m = "on",
    // @ts-expect-error
    internal_do_not_use_render: f
  } = e, [p, h] = Re({
    prop: n,
    defaultProp: r ?? !1,
    onChange: l,
    caller: or
  }), [g, b] = s.useState(null), [v, y] = s.useState(null), x = s.useRef(!1), [w, C] = s.useReducer(
    (_) => _ + 1,
    0
  ), P = g ? !!i || !!g.closest("form") : (
    // We set this to true by default so that events bubble to forms without JS (SSR)
    !0
  ), S = {
    checked: p,
    disabled: a,
    setChecked: h,
    control: g,
    setControl: b,
    name: c,
    form: i,
    value: m,
    hasConsumerStoppedPropagationRef: x,
    userInteractionCount: w,
    onUserInteraction: C,
    required: u,
    defaultChecked: Ue(r) ? !1 : r,
    isFormControl: P,
    bubbleInput: v,
    setBubbleInput: y
  };
  return /* @__PURE__ */ d(
    Qu,
    {
      scope: t,
      ...S,
      children: Li(f) ? f(S) : o
    }
  );
}
qe(Ni, "CheckboxProvider");
var Ju = "CheckboxTrigger", ed = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ qe(function({ __scopeCheckbox: t, onKeyDown: n, onClick: o, ...r }, a) {
    const {
      control: i,
      value: c,
      disabled: l,
      checked: u,
      required: m,
      setControl: f,
      setChecked: p,
      hasConsumerStoppedPropagationRef: h,
      onUserInteraction: g,
      isFormControl: b,
      bubbleInput: v
    } = rr(Ju, t), y = H(a, f), x = s.useRef(u);
    return s.useEffect(() => {
      const w = i?.form;
      if (w) {
        const C = /* @__PURE__ */ qe(() => p(x.current), "reset");
        return w.addEventListener("reset", C), () => w.removeEventListener("reset", C);
      }
    }, [i, p]), /* @__PURE__ */ d(
      $.button,
      {
        type: "button",
        role: "checkbox",
        "aria-checked": Ue(u) ? "mixed" : u,
        "aria-required": m,
        "data-state": ar(u),
        "data-disabled": l ? "" : void 0,
        disabled: l,
        value: c,
        ...r,
        ref: y,
        onKeyDown: A(n, (w) => {
          w.key === "Enter" && w.preventDefault();
        }),
        onClick: A(o, (w) => {
          g(), p((C) => Ue(C) ? !0 : !C), v && b && (h.current = w.isPropagationStopped(), h.current || w.stopPropagation());
        })
      }
    );
  }, "CheckboxTrigger")
), td = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ qe(function(t, n) {
    const {
      __scopeCheckbox: o,
      name: r,
      checked: a,
      defaultChecked: i,
      required: c,
      disabled: l,
      value: u,
      onCheckedChange: m,
      form: f,
      ...p
    } = t;
    return /* @__PURE__ */ d(
      Ni,
      {
        __scopeCheckbox: o,
        checked: a,
        defaultChecked: i,
        disabled: l,
        required: c,
        onCheckedChange: m,
        name: r,
        form: f,
        value: u,
        internal_do_not_use_render: ({ isFormControl: h }) => /* @__PURE__ */ Q(mt, { children: [
          /* @__PURE__ */ d(
            ed,
            {
              ...p,
              ref: n,
              __scopeCheckbox: o
            }
          ),
          h && /* @__PURE__ */ d(
            ad,
            {
              __scopeCheckbox: o
            }
          )
        ] })
      }
    );
  }, "Checkbox")
), nd = "CheckboxIndicator", od = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ qe(function(t, n) {
    const { __scopeCheckbox: o, forceMount: r, ...a } = t, i = rr(nd, o);
    return /* @__PURE__ */ d(
      he,
      {
        present: r || Ue(i.checked) || i.checked === !0,
        children: /* @__PURE__ */ d(
          $.span,
          {
            "data-state": ar(i.checked),
            "data-disabled": i.disabled ? "" : void 0,
            ...a,
            ref: n,
            style: { pointerEvents: "none", ...t.style }
          }
        )
      }
    );
  }, "CheckboxIndicator")
), rd = "CheckboxBubbleInput", ad = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ qe(function({ __scopeCheckbox: t, onClick: n, ...o }, r) {
    const {
      control: a,
      hasConsumerStoppedPropagationRef: i,
      userInteractionCount: c,
      checked: l,
      defaultChecked: u,
      required: m,
      disabled: f,
      name: p,
      value: h,
      form: g,
      bubbleInput: b,
      setBubbleInput: v
    } = rr(rd, t), y = H(r, v), x = On(a), w = s.useRef(!1), C = s.useRef(l), P = s.useRef(c);
    s.useEffect(() => {
      const _ = b;
      if (!_) return;
      const R = window.HTMLInputElement.prototype, k = Object.getOwnPropertyDescriptor(
        R,
        "checked"
      ).set, N = c !== P.current;
      P.current = c;
      const M = C.current !== l;
      C.current = l;
      const F = !(N && i.current);
      if (M && k) {
        w.current = !N;
        const V = new Event("click", { bubbles: F });
        _.indeterminate = Ue(l), k.call(_, Ue(l) ? !1 : l), _.dispatchEvent(V), w.current = !1;
      }
    }, [b, l, i, c]);
    const S = s.useRef(Ue(l) ? !1 : l);
    return /* @__PURE__ */ d(
      $.input,
      {
        type: "checkbox",
        "aria-hidden": !0,
        defaultChecked: u ?? S.current,
        required: m,
        disabled: f,
        name: p,
        value: h,
        form: g,
        ...o,
        tabIndex: -1,
        ref: y,
        onClick: A(n, (_) => {
          w.current && _.stopPropagation();
        }),
        style: {
          ...o.style,
          ...x,
          position: "absolute",
          pointerEvents: "none",
          opacity: 0,
          margin: 0,
          // We transform because the input is absolutely positioned but we have
          // rendered it **after** the button. This pulls it back to sit on top
          // of the button.
          transform: "translateX(-100%)"
        }
      }
    );
  }, "CheckboxBubbleInput")
);
function Li(e) {
  return typeof e == "function";
}
qe(Li, "isFunction");
function Ue(e) {
  return e === "indeterminate";
}
qe(Ue, "isIndeterminate");
function ar(e) {
  return Ue(e) ? "indeterminate" : e ? "checked" : "unchecked";
}
qe(ar, "getState");
const id = ["top", "right", "bottom", "left"], tt = Math.min, je = Math.max, wn = Math.round, un = Math.floor, Ke = (e) => ({
  x: e,
  y: e
}), sd = {
  left: "right",
  right: "left",
  bottom: "top",
  top: "bottom"
};
function $i(e, t, n) {
  return je(e, tt(t, n));
}
function Ze(e, t) {
  return typeof e == "function" ? e(t) : e;
}
function nt(e) {
  return e.split("-")[0];
}
function Ot(e) {
  return e.split("-")[1];
}
function ir(e) {
  return e === "x" ? "y" : "x";
}
function sr(e) {
  return e === "y" ? "height" : "width";
}
function Fe(e) {
  const t = e[0];
  return t === "t" || t === "b" ? "y" : "x";
}
function cr(e) {
  return ir(Fe(e));
}
function cd(e, t, n) {
  n === void 0 && (n = !1);
  const o = Ot(e), r = cr(e), a = sr(r);
  let i = r === "x" ? o === (n ? "end" : "start") ? "right" : "left" : o === "start" ? "bottom" : "top";
  return t.reference[a] > t.floating[a] && (i = xn(i)), [i, xn(i)];
}
function ld(e) {
  const t = xn(e);
  return [ko(e), t, ko(t)];
}
function ko(e) {
  return e.includes("start") ? e.replace("start", "end") : e.replace("end", "start");
}
const ra = ["left", "right"], aa = ["right", "left"], ud = ["top", "bottom"], dd = ["bottom", "top"];
function fd(e, t, n) {
  switch (e) {
    case "top":
    case "bottom":
      return n ? t ? aa : ra : t ? ra : aa;
    case "left":
    case "right":
      return t ? ud : dd;
    default:
      return [];
  }
}
function pd(e, t, n, o) {
  const r = Ot(e);
  let a = fd(nt(e), n === "start", o);
  return r && (a = a.map((i) => i + "-" + r), t && (a = a.concat(a.map(ko)))), a;
}
function xn(e) {
  const t = nt(e);
  return sd[t] + e.slice(t.length);
}
function md(e) {
  var t, n, o, r;
  return {
    top: (t = e.top) != null ? t : 0,
    right: (n = e.right) != null ? n : 0,
    bottom: (o = e.bottom) != null ? o : 0,
    left: (r = e.left) != null ? r : 0
  };
}
function Fi(e) {
  return typeof e != "number" ? md(e) : {
    top: e,
    right: e,
    bottom: e,
    left: e
  };
}
function yn(e) {
  const {
    x: t,
    y: n,
    width: o,
    height: r
  } = e;
  return {
    width: o,
    height: r,
    top: n,
    left: t,
    right: t + o,
    bottom: n + r,
    x: t,
    y: n
  };
}
function ia(e, t, n) {
  let {
    reference: o,
    floating: r
  } = e;
  const a = Fe(t), i = cr(t), c = sr(i), l = nt(t), u = a === "y", m = o.x + o.width / 2 - r.width / 2, f = o.y + o.height / 2 - r.height / 2, p = o[c] / 2 - r[c] / 2;
  let h;
  switch (l) {
    case "top":
      h = {
        x: m,
        y: o.y - r.height
      };
      break;
    case "bottom":
      h = {
        x: m,
        y: o.y + o.height
      };
      break;
    case "right":
      h = {
        x: o.x + o.width,
        y: f
      };
      break;
    case "left":
      h = {
        x: o.x - r.width,
        y: f
      };
      break;
    default:
      h = {
        x: o.x,
        y: o.y
      };
  }
  const g = Ot(t);
  return g && (h[i] += p * (g === "end" ? 1 : -1) * (n && u ? -1 : 1)), h;
}
async function hd(e, t) {
  var n;
  t === void 0 && (t = {});
  const {
    x: o,
    y: r,
    platform: a,
    rects: i,
    elements: c,
    strategy: l
  } = e, {
    boundary: u = "clippingAncestors",
    rootBoundary: m = "viewport",
    elementContext: f = "floating",
    altBoundary: p = !1,
    padding: h = 0
  } = Ze(t, e), g = Fi(h), v = c[p ? f === "floating" ? "reference" : "floating" : f], y = yn(await a.getClippingRect({
    element: (n = await (a.isElement == null ? void 0 : a.isElement(v))) == null || n ? v : v.contextElement || await (a.getDocumentElement == null ? void 0 : a.getDocumentElement(c.floating)),
    boundary: u,
    rootBoundary: m,
    strategy: l
  })), x = f === "floating" ? {
    x: o,
    y: r,
    width: i.floating.width,
    height: i.floating.height
  } : i.reference, w = await (a.getOffsetParent == null ? void 0 : a.getOffsetParent(c.floating)), C = await (a.isElement == null ? void 0 : a.isElement(w)) && await (a.getScale == null ? void 0 : a.getScale(w)) || {
    x: 1,
    y: 1
  }, P = yn(a.convertOffsetParentRelativeRectToViewportRelativeRect ? await a.convertOffsetParentRelativeRectToViewportRelativeRect({
    elements: c,
    rect: x,
    offsetParent: w,
    strategy: l
  }) : x);
  return {
    top: (y.top - P.top + g.top) / C.y,
    bottom: (P.bottom - y.bottom + g.bottom) / C.y,
    left: (y.left - P.left + g.left) / C.x,
    right: (P.right - y.right + g.right) / C.x
  };
}
const gd = 50, bd = async (e, t, n) => {
  const {
    placement: o = "bottom",
    strategy: r = "absolute",
    middleware: a = [],
    platform: i
  } = n, c = i.detectOverflow ? i : {
    ...i,
    detectOverflow: hd
  }, l = await (i.isRTL == null ? void 0 : i.isRTL(t));
  let u = await i.getElementRects({
    reference: e,
    floating: t,
    strategy: r
  }), {
    x: m,
    y: f
  } = ia(u, o, l), p = o, h = 0;
  const g = {};
  for (let b = 0; b < a.length; b++) {
    const v = a[b];
    if (!v)
      continue;
    const {
      name: y,
      fn: x
    } = v, {
      x: w,
      y: C,
      data: P,
      reset: S
    } = await x({
      x: m,
      y: f,
      initialPlacement: o,
      placement: p,
      strategy: r,
      middlewareData: g,
      rects: u,
      platform: c,
      elements: {
        reference: e,
        floating: t
      }
    });
    m = w ?? m, f = C ?? f, g[y] = {
      ...g[y],
      ...P
    }, S && h < gd && (h++, typeof S == "object" && (S.placement && (p = S.placement), S.rects && (u = S.rects === !0 ? await i.getElementRects({
      reference: e,
      floating: t,
      strategy: r
    }) : S.rects), {
      x: m,
      y: f
    } = ia(u, p, l)), b = -1);
  }
  return {
    x: m,
    y: f,
    placement: p,
    strategy: r,
    middlewareData: g
  };
}, vd = (e) => ({
  name: "arrow",
  options: e,
  async fn(t) {
    const {
      x: n,
      y: o,
      placement: r,
      rects: a,
      platform: i,
      elements: c,
      middlewareData: l
    } = t, {
      element: u,
      padding: m = 0
    } = Ze(e, t) || {};
    if (u == null)
      return {};
    const f = Fi(m), p = {
      x: n,
      y: o
    }, h = cr(r), g = sr(h), b = await i.getDimensions(u), v = h === "y", y = v ? "top" : "left", x = v ? "bottom" : "right", w = v ? "clientHeight" : "clientWidth", C = a.reference[g] + a.reference[h] - p[h] - a.floating[g], P = p[h] - a.reference[h], S = await (i.getOffsetParent == null ? void 0 : i.getOffsetParent(u));
    let _ = S ? S[w] : 0;
    (!_ || !await (i.isElement == null ? void 0 : i.isElement(S))) && (_ = c.floating[w] || a.floating[g]);
    const R = C / 2 - P / 2, I = _ / 2 - b[g] / 2 - 1, k = tt(f[y], I), N = tt(f[x], I), M = _ - b[g] - N, F = _ / 2 - b[g] / 2 + R, V = $i(k, F, M), j = !l.arrow && Ot(r) != null && F !== V && a.reference[g] / 2 - (F < k ? k : N) - b[g] / 2 < 0, B = j ? F < k ? F - k : F - M : 0;
    return {
      [h]: p[h] + B,
      data: {
        [h]: V,
        centerOffset: F - V - B,
        ...j && {
          alignmentOffset: B
        }
      },
      reset: j
    };
  }
}), wd = function(e) {
  return e === void 0 && (e = {}), {
    name: "flip",
    options: e,
    async fn(t) {
      var n, o;
      const {
        placement: r,
        middlewareData: a,
        rects: i,
        initialPlacement: c,
        platform: l,
        elements: u
      } = t, {
        mainAxis: m = !0,
        crossAxis: f = !0,
        fallbackPlacements: p,
        fallbackStrategy: h = "bestFit",
        fallbackAxisSideDirection: g = "none",
        flipAlignment: b = !0,
        ...v
      } = Ze(e, t);
      if ((n = a.arrow) != null && n.alignmentOffset)
        return {};
      const y = nt(r), x = Fe(c), w = nt(c) === c, C = await (l.isRTL == null ? void 0 : l.isRTL(u.floating)), P = p || (w || !b ? [xn(c)] : ld(c)), S = g !== "none";
      !p && S && P.push(...pd(c, b, g, C));
      const _ = [c, ...P], R = await l.detectOverflow(t, v), I = [];
      let k = ((o = a.flip) == null ? void 0 : o.overflows) || [];
      if (m && I.push(R[y]), f) {
        const V = cd(r, i, C);
        I.push(R[V[0]], R[V[1]]);
      }
      if (k = [...k, {
        placement: r,
        overflows: I
      }], !I.every((V) => V <= 0)) {
        var N, M;
        const V = (((N = a.flip) == null ? void 0 : N.index) || 0) + 1, j = _[V];
        if (j && (!(f === "alignment" ? x !== Fe(j) : !1) || // We leave the current main axis only if every placement on that axis
        // overflows the main axis.
        k.every((W) => Fe(W.placement) === x ? W.overflows[0] > 0 : !0)))
          return {
            data: {
              index: V,
              overflows: k
            },
            reset: {
              placement: j
            }
          };
        let B = (M = k.filter((z) => z.overflows[0] <= 0).sort((z, W) => z.overflows[1] - W.overflows[1])[0]) == null ? void 0 : M.placement;
        if (!B)
          switch (h) {
            case "bestFit": {
              var F;
              const z = (F = k.filter((W) => {
                if (S) {
                  const U = Fe(W.placement);
                  return U === x || // Create a bias to the `y` side axis due to horizontal
                  // reading directions favoring greater width.
                  U === "y";
                }
                return !0;
              }).map((W) => [W.placement, W.overflows.filter((U) => U > 0).reduce((U, E) => U + E, 0)]).sort((W, U) => W[1] - U[1])[0]) == null ? void 0 : F[0];
              z && (B = z);
              break;
            }
            case "initialPlacement":
              B = c;
              break;
          }
        if (r !== B)
          return {
            reset: {
              placement: B
            }
          };
      }
      return {};
    }
  };
};
function sa(e, t) {
  return {
    top: e.top - t.height,
    right: e.right - t.width,
    bottom: e.bottom - t.height,
    left: e.left - t.width
  };
}
function ca(e) {
  return id.some((t) => e[t] >= 0);
}
const xd = function(e) {
  return e === void 0 && (e = {}), {
    name: "hide",
    options: e,
    async fn(t) {
      const {
        rects: n,
        platform: o
      } = t, {
        strategy: r = "referenceHidden",
        ...a
      } = Ze(e, t);
      switch (r) {
        case "referenceHidden": {
          const i = await o.detectOverflow(t, {
            ...a,
            elementContext: "reference"
          }), c = sa(i, n.reference);
          return {
            data: {
              referenceHiddenOffsets: c,
              referenceHidden: ca(c)
            }
          };
        }
        case "escaped": {
          const i = await o.detectOverflow(t, {
            ...a,
            altBoundary: !0
          }), c = sa(i, n.floating);
          return {
            data: {
              escapedOffsets: c,
              escaped: ca(c)
            }
          };
        }
        default:
          return {};
      }
    }
  };
}, zi = /* @__PURE__ */ new Set(["left", "top"]);
async function yd(e, t) {
  const {
    placement: n,
    platform: o,
    elements: r
  } = e, a = await (o.isRTL == null ? void 0 : o.isRTL(r.floating)), i = nt(n), c = Ot(n), l = Fe(n) === "y", u = zi.has(i) ? -1 : 1, m = a && l ? -1 : 1, f = Ze(t, e);
  let {
    mainAxis: p,
    crossAxis: h,
    alignmentAxis: g
  } = typeof f == "number" ? {
    mainAxis: f,
    crossAxis: 0,
    alignmentAxis: null
  } : {
    mainAxis: f.mainAxis || 0,
    crossAxis: f.crossAxis || 0,
    alignmentAxis: f.alignmentAxis
  };
  return c && typeof g == "number" && (h = c === "end" ? g * -1 : g), l ? {
    x: h * m,
    y: p * u
  } : {
    x: p * u,
    y: h * m
  };
}
const Cd = function(e) {
  return e === void 0 && (e = 0), {
    name: "offset",
    options: e,
    async fn(t) {
      var n, o;
      const {
        x: r,
        y: a,
        placement: i,
        middlewareData: c
      } = t, l = await yd(t, e);
      return i === ((n = c.offset) == null ? void 0 : n.placement) && (o = c.arrow) != null && o.alignmentOffset ? {} : {
        x: r + l.x,
        y: a + l.y,
        data: {
          ...l,
          placement: i
        }
      };
    }
  };
}, Sd = function(e) {
  return e === void 0 && (e = {}), {
    name: "shift",
    options: e,
    async fn(t) {
      const {
        x: n,
        y: o,
        placement: r,
        platform: a
      } = t, {
        mainAxis: i = !0,
        crossAxis: c = !1,
        limiter: l = {
          fn: (x) => {
            let {
              x: w,
              y: C
            } = x;
            return {
              x: w,
              y: C
            };
          }
        },
        ...u
      } = Ze(e, t), m = {
        x: n,
        y: o
      }, f = await a.detectOverflow(t, u), p = Fe(r), h = ir(p);
      let g = m[h], b = m[p];
      const v = (x, w) => $i(w + f[x === "y" ? "top" : "left"], w, w - f[x === "y" ? "bottom" : "right"]);
      i && (g = v(h, g)), c && (b = v(p, b));
      const y = l.fn({
        ...t,
        [h]: g,
        [p]: b
      });
      return {
        ...y,
        data: {
          x: y.x - n,
          y: y.y - o,
          enabled: {
            [h]: i,
            [p]: c
          }
        }
      };
    }
  };
}, Pd = function(e) {
  return e === void 0 && (e = {}), {
    options: e,
    fn(t) {
      var n, o;
      const {
        x: r,
        y: a,
        placement: i,
        rects: c,
        middlewareData: l
      } = t, {
        offset: u = 0,
        mainAxis: m = !0,
        crossAxis: f = !0
      } = Ze(e, t), p = {
        x: r,
        y: a
      }, h = Fe(i), g = ir(h);
      let b = p[g], v = p[h];
      const y = Ze(u, t), x = typeof y == "number" ? {
        mainAxis: y,
        crossAxis: 0
      } : {
        mainAxis: (n = y.mainAxis) != null ? n : 0,
        crossAxis: (o = y.crossAxis) != null ? o : 0
      };
      if (m) {
        const P = g === "y" ? "height" : "width", S = c.reference[g] - c.floating[P] + x.mainAxis, _ = c.reference[g] + c.reference[P] - x.mainAxis;
        b < S ? b = S : b > _ && (b = _);
      }
      if (f) {
        var w, C;
        const P = g === "y" ? "width" : "height", S = zi.has(nt(i)), _ = c.reference[h] - c.floating[P] + (S && ((w = l.offset) == null ? void 0 : w[h]) || 0) + (S ? 0 : x.crossAxis), R = c.reference[h] + c.reference[P] + (S ? 0 : ((C = l.offset) == null ? void 0 : C[h]) || 0) - (S ? x.crossAxis : 0);
        v < _ ? v = _ : v > R && (v = R);
      }
      return {
        [g]: b,
        [h]: v
      };
    }
  };
}, Rd = function(e) {
  return e === void 0 && (e = {}), {
    name: "size",
    options: e,
    async fn(t) {
      const {
        placement: n,
        rects: o,
        platform: r,
        elements: a
      } = t, {
        apply: i = () => {
        },
        ...c
      } = Ze(e, t), l = await r.detectOverflow(t, c), u = nt(n), m = Ot(n), f = Fe(n) === "y", {
        width: p,
        height: h
      } = o.floating;
      let g, b;
      u === "top" || u === "bottom" ? (g = u, b = m === (await (r.isRTL == null ? void 0 : r.isRTL(a.floating)) ? "start" : "end") ? "left" : "right") : (b = u, g = m === "end" ? "top" : "bottom");
      const v = h - l.top - l.bottom, y = p - l.left - l.right, x = tt(h - l[g], v), w = tt(p - l[b], y), C = t.middlewareData.shift, P = !C;
      let S = x, _ = w;
      C != null && C.enabled.x && (_ = y), C != null && C.enabled.y && (S = v), P && !m && (f ? _ = p - 2 * je(l.left, l.right) : S = h - 2 * je(l.top, l.bottom)), await i({
        ...t,
        availableWidth: _,
        availableHeight: S
      });
      const R = await r.getDimensions(a.floating);
      return p !== R.width || h !== R.height ? {
        reset: {
          rects: !0
        }
      } : {};
    }
  };
};
function Dn() {
  return typeof window < "u";
}
function Dt(e) {
  return Bi(e) ? (e.nodeName || "").toLowerCase() : "#document";
}
function Pe(e) {
  var t;
  return (e == null || (t = e.ownerDocument) == null ? void 0 : t.defaultView) || window;
}
function Qe(e) {
  var t;
  return (t = (Bi(e) ? e.ownerDocument : e.document) || window.document) == null ? void 0 : t.documentElement;
}
function Bi(e) {
  return Dn() ? e instanceof Node || e instanceof Pe(e).Node : !1;
}
function Be(e) {
  return Dn() ? e instanceof Element || e instanceof Pe(e).Element : !1;
}
function rt(e) {
  return Dn() ? e instanceof HTMLElement || e instanceof Pe(e).HTMLElement : !1;
}
function la(e) {
  return !Dn() || typeof ShadowRoot > "u" ? !1 : e instanceof ShadowRoot || e instanceof Pe(e).ShadowRoot;
}
function Nn(e) {
  const {
    overflow: t,
    overflowX: n,
    overflowY: o,
    display: r
  } = Ve(e);
  return /auto|scroll|overlay|hidden|clip/.test(t + o + n) && r !== "inline" && r !== "contents";
}
function Ed(e) {
  return /^(table|td|th)$/.test(Dt(e));
}
function Ln(e) {
  try {
    if (e.matches(":popover-open"))
      return !0;
  } catch {
  }
  try {
    return e.matches(":modal");
  } catch {
    return !1;
  }
}
const _d = /transform|translate|scale|rotate|perspective|filter/, Td = /paint|layout|strict|content/, ct = (e) => !!e && e !== "none";
let co;
function lr(e) {
  const t = Be(e) ? Ve(e) : e;
  return ct(t.transform) || ct(t.translate) || ct(t.scale) || ct(t.rotate) || ct(t.perspective) || !ur() && (ct(t.backdropFilter) || ct(t.filter)) || _d.test(t.willChange || "") || Td.test(t.contain || "");
}
function Id(e) {
  let t = ut(e);
  for (; rt(t) && !zt(t); ) {
    if (lr(t))
      return t;
    if (Ln(t))
      return null;
    t = ut(t);
  }
  return null;
}
function ur() {
  return co == null && (co = typeof CSS < "u" && CSS.supports && CSS.supports("-webkit-backdrop-filter", "none")), co;
}
function zt(e) {
  return /^(html|body|#document)$/.test(Dt(e));
}
function Ve(e) {
  return Pe(e).getComputedStyle(e);
}
function $n(e) {
  return Be(e) ? {
    scrollLeft: e.scrollLeft,
    scrollTop: e.scrollTop
  } : {
    scrollLeft: e.scrollX,
    scrollTop: e.scrollY
  };
}
function ut(e) {
  if (Dt(e) === "html")
    return e;
  const t = (
    // Step into the shadow DOM of the parent of a slotted node.
    e.assignedSlot || // DOM Element detected.
    e.parentNode || // ShadowRoot detected.
    la(e) && e.host || // Fallback.
    Qe(e)
  );
  return la(t) ? t.host : t;
}
function Vi(e) {
  const t = ut(e);
  return zt(t) ? (e.ownerDocument || e).body : rt(t) && Nn(t) ? t : Vi(t);
}
function Bt(e, t, n) {
  var o;
  t === void 0 && (t = []), n === void 0 && (n = !0);
  const r = Vi(e), a = r === ((o = e.ownerDocument) == null ? void 0 : o.body), i = Pe(r);
  if (a) {
    const c = Mo(i);
    return t.concat(i, i.visualViewport || [], Nn(r) ? r : [], c && n ? Bt(c) : []);
  } else
    return t.concat(r, Bt(r, [], n));
}
function Mo(e) {
  return e.parent && Object.getPrototypeOf(e.parent) ? e.frameElement : null;
}
function Wi(e) {
  const t = Ve(e);
  let n = parseFloat(t.width) || 0, o = parseFloat(t.height) || 0;
  const r = rt(e), a = r ? e.offsetWidth : n, i = r ? e.offsetHeight : o, c = wn(n) !== a || wn(o) !== i;
  return c && (n = a, o = i), {
    width: n,
    height: o,
    $: c
  };
}
function dr(e) {
  return Be(e) ? e : e.contextElement;
}
function It(e) {
  const t = dr(e);
  if (!rt(t))
    return Ke(1);
  const n = t.getBoundingClientRect(), {
    width: o,
    height: r,
    $: a
  } = Wi(t);
  let i = (a ? wn(n.width) : n.width) / o, c = (a ? wn(n.height) : n.height) / r;
  return (!i || !Number.isFinite(i)) && (i = 1), (!c || !Number.isFinite(c)) && (c = 1), {
    x: i,
    y: c
  };
}
const Ad = /* @__PURE__ */ Ke(0);
function Hi(e) {
  const t = Pe(e);
  return !ur() || !t.visualViewport ? Ad : {
    x: t.visualViewport.offsetLeft,
    y: t.visualViewport.offsetTop
  };
}
function kd(e, t, n) {
  return t === void 0 && (t = !1), !!n && t && n === Pe(e);
}
function dt(e, t, n, o) {
  t === void 0 && (t = !1), n === void 0 && (n = !1);
  const r = e.getBoundingClientRect(), a = dr(e);
  let i = Ke(1);
  t && (o ? Be(o) && (i = It(o)) : i = It(e));
  const c = kd(a, n, o) ? Hi(a) : Ke(0);
  let l = (r.left + c.x) / i.x, u = (r.top + c.y) / i.y, m = r.width / i.x, f = r.height / i.y;
  if (a && o) {
    const p = Pe(a), h = Be(o) ? Pe(o) : o;
    let g = p, b = Mo(g);
    for (; b && h !== g; ) {
      const v = It(b), y = b.getBoundingClientRect(), x = Ve(b), w = y.left + (b.clientLeft + parseFloat(x.paddingLeft)) * v.x, C = y.top + (b.clientTop + parseFloat(x.paddingTop)) * v.y;
      l *= v.x, u *= v.y, m *= v.x, f *= v.y, l += w, u += C, g = Pe(b), b = Mo(g);
    }
  }
  return yn({
    width: m,
    height: f,
    x: l,
    y: u
  });
}
function Fn(e, t) {
  const n = $n(e).scrollLeft;
  return t ? t.left + n : dt(Qe(e)).left + n;
}
function Gi(e, t) {
  const n = e.getBoundingClientRect(), o = n.left + t.scrollLeft - Fn(e, n), r = n.top + t.scrollTop;
  return {
    x: o,
    y: r
  };
}
function Md(e) {
  let {
    elements: t,
    rect: n,
    offsetParent: o,
    strategy: r
  } = e;
  const a = r === "fixed", i = Qe(o), c = t ? Ln(t.floating) : !1;
  if (o === i || c && a)
    return n;
  let l = {
    scrollLeft: 0,
    scrollTop: 0
  }, u = Ke(1);
  const m = Ke(0), f = rt(o);
  if ((f || !a) && ((Dt(o) !== "body" || Nn(i)) && (l = $n(o)), f)) {
    const h = dt(o);
    u = It(o), m.x = h.x + o.clientLeft, m.y = h.y + o.clientTop;
  }
  const p = i && !f && !a ? Gi(i, l) : Ke(0);
  return {
    width: n.width * u.x,
    height: n.height * u.y,
    x: n.x * u.x - l.scrollLeft * u.x + m.x + p.x,
    y: n.y * u.y - l.scrollTop * u.y + m.y + p.y
  };
}
function Od(e) {
  return e.getClientRects ? Array.from(e.getClientRects()) : [];
}
function Dd(e) {
  const t = $n(e), n = e.ownerDocument.body, o = je(e.scrollWidth, e.clientWidth, n.scrollWidth, n.clientWidth), r = je(e.scrollHeight, e.clientHeight, n.scrollHeight, n.clientHeight);
  let a = -t.scrollLeft + Fn(e);
  const i = -t.scrollTop;
  return Ve(n).direction === "rtl" && (a += je(e.clientWidth, n.clientWidth) - o), {
    width: o,
    height: r,
    x: a,
    y: i
  };
}
const Nd = 25;
function Ld(e, t, n) {
  n === void 0 && (n = "viewport");
  const o = n === "layoutViewport", r = Pe(e), a = Qe(e), i = r.visualViewport;
  let c = a.clientWidth, l = a.clientHeight, u = 0, m = 0;
  if (i) {
    const p = !ur() || t === "fixed";
    o ? p || (u = -i.offsetLeft, m = -i.offsetTop) : (c = i.width, l = i.height, p && (u = i.offsetLeft, m = i.offsetTop));
  }
  if (Fn(a) <= 0) {
    const p = a.ownerDocument, h = p.body, g = getComputedStyle(h), b = p.compatMode === "CSS1Compat" && parseFloat(g.marginLeft) + parseFloat(g.marginRight) || 0, v = Math.abs(a.clientWidth - h.clientWidth - b), y = getComputedStyle(a).scrollbarGutter === "stable both-edges" ? v / 2 : v;
    y <= Nd && (c -= y);
  }
  return {
    width: c,
    height: l,
    x: u,
    y: m
  };
}
function $d(e, t) {
  const n = dt(e, !0, t === "fixed"), o = n.top + e.clientTop, r = n.left + e.clientLeft, a = It(e), i = e.clientWidth * a.x, c = e.clientHeight * a.y, l = r * a.x, u = o * a.y;
  return {
    width: i,
    height: c,
    x: l,
    y: u
  };
}
function ua(e, t, n) {
  let o;
  if (t === "viewport" || t === "layoutViewport")
    o = Ld(e, n, t);
  else if (t === "document")
    o = Dd(Qe(e));
  else if (Be(t))
    o = $d(t, n);
  else {
    const r = Hi(e);
    o = {
      x: t.x - r.x,
      y: t.y - r.y,
      width: t.width,
      height: t.height
    };
  }
  return yn(o);
}
function Fd(e, t) {
  const n = t.get(e);
  if (n)
    return n;
  let o = Bt(e, [], !1).filter((c) => Be(c) && Dt(c) !== "body"), r = null;
  const a = Ve(e).position === "fixed";
  let i = a ? ut(e) : e;
  for (; Be(i) && !zt(i); ) {
    const c = Ve(i), l = lr(i), u = r ? r.position : a ? "fixed" : "";
    !l && (u === "fixed" || u === "absolute" && c.position === "static") ? o = o.filter((f) => f !== i) : r = c, i = ut(i);
  }
  return t.set(e, o), o;
}
function zd(e) {
  let {
    element: t,
    boundary: n,
    rootBoundary: o,
    strategy: r
  } = e;
  const i = [...n === "clippingAncestors" ? Ln(t) ? [] : Fd(t, this._c) : [].concat(n), o], c = ua(t, i[0], r);
  let l = c.top, u = c.right, m = c.bottom, f = c.left;
  for (let p = 1; p < i.length; p++) {
    const h = ua(t, i[p], r);
    l = je(h.top, l), u = tt(h.right, u), m = tt(h.bottom, m), f = je(h.left, f);
  }
  return {
    width: u - f,
    height: m - l,
    x: f,
    y: l
  };
}
function Bd(e) {
  const {
    width: t,
    height: n
  } = Wi(e);
  return {
    width: t,
    height: n
  };
}
function Vd(e, t, n) {
  const o = rt(t), r = Qe(t), a = n === "fixed", i = dt(e, !0, a, t);
  let c = {
    scrollLeft: 0,
    scrollTop: 0
  };
  const l = Ke(0);
  if ((o || !a) && ((Dt(t) !== "body" || Nn(r)) && (c = $n(t)), o)) {
    const p = dt(t, !0, a, t);
    l.x = p.x + t.clientLeft, l.y = p.y + t.clientTop;
  }
  !o && r && (l.x = Fn(r));
  const u = r && !o && !a ? Gi(r, c) : Ke(0), m = i.left + c.scrollLeft - l.x - u.x, f = i.top + c.scrollTop - l.y - u.y;
  return {
    x: m,
    y: f,
    width: i.width,
    height: i.height
  };
}
function lo(e) {
  return Ve(e).position === "static";
}
function da(e, t) {
  if (!rt(e) || Ve(e).position === "fixed")
    return null;
  if (t)
    return t(e);
  let n = e.offsetParent;
  return Qe(e) === n && (n = n.ownerDocument.body), n;
}
function Ui(e, t) {
  const n = Pe(e);
  if (Ln(e))
    return n;
  if (!rt(e)) {
    let r = ut(e);
    for (; r && !zt(r); ) {
      if (Be(r) && !lo(r))
        return r;
      r = ut(r);
    }
    return n;
  }
  let o = da(e, t);
  for (; o && Ed(o) && lo(o); )
    o = da(o, t);
  return o && zt(o) && lo(o) && !lr(o) ? n : o || Id(e) || n;
}
const Wd = async function(e) {
  const t = this.getOffsetParent || Ui, n = this.getDimensions, o = await n(e.floating);
  return {
    reference: Vd(e.reference, await t(e.floating), e.strategy),
    floating: {
      x: 0,
      y: 0,
      width: o.width,
      height: o.height
    }
  };
};
function Hd(e) {
  return Ve(e).direction === "rtl";
}
const Gd = {
  convertOffsetParentRelativeRectToViewportRelativeRect: Md,
  getDocumentElement: Qe,
  getClippingRect: zd,
  getOffsetParent: Ui,
  getElementRects: Wd,
  getClientRects: Od,
  getDimensions: Bd,
  getScale: It,
  isElement: Be,
  isRTL: Hd
};
function ji(e, t) {
  return e.x === t.x && e.y === t.y && e.width === t.width && e.height === t.height;
}
function Ud(e, t, n) {
  let o = null, r;
  const a = Qe(e);
  function i() {
    var m;
    clearTimeout(r), (m = o) == null || m.disconnect(), o = null;
  }
  function c(m, f) {
    m === void 0 && (m = !1), f === void 0 && (f = 1), i();
    const p = e.getBoundingClientRect(), {
      left: h,
      top: g,
      width: b,
      height: v
    } = p;
    if (m || t(), !b || !v)
      return;
    const y = un(g), x = un(a.clientWidth - (h + b)), w = un(a.clientHeight - (g + v)), C = un(h), S = {
      rootMargin: -y + "px " + -x + "px " + -w + "px " + -C + "px",
      threshold: je(0, tt(1, f)) || 1
    };
    let _ = !0;
    function R(I) {
      const k = I[0].intersectionRatio;
      if (!ji(p, e.getBoundingClientRect()))
        return c();
      if (k !== f) {
        if (!_)
          return c();
        k ? c(!1, k) : r = setTimeout(() => {
          c(!1, 1e-7);
        }, 1e3);
      }
      _ = !1;
    }
    try {
      o = new IntersectionObserver(R, {
        ...S,
        // Handle <iframe>s
        root: a.ownerDocument
      });
    } catch {
      o = new IntersectionObserver(R, S);
    }
    o.observe(e);
  }
  const l = Pe(e), u = () => c(n);
  return l.addEventListener("resize", u), c(!0), () => {
    l.removeEventListener("resize", u), i();
  };
}
function jd(e, t, n, o) {
  o === void 0 && (o = {});
  const {
    ancestorScroll: r = !0,
    ancestorResize: a = !0,
    elementResize: i = typeof ResizeObserver == "function",
    layoutShift: c = typeof IntersectionObserver == "function",
    animationFrame: l = !1
  } = o, u = dr(e), m = r || a ? [...u ? Bt(u) : [], ...t ? Bt(t) : []] : [];
  m.forEach((y) => {
    r && y.addEventListener("scroll", n), a && y.addEventListener("resize", n);
  });
  const f = u && c ? Ud(u, n, a) : null;
  let p = -1, h = null;
  i && (h = new ResizeObserver((y) => {
    let [x] = y;
    x && x.target === u && h && t && (h.unobserve(t), cancelAnimationFrame(p), p = requestAnimationFrame(() => {
      var w;
      (w = h) == null || w.observe(t);
    })), n();
  }), u && !l && h.observe(u), t && h.observe(t));
  let g, b = l ? dt(e) : null;
  l && v();
  function v() {
    const y = dt(e);
    b && !ji(b, y) && n(), b = y, g = requestAnimationFrame(v);
  }
  return n(), () => {
    var y;
    m.forEach((x) => {
      r && x.removeEventListener("scroll", n), a && x.removeEventListener("resize", n);
    }), f?.(), (y = h) == null || y.disconnect(), h = null, l && cancelAnimationFrame(g);
  };
}
const Kd = Cd, Yd = Sd, Xd = wd, qd = Rd, Zd = xd, fa = vd, Qd = Pd, Jd = (e, t, n) => {
  const o = /* @__PURE__ */ new Map(), r = n ?? {}, a = {
    ...Gd,
    ...r.platform,
    _c: o
  };
  return bd(e, t, {
    ...r,
    platform: a
  });
};
var ef = typeof document < "u", tf = function() {
}, vn = ef ? _c : tf;
function Cn(e, t) {
  if (e === t)
    return !0;
  if (typeof e != typeof t)
    return !1;
  if (typeof e == "function" && e.toString() === t.toString())
    return !0;
  let n, o, r;
  if (e && t && typeof e == "object") {
    if (Array.isArray(e)) {
      if (n = e.length, n !== t.length) return !1;
      for (o = n; o-- !== 0; )
        if (!Cn(e[o], t[o]))
          return !1;
      return !0;
    }
    if (r = Object.keys(e), n = r.length, n !== Object.keys(t).length)
      return !1;
    for (o = n; o-- !== 0; )
      if (!{}.hasOwnProperty.call(t, r[o]))
        return !1;
    for (o = n; o-- !== 0; ) {
      const a = r[o];
      if (!(a === "_owner" && e.$$typeof) && !Cn(e[a], t[a]))
        return !1;
    }
    return !0;
  }
  return e !== e && t !== t;
}
function Ki(e) {
  return typeof window > "u" ? 1 : (e.ownerDocument.defaultView || window).devicePixelRatio || 1;
}
function pa(e, t) {
  const n = Ki(e);
  return Math.round(t * n) / n;
}
function uo(e) {
  const t = s.useRef(e);
  return vn(() => {
    t.current = e;
  }), t;
}
function nf(e) {
  e === void 0 && (e = {});
  const {
    placement: t = "bottom",
    strategy: n = "absolute",
    middleware: o = [],
    platform: r,
    elements: {
      reference: a,
      floating: i
    } = {},
    transform: c = !0,
    whileElementsMounted: l,
    open: u
  } = e, [m, f] = s.useState({
    x: 0,
    y: 0,
    strategy: n,
    placement: t,
    middlewareData: {},
    isPositioned: !1
  }), [p, h] = s.useState(o);
  Cn(p, o) || h(o);
  const [g, b] = s.useState(null), [v, y] = s.useState(null), x = s.useCallback((W) => {
    W !== S.current && (S.current = W, b(W));
  }, []), w = s.useCallback((W) => {
    W !== _.current && (_.current = W, y(W));
  }, []), C = a || g, P = i || v, S = s.useRef(null), _ = s.useRef(null), R = s.useRef(m), I = l != null, k = uo(l), N = uo(r), M = uo(u), F = s.useCallback(() => {
    if (!S.current || !_.current)
      return;
    const W = {
      placement: t,
      strategy: n,
      middleware: p
    };
    N.current && (W.platform = N.current), Jd(S.current, _.current, W).then((U) => {
      const E = {
        ...U,
        // The floating element's position may be recomputed while it's closed
        // but still mounted (such as when transitioning out). To ensure
        // `isPositioned` will be `false` initially on the next open, avoid
        // setting it to `true` when `open === false` (must be specified).
        isPositioned: M.current !== !1
      };
      V.current && !Cn(R.current, E) && (R.current = E, Ut.flushSync(() => {
        f(E);
      }));
    });
  }, [p, t, n, N, M]);
  vn(() => {
    u === !1 && R.current.isPositioned && (R.current.isPositioned = !1, f((W) => ({
      ...W,
      isPositioned: !1
    })));
  }, [u]);
  const V = s.useRef(!1);
  vn(() => (V.current = !0, () => {
    V.current = !1;
  }), []), vn(() => {
    if (C && (S.current = C), P && (_.current = P), C && P) {
      if (k.current)
        return k.current(C, P, F);
      F();
    }
  }, [C, P, F, k, I]);
  const j = s.useMemo(() => ({
    reference: S,
    floating: _,
    setReference: x,
    setFloating: w
  }), [x, w]), B = s.useMemo(() => ({
    reference: C,
    floating: P
  }), [C, P]), z = s.useMemo(() => {
    const W = {
      position: n,
      left: 0,
      top: 0
    };
    if (!B.floating)
      return W;
    const U = pa(B.floating, m.x), E = pa(B.floating, m.y);
    return c ? {
      ...W,
      transform: "translate(" + U + "px, " + E + "px)",
      ...Ki(B.floating) >= 1.5 && {
        willChange: "transform"
      }
    } : {
      position: n,
      left: U,
      top: E
    };
  }, [n, c, B.floating, m.x, m.y]);
  return s.useMemo(() => ({
    ...m,
    update: F,
    refs: j,
    elements: B,
    floatingStyles: z
  }), [m, F, j, B, z]);
}
const of = (e) => {
  function t(n) {
    return {}.hasOwnProperty.call(n, "current");
  }
  return {
    name: "arrow",
    options: e,
    fn(n) {
      const {
        element: o,
        padding: r
      } = typeof e == "function" ? e(n) : e;
      return o && t(o) ? o.current != null ? fa({
        element: o.current,
        padding: r
      }).fn(n) : {} : o ? fa({
        element: o,
        padding: r
      }).fn(n) : {};
    }
  };
}, rf = (e, t) => {
  const n = Kd(e);
  return {
    name: n.name,
    fn: n.fn,
    options: [e, t]
  };
}, af = (e, t) => {
  const n = Yd(e);
  return {
    name: n.name,
    fn: n.fn,
    options: [e, t]
  };
}, sf = (e, t) => ({
  fn: Qd(e).fn,
  options: [e, t]
}), cf = (e, t) => {
  const n = Xd(e);
  return {
    name: n.name,
    fn: n.fn,
    options: [e, t]
  };
}, lf = (e, t) => {
  const n = qd(e);
  return {
    name: n.name,
    fn: n.fn,
    options: [e, t]
  };
}, uf = (e, t) => {
  const n = Zd(e);
  return {
    name: n.name,
    fn: n.fn,
    options: [e, t]
  };
}, df = (e, t) => {
  const n = of(e);
  return {
    name: n.name,
    fn: n.fn,
    options: [e, t]
  };
};
var ff = Object.defineProperty, pf = (e, t) => ff(e, "name", { value: t, configurable: !0 }), mf = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ pf(function(t, n) {
    const { children: o, width: r = 10, height: a = 5, ...i } = t;
    return /* @__PURE__ */ d(
      $.svg,
      {
        ...i,
        ref: n,
        width: r,
        height: a,
        viewBox: "0 0 30 10",
        preserveAspectRatio: "none",
        children: t.asChild ? o : /* @__PURE__ */ d("polygon", { points: "0,0 30,0 15,10" })
      }
    );
  }, "Arrow")
), hf = mf, gf = Object.defineProperty, Ye = (e, t) => gf(e, "name", { value: t, configurable: !0 }), Yi = "Popper", [Xi, Nt] = /* @__PURE__ */ we(Yi), [bf, qi] = Xi(Yi), vf = /* @__PURE__ */ Ye((e) => {
  const { __scopePopper: t, children: n } = e, [o, r] = s.useState(null), [a, i] = s.useState(void 0);
  return /* @__PURE__ */ d(
    bf,
    {
      scope: t,
      anchor: o,
      onAnchorChange: r,
      placementState: a,
      setPlacementState: i,
      children: n
    }
  );
}, "Popper"), wf = "PopperAnchor", xf = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ Ye(function(t, n) {
    const { __scopePopper: o, virtualRef: r, ...a } = t, i = qi(wf, o), c = s.useRef(null), l = i.onAnchorChange, u = s.useCallback(
      (b) => {
        c.current = b, b && l(b);
      },
      [l]
    ), m = H(n, u), f = s.useRef(null);
    s.useEffect(() => {
      if (!r)
        return;
      const b = f.current;
      f.current = r.current, b !== f.current && l(f.current);
    });
    const p = i.placementState && zn(i.placementState), h = p?.[0], g = p?.[1];
    return r ? null : /* @__PURE__ */ d(
      $.div,
      {
        "data-radix-popper-side": h,
        "data-radix-popper-align": g,
        ...a,
        ref: m
      }
    );
  }, "PopperAnchor")
), Zi = "PopperContent", [yf, Cf] = Xi(Zi), Sf = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ Ye(function(t, n) {
    const {
      __scopePopper: o,
      side: r = "bottom",
      sideOffset: a = 0,
      align: i = "center",
      alignOffset: c = 0,
      arrowPadding: l = 0,
      avoidCollisions: u = !0,
      collisionBoundary: m = [],
      collisionPadding: f = 0,
      sticky: p = "partial",
      hideWhenDetached: h = !1,
      updatePositionStrategy: g = "optimized",
      onPlaced: b,
      ...v
    } = t, y = qi(Zi, o), [x, w] = s.useState(null), C = H(n, w), [P, S] = s.useState(null), _ = On(P), R = _?.width ?? 0, I = _?.height ?? 0, k = r + (i !== "center" ? "-" + i : ""), N = typeof f == "number" ? f : { top: 0, right: 0, bottom: 0, left: 0, ...f }, M = Array.isArray(m) ? m : [m], F = M.length > 0, V = {
      padding: N,
      boundary: M.filter(Qi),
      // with `strategy: 'fixed'`, this is the only way to get it to respect boundaries
      altBoundary: F
    }, { refs: j, floatingStyles: B, placement: z, isPositioned: W, middlewareData: U } = nf({
      // default to `fixed` strategy so users don't have to pick and we also avoid focus scroll issues
      strategy: "fixed",
      placement: k,
      whileElementsMounted: /* @__PURE__ */ Ye((...G) => jd(...G, {
        animationFrame: g === "always"
      }), "whileElementsMounted"),
      elements: {
        reference: y.anchor
      },
      middleware: [
        rf({ mainAxis: a + I, alignmentAxis: c }),
        u && af({
          mainAxis: !0,
          crossAxis: !1,
          limiter: p === "partial" ? sf() : void 0,
          ...V
        }),
        u && cf({ ...V }),
        lf({
          ...V,
          apply: /* @__PURE__ */ Ye(({ elements: G, rects: le, availableWidth: Z, availableHeight: J }) => {
            const { width: oe, height: Se } = le.reference, Ie = G.floating.style;
            Ie.setProperty("--radix-popper-available-width", `${Z}px`), Ie.setProperty("--radix-popper-available-height", `${J}px`), Ie.setProperty("--radix-popper-anchor-width", `${oe}px`), Ie.setProperty("--radix-popper-anchor-height", `${Se}px`);
          }, "apply")
        }),
        P && df({ element: P, padding: l }),
        _f({ arrowWidth: R, arrowHeight: I }),
        h && uf({
          strategy: "referenceHidden",
          ...V,
          // `hide` detects whether the anchor (reference) is clipped, so when
          // no explicit `collisionBoundary` is set we fall back to Floating
          // UI's default clipping ancestors (e.g. a scrollable menu). This
          // lets an occluded submenu hide once its anchor scrolls out of view
          // (#3237). The collision/size middlewares deliberately keep the
          // viewport-based default to avoid clamping content rendered inside
          // transformed or overflow-clipping portal containers.
          boundary: F ? V.boundary : void 0
        })
      ]
    }), E = y.setPlacementState;
    re(() => (E(z), () => {
      E(void 0);
    }), [z, E]);
    const [ce, ee] = zn(z), ae = ie(b);
    re(() => {
      W && ae?.();
    }, [W, ae]);
    const ge = U.arrow?.x, te = U.arrow?.y, ne = U.arrow?.centerOffset !== 0, [fe, L] = s.useState();
    return re(() => {
      x && L(window.getComputedStyle(x).zIndex);
    }, [x]), /* @__PURE__ */ d(
      "div",
      {
        ref: j.setFloating,
        "data-radix-popper-content-wrapper": "",
        style: {
          ...B,
          transform: W ? B.transform : "translate(0, -200%)",
          // keep off the page when measuring
          minWidth: "max-content",
          zIndex: fe,
          "--radix-popper-transform-origin": [
            U.transformOrigin?.x,
            U.transformOrigin?.y
          ].join(" "),
          // hide the content if using the hide middleware and should be hidden
          // set visibility to hidden and disable pointer events so the UI behaves
          // as if the PopperContent isn't there at all
          ...U.hide?.referenceHidden && {
            visibility: "hidden",
            pointerEvents: "none"
          }
        },
        dir: t.dir,
        children: /* @__PURE__ */ d(
          yf,
          {
            scope: o,
            placedSide: ce,
            placedAlign: ee,
            onArrowChange: S,
            arrowX: ge,
            arrowY: te,
            shouldHideArrow: ne,
            children: /* @__PURE__ */ d(
              $.div,
              {
                "data-side": ce,
                "data-align": ee,
                ...v,
                ref: C,
                style: {
                  ...v.style,
                  // if the PopperContent hasn't been placed yet (not all
                  // measurements done) we prevent animations so that users'
                  // animations don't kick in too early from the wrong sides.
                  animation: W ? v.style?.animation : "none"
                }
              }
            )
          }
        )
      }
    );
  }, "PopperContent")
), Pf = "PopperArrow", Rf = {
  top: "bottom",
  right: "left",
  bottom: "top",
  left: "right"
}, Ef = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ Ye(function(t, n) {
    const { __scopePopper: o, ...r } = t, a = Cf(Pf, o), i = Rf[a.placedSide];
    return (
      // we have to use an extra wrapper because `ResizeObserver` (used by `useSize`)
      // doesn't report size as we'd expect on SVG elements.
      // it reports their bounding box which is effectively the largest path inside the SVG.
      /* @__PURE__ */ d(
        "span",
        {
          ref: a.onArrowChange,
          style: {
            position: "absolute",
            left: a.arrowX,
            top: a.arrowY,
            [i]: 0,
            transformOrigin: {
              top: "",
              right: "0 0",
              bottom: "center 0",
              left: "100% 0"
            }[a.placedSide],
            transform: {
              top: "translateY(100%)",
              right: "translateY(50%) rotate(90deg) translateX(-50%)",
              bottom: "rotate(180deg)",
              left: "translateY(50%) rotate(-90deg) translateX(50%)"
            }[a.placedSide],
            visibility: a.shouldHideArrow ? "hidden" : void 0
          },
          children: /* @__PURE__ */ d(
            hf,
            {
              ...r,
              ref: n,
              style: {
                ...r.style,
                // ensures the element can be measured correctly (mostly for if SVG)
                display: "block"
              }
            }
          )
        }
      )
    );
  }, "PopperArrow")
);
function Qi(e) {
  return e !== null;
}
Ye(Qi, "isNotNull");
var _f = /* @__PURE__ */ Ye((e) => ({
  name: "transformOrigin",
  options: e,
  fn(t) {
    const { placement: n, rects: o, middlewareData: r } = t, i = r.arrow?.centerOffset !== 0, c = i ? 0 : e.arrowWidth, l = i ? 0 : e.arrowHeight, [u, m] = zn(n), f = { start: "0%", center: "50%", end: "100%" }[m], p = (r.arrow?.x ?? 0) + c / 2, h = (r.arrow?.y ?? 0) + l / 2;
    let g = "", b = "";
    return u === "bottom" ? (g = i ? f : `${p}px`, b = `${-l}px`) : u === "top" ? (g = i ? f : `${p}px`, b = `${o.floating.height + l}px`) : u === "right" ? (g = `${-l}px`, b = i ? f : `${h}px`) : u === "left" && (g = `${o.floating.width + l}px`, b = i ? f : `${h}px`), { data: { x: g, y: b } };
  }
}), "transformOrigin");
function zn(e) {
  const [t, n = "center"] = e.split("-");
  return [t, n];
}
Ye(zn, "getSideAndAlignFromPlacement");
var Bn = vf, fr = xf, pr = Sf, Tf = Ef, If = Object.defineProperty, mr = (e, t) => If(e, "name", { value: t, configurable: !0 }), fo = !1;
function Ji() {
  const [e, t] = s.useState(fo);
  return s.useEffect(() => {
    fo || (fo = !0, t(!0));
  }, []), e;
}
mr(Ji, "useIsHydrated");
var es = s[" useSyncExternalStore ".trim().toString()];
function ts() {
  return () => {
  };
}
mr(ts, "subscribe");
function ns() {
  return es(
    ts,
    () => !0,
    () => !1
  );
}
mr(ns, "useIsHydratedModern");
var Af = typeof es == "function" ? ns : Ji, kf = Object.defineProperty, bt = (e, t) => kf(e, "name", { value: t, configurable: !0 }), po = "rovingFocusGroup.onEntryFocus", Mf = { bubbles: !1, cancelable: !0 }, Vn = "RovingFocusGroup", [Oo, os, Of] = /* @__PURE__ */ jt(Vn), [Df, Wn] = /* @__PURE__ */ we(
  Vn,
  [Of]
), [Nf, Lf] = Df(Vn), $f = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ bt(function(t, n) {
    return /* @__PURE__ */ d(Oo.Provider, { scope: t.__scopeRovingFocusGroup, children: /* @__PURE__ */ d(Oo.Slot, { scope: t.__scopeRovingFocusGroup, children: /* @__PURE__ */ d(Ff, { ...t, ref: n }) }) });
  }, "RovingFocusGroup")
), Ff = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ bt(function(t, n) {
  const {
    __scopeRovingFocusGroup: o,
    orientation: r,
    loop: a = !1,
    dir: i,
    currentTabStopId: c,
    defaultCurrentTabStopId: l,
    onCurrentTabStopIdChange: u,
    onEntryFocus: m,
    preventScrollOnEntryFocus: f = !1,
    ...p
  } = t, h = s.useRef(null), g = H(n, h), b = gt(i), [v, y] = Re({
    prop: c,
    defaultProp: l ?? null,
    onChange: u,
    caller: Vn
  }), [x, w] = s.useState(!1), C = ie(m), P = os(o), S = s.useRef(!1), [_, R] = s.useState(0);
  return s.useEffect(() => {
    const I = h.current;
    if (I)
      return I.addEventListener(po, C), () => I.removeEventListener(po, C);
  }, [C]), /* @__PURE__ */ d(
    Nf,
    {
      scope: o,
      orientation: r,
      dir: b,
      loop: a,
      currentTabStopId: v,
      onItemFocus: s.useCallback(
        (I) => y(I),
        [y]
      ),
      onItemShiftTab: s.useCallback(() => w(!0), []),
      onFocusableItemAdd: s.useCallback(
        () => R((I) => I + 1),
        []
      ),
      onFocusableItemRemove: s.useCallback(
        () => R((I) => I - 1),
        []
      ),
      children: /* @__PURE__ */ d(
        $.div,
        {
          tabIndex: x || _ === 0 ? -1 : 0,
          "data-orientation": r,
          ...p,
          ref: g,
          style: { outline: "none", ...t.style },
          onMouseDown: A(t.onMouseDown, () => {
            S.current = !0;
          }),
          onFocus: A(t.onFocus, (I) => {
            const k = !S.current;
            if (I.target === I.currentTarget && k && !x) {
              const N = new CustomEvent(po, Mf);
              if (I.currentTarget.dispatchEvent(N), !N.defaultPrevented) {
                const M = P().filter((z) => z.focusable), F = M.find((z) => z.active), V = M.find((z) => z.id === v), B = [F, V, ...M].filter(
                  Boolean
                ).map((z) => z.ref.current);
                hr(B, f);
              }
            }
            S.current = !1;
          }),
          onBlur: A(t.onBlur, () => w(!1))
        }
      )
    }
  );
}, "RovingFocusGroupImpl")), zf = "RovingFocusGroupItem", Bf = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ bt(function(t, n) {
    const {
      __scopeRovingFocusGroup: o,
      focusable: r = !0,
      active: a = !1,
      tabStopId: i,
      children: c,
      ...l
    } = t, u = ve(), m = i || u, f = Lf(zf, o), p = f.currentTabStopId === m, h = os(o), { onFocusableItemAdd: g, onFocusableItemRemove: b, currentTabStopId: v } = f, y = Af();
    return re(() => {
      if (!(!y || !r))
        return g(), () => b();
    }, [y, r, g, b]), s.useEffect(() => {
      if (!(y || !r))
        return g(), () => b();
    }, [y, r, g, b]), /* @__PURE__ */ d(
      Oo.ItemSlot,
      {
        scope: o,
        id: m,
        focusable: r,
        active: a,
        children: /* @__PURE__ */ d(
          $.span,
          {
            tabIndex: p ? 0 : -1,
            "data-orientation": f.orientation,
            ...l,
            ref: n,
            onMouseDown: A(t.onMouseDown, (x) => {
              r ? f.onItemFocus(m) : x.preventDefault();
            }),
            onFocus: A(t.onFocus, () => f.onItemFocus(m)),
            onKeyDown: A(t.onKeyDown, (x) => {
              if (x.key === "Tab" && x.shiftKey) {
                f.onItemShiftTab();
                return;
              }
              if (x.target !== x.currentTarget) return;
              const w = as(x, f.orientation, f.dir);
              if (w !== void 0) {
                if (x.metaKey || x.ctrlKey || x.altKey || x.shiftKey) return;
                x.preventDefault();
                let P = h().filter((S) => S.focusable).map((S) => S.ref.current);
                if (w === "last") P.reverse();
                else if (w === "prev" || w === "next") {
                  w === "prev" && P.reverse();
                  const S = P.indexOf(x.currentTarget);
                  P = f.loop ? is(P, S + 1) : P.slice(S + 1);
                }
                setTimeout(() => hr(P));
              }
            }),
            children: typeof c == "function" ? c({ isCurrentTabStop: p, hasTabStop: v != null }) : c
          }
        )
      }
    );
  }, "RovingFocusGroupItem")
), Vf = {
  ArrowLeft: "prev",
  ArrowUp: "prev",
  ArrowRight: "next",
  ArrowDown: "next",
  PageUp: "first",
  Home: "first",
  PageDown: "last",
  End: "last"
};
function rs(e, t) {
  return t !== "rtl" ? e : e === "ArrowLeft" ? "ArrowRight" : e === "ArrowRight" ? "ArrowLeft" : e;
}
bt(rs, "getDirectionAwareKey");
function as(e, t, n) {
  const o = rs(e.key, n);
  if (!(t === "vertical" && ["ArrowLeft", "ArrowRight"].includes(o)) && !(t === "horizontal" && ["ArrowUp", "ArrowDown"].includes(o)))
    return Vf[o];
}
bt(as, "getFocusIntent");
function hr(e, t = !1) {
  const n = document.activeElement;
  for (const o of e)
    if (o === n || (o.focus({ preventScroll: t }), document.activeElement !== n)) return;
}
bt(hr, "focusFirst");
function is(e, t) {
  return e.map((n, o) => e[(t + o) % e.length]);
}
bt(is, "wrapArray");
var ss = $f, cs = Bf, Wf = Object.defineProperty, q = (e, t) => Wf(e, "name", { value: t, configurable: !0 }), Do = ["Enter", " "], Hf = ["ArrowDown", "PageUp", "Home"], ls = ["ArrowUp", "PageDown", "End"], Gf = [...Hf, ...ls], Uf = {
  ltr: [...Do, "ArrowRight"],
  rtl: [...Do, "ArrowLeft"]
}, jf = {
  ltr: ["ArrowLeft"],
  rtl: ["ArrowRight"]
}, Hn = "Menu", [Vt, Kf, Yf] = /* @__PURE__ */ jt(Hn), [vt, us] = /* @__PURE__ */ we(Hn, [
  Yf,
  Nt,
  Wn
]), Gn = Nt(), ds = Wn(), [fs, at] = vt(Hn), [Xf, Zt] = vt(Hn), qf = /* @__PURE__ */ q((e) => {
  const { __scopeMenu: t, open: n = !1, children: o, dir: r, onOpenChange: a, modal: i = !0 } = e, c = Gn(t), [l, u] = s.useState(null), m = s.useRef(!1), f = ie(a), p = gt(r);
  return s.useEffect(() => {
    const h = /* @__PURE__ */ q(() => {
      m.current = !0, document.addEventListener("pointerdown", g, { capture: !0, once: !0 }), document.addEventListener("pointermove", g, { capture: !0, once: !0 });
    }, "handleKeyDown"), g = /* @__PURE__ */ q(() => m.current = !1, "handlePointer");
    return document.addEventListener("keydown", h, { capture: !0 }), () => {
      document.removeEventListener("keydown", h, { capture: !0 }), document.removeEventListener("pointerdown", g, { capture: !0 }), document.removeEventListener("pointermove", g, { capture: !0 });
    };
  }, []), s.useEffect(() => {
    if (!n)
      return;
    const h = /* @__PURE__ */ q(() => f(!1), "handleBlur");
    return window.addEventListener("blur", h), () => window.removeEventListener("blur", h);
  }, [n, f]), /* @__PURE__ */ d(Bn, { ...c, children: /* @__PURE__ */ d(
    fs,
    {
      scope: t,
      open: n,
      onOpenChange: f,
      content: l,
      onContentChange: u,
      children: /* @__PURE__ */ d(
        Xf,
        {
          scope: t,
          onClose: s.useCallback(() => f(!1), [f]),
          isUsingKeyboardRef: m,
          dir: p,
          modal: i,
          children: o
        }
      )
    }
  ) });
}, "Menu"), ps = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ q(function(t, n) {
    const { __scopeMenu: o, ...r } = t, a = Gn(o);
    return /* @__PURE__ */ d(fr, { ...a, ...r, ref: n });
  }, "MenuAnchor")
), ms = "MenuPortal", [Zf, hs] = vt(ms, {
  forceMount: void 0
}), Qf = /* @__PURE__ */ q((e) => {
  const { __scopeMenu: t, forceMount: n, children: o, container: r } = e, a = at(ms, t);
  return /* @__PURE__ */ d(Zf, { scope: t, forceMount: n, children: /* @__PURE__ */ d(he, { present: n || a.open, children: /* @__PURE__ */ d(In, { asChild: !0, container: r, children: o }) }) });
}, "MenuPortal"), Oe = "MenuContent", [Jf, gr] = vt(Oe), ep = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ q(function(t, n) {
    const o = hs(Oe, t.__scopeMenu), { forceMount: r = o.forceMount, ...a } = t, i = at(Oe, t.__scopeMenu), c = Zt(Oe, t.__scopeMenu);
    return /* @__PURE__ */ d(Vt.Provider, { scope: t.__scopeMenu, children: /* @__PURE__ */ d(he, { present: r || i.open, children: /* @__PURE__ */ d(Vt.Slot, { scope: t.__scopeMenu, children: c.modal ? /* @__PURE__ */ d(tp, { ...a, ref: n }) : /* @__PURE__ */ d(np, { ...a, ref: n }) }) }) });
  }, "MenuContent")
), tp = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ q(function(t, n) {
    const o = at(Oe, t.__scopeMenu), r = s.useRef(null), a = H(n, r);
    return s.useEffect(() => {
      const i = r.current;
      if (i) return tr(i);
    }, []), /* @__PURE__ */ d(
      br,
      {
        ...t,
        ref: a,
        trapFocus: o.open,
        disableOutsidePointerEvents: o.open,
        disableOutsideScroll: !0,
        onFocusOutside: A(
          t.onFocusOutside,
          (i) => i.preventDefault(),
          { checkForDefaultPrevented: !1 }
        ),
        onDismiss: () => o.onOpenChange(!1)
      }
    );
  }, "MenuRootContentModal")
), np = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ q(function(t, n) {
  const o = at(Oe, t.__scopeMenu);
  return /* @__PURE__ */ d(
    br,
    {
      ...t,
      ref: n,
      trapFocus: !1,
      disableOutsidePointerEvents: !1,
      disableOutsideScroll: !1,
      onDismiss: () => o.onOpenChange(!1)
    }
  );
}, "MenuRootContentNonModal")), op = /* @__PURE__ */ ze("MenuContent.ScrollLock"), br = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ q(function(t, n) {
    const {
      __scopeMenu: o,
      loop: r = !1,
      trapFocus: a,
      onOpenAutoFocus: i,
      onCloseAutoFocus: c,
      disableOutsidePointerEvents: l,
      onEntryFocus: u,
      onEscapeKeyDown: m,
      onPointerDownOutside: f,
      onFocusOutside: p,
      onInteractOutside: h,
      onDismiss: g,
      disableOutsideScroll: b,
      ...v
    } = t, y = at(Oe, o), x = Zt(Oe, o), w = Gn(o), C = ds(o), P = Kf(o), [S, _] = s.useState(null), R = s.useRef(null), I = H(n, R, y.onContentChange), k = s.useRef(0), N = s.useRef(""), M = s.useRef(0), F = s.useRef(null), V = s.useRef("right"), j = s.useRef(0), B = b ? kn : s.Fragment, z = b ? { as: op, allowPinchZoom: !0 } : void 0, W = /* @__PURE__ */ q((E) => {
      const ce = N.current + E, ee = P().filter((L) => !L.disabled), ae = document.activeElement, ge = ee.find((L) => L.ref.current === ae)?.textValue, te = ee.map((L) => L.textValue), ne = Ps(te, ce, ge), fe = ee.find((L) => L.textValue === ne)?.ref.current;
      (/* @__PURE__ */ q((function L(G) {
        N.current = G, window.clearTimeout(k.current), G !== "" && (k.current = window.setTimeout(() => L(""), 1e3));
      }), "updateSearch"))(ce), fe && setTimeout(() => fe.focus());
    }, "handleTypeaheadSearch");
    s.useEffect(() => () => window.clearTimeout(k.current), []), Xt();
    const U = s.useCallback((E) => V.current === F.current?.side && Es(E, F.current?.area), []);
    return /* @__PURE__ */ d(
      Jf,
      {
        scope: o,
        searchRef: N,
        onItemEnter: s.useCallback(
          (E) => {
            U(E) && E.preventDefault();
          },
          [U]
        ),
        onItemLeave: s.useCallback(
          (E) => {
            U(E) || (R.current?.focus(), _(null));
          },
          [U]
        ),
        onTriggerLeave: s.useCallback(
          (E) => {
            U(E) && E.preventDefault();
          },
          [U]
        ),
        pointerGraceTimerRef: M,
        onPointerGraceIntentChange: s.useCallback((E) => {
          F.current = E;
        }, []),
        children: /* @__PURE__ */ d(B, { ...z, children: /* @__PURE__ */ d(
          Qo,
          {
            asChild: !0,
            trapped: a,
            onMountAutoFocus: A(i, (E) => {
              E.preventDefault(), R.current?.focus({ preventScroll: !0 });
            }),
            onUnmountAutoFocus: c,
            children: /* @__PURE__ */ d(
              Tn,
              {
                asChild: !0,
                disableOutsidePointerEvents: l,
                onEscapeKeyDown: m,
                onPointerDownOutside: f,
                onFocusOutside: p,
                onInteractOutside: h,
                onDismiss: g,
                children: /* @__PURE__ */ d(
                  ss,
                  {
                    asChild: !0,
                    ...C,
                    dir: x.dir,
                    orientation: "vertical",
                    loop: r,
                    currentTabStopId: S,
                    onCurrentTabStopIdChange: _,
                    onEntryFocus: A(u, (E) => {
                      x.isUsingKeyboardRef.current || E.preventDefault();
                    }),
                    preventScrollOnEntryFocus: !0,
                    children: /* @__PURE__ */ d(
                      pr,
                      {
                        role: "menu",
                        "aria-orientation": "vertical",
                        "data-state": wr(y.open),
                        "data-radix-menu-content": "",
                        dir: x.dir,
                        ...w,
                        ...v,
                        ref: I,
                        style: { outline: "none", ...v.style },
                        onKeyDown: A(v.onKeyDown, (E) => {
                          const ee = E.target.closest("[data-radix-menu-content]") === E.currentTarget, ae = E.ctrlKey || E.altKey || E.metaKey, ge = E.key.length === 1;
                          ee && (E.key === "Tab" && E.preventDefault(), !ae && ge && W(E.key));
                          const te = R.current;
                          if (E.target !== te || !Gf.includes(E.key)) return;
                          E.preventDefault();
                          const fe = P().filter((L) => !L.disabled).map((L) => L.ref.current);
                          ls.includes(E.key) && fe.reverse(), Cs(fe);
                        }),
                        onBlur: A(t.onBlur, (E) => {
                          E.currentTarget.contains(E.target) || (window.clearTimeout(k.current), N.current = "");
                        }),
                        onPointerMove: A(
                          t.onPointerMove,
                          At((E) => {
                            const ce = E.target, ee = j.current !== E.clientX;
                            if (E.currentTarget.contains(ce) && ee) {
                              const ae = E.clientX > j.current ? "right" : "left";
                              V.current = ae, j.current = E.clientX;
                            }
                          })
                        )
                      }
                    )
                  }
                )
              }
            )
          }
        ) })
      }
    );
  }, "MenuContentImpl")
), gs = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ q(function(t, n) {
    const { __scopeMenu: o, ...r } = t;
    return /* @__PURE__ */ d($.div, { role: "group", ...r, ref: n });
  }, "MenuGroup")
), rp = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ q(function(t, n) {
    const { __scopeMenu: o, ...r } = t;
    return /* @__PURE__ */ d($.div, { ...r, ref: n });
  }, "MenuLabel")
), No = "MenuItem", ma = "menu.itemSelect", vr = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ q(function(t, n) {
    const { disabled: o = !1, onSelect: r, ...a } = t, i = s.useRef(null), c = Zt(No, t.__scopeMenu), l = gr(No, t.__scopeMenu), u = H(n, i), m = s.useRef(!1), f = /* @__PURE__ */ q(() => {
      const p = i.current;
      if (!o && p) {
        const h = new CustomEvent(ma, { bubbles: !0, cancelable: !0 });
        p.addEventListener(ma, (g) => r?.(g), { once: !0 }), Ho(p, h), h.defaultPrevented ? m.current = !1 : c.onClose();
      }
    }, "handleSelect");
    return /* @__PURE__ */ d(
      bs,
      {
        ...a,
        ref: u,
        disabled: o,
        onClick: A(t.onClick, f),
        onPointerDown: (p) => {
          t.onPointerDown?.(p), m.current = !0;
        },
        onPointerUp: A(t.onPointerUp, (p) => {
          m.current || p.currentTarget?.click();
        }),
        onKeyDown: A(t.onKeyDown, (p) => {
          o || p.target !== p.currentTarget || l.searchRef.current !== "" && p.key === " " || Do.includes(p.key) && (p.currentTarget.click(), p.preventDefault());
        })
      }
    );
  }, "MenuItem")
), bs = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ q(function(t, n) {
    const { __scopeMenu: o, disabled: r = !1, textValue: a, ...i } = t, c = gr(No, o), l = ds(o), u = s.useRef(null), m = H(n, u), [f, p] = s.useState(!1), [h, g] = s.useState("");
    return s.useEffect(() => {
      const b = u.current;
      b && g((b.textContent ?? "").trim());
    }, [i.children]), /* @__PURE__ */ d(
      Vt.ItemSlot,
      {
        scope: o,
        disabled: r,
        textValue: a ?? h,
        children: /* @__PURE__ */ d(cs, { asChild: !0, ...l, focusable: !r, children: /* @__PURE__ */ d(
          $.div,
          {
            role: "menuitem",
            "data-highlighted": f ? "" : void 0,
            "aria-disabled": r || void 0,
            "data-disabled": r ? "" : void 0,
            ...i,
            ref: m,
            onPointerMove: A(
              t.onPointerMove,
              At((b) => {
                r ? c.onItemLeave(b) : (c.onItemEnter(b), b.defaultPrevented || b.currentTarget.focus({ preventScroll: !0 }));
              })
            ),
            onPointerLeave: A(
              t.onPointerLeave,
              At((b) => c.onItemLeave(b))
            ),
            onFocus: A(t.onFocus, () => p(!0)),
            onBlur: A(t.onBlur, () => p(!1))
          }
        ) })
      }
    );
  }, "MenuItemImpl")
), ap = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ q(function(t, n) {
    const { checked: o = !1, onCheckedChange: r, ...a } = t;
    return /* @__PURE__ */ d(ws, { scope: t.__scopeMenu, checked: o, children: /* @__PURE__ */ d(
      vr,
      {
        role: "menuitemcheckbox",
        "aria-checked": Wt(o) ? "mixed" : o,
        ...a,
        ref: n,
        "data-state": Un(o),
        onSelect: A(
          a.onSelect,
          () => r?.(Wt(o) ? !0 : !o),
          { checkForDefaultPrevented: !1 }
        )
      }
    ) });
  }, "MenuCheckboxItem")
), ip = "MenuRadioGroup", [sp, cp] = vt(
  ip,
  { value: void 0, onValueChange: /* @__PURE__ */ q(() => {
  }, "onValueChange") }
), lp = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ q(function(t, n) {
    const { value: o, onValueChange: r, ...a } = t, i = ie(r);
    return /* @__PURE__ */ d(sp, { scope: t.__scopeMenu, value: o, onValueChange: i, children: /* @__PURE__ */ d(gs, { ...a, ref: n }) });
  }, "MenuRadioGroup")
), up = "MenuRadioItem", dp = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ q(function(t, n) {
    const { value: o, ...r } = t, a = cp(up, t.__scopeMenu), i = o === a.value;
    return /* @__PURE__ */ d(ws, { scope: t.__scopeMenu, checked: i, children: /* @__PURE__ */ d(
      vr,
      {
        role: "menuitemradio",
        "aria-checked": i,
        ...r,
        ref: n,
        "data-state": Un(i),
        onSelect: A(
          r.onSelect,
          () => a.onValueChange?.(o),
          { checkForDefaultPrevented: !1 }
        )
      }
    ) });
  }, "MenuRadioItem")
), vs = "MenuItemIndicator", [ws, fp] = vt(
  vs,
  { checked: !1 }
), pp = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ q(function(t, n) {
    const { __scopeMenu: o, forceMount: r, ...a } = t, i = fp(vs, o);
    return /* @__PURE__ */ d(
      he,
      {
        present: r || Wt(i.checked) || i.checked === !0,
        children: /* @__PURE__ */ d(
          $.span,
          {
            ...a,
            ref: n,
            "data-state": Un(i.checked)
          }
        )
      }
    );
  }, "MenuItemIndicator")
), mp = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ q(function(t, n) {
    const { __scopeMenu: o, ...r } = t;
    return /* @__PURE__ */ d(
      $.div,
      {
        role: "separator",
        "aria-orientation": "horizontal",
        ...r,
        ref: n
      }
    );
  }, "MenuSeparator")
), xs = "MenuSub", [hp, ys] = vt(xs), gp = /* @__PURE__ */ q((e) => {
  const { __scopeMenu: t, children: n, open: o = !1, onOpenChange: r } = e, a = at(xs, t), i = Gn(t), [c, l] = s.useState(null), [u, m] = s.useState(null), f = ie(r);
  return s.useEffect(() => (a.open === !1 && f(!1), () => f(!1)), [a.open, f]), /* @__PURE__ */ d(Bn, { ...i, children: /* @__PURE__ */ d(
    fs,
    {
      scope: t,
      open: o,
      onOpenChange: f,
      content: u,
      onContentChange: m,
      children: /* @__PURE__ */ d(
        hp,
        {
          scope: t,
          contentId: ve(),
          triggerId: ve(),
          trigger: c,
          onTriggerChange: l,
          children: n
        }
      )
    }
  ) });
}, "MenuSub"), dn = "MenuSubTrigger", bp = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ q(function(t, n) {
    const o = at(dn, t.__scopeMenu), r = Zt(dn, t.__scopeMenu), a = ys(dn, t.__scopeMenu), i = gr(dn, t.__scopeMenu), c = s.useRef(null), { pointerGraceTimerRef: l, onPointerGraceIntentChange: u } = i, m = { __scopeMenu: t.__scopeMenu }, f = s.useCallback(() => {
      c.current && window.clearTimeout(c.current), c.current = null;
    }, []);
    s.useEffect(() => f, [f]), s.useEffect(() => {
      const h = l.current;
      return () => {
        window.clearTimeout(h), u(null);
      };
    }, [l, u]);
    const p = H(n, a.onTriggerChange);
    return /* @__PURE__ */ d(ps, { asChild: !0, ...m, children: /* @__PURE__ */ d(
      bs,
      {
        id: a.triggerId,
        "aria-haspopup": "menu",
        "aria-expanded": o.open,
        "aria-controls": o.open ? a.contentId : void 0,
        "data-state": wr(o.open),
        ...t,
        ref: p,
        onClick: (h) => {
          t.onClick?.(h), !(t.disabled || h.defaultPrevented) && (h.currentTarget.focus(), o.open || o.onOpenChange(!0));
        },
        onPointerMove: A(
          t.onPointerMove,
          At((h) => {
            i.onItemEnter(h), !h.defaultPrevented && !t.disabled && !o.open && !c.current && (i.onPointerGraceIntentChange(null), c.current = window.setTimeout(() => {
              o.onOpenChange(!0), f();
            }, 100));
          })
        ),
        onPointerLeave: A(
          t.onPointerLeave,
          At((h) => {
            f();
            const g = o.content?.getBoundingClientRect();
            if (g) {
              const b = o.content?.dataset.side, v = b === "right", y = v ? -5 : 5, x = g[v ? "left" : "right"], w = g[v ? "right" : "left"];
              i.onPointerGraceIntentChange({
                area: [
                  // Apply a bleed on clientX to ensure that our exit point is
                  // consistently within polygon bounds
                  { x: h.clientX + y, y: h.clientY },
                  { x, y: g.top },
                  { x: w, y: g.top },
                  { x: w, y: g.bottom },
                  { x, y: g.bottom }
                ],
                side: b
              }), window.clearTimeout(l.current), l.current = window.setTimeout(
                () => i.onPointerGraceIntentChange(null),
                300
              );
            } else {
              if (i.onTriggerLeave(h), h.defaultPrevented) return;
              i.onPointerGraceIntentChange(null);
            }
          })
        ),
        onKeyDown: A(t.onKeyDown, (h) => {
          t.disabled || h.target !== h.currentTarget || i.searchRef.current !== "" && h.key === " " || Uf[r.dir].includes(h.key) && (o.onOpenChange(!0), o.content?.focus(), h.preventDefault());
        })
      }
    ) });
  }, "MenuSubTrigger")
), vp = "MenuSubContent", wp = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ q(function(t, n) {
    const o = hs(Oe, t.__scopeMenu), { forceMount: r = o.forceMount, align: a = "start", ...i } = t, c = at(Oe, t.__scopeMenu), l = Zt(Oe, t.__scopeMenu), u = ys(vp, t.__scopeMenu), m = s.useRef(null), f = H(n, m);
    return /* @__PURE__ */ d(Vt.Provider, { scope: t.__scopeMenu, children: /* @__PURE__ */ d(he, { present: r || c.open, children: /* @__PURE__ */ d(Vt.Slot, { scope: t.__scopeMenu, children: /* @__PURE__ */ d(
      br,
      {
        id: u.contentId,
        "aria-labelledby": u.triggerId,
        ...i,
        ref: f,
        align: a,
        side: l.dir === "rtl" ? "left" : "right",
        disableOutsidePointerEvents: !1,
        disableOutsideScroll: !1,
        trapFocus: !1,
        onOpenAutoFocus: (p) => {
          l.isUsingKeyboardRef.current && m.current?.focus(), p.preventDefault();
        },
        onCloseAutoFocus: (p) => p.preventDefault(),
        onFocusOutside: A(t.onFocusOutside, (p) => {
          p.target !== u.trigger && c.onOpenChange(!1);
        }),
        onEscapeKeyDown: A(t.onEscapeKeyDown, (p) => {
          l.onClose(), p.preventDefault();
        }),
        onKeyDown: A(t.onKeyDown, (p) => {
          const h = p.currentTarget.contains(p.target), g = jf[l.dir].includes(p.key);
          h && g && (c.onOpenChange(!1), u.trigger?.focus(), p.preventDefault());
        })
      }
    ) }) }) });
  }, "MenuSubContent")
);
function wr(e) {
  return e ? "open" : "closed";
}
q(wr, "getOpenState");
function Wt(e) {
  return e === "indeterminate";
}
q(Wt, "isIndeterminate");
function Un(e) {
  return Wt(e) ? "indeterminate" : e ? "checked" : "unchecked";
}
q(Un, "getCheckedState");
function Cs(e) {
  const t = document.activeElement;
  for (const n of e)
    if (n === t || (n.focus(), document.activeElement !== t)) return;
}
q(Cs, "focusFirst");
function Ss(e, t) {
  return e.map((n, o) => e[(t + o) % e.length]);
}
q(Ss, "wrapArray");
function Ps(e, t, n) {
  const r = t.length > 1 && Array.from(t).every((u) => u === t[0]) ? t[0] : t, a = n ? e.indexOf(n) : -1;
  let i = Ss(e, Math.max(a, 0));
  r.length === 1 && (i = i.filter((u) => u !== n));
  const l = i.find(
    (u) => u.toLowerCase().startsWith(r.toLowerCase())
  );
  return l !== n ? l : void 0;
}
q(Ps, "getNextMatch");
function Rs(e, t) {
  const { x: n, y: o } = e;
  let r = !1;
  for (let a = 0, i = t.length - 1; a < t.length; i = a++) {
    const c = t[a], l = t[i], u = c.x, m = c.y, f = l.x, p = l.y;
    m > o != p > o && n < (f - u) * (o - m) / (p - m) + u && (r = !r);
  }
  return r;
}
q(Rs, "isPointInPolygon");
function Es(e, t) {
  if (!t) return !1;
  const n = { x: e.clientX, y: e.clientY };
  return Rs(n, t);
}
q(Es, "isPointerInGraceArea");
function At(e) {
  return (t) => t.pointerType === "mouse" ? e(t) : void 0;
}
q(At, "whenMouse");
var xp = qf, yp = ps, Cp = Qf, Sp = ep, Pp = gs, Rp = rp, Ep = vr, _p = ap, Tp = lp, Ip = dp, Ap = pp, kp = mp, Mp = gp, Op = bp, Dp = wp, Np = Object.defineProperty, ye = (e, t) => Np(e, "name", { value: t, configurable: !0 }), xr = "DropdownMenu", [Lp, hv] = /* @__PURE__ */ we(
  xr,
  [us]
), Ce = us(), [$p, _s] = Lp(xr), Fp = /* @__PURE__ */ ye((e) => {
  const {
    __scopeDropdownMenu: t,
    children: n,
    dir: o,
    open: r,
    defaultOpen: a,
    onOpenChange: i,
    modal: c = !0
  } = e, l = Ce(t), u = s.useRef(null), [m, f] = Re({
    prop: r,
    defaultProp: a ?? !1,
    onChange: i,
    caller: xr
  });
  return /* @__PURE__ */ d(
    $p,
    {
      scope: t,
      triggerId: ve(),
      triggerRef: u,
      contentId: ve(),
      open: m,
      onOpenChange: f,
      onOpenToggle: s.useCallback(() => f((p) => !p), [f]),
      modal: c,
      children: /* @__PURE__ */ d(xp, { ...l, open: m, onOpenChange: f, dir: o, modal: c, children: n })
    }
  );
}, "DropdownMenu"), zp = "DropdownMenuTrigger", Bp = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ ye(function(t, n) {
    const { __scopeDropdownMenu: o, disabled: r = !1, ...a } = t, i = _s(zp, o), c = Ce(o), l = H(n, i.triggerRef);
    return /* @__PURE__ */ d(yp, { asChild: !0, ...c, children: /* @__PURE__ */ d(
      $.button,
      {
        type: "button",
        id: i.triggerId,
        "aria-haspopup": "menu",
        "aria-expanded": i.open,
        "aria-controls": i.open ? i.contentId : void 0,
        "data-state": i.open ? "open" : "closed",
        "data-disabled": r ? "" : void 0,
        disabled: r,
        ...a,
        ref: l,
        onPointerDown: A(t.onPointerDown, (u) => {
          !r && u.button === 0 && u.ctrlKey === !1 && (i.onOpenToggle(), i.open || u.preventDefault());
        }),
        onKeyDown: A(t.onKeyDown, (u) => {
          r || (["Enter", " "].includes(u.key) && i.onOpenToggle(), u.key === "ArrowDown" && i.onOpenChange(!0), ["Enter", " ", "ArrowDown"].includes(u.key) && u.preventDefault());
        })
      }
    ) });
  }, "DropdownMenuTrigger")
), Vp = /* @__PURE__ */ ye((e) => {
  const { __scopeDropdownMenu: t, ...n } = e, o = Ce(t);
  return /* @__PURE__ */ d(Cp, { ...o, ...n });
}, "DropdownMenuPortal"), Wp = "DropdownMenuContent", Hp = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ ye(function(t, n) {
    const { __scopeDropdownMenu: o, ...r } = t, a = _s(Wp, o), i = Ce(o), c = s.useRef(!1);
    return /* @__PURE__ */ d(
      Sp,
      {
        id: a.contentId,
        "aria-labelledby": a.triggerId,
        ...i,
        ...r,
        ref: n,
        onCloseAutoFocus: A(t.onCloseAutoFocus, (l) => {
          c.current || a.triggerRef.current?.focus(), c.current = !1, l.preventDefault();
        }),
        onInteractOutside: A(t.onInteractOutside, (l) => {
          const u = l.detail.originalEvent, m = u.button === 0 && u.ctrlKey === !0, f = u.button === 2 || m;
          (!a.modal || f) && (c.current = !0);
        }),
        style: {
          ...t.style,
          "--radix-dropdown-menu-content-transform-origin": "var(--radix-popper-transform-origin)",
          "--radix-dropdown-menu-content-available-width": "var(--radix-popper-available-width)",
          "--radix-dropdown-menu-content-available-height": "var(--radix-popper-available-height)",
          "--radix-dropdown-menu-trigger-width": "var(--radix-popper-anchor-width)",
          "--radix-dropdown-menu-trigger-height": "var(--radix-popper-anchor-height)"
        }
      }
    );
  }, "DropdownMenuContent")
), Gp = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ ye(function(t, n) {
    const { __scopeDropdownMenu: o, ...r } = t, a = Ce(o);
    return /* @__PURE__ */ d(Pp, { ...a, ...r, ref: n });
  }, "DropdownMenuGroup")
), Up = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ ye(function(t, n) {
    const { __scopeDropdownMenu: o, ...r } = t, a = Ce(o);
    return /* @__PURE__ */ d(Rp, { ...a, ...r, ref: n });
  }, "DropdownMenuLabel")
), jp = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ ye(function(t, n) {
    const { __scopeDropdownMenu: o, ...r } = t, a = Ce(o);
    return /* @__PURE__ */ d(Ep, { ...a, ...r, ref: n });
  }, "DropdownMenuItem")
), Kp = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ ye(function(t, n) {
  const { __scopeDropdownMenu: o, ...r } = t, a = Ce(o);
  return /* @__PURE__ */ d(_p, { ...a, ...r, ref: n });
}, "DropdownMenuCheckboxItem")), Yp = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ ye(function(t, n) {
  const { __scopeDropdownMenu: o, ...r } = t, a = Ce(o);
  return /* @__PURE__ */ d(Tp, { ...a, ...r, ref: n });
}, "DropdownMenuRadioGroup")), Xp = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ ye(function(t, n) {
  const { __scopeDropdownMenu: o, ...r } = t, a = Ce(o);
  return /* @__PURE__ */ d(Ip, { ...a, ...r, ref: n });
}, "DropdownMenuRadioItem")), qp = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ ye(function(t, n) {
  const { __scopeDropdownMenu: o, ...r } = t, a = Ce(o);
  return /* @__PURE__ */ d(Ap, { ...a, ...r, ref: n });
}, "DropdownMenuItemIndicator")), Zp = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ ye(function(t, n) {
  const { __scopeDropdownMenu: o, ...r } = t, a = Ce(o);
  return /* @__PURE__ */ d(kp, { ...a, ...r, ref: n });
}, "DropdownMenuSeparator")), Qp = /* @__PURE__ */ ye((e) => {
  const { __scopeDropdownMenu: t, children: n, open: o, onOpenChange: r, defaultOpen: a } = e, i = Ce(t), [c, l] = Re({
    prop: o,
    defaultProp: a ?? !1,
    onChange: r,
    caller: "DropdownMenuSub"
  });
  return /* @__PURE__ */ d(Mp, { ...i, open: c, onOpenChange: l, children: n });
}, "DropdownMenuSub"), Jp = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ ye(function(t, n) {
  const { __scopeDropdownMenu: o, ...r } = t, a = Ce(o);
  return /* @__PURE__ */ d(Op, { ...a, ...r, ref: n });
}, "DropdownMenuSubTrigger")), em = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ ye(function(t, n) {
  const { __scopeDropdownMenu: o, ...r } = t, a = Ce(o);
  return /* @__PURE__ */ d(
    Dp,
    {
      ...a,
      ...r,
      ref: n,
      style: {
        ...t.style,
        "--radix-dropdown-menu-content-transform-origin": "var(--radix-popper-transform-origin)",
        "--radix-dropdown-menu-content-available-width": "var(--radix-popper-available-width)",
        "--radix-dropdown-menu-content-available-height": "var(--radix-popper-available-height)",
        "--radix-dropdown-menu-trigger-width": "var(--radix-popper-anchor-width)",
        "--radix-dropdown-menu-trigger-height": "var(--radix-popper-anchor-height)"
      }
    }
  );
}, "DropdownMenuSubContent")), tm = Fp, nm = Bp, om = Vp, rm = Hp, am = Gp, im = Up, sm = jp, cm = Kp, lm = Yp, um = Xp, Ts = qp, dm = Zp, fm = Qp, pm = Jp, mm = em, hm = Object.defineProperty, gm = (e, t) => hm(e, "name", { value: t, configurable: !0 }), bm = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ gm(function(t, n) {
    return /* @__PURE__ */ d(
      $.label,
      {
        ...t,
        ref: n,
        onMouseDown: (o) => {
          o.target.closest("button, input, select, textarea") || (t.onMouseDown?.(o), !o.defaultPrevented && o.detail > 1 && o.preventDefault());
        }
      }
    );
  }, "Label")
), vm = bm, wm = Object.defineProperty, xm = (e, t) => wm(e, "name", { value: t, configurable: !0 });
function Is(e) {
  const t = s.useRef({ value: e, previous: e });
  return s.useMemo(() => (t.current.value !== e && (t.current.previous = t.current.value, t.current.value = e), t.current.previous), [e]);
}
xm(Is, "usePrevious");
var ym = Object.defineProperty, Cm = (e, t) => ym(e, "name", { value: t, configurable: !0 });
function Sn(e, [t, n]) {
  return Math.min(n, Math.max(t, e));
}
Cm(Sn, "clamp");
var Sm = Object.defineProperty, Y = (e, t) => Sm(e, "name", { value: t, configurable: !0 });
function As(e, t) {
  return s.useReducer((n, o) => t[n][o] ?? n, e);
}
Y(As, "useStateMachine");
var ks = "ScrollArea", [Ms, gv] = /* @__PURE__ */ we(ks), [Pm, ke] = Ms(ks), Rm = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ Y(function(t, n) {
    const {
      __scopeScrollArea: o,
      type: r = "hover",
      dir: a,
      scrollHideDelay: i = 600,
      ...c
    } = t, [l, u] = s.useState(null), [m, f] = s.useState(null), [p, h] = s.useState(null), [g, b] = s.useState(null), [v, y] = s.useState(null), [x, w] = s.useState(0), [C, P] = s.useState(0), [S, _] = s.useState(!1), [R, I] = s.useState(!1), k = H(n, u), N = gt(a);
    return /* @__PURE__ */ d(
      Pm,
      {
        scope: o,
        type: r,
        dir: N,
        scrollHideDelay: i,
        scrollArea: l,
        viewport: m,
        onViewportChange: f,
        content: p,
        onContentChange: h,
        scrollbarX: g,
        onScrollbarXChange: b,
        scrollbarXEnabled: S,
        onScrollbarXEnabledChange: _,
        scrollbarY: v,
        onScrollbarYChange: y,
        scrollbarYEnabled: R,
        onScrollbarYEnabledChange: I,
        onCornerWidthChange: w,
        onCornerHeightChange: P,
        children: /* @__PURE__ */ d(
          $.div,
          {
            dir: N,
            ...c,
            ref: k,
            style: {
              position: "relative",
              // Pass corner sizes as CSS vars to reduce re-renders of context consumers
              "--radix-scroll-area-corner-width": x + "px",
              "--radix-scroll-area-corner-height": C + "px",
              ...t.style
            }
          }
        )
      }
    );
  }, "ScrollArea")
), Em = "ScrollAreaViewport", _m = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ Y(function(t, n) {
    const { __scopeScrollArea: o, children: r, nonce: a, ...i } = t, c = ke(Em, o), l = s.useRef(null), u = H(n, l, c.onViewportChange);
    return /* @__PURE__ */ Q(mt, { children: [
      /* @__PURE__ */ d(Tm, { nonce: a }),
      /* @__PURE__ */ d(
        $.div,
        {
          "data-radix-scroll-area-viewport": "",
          ...i,
          ref: u,
          style: {
            /**
             * We don't support `visible` because the intention is to have at least one scrollbar
             * if this component is used and `visible` will behave like `auto` in that case
             * https://developer.mozilla.org/en-US/docs/Web/CSS/overflow#description
             *
             * We don't handle `auto` because the intention is for the native implementation
             * to be hidden if using this component. We just want to ensure the node is scrollable
             * so could have used either `scroll` or `auto` here. We picked `scroll` to prevent
             * the browser from having to work out whether to render native scrollbars or not,
             * we tell it to with the intention of hiding them in CSS.
             */
            overflowX: c.scrollbarXEnabled ? "scroll" : "hidden",
            overflowY: c.scrollbarYEnabled ? "scroll" : "hidden",
            ...t.style
          },
          children: /* @__PURE__ */ d("div", { ref: c.onContentChange, style: { minWidth: "100%", display: "table" }, children: r })
        }
      )
    ] });
  }, "ScrollAreaViewport")
), Tm = /* @__PURE__ */ s.memo(
  /* @__PURE__ */ Y(function({ nonce: t }) {
    return /* @__PURE__ */ d(
      "style",
      {
        dangerouslySetInnerHTML: {
          __html: "[data-radix-scroll-area-viewport]{scrollbar-width:none;-ms-overflow-style:none;-webkit-overflow-scrolling:touch;}[data-radix-scroll-area-viewport]::-webkit-scrollbar{display:none}"
        },
        nonce: t
      }
    );
  }, "ScrollAreaViewportStyle"),
  (e, t) => e.nonce === t.nonce
), Je = "ScrollAreaScrollbar", Im = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ Y(function(t, n) {
    const { forceMount: o, ...r } = t, a = ke(Je, t.__scopeScrollArea), { onScrollbarXEnabledChange: i, onScrollbarYEnabledChange: c } = a, l = t.orientation === "horizontal";
    return s.useEffect(() => (l ? i(!0) : c(!0), () => {
      l ? i(!1) : c(!1);
    }), [l, i, c]), a.type === "hover" ? /* @__PURE__ */ d(Am, { ...r, ref: n, forceMount: o }) : a.type === "scroll" ? /* @__PURE__ */ d(km, { ...r, ref: n, forceMount: o }) : a.type === "auto" ? /* @__PURE__ */ d(Os, { ...r, ref: n, forceMount: o }) : a.type === "always" ? /* @__PURE__ */ d(yr, { ...r, ref: n, "data-state": "visible" }) : null;
  }, "ScrollAreaScrollbar")
), Am = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ Y(function(t, n) {
  const { forceMount: o, ...r } = t, a = ke(Je, t.__scopeScrollArea), [i, c] = s.useState(!1);
  return s.useEffect(() => {
    const l = a.scrollArea;
    let u = 0;
    if (l) {
      const m = /* @__PURE__ */ Y(() => {
        window.clearTimeout(u), c(!0);
      }, "handlePointerEnter"), f = /* @__PURE__ */ Y(() => {
        u = window.setTimeout(() => c(!1), a.scrollHideDelay);
      }, "handlePointerLeave");
      return l.addEventListener("pointerenter", m), l.addEventListener("pointerleave", f), () => {
        window.clearTimeout(u), l.removeEventListener("pointerenter", m), l.removeEventListener("pointerleave", f);
      };
    }
  }, [a.scrollArea, a.scrollHideDelay]), /* @__PURE__ */ d(he, { present: o || i, children: /* @__PURE__ */ d(
    Os,
    {
      "data-state": i ? "visible" : "hidden",
      ...r,
      ref: n
    }
  ) });
}, "ScrollAreaScrollbarHover")), km = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ Y(function(t, n) {
  const { forceMount: o, ...r } = t, a = ke(Je, t.__scopeScrollArea), i = t.orientation === "horizontal", c = Jt(() => u("SCROLL_END"), 100), [l, u] = As("hidden", {
    hidden: {
      SCROLL: "scrolling"
    },
    scrolling: {
      SCROLL_END: "idle",
      POINTER_ENTER: "interacting"
    },
    interacting: {
      SCROLL: "interacting",
      POINTER_LEAVE: "idle"
    },
    idle: {
      HIDE: "hidden",
      SCROLL: "scrolling",
      POINTER_ENTER: "interacting"
    }
  });
  return s.useEffect(() => {
    if (l === "idle") {
      const m = window.setTimeout(() => u("HIDE"), a.scrollHideDelay);
      return () => window.clearTimeout(m);
    }
  }, [l, a.scrollHideDelay, u]), s.useEffect(() => {
    const m = a.viewport, f = i ? "scrollLeft" : "scrollTop";
    if (m) {
      let p = m[f];
      const h = /* @__PURE__ */ Y(() => {
        const g = m[f];
        p !== g && (u("SCROLL"), c()), p = g;
      }, "handleScroll");
      return m.addEventListener("scroll", h), () => m.removeEventListener("scroll", h);
    }
  }, [a.viewport, i, u, c]), /* @__PURE__ */ d(he, { present: o || l !== "hidden", children: /* @__PURE__ */ d(
    yr,
    {
      "data-state": l === "hidden" ? "hidden" : "visible",
      ...r,
      ref: n,
      onPointerEnter: A(t.onPointerEnter, () => u("POINTER_ENTER")),
      onPointerLeave: A(t.onPointerLeave, () => u("POINTER_LEAVE"))
    }
  ) });
}, "ScrollAreaScrollbarScroll")), Os = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ Y(function(t, n) {
  const o = ke(Je, t.__scopeScrollArea), { forceMount: r, ...a } = t, [i, c] = s.useState(!1), l = t.orientation === "horizontal", u = Jt(() => {
    if (o.viewport) {
      const m = o.viewport.offsetWidth < o.viewport.scrollWidth, f = o.viewport.offsetHeight < o.viewport.scrollHeight;
      c(l ? m : f);
    }
  }, 10);
  return ft(o.viewport, u), ft(o.content, u), /* @__PURE__ */ d(he, { present: r || i, children: /* @__PURE__ */ d(
    yr,
    {
      "data-state": i ? "visible" : "hidden",
      ...a,
      ref: n
    }
  ) });
}, "ScrollAreaScrollbarAuto")), yr = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ Y(function(t, n) {
  const { orientation: o = "vertical", ...r } = t, a = ke(Je, t.__scopeScrollArea), i = s.useRef(null), c = s.useRef(0), [l, u] = s.useState({
    content: 0,
    viewport: 0,
    scrollbar: { size: 0, paddingStart: 0, paddingEnd: 0 }
  }), m = Cr(l.viewport, l.content), f = {
    ...r,
    sizes: l,
    onSizesChange: u,
    hasThumb: m > 0 && m < 1,
    onThumbChange: /* @__PURE__ */ Y((h) => i.current = h, "onThumbChange"),
    onThumbPointerUp: /* @__PURE__ */ Y(() => c.current = 0, "onThumbPointerUp"),
    onThumbPointerDown: /* @__PURE__ */ Y((h) => c.current = h, "onThumbPointerDown")
  };
  function p(h, g) {
    return $s(h, c.current, l, g);
  }
  return Y(p, "getScrollPosition"), o === "horizontal" ? /* @__PURE__ */ d(
    Mm,
    {
      ...f,
      ref: n,
      onThumbPositionChange: () => {
        if (a.viewport && i.current) {
          const h = a.viewport.scrollLeft, g = $o(h, l, a.dir);
          i.current.style.transform = `translate3d(${g}px, 0, 0)`;
        }
      },
      onWheelScroll: (h) => {
        a.viewport && (a.viewport.scrollLeft = h);
      },
      onDragScroll: (h) => {
        a.viewport && (a.viewport.scrollLeft = p(h, a.dir));
      }
    }
  ) : o === "vertical" ? /* @__PURE__ */ d(
    Om,
    {
      ...f,
      ref: n,
      onThumbPositionChange: () => {
        if (a.viewport && i.current) {
          const h = a.viewport.scrollTop, g = $o(h, l);
          i.current.style.transform = `translate3d(0, ${g}px, 0)`;
        }
      },
      onWheelScroll: (h) => {
        a.viewport && (a.viewport.scrollTop = h);
      },
      onDragScroll: (h) => {
        a.viewport && (a.viewport.scrollTop = p(h));
      }
    }
  ) : null;
}, "ScrollAreaScrollbarVisible")), Mm = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ Y(function(t, n) {
  const { sizes: o, onSizesChange: r, ...a } = t, i = ke(Je, t.__scopeScrollArea), [c, l] = s.useState(), u = s.useRef(null), m = H(n, u, i.onScrollbarXChange);
  return s.useEffect(() => {
    u.current && l(getComputedStyle(u.current));
  }, [u]), /* @__PURE__ */ d(
    Ns,
    {
      "data-orientation": "horizontal",
      ...a,
      ref: m,
      sizes: o,
      style: {
        bottom: 0,
        left: i.dir === "rtl" ? "var(--radix-scroll-area-corner-width)" : 0,
        right: i.dir === "ltr" ? "var(--radix-scroll-area-corner-width)" : 0,
        "--radix-scroll-area-thumb-width": Qt(o) + "px",
        ...t.style
      },
      onThumbPointerDown: (f) => t.onThumbPointerDown(f.x),
      onDragScroll: (f) => t.onDragScroll(f.x),
      onWheelScroll: (f, p) => {
        if (i.viewport) {
          const h = i.viewport.scrollLeft + f.deltaX;
          t.onWheelScroll(h), Pr(h, p) && f.preventDefault();
        }
      },
      onResize: () => {
        u.current && i.viewport && c && r({
          content: i.viewport.scrollWidth,
          viewport: i.viewport.offsetWidth,
          scrollbar: {
            size: u.current.clientWidth,
            paddingStart: Ht(c.paddingLeft),
            paddingEnd: Ht(c.paddingRight)
          }
        });
      }
    }
  );
}, "ScrollAreaScrollbarX")), Om = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ Y(function(t, n) {
  const { sizes: o, onSizesChange: r, ...a } = t, i = ke(Je, t.__scopeScrollArea), [c, l] = s.useState(), u = s.useRef(null), m = H(n, u, i.onScrollbarYChange);
  return s.useEffect(() => {
    u.current && l(getComputedStyle(u.current));
  }, [u]), /* @__PURE__ */ d(
    Ns,
    {
      "data-orientation": "vertical",
      ...a,
      ref: m,
      sizes: o,
      style: {
        top: 0,
        right: i.dir === "ltr" ? 0 : void 0,
        left: i.dir === "rtl" ? 0 : void 0,
        bottom: "var(--radix-scroll-area-corner-height)",
        "--radix-scroll-area-thumb-height": Qt(o) + "px",
        ...t.style
      },
      onThumbPointerDown: (f) => t.onThumbPointerDown(f.y),
      onDragScroll: (f) => t.onDragScroll(f.y),
      onWheelScroll: (f, p) => {
        if (i.viewport) {
          const h = i.viewport.scrollTop + f.deltaY;
          t.onWheelScroll(h), Pr(h, p) && f.preventDefault();
        }
      },
      onResize: () => {
        u.current && i.viewport && c && r({
          content: i.viewport.scrollHeight,
          viewport: i.viewport.offsetHeight,
          scrollbar: {
            size: u.current.clientHeight,
            paddingStart: Ht(c.paddingTop),
            paddingEnd: Ht(c.paddingBottom)
          }
        });
      }
    }
  );
}, "ScrollAreaScrollbarY")), [Dm, Ds] = Ms(Je), Ns = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ Y(function(t, n) {
  const {
    __scopeScrollArea: o,
    sizes: r,
    hasThumb: a,
    onThumbChange: i,
    onThumbPointerUp: c,
    onThumbPointerDown: l,
    onThumbPositionChange: u,
    onDragScroll: m,
    onWheelScroll: f,
    onResize: p,
    ...h
  } = t, g = ke(Je, o), [b, v] = s.useState(null), y = H(n, v), x = s.useRef(null), w = s.useRef(""), C = g.viewport, P = r.content - r.viewport, S = ie(f), _ = ie(u), R = Jt(p, 10);
  function I(k) {
    if (x.current) {
      const N = k.clientX - x.current.left, M = k.clientY - x.current.top;
      m({ x: N, y: M });
    }
  }
  return Y(I, "handleDragScroll"), s.useEffect(() => {
    const k = /* @__PURE__ */ Y((N) => {
      const M = N.target;
      b?.contains(M) && S(N, P);
    }, "handleWheel");
    return document.addEventListener("wheel", k, { passive: !1 }), () => document.removeEventListener("wheel", k, { passive: !1 });
  }, [C, b, P, S]), s.useEffect(_, [r, _]), ft(b, R), ft(g.content, R), /* @__PURE__ */ d(
    Dm,
    {
      scope: o,
      scrollbar: b,
      hasThumb: a,
      onThumbChange: ie(i),
      onThumbPointerUp: ie(c),
      onThumbPositionChange: _,
      onThumbPointerDown: ie(l),
      children: /* @__PURE__ */ d(
        $.div,
        {
          ...h,
          ref: y,
          style: { position: "absolute", ...h.style },
          onPointerDown: A(t.onPointerDown, (k) => {
            k.button === 0 && (k.target.setPointerCapture(k.pointerId), x.current = b.getBoundingClientRect(), w.current = document.body.style.webkitUserSelect, document.body.style.webkitUserSelect = "none", g.viewport && (g.viewport.style.scrollBehavior = "auto"), I(k));
          }),
          onPointerMove: A(t.onPointerMove, I),
          onPointerUp: A(t.onPointerUp, (k) => {
            const N = k.target;
            N.hasPointerCapture(k.pointerId) && N.releasePointerCapture(k.pointerId), document.body.style.webkitUserSelect = w.current, g.viewport && (g.viewport.style.scrollBehavior = ""), x.current = null;
          })
        }
      )
    }
  );
}, "ScrollAreaScrollbarImpl")), Lo = "ScrollAreaThumb", Nm = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ Y(function(t, n) {
    const { forceMount: o, ...r } = t, a = Ds(Lo, t.__scopeScrollArea);
    return /* @__PURE__ */ d(he, { present: o || a.hasThumb, children: /* @__PURE__ */ d(Lm, { ref: n, ...r }) });
  }, "ScrollAreaThumb")
), Lm = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ Y(function(t, n) {
    const { __scopeScrollArea: o, style: r, ...a } = t, i = ke(Lo, o), c = Ds(Lo, o), { onThumbPositionChange: l } = c, u = H(n, c.onThumbChange), m = s.useRef(void 0), f = Jt(() => {
      m.current && (m.current(), m.current = void 0);
    }, 100);
    return s.useEffect(() => {
      const p = i.viewport;
      if (p) {
        const h = /* @__PURE__ */ Y(() => {
          if (f(), !m.current) {
            const g = zm(p, l);
            m.current = g, l();
          }
        }, "handleScroll");
        return l(), p.addEventListener("scroll", h), () => p.removeEventListener("scroll", h);
      }
    }, [i.viewport, f, l]), /* @__PURE__ */ d(
      $.div,
      {
        "data-state": c.hasThumb ? "visible" : "hidden",
        ...a,
        ref: u,
        style: {
          width: "var(--radix-scroll-area-thumb-width)",
          height: "var(--radix-scroll-area-thumb-height)",
          ...r
        },
        onPointerDownCapture: A(t.onPointerDownCapture, (p) => {
          const g = p.target.getBoundingClientRect(), b = p.clientX - g.left, v = p.clientY - g.top;
          c.onThumbPointerDown({ x: b, y: v });
        }),
        onPointerUp: A(t.onPointerUp, c.onThumbPointerUp)
      }
    );
  }, "ScrollAreaThumbImpl")
), Ls = "ScrollAreaCorner", $m = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ Y(function(t, n) {
    const o = ke(Ls, t.__scopeScrollArea), r = !!(o.scrollbarX && o.scrollbarY);
    return o.type !== "scroll" && r ? /* @__PURE__ */ d(Fm, { ...t, ref: n }) : null;
  }, "ScrollAreaCorner")
), Fm = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ Y(function(t, n) {
  const { __scopeScrollArea: o, ...r } = t, a = ke(Ls, o), [i, c] = s.useState(0), [l, u] = s.useState(0), m = !!(i && l), { onCornerWidthChange: f, onCornerHeightChange: p } = a;
  return ft(a.scrollbarX, () => {
    const h = a.scrollbarX?.offsetHeight || 0;
    a.onCornerHeightChange(h), u(h);
  }), ft(a.scrollbarY, () => {
    const h = a.scrollbarY?.offsetWidth || 0;
    a.onCornerWidthChange(h), c(h);
  }), s.useEffect(() => () => {
    f(0), p(0);
  }, [f, p]), m ? /* @__PURE__ */ d(
    $.div,
    {
      ...r,
      ref: n,
      style: {
        width: i,
        height: l,
        position: "absolute",
        right: a.dir === "ltr" ? 0 : void 0,
        left: a.dir === "rtl" ? 0 : void 0,
        bottom: 0,
        ...t.style
      }
    }
  ) : null;
}, "ScrollAreaCornerImpl"));
function Ht(e) {
  return e ? parseInt(e, 10) : 0;
}
Y(Ht, "toInt");
function Cr(e, t) {
  const n = e / t;
  return isNaN(n) ? 0 : n;
}
Y(Cr, "getThumbRatio");
function Qt(e) {
  const t = Cr(e.viewport, e.content), n = e.scrollbar.paddingStart + e.scrollbar.paddingEnd, o = (e.scrollbar.size - n) * t;
  return Math.max(o, 18);
}
Y(Qt, "getThumbSize");
function $s(e, t, n, o = "ltr") {
  const r = Qt(n), a = r / 2, i = t || a, c = r - i, l = n.scrollbar.paddingStart + i, u = n.scrollbar.size - n.scrollbar.paddingEnd - c, m = n.content - n.viewport, f = o === "ltr" ? [0, m] : [m * -1, 0];
  return Sr([l, u], f)(e);
}
Y($s, "getScrollPositionFromPointer");
function $o(e, t, n = "ltr") {
  const o = Qt(t), r = t.scrollbar.paddingStart + t.scrollbar.paddingEnd, a = t.scrollbar.size - r, i = t.content - t.viewport, c = a - o, l = n === "ltr" ? [0, i] : [i * -1, 0], u = Sn(e, l);
  return Sr([0, i], [0, c])(u);
}
Y($o, "getThumbOffsetFromScroll");
function Sr(e, t) {
  return (n) => {
    if (e[0] === e[1] || t[0] === t[1]) return t[0];
    const o = (t[1] - t[0]) / (e[1] - e[0]);
    return t[0] + o * (n - e[0]);
  };
}
Y(Sr, "linearScale");
function Pr(e, t) {
  return e > 0 && e < t;
}
Y(Pr, "isScrollingWithinScrollbarBounds");
var zm = /* @__PURE__ */ Y((e, t = () => {
}) => {
  let n = { left: e.scrollLeft, top: e.scrollTop }, o = 0;
  return (/* @__PURE__ */ Y((function r() {
    const a = { left: e.scrollLeft, top: e.scrollTop }, i = n.left !== a.left, c = n.top !== a.top;
    (i || c) && t(), n = a, o = window.requestAnimationFrame(r);
  }), "loop"))(), () => window.cancelAnimationFrame(o);
}, "addUnlinkedScrollListener");
function Jt(e, t) {
  const n = ie(e), o = s.useRef(0);
  return s.useEffect(() => () => window.clearTimeout(o.current), []), s.useCallback(() => {
    window.clearTimeout(o.current), o.current = window.setTimeout(n, t);
  }, [n, t]);
}
Y(Jt, "useDebounceCallback");
function ft(e, t) {
  const n = ie(t);
  re(() => {
    let o = 0;
    if (e) {
      const r = new ResizeObserver(() => {
        cancelAnimationFrame(o), o = window.requestAnimationFrame(n);
      });
      return r.observe(e), () => {
        window.cancelAnimationFrame(o), r.unobserve(e);
      };
    }
  }, [e, n]);
}
Y(ft, "useResizeObserver");
var Bm = Rm, Vm = _m, Wm = $m, Hm = Object.defineProperty, X = (e, t) => Hm(e, "name", { value: t, configurable: !0 }), Gm = [" ", "Enter", "ArrowUp", "ArrowDown"], Um = [" ", "Enter"], kt = "Select", [jn, Kn, jm] = /* @__PURE__ */ jt(kt), [wt, bv] = /* @__PURE__ */ we(kt, [
  jm,
  Nt
]), Rr = Nt(), [Km, it] = wt(kt), [Ym, Xm] = wt(kt);
function Fs(e) {
  const {
    __scopeSelect: t,
    children: n,
    open: o,
    defaultOpen: r,
    onOpenChange: a,
    value: i,
    defaultValue: c,
    onValueChange: l,
    dir: u,
    name: m,
    autoComplete: f,
    disabled: p,
    required: h,
    form: g,
    // @ts-expect-error internal render prop used by `Select` to compose its default parts
    internal_do_not_use_render: b
  } = e, v = Rr(t), [y, x] = s.useState(null), [w, C] = s.useState(null), [P, S] = s.useState(!1), _ = gt(u), [R, I] = Re({
    prop: o,
    defaultProp: r ?? !1,
    onChange: a,
    caller: kt
  }), [k, N] = Re({
    prop: i,
    defaultProp: c,
    onChange: l,
    caller: kt
  }), M = s.useRef(null), F = s.useRef(k);
  s.useEffect(() => {
    const ee = g ? y?.ownerDocument.getElementById(g) : y?.form;
    if (ee instanceof HTMLFormElement) {
      const ae = /* @__PURE__ */ X(() => N(F.current), "reset");
      return ee.addEventListener("reset", ae), () => ee.removeEventListener("reset", ae);
    }
  }, [g, y, N]);
  const V = y ? !!g || !!y.closest("form") : !0, [j, B] = s.useState(/* @__PURE__ */ new Set()), z = ve(), W = Array.from(j).map((ee) => ee.props.value).join(";"), U = s.useCallback((ee) => {
    B((ae) => new Set(ae).add(ee));
  }, []), E = s.useCallback((ee) => {
    B((ae) => {
      const ge = new Set(ae);
      return ge.delete(ee), ge;
    });
  }, []), ce = {
    required: h,
    trigger: y,
    onTriggerChange: x,
    valueNode: w,
    onValueNodeChange: C,
    valueNodeHasChildren: P,
    onValueNodeHasChildrenChange: S,
    contentId: z,
    value: k,
    onValueChange: N,
    open: R,
    onOpenChange: I,
    dir: _,
    triggerPointerDownPosRef: M,
    disabled: p,
    name: m,
    autoComplete: f,
    form: g,
    nativeOptions: j,
    nativeSelectKey: W,
    isFormControl: V
  };
  return /* @__PURE__ */ d(Bn, { ...v, children: /* @__PURE__ */ d(Km, { scope: t, ...ce, children: /* @__PURE__ */ d(jn.Provider, { scope: t, children: /* @__PURE__ */ d(
    Ym,
    {
      scope: t,
      onNativeOptionAdd: U,
      onNativeOptionRemove: E,
      children: Ws(b) ? b(ce) : n
    }
  ) }) }) });
}
X(Fs, "SelectProvider");
var qm = /* @__PURE__ */ X((e) => {
  const { __scopeSelect: t, children: n, ...o } = e;
  return /* @__PURE__ */ d(
    Fs,
    {
      __scopeSelect: t,
      ...o,
      internal_do_not_use_render: ({ isFormControl: r }) => /* @__PURE__ */ Q(mt, { children: [
        n,
        r ? /* @__PURE__ */ d(
          Th,
          {
            __scopeSelect: t
          }
        ) : null
      ] })
    }
  );
}, "Select"), Zm = "SelectTrigger", Qm = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ X(function(t, n) {
    const { __scopeSelect: o, disabled: r = !1, ...a } = t, i = Rr(o), c = it(Zm, o), l = c.disabled || r, u = H(n, c.onTriggerChange), m = Kn(o), f = s.useRef("touch"), [p, h, g] = _r((v) => {
      const y = m().filter((C) => !C.disabled), x = y.find((C) => C.value === c.value), w = Tr(y, v, x);
      w !== void 0 && c.onValueChange(w.value);
    }), b = /* @__PURE__ */ X((v) => {
      l || (c.onOpenChange(!0), g()), v && (c.triggerPointerDownPosRef.current = {
        x: Math.round(v.pageX),
        y: Math.round(v.pageY)
      });
    }, "handleOpen");
    return /* @__PURE__ */ d(fr, { asChild: !0, ...i, children: /* @__PURE__ */ d(
      $.button,
      {
        type: "button",
        role: "combobox",
        "aria-controls": c.open ? c.contentId : void 0,
        "aria-expanded": c.open,
        "aria-required": c.required,
        "aria-autocomplete": "none",
        dir: c.dir,
        "data-state": c.open ? "open" : "closed",
        disabled: l,
        "data-disabled": l ? "" : void 0,
        "data-placeholder": en(c.value) ? "" : void 0,
        ...a,
        ref: u,
        onClick: A(a.onClick, (v) => {
          v.currentTarget.focus(), f.current !== "mouse" && b(v);
        }),
        onPointerDown: A(a.onPointerDown, (v) => {
          f.current = v.pointerType;
          const y = v.target;
          y.hasPointerCapture(v.pointerId) && y.releasePointerCapture(v.pointerId), v.button === 0 && v.ctrlKey === !1 && v.pointerType === "mouse" && (b(v), v.preventDefault());
        }),
        onKeyDown: A(a.onKeyDown, (v) => {
          const y = p.current !== "";
          !(v.ctrlKey || v.altKey || v.metaKey) && v.key.length === 1 && h(v.key), !(y && v.key === " ") && Gm.includes(v.key) && (b(), v.preventDefault());
        })
      }
    ) });
  }, "SelectTrigger")
), Jm = "SelectValue", eh = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ X(function(t, n) {
    const { __scopeSelect: o, className: r, style: a, children: i, placeholder: c = "", ...l } = t, u = it(Jm, o), { onValueNodeHasChildrenChange: m } = u, f = i !== void 0, p = H(n, u.onValueNodeChange);
    re(() => {
      m(f);
    }, [m, f]);
    const h = en(u.value);
    return /* @__PURE__ */ d(
      $.span,
      {
        ...l,
        asChild: h ? !1 : l.asChild,
        ref: p,
        style: { pointerEvents: "none" },
        children: /* @__PURE__ */ d(s.Fragment, { children: h ? c : i }, h ? "placeholder" : "value")
      }
    );
  }, "SelectValue")
), th = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ X(function(t, n) {
    const { __scopeSelect: o, children: r, ...a } = t;
    return /* @__PURE__ */ d($.span, { "aria-hidden": !0, ...a, ref: n, children: r || "▼" });
  }, "SelectIcon")
), nh = "SelectPortal", [oh, rh] = wt(nh, {
  forceMount: void 0
}), ah = /* @__PURE__ */ X((e) => {
  const { __scopeSelect: t, forceMount: n, ...o } = e;
  return /* @__PURE__ */ d(oh, { scope: e.__scopeSelect, forceMount: n, children: /* @__PURE__ */ d(In, { asChild: !0, ...o }) });
}, "SelectPortal"), pt = "SelectContent", ih = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ X(function(t, n) {
    const o = rh(pt, t.__scopeSelect), { forceMount: r = o.forceMount, ...a } = t, i = it(pt, t.__scopeSelect), [c, l] = s.useState();
    return re(() => {
      l(new DocumentFragment());
    }, []), /* @__PURE__ */ d(he, { present: r || i.open, children: ({ present: u }) => u ? /* @__PURE__ */ d(lh, { ...a, ref: n }) : /* @__PURE__ */ d(sh, { ...a, fragment: c }) });
  }, "SelectContent")
), sh = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ X(function(t, n) {
  const { __scopeSelect: o, children: r, fragment: a } = t;
  return a ? Ut.createPortal(
    /* @__PURE__ */ d(zs, { scope: o, children: /* @__PURE__ */ d(jn.Slot, { scope: o, children: /* @__PURE__ */ d("div", { ref: n, children: r }) }) }),
    a
  ) : null;
}, "SelectContentFragment")), Me = 10, [zs, xt] = wt(pt), ch = /* @__PURE__ */ ze("SelectContent.RemoveScroll"), lh = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ X(function(t, n) {
    const { __scopeSelect: o } = t, {
      position: r = "item-aligned",
      onCloseAutoFocus: a,
      onEscapeKeyDown: i,
      onPointerDownOutside: c,
      //
      // PopperContent props
      side: l,
      sideOffset: u,
      align: m,
      alignOffset: f,
      arrowPadding: p,
      collisionBoundary: h,
      collisionPadding: g,
      sticky: b,
      hideWhenDetached: v,
      avoidCollisions: y,
      //
      ...x
    } = t, w = it(pt, o), [C, P] = s.useState(null), [S, _] = s.useState(null), R = H(n, P), [I, k] = s.useState(null), [N, M] = s.useState(
      null
    ), F = Kn(o), [V, j] = s.useState(!1), B = s.useRef(!1);
    s.useEffect(() => {
      if (C) return tr(C);
    }, [C]), Xt();
    const z = s.useCallback(
      (L) => {
        const [G, ...le] = F().map((oe) => oe.ref.current), [Z] = le.slice(-1), J = document.activeElement;
        for (const oe of L)
          if (oe === J || (oe?.scrollIntoView({ block: "nearest" }), oe === G && S && (S.scrollTop = 0), oe === Z && S && (S.scrollTop = S.scrollHeight), oe?.focus(), document.activeElement !== J)) return;
      },
      [F, S]
    ), W = s.useCallback(
      () => z([I, C]),
      [z, I, C]
    );
    s.useEffect(() => {
      V && W();
    }, [V, W]);
    const { onOpenChange: U, triggerPointerDownPosRef: E } = w;
    s.useEffect(() => {
      if (C) {
        let L = { x: 0, y: 0 };
        const G = /* @__PURE__ */ X((Z) => {
          L = {
            x: Math.abs(Math.round(Z.pageX) - (E.current?.x ?? 0)),
            y: Math.abs(Math.round(Z.pageY) - (E.current?.y ?? 0))
          };
        }, "handlePointerMove"), le = /* @__PURE__ */ X((Z) => {
          L.x <= 10 && L.y <= 10 ? Z.preventDefault() : Z.composedPath().includes(C) || U(!1), document.removeEventListener("pointermove", G), E.current = null;
        }, "handlePointerUp");
        return E.current !== null && (document.addEventListener("pointermove", G), document.addEventListener("pointerup", le, { capture: !0, once: !0 })), () => {
          document.removeEventListener("pointermove", G), document.removeEventListener("pointerup", le, { capture: !0 });
        };
      }
    }, [C, U, E]), s.useEffect(() => {
      const L = /* @__PURE__ */ X(() => U(!1), "close");
      return window.addEventListener("blur", L), window.addEventListener("resize", L), () => {
        window.removeEventListener("blur", L), window.removeEventListener("resize", L);
      };
    }, [U]);
    const [ce, ee] = _r((L) => {
      const G = F().filter((J) => !J.disabled), le = G.find((J) => J.ref.current === document.activeElement), Z = Tr(G, L, le);
      Z && setTimeout(() => Z.ref.current?.focus());
    }), ae = s.useCallback(
      (L, G, le) => {
        const Z = !B.current && !le;
        (w.value !== void 0 && w.value === G || Z) && (k(L), Z && (B.current = !0));
      },
      [w.value]
    ), ge = s.useCallback(() => C?.focus(), [C]), te = s.useCallback(
      (L, G, le) => {
        const Z = !B.current && !le;
        (w.value !== void 0 && w.value === G || Z) && M(L);
      },
      [w.value]
    ), ne = r === "popper" ? ha : uh, fe = ne === ha ? {
      side: l,
      sideOffset: u,
      align: m,
      alignOffset: f,
      arrowPadding: p,
      collisionBoundary: h,
      collisionPadding: g,
      sticky: b,
      hideWhenDetached: v,
      avoidCollisions: y
    } : {};
    return /* @__PURE__ */ d(
      zs,
      {
        scope: o,
        content: C,
        viewport: S,
        onViewportChange: _,
        itemRefCallback: ae,
        selectedItem: I,
        onItemLeave: ge,
        itemTextRefCallback: te,
        focusSelectedItem: W,
        selectedItemText: N,
        position: r,
        isPositioned: V,
        searchRef: ce,
        children: /* @__PURE__ */ d(kn, { as: ch, allowPinchZoom: !0, children: /* @__PURE__ */ d(
          Qo,
          {
            asChild: !0,
            trapped: w.open,
            onMountAutoFocus: (L) => {
              L.preventDefault();
            },
            onUnmountAutoFocus: A(a, (L) => {
              w.trigger?.focus({ preventScroll: !0 }), L.preventDefault();
            }),
            children: /* @__PURE__ */ d(
              Tn,
              {
                asChild: !0,
                disableOutsidePointerEvents: !0,
                onEscapeKeyDown: i,
                onPointerDownOutside: c,
                onFocusOutside: (L) => L.preventDefault(),
                onDismiss: () => w.onOpenChange(!1),
                children: /* @__PURE__ */ d(
                  ne,
                  {
                    role: "listbox",
                    id: w.contentId,
                    "data-state": w.open ? "open" : "closed",
                    dir: w.dir,
                    onContextMenu: (L) => L.preventDefault(),
                    ...x,
                    ...fe,
                    onPlaced: () => j(!0),
                    ref: R,
                    style: {
                      // flex layout so we can place the scroll buttons properly
                      display: "flex",
                      flexDirection: "column",
                      // reset the outline by default as the content MAY get focused
                      outline: "none",
                      ...x.style
                    },
                    onKeyDown: A(x.onKeyDown, (L) => {
                      const G = L.ctrlKey || L.altKey || L.metaKey;
                      if (L.key === "Tab" && L.preventDefault(), !G && L.key.length === 1 && ee(L.key), ["ArrowUp", "ArrowDown", "Home", "End"].includes(L.key)) {
                        let Z = F().filter((J) => !J.disabled).map((J) => J.ref.current);
                        if (["ArrowUp", "End"].includes(L.key) && (Z = Z.slice().reverse()), ["ArrowUp", "ArrowDown"].includes(L.key)) {
                          const J = L.target, oe = Z.indexOf(J);
                          Z = Z.slice(oe + 1);
                        }
                        setTimeout(() => z(Z)), L.preventDefault();
                      }
                    })
                  }
                )
              }
            )
          }
        ) })
      }
    );
  }, "SelectContentImpl")
), uh = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ X(function(t, n) {
  const { __scopeSelect: o, onPlaced: r, ...a } = t, i = it(pt, o), c = xt(pt, o), [l, u] = s.useState(null), [m, f] = s.useState(null), p = H(n, f), h = Kn(o), g = s.useRef(!1), b = s.useRef(!0), { viewport: v, selectedItem: y, selectedItemText: x, focusSelectedItem: w } = c, C = s.useCallback(() => {
    if (i.trigger && i.valueNode && l && m && v && y && x) {
      const R = i.trigger.getBoundingClientRect(), I = m.getBoundingClientRect(), k = i.valueNode.getBoundingClientRect(), N = x.getBoundingClientRect();
      if (i.dir !== "rtl") {
        const J = N.left - I.left, oe = k.left - J, Se = R.left - oe, Ie = R.width + Se, Zn = Math.max(Ie, I.width), Qn = window.innerWidth - Me, Jn = Sn(oe, [
          Me,
          // Prevents the content from going off the starting edge of the
          // viewport. It may still go off the ending edge, but this can be
          // controlled by the user since they may want to manage overflow in a
          // specific way.
          // https://github.com/radix-ui/primitives/issues/2049
          Math.max(Me, Qn - Zn)
        ]);
        l.style.minWidth = Ie + "px", l.style.left = Jn + "px";
      } else {
        const J = I.right - N.right, oe = window.innerWidth - k.right - J, Se = window.innerWidth - R.right - oe, Ie = R.width + Se, Zn = Math.max(Ie, I.width), Qn = window.innerWidth - Me, Jn = Sn(oe, [
          Me,
          Math.max(Me, Qn - Zn)
        ]);
        l.style.minWidth = Ie + "px", l.style.right = Jn + "px";
      }
      const M = h(), F = window.innerHeight - Me * 2, V = v.scrollHeight, j = window.getComputedStyle(m), B = parseInt(j.borderTopWidth, 10), z = parseInt(j.paddingTop, 10), W = parseInt(j.borderBottomWidth, 10), U = parseInt(j.paddingBottom, 10), E = B + z + V + U + W, ce = Math.min(y.offsetHeight * 5, E), ee = window.getComputedStyle(v), ae = parseInt(ee.paddingTop, 10), ge = parseInt(ee.paddingBottom, 10), te = R.top + R.height / 2 - Me, ne = F - te, fe = y.offsetHeight / 2, L = y.offsetTop + fe, G = B + z + L, le = E - G;
      if (G <= te) {
        const J = M.length > 0 && y === M[M.length - 1].ref.current;
        l.style.bottom = "0px";
        const oe = m.clientHeight - v.offsetTop - v.offsetHeight, Se = Math.max(
          ne,
          fe + // viewport might have padding bottom, include it to avoid a scrollable viewport
          (J ? ge : 0) + oe + W
        ), Ie = G + Se;
        l.style.height = Ie + "px";
      } else {
        const J = M.length > 0 && y === M[0].ref.current;
        l.style.top = "0px";
        const Se = Math.max(
          te,
          B + v.offsetTop + // viewport might have padding top, include it to avoid a scrollable viewport
          (J ? ae : 0) + fe
        ) + le;
        l.style.height = Se + "px", v.scrollTop = G - te + v.offsetTop;
      }
      l.style.margin = `${Me}px 0`, l.style.minHeight = ce + "px", l.style.maxHeight = F + "px", r?.(), requestAnimationFrame(() => g.current = !0);
    }
  }, [
    h,
    i.trigger,
    i.valueNode,
    l,
    m,
    v,
    y,
    x,
    i.dir,
    r
  ]);
  re(() => C(), [C]);
  const [P, S] = s.useState();
  re(() => {
    m && S(window.getComputedStyle(m).zIndex);
  }, [m]);
  const _ = s.useCallback(
    (R) => {
      R && b.current === !0 && (C(), w?.(), b.current = !1);
    },
    [C, w]
  );
  return /* @__PURE__ */ d(
    dh,
    {
      scope: o,
      contentWrapper: l,
      shouldExpandOnScrollRef: g,
      onScrollButtonChange: _,
      children: /* @__PURE__ */ d(
        "div",
        {
          ref: u,
          style: {
            display: "flex",
            flexDirection: "column",
            position: "fixed",
            zIndex: P
          },
          children: /* @__PURE__ */ d(
            $.div,
            {
              ...a,
              ref: p,
              style: {
                // When we get the height of the content, it includes borders. If we were to set
                // the height without having `boxSizing: 'border-box'` it would be too big.
                boxSizing: "border-box",
                // We need to ensure the content doesn't get taller than the wrapper
                maxHeight: "100%",
                ...a.style
              }
            }
          )
        }
      )
    }
  );
}, "SelectItemAlignedPosition")), ha = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ X(function(t, n) {
  const {
    __scopeSelect: o,
    align: r = "start",
    collisionPadding: a = Me,
    ...i
  } = t, c = Rr(o);
  return /* @__PURE__ */ d(
    pr,
    {
      ...c,
      ...i,
      ref: n,
      align: r,
      collisionPadding: a,
      style: {
        // Ensure border-box for floating-ui calculations
        boxSizing: "border-box",
        ...i.style,
        "--radix-select-content-transform-origin": "var(--radix-popper-transform-origin)",
        "--radix-select-content-available-width": "var(--radix-popper-available-width)",
        "--radix-select-content-available-height": "var(--radix-popper-available-height)",
        "--radix-select-trigger-width": "var(--radix-popper-anchor-width)",
        "--radix-select-trigger-height": "var(--radix-popper-anchor-height)"
      }
    }
  );
}, "SelectPopperPosition")), [dh, Er] = wt(pt, {}), ga = "SelectViewport", fh = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ X(function(t, n) {
    const { __scopeSelect: o, nonce: r, ...a } = t, i = xt(ga, o), c = Er(ga, o), l = H(n, i.onViewportChange), u = s.useRef(0);
    return /* @__PURE__ */ Q(mt, { children: [
      /* @__PURE__ */ d(
        "style",
        {
          dangerouslySetInnerHTML: {
            __html: "[data-radix-select-viewport]{scrollbar-width:none;-ms-overflow-style:none;-webkit-overflow-scrolling:touch;}[data-radix-select-viewport]::-webkit-scrollbar{display:none}"
          },
          nonce: r
        }
      ),
      /* @__PURE__ */ d(jn.Slot, { scope: o, children: /* @__PURE__ */ d(
        $.div,
        {
          "data-radix-select-viewport": "",
          role: "presentation",
          ...a,
          ref: l,
          style: {
            // we use position: 'relative' here on the `viewport` so that when we call
            // `selectedItem.offsetTop` in calculations, the offset is relative to the viewport
            // (independent of the scrollUpButton).
            position: "relative",
            flex: 1,
            // Viewport should only be scrollable in the vertical direction.
            // This won't work in vertical writing modes, so we'll need to
            // revisit this if/when that is supported
            // https://developer.chrome.com/blog/vertical-form-controls
            overflow: "hidden auto",
            ...a.style
          },
          onScroll: A(a.onScroll, (m) => {
            const f = m.currentTarget, { contentWrapper: p, shouldExpandOnScrollRef: h } = c;
            if (h?.current && p) {
              const g = Math.abs(u.current - f.scrollTop);
              if (g > 0) {
                const b = window.innerHeight - Me * 2, v = parseFloat(p.style.minHeight), y = parseFloat(p.style.height), x = Math.max(v, y);
                if (x < b) {
                  const w = x + g, C = Math.min(b, w), P = w - C;
                  p.style.height = C + "px", p.style.bottom === "0px" && (f.scrollTop = P > 0 ? P : 0, p.style.justifyContent = "flex-end");
                }
              }
            }
            u.current = f.scrollTop;
          })
        }
      ) })
    ] });
  }, "SelectViewport")
), ph = "SelectGroup", [mh, hh] = wt(ph), gh = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ X(function(t, n) {
    const { __scopeSelect: o, ...r } = t, a = ve();
    return /* @__PURE__ */ d(mh, { scope: o, id: a, children: /* @__PURE__ */ d($.div, { role: "group", "aria-labelledby": a, ...r, ref: n }) });
  }, "SelectGroup")
), bh = "SelectLabel", vh = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ X(function(t, n) {
    const { __scopeSelect: o, ...r } = t, a = hh(bh, o);
    return /* @__PURE__ */ d($.div, { id: a.id, ...r, ref: n });
  }, "SelectLabel")
), Fo = "SelectItem", [wh, Bs] = wt(Fo), xh = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ X(function(t, n) {
    const {
      __scopeSelect: o,
      value: r,
      disabled: a = !1,
      textValue: i,
      ...c
    } = t, l = it(Fo, o), u = xt(Fo, o), m = l.value === r, [f, p] = s.useState(i ?? ""), [h, g] = s.useState(!1), b = ie(
      (C) => u.itemRefCallback?.(C, r, a)
    ), v = H(n, b), y = ve(), x = s.useRef("touch"), w = /* @__PURE__ */ X(() => {
      a || (l.onValueChange(r), l.onOpenChange(!1));
    }, "handleSelect");
    return /* @__PURE__ */ d(
      wh,
      {
        scope: o,
        value: r,
        disabled: a,
        textId: y,
        isSelected: m,
        onItemTextChange: s.useCallback((C) => {
          p((P) => P || (C?.textContent ?? "").trim());
        }, []),
        children: /* @__PURE__ */ d(
          jn.ItemSlot,
          {
            scope: o,
            value: r,
            disabled: a,
            textValue: f,
            children: /* @__PURE__ */ d(
              $.div,
              {
                role: "option",
                "aria-labelledby": y,
                "data-highlighted": h ? "" : void 0,
                "aria-selected": m && h,
                "data-state": m ? "checked" : "unchecked",
                "aria-disabled": a || void 0,
                "data-disabled": a ? "" : void 0,
                tabIndex: a ? void 0 : -1,
                ...c,
                ref: v,
                onFocus: A(c.onFocus, () => g(!0)),
                onBlur: A(c.onBlur, () => g(!1)),
                onClick: A(c.onClick, () => {
                  x.current !== "mouse" && w();
                }),
                onPointerUp: A(c.onPointerUp, () => {
                  x.current === "mouse" && w();
                }),
                onPointerDown: A(c.onPointerDown, (C) => {
                  x.current = C.pointerType;
                }),
                onPointerMove: A(c.onPointerMove, (C) => {
                  x.current = C.pointerType, a ? u.onItemLeave?.() : x.current === "mouse" && C.currentTarget.focus({ preventScroll: !0 });
                }),
                onPointerLeave: A(c.onPointerLeave, (C) => {
                  C.currentTarget === document.activeElement && u.onItemLeave?.();
                }),
                onKeyDown: A(c.onKeyDown, (C) => {
                  a || C.target !== C.currentTarget || u.searchRef?.current !== "" && C.key === " " || (Um.includes(C.key) && w(), C.key === " " && C.preventDefault());
                })
              }
            )
          }
        )
      }
    );
  }, "SelectItem")
), fn = "SelectItemText", yh = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ X(function(t, n) {
    const { __scopeSelect: o, className: r, style: a, ...i } = t, c = it(fn, o), l = xt(fn, o), u = Bs(fn, o), m = Xm(fn, o), [f, p] = s.useState(null), h = ie(
      (w) => l.itemTextRefCallback?.(w, u.value, u.disabled)
    ), g = H(
      n,
      p,
      u.onItemTextChange,
      h
    ), b = f?.textContent, v = s.useMemo(
      () => /* @__PURE__ */ d("option", { value: u.value, disabled: u.disabled, children: b }, u.value),
      [u.disabled, u.value, b]
    ), { onNativeOptionAdd: y, onNativeOptionRemove: x } = m;
    return re(() => (y(v), () => x(v)), [y, x, v]), /* @__PURE__ */ Q(mt, { children: [
      /* @__PURE__ */ d($.span, { id: u.textId, ...i, ref: g }),
      u.isSelected && c.valueNode && !c.valueNodeHasChildren && !en(c.value) ? Ut.createPortal(i.children, c.valueNode) : null
    ] });
  }, "SelectItemText")
), Ch = "SelectItemIndicator", Sh = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ X(function(t, n) {
    const { __scopeSelect: o, ...r } = t;
    return Bs(Ch, o).isSelected ? /* @__PURE__ */ d($.span, { "aria-hidden": !0, ...r, ref: n }) : null;
  }, "SelectItemIndicator")
), ba = "SelectScrollUpButton", Ph = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ X(function(t, n) {
  const o = xt(ba, t.__scopeSelect), r = Er(ba, t.__scopeSelect), [a, i] = s.useState(!1), c = H(n, r.onScrollButtonChange);
  return re(() => {
    if (o.viewport && o.isPositioned) {
      let l = function() {
        const m = u.scrollTop > 0;
        i(m);
      };
      X(l, "handleScroll");
      const u = o.viewport;
      return l(), u.addEventListener("scroll", l), () => u.removeEventListener("scroll", l);
    }
  }, [o.viewport, o.isPositioned]), a ? /* @__PURE__ */ d(
    Vs,
    {
      ...t,
      ref: c,
      onAutoScroll: () => {
        const { viewport: l, selectedItem: u } = o;
        l && u && (l.scrollTop = l.scrollTop - u.offsetHeight);
      }
    }
  ) : null;
}, "SelectScrollUpButton")), va = "SelectScrollDownButton", Rh = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ X(function(t, n) {
  const o = xt(va, t.__scopeSelect), r = Er(va, t.__scopeSelect), [a, i] = s.useState(!1), c = H(n, r.onScrollButtonChange);
  return re(() => {
    if (o.viewport && o.isPositioned) {
      let l = function() {
        const m = u.scrollHeight - u.clientHeight, f = Math.ceil(u.scrollTop) < m;
        i(f);
      };
      X(l, "handleScroll");
      const u = o.viewport;
      return l(), u.addEventListener("scroll", l), () => u.removeEventListener("scroll", l);
    }
  }, [o.viewport, o.isPositioned]), a ? /* @__PURE__ */ d(
    Vs,
    {
      ...t,
      ref: c,
      onAutoScroll: () => {
        const { viewport: l, selectedItem: u } = o;
        l && u && (l.scrollTop = l.scrollTop + u.offsetHeight);
      }
    }
  ) : null;
}, "SelectScrollDownButton")), Vs = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ X(function(t, n) {
  const { __scopeSelect: o, onAutoScroll: r, ...a } = t, i = xt("SelectScrollButton", o), c = s.useRef(null), l = Kn(o), u = s.useCallback(() => {
    c.current !== null && (window.clearInterval(c.current), c.current = null);
  }, []);
  return s.useEffect(() => () => u(), [u]), re(() => {
    l().find((f) => f.ref.current === document.activeElement)?.ref.current?.scrollIntoView({ block: "nearest" });
  }, [l]), /* @__PURE__ */ d(
    $.div,
    {
      "aria-hidden": !0,
      ...a,
      ref: n,
      style: { flexShrink: 0, ...a.style },
      onPointerDown: A(a.onPointerDown, () => {
        c.current === null && (c.current = window.setInterval(r, 50));
      }),
      onPointerMove: A(a.onPointerMove, () => {
        i.onItemLeave?.(), c.current === null && (c.current = window.setInterval(r, 50));
      }),
      onPointerLeave: A(a.onPointerLeave, () => {
        u();
      })
    }
  );
}, "SelectScrollButtonImpl")), Eh = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ X(function(t, n) {
    const { __scopeSelect: o, ...r } = t;
    return /* @__PURE__ */ d($.div, { "aria-hidden": !0, ...r, ref: n });
  }, "SelectSeparator")
), _h = "SelectBubbleInput", Th = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ X(function({ __scopeSelect: t, ...n }, o) {
    const r = it(_h, t), { value: a, onValueChange: i, required: c, disabled: l, name: u, autoComplete: m, form: f } = r, { nativeOptions: p, nativeSelectKey: h } = r, g = s.useRef(null), b = H(o, g), v = a ?? "", y = Is(v), x = Array.from(p).some(
      (w) => (w.props.value ?? "") === ""
    );
    return s.useEffect(() => {
      const w = g.current;
      if (!w) return;
      const C = window.HTMLSelectElement.prototype, S = Object.getOwnPropertyDescriptor(
        C,
        "value"
      ).set;
      if (y !== v && S) {
        const _ = new Event("change", { bubbles: !0 });
        S.call(w, v), w.dispatchEvent(_);
      }
    }, [y, v]), /* @__PURE__ */ Q(
      $.select,
      {
        "aria-hidden": !0,
        required: c,
        tabIndex: -1,
        name: u,
        autoComplete: m,
        disabled: l,
        form: f,
        onChange: (w) => i(w.target.value),
        ...n,
        style: { ...za, ...n.style },
        ref: b,
        defaultValue: v,
        children: [
          en(a) && !x ? /* @__PURE__ */ d("option", { value: "" }) : null,
          Array.from(p)
        ]
      },
      h
    );
  }, "SelectBubbleInput")
);
function Ws(e) {
  return typeof e == "function";
}
X(Ws, "isFunction");
function en(e) {
  return e === "" || e === void 0;
}
X(en, "shouldShowPlaceholder");
function _r(e) {
  const t = ie(e), n = s.useRef(""), o = s.useRef(0), r = s.useCallback(
    (i) => {
      const c = n.current + i;
      t(c), (/* @__PURE__ */ X((function l(u) {
        n.current = u, window.clearTimeout(o.current), u !== "" && (o.current = window.setTimeout(() => l(""), 1e3));
      }), "updateSearch"))(c);
    },
    [t]
  ), a = s.useCallback(() => {
    n.current = "", window.clearTimeout(o.current);
  }, []);
  return s.useEffect(() => () => window.clearTimeout(o.current), []), [n, r, a];
}
X(_r, "useTypeaheadSearch");
function Tr(e, t, n) {
  const r = t.length > 1 && Array.from(t).every((u) => u === t[0]) ? t[0] : t, a = n ? e.indexOf(n) : -1;
  let i = Hs(e, Math.max(a, 0));
  r.length === 1 && (i = i.filter((u) => u !== n));
  const l = i.find(
    (u) => u.textValue.toLowerCase().startsWith(r.toLowerCase())
  );
  return l !== n ? l : void 0;
}
X(Tr, "findNextItem");
function Hs(e, t) {
  return e.map((n, o) => e[(t + o) % e.length]);
}
X(Hs, "wrapArray");
var Ih = Object.defineProperty, Gs = (e, t) => Ih(e, "name", { value: t, configurable: !0 }), wa = "horizontal", Ah = ["horizontal", "vertical"], kh = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ Gs(function(t, n) {
    const { decorative: o, orientation: r = wa, ...a } = t, i = Us(r) ? r : wa, l = o ? { role: "none" } : { "aria-orientation": i === "vertical" ? i : void 0, role: "separator" };
    return /* @__PURE__ */ d(
      $.div,
      {
        "data-orientation": i,
        ...l,
        ...a,
        ref: n
      }
    );
  }, "Separator")
);
function Us(e) {
  return Ah.includes(e);
}
Gs(Us, "isValidOrientation");
var Mh = kh, Oh = Object.defineProperty, ot = (e, t) => Oh(e, "name", { value: t, configurable: !0 }), Ir = "Switch", [Dh, vv] = /* @__PURE__ */ we(Ir), [Nh, Ar] = Dh(Ir);
function js(e) {
  const {
    __scopeSwitch: t,
    checked: n,
    children: o,
    defaultChecked: r,
    disabled: a,
    form: i,
    name: c,
    onCheckedChange: l,
    required: u,
    value: m = "on",
    // @ts-expect-error
    internal_do_not_use_render: f
  } = e, [p, h] = Re({
    prop: n,
    defaultProp: r ?? !1,
    onChange: l,
    caller: Ir
  }), [g, b] = s.useState(null), [v, y] = s.useState(null), x = s.useRef(!1), [w, C] = s.useReducer(
    (_) => _ + 1,
    0
  ), P = g ? !!i || !!g.closest("form") : (
    // We set this to true by default so that events bubble to forms without JS (SSR)
    !0
  ), S = {
    checked: p,
    setChecked: h,
    disabled: a,
    control: g,
    setControl: b,
    name: c,
    form: i,
    value: m,
    hasConsumerStoppedPropagationRef: x,
    userInteractionCount: w,
    onUserInteraction: C,
    required: u,
    defaultChecked: r,
    isFormControl: P,
    bubbleInput: v,
    setBubbleInput: y
  };
  return /* @__PURE__ */ d(Nh, { scope: t, ...S, children: Ks(f) ? f(S) : o });
}
ot(js, "SwitchProvider");
var Lh = "SwitchTrigger", $h = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ ot(function({ __scopeSwitch: t, onClick: n, ...o }, r) {
    const {
      control: a,
      form: i,
      value: c,
      disabled: l,
      checked: u,
      required: m,
      setControl: f,
      setChecked: p,
      hasConsumerStoppedPropagationRef: h,
      onUserInteraction: g,
      isFormControl: b,
      bubbleInput: v
    } = Ar(Lh, t), y = H(r, f), x = s.useRef(u);
    return s.useEffect(() => {
      const w = i ? a?.ownerDocument.getElementById(i) : a?.form;
      if (w instanceof HTMLFormElement) {
        const C = /* @__PURE__ */ ot(() => p(x.current), "reset");
        return w.addEventListener("reset", C), () => w.removeEventListener("reset", C);
      }
    }, [a, i, p]), /* @__PURE__ */ d(
      $.button,
      {
        type: "button",
        role: "switch",
        "aria-checked": u,
        "aria-required": m,
        "data-state": kr(u),
        "data-disabled": l ? "" : void 0,
        disabled: l,
        value: c,
        ...o,
        ref: y,
        onClick: A(n, (w) => {
          g(), p((C) => !C), v && b && (h.current = w.isPropagationStopped(), h.current || w.stopPropagation());
        })
      }
    );
  }, "SwitchTrigger")
), Fh = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ ot(function(t, n) {
    const {
      __scopeSwitch: o,
      name: r,
      checked: a,
      defaultChecked: i,
      required: c,
      disabled: l,
      value: u,
      onCheckedChange: m,
      form: f,
      ...p
    } = t;
    return /* @__PURE__ */ d(
      js,
      {
        __scopeSwitch: o,
        checked: a,
        defaultChecked: i,
        disabled: l,
        required: c,
        onCheckedChange: m,
        name: r,
        form: f,
        value: u,
        internal_do_not_use_render: ({ isFormControl: h }) => /* @__PURE__ */ Q(mt, { children: [
          /* @__PURE__ */ d(
            $h,
            {
              ...p,
              ref: n,
              __scopeSwitch: o
            }
          ),
          h && /* @__PURE__ */ d(
            Wh,
            {
              __scopeSwitch: o
            }
          )
        ] })
      }
    );
  }, "Switch")
), zh = "SwitchThumb", Bh = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ ot(function(t, n) {
    const { __scopeSwitch: o, ...r } = t, a = Ar(zh, o);
    return /* @__PURE__ */ d(
      $.span,
      {
        "data-state": kr(a.checked),
        "data-disabled": a.disabled ? "" : void 0,
        ...r,
        ref: n
      }
    );
  }, "SwitchThumb")
), Vh = "SwitchBubbleInput", Wh = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ ot(function({ __scopeSwitch: t, onClick: n, ...o }, r) {
    const {
      control: a,
      hasConsumerStoppedPropagationRef: i,
      userInteractionCount: c,
      checked: l,
      defaultChecked: u,
      required: m,
      disabled: f,
      name: p,
      value: h,
      form: g,
      bubbleInput: b,
      setBubbleInput: v
    } = Ar(Vh, t), y = H(r, v), x = On(a), w = s.useRef(!1), C = s.useRef(l), P = s.useRef(c);
    s.useEffect(() => {
      const _ = b;
      if (!_) return;
      const R = window.HTMLInputElement.prototype, k = Object.getOwnPropertyDescriptor(
        R,
        "checked"
      ).set, N = c !== P.current;
      P.current = c;
      const M = C.current !== l;
      C.current = l;
      const F = !(N && i.current);
      if (M && k) {
        w.current = !N;
        const V = new Event("click", { bubbles: F });
        k.call(_, l), _.dispatchEvent(V), w.current = !1;
      }
    }, [b, l, i, c]);
    const S = s.useRef(l);
    return /* @__PURE__ */ d(
      $.input,
      {
        type: "checkbox",
        "aria-hidden": !0,
        defaultChecked: u ?? S.current,
        required: m,
        disabled: f,
        name: p,
        value: h,
        form: g,
        ...o,
        tabIndex: -1,
        ref: y,
        onClick: A(n, (_) => {
          w.current && _.stopPropagation();
        }),
        style: {
          ...o.style,
          ...x,
          position: "absolute",
          pointerEvents: "none",
          opacity: 0,
          margin: 0,
          // We transform because the input is absolutely positioned but we have
          // rendered it **after** the button. This pulls it back to sit on top
          // of the button.
          transform: "translateX(-100%)"
        }
      }
    );
  }, "SwitchBubbleInput")
);
function Ks(e) {
  return typeof e == "function";
}
ot(Ks, "isFunction");
function kr(e) {
  return e ? "checked" : "unchecked";
}
ot(kr, "getState");
var Hh = Object.defineProperty, Lt = (e, t) => Hh(e, "name", { value: t, configurable: !0 }), Mr = "Tabs", [Gh, wv] = /* @__PURE__ */ we(Mr, [
  Wn
]), Ys = Wn(), [Uh, Or] = Gh(Mr), jh = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ Lt(function(t, n) {
    const {
      __scopeTabs: o,
      value: r,
      onValueChange: a,
      defaultValue: i,
      orientation: c = "horizontal",
      dir: l,
      activationMode: u = "automatic",
      ...m
    } = t, f = gt(l), [p, h] = Re({
      prop: r,
      onChange: a,
      defaultProp: i ?? "",
      caller: Mr
    });
    return /* @__PURE__ */ d(
      Uh,
      {
        scope: o,
        baseId: ve(),
        value: p,
        onValueChange: h,
        orientation: c,
        dir: f,
        activationMode: u,
        children: /* @__PURE__ */ d(
          $.div,
          {
            dir: f,
            "data-orientation": c,
            ...m,
            ref: n
          }
        )
      }
    );
  }, "Tabs")
), Kh = "TabsList", Yh = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ Lt(function(t, n) {
    const { __scopeTabs: o, loop: r = !0, ...a } = t, i = Or(Kh, o), c = Ys(o);
    return /* @__PURE__ */ d(
      ss,
      {
        asChild: !0,
        ...c,
        orientation: i.orientation,
        dir: i.dir,
        loop: r,
        children: /* @__PURE__ */ d(
          $.div,
          {
            role: "tablist",
            "aria-orientation": i.orientation,
            ...a,
            ref: n
          }
        )
      }
    );
  }, "TabsList")
), Xh = "TabsTrigger", qh = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ Lt(function(t, n) {
    const { __scopeTabs: o, value: r, disabled: a = !1, ...i } = t, c = Or(Xh, o), l = Ys(o), u = Dr(c.baseId, r), m = Nr(c.baseId, r), f = r === c.value;
    return /* @__PURE__ */ d(
      cs,
      {
        asChild: !0,
        ...l,
        focusable: !a,
        active: f,
        children: /* @__PURE__ */ d(
          $.button,
          {
            type: "button",
            role: "tab",
            "aria-selected": f,
            "aria-controls": m,
            "data-state": f ? "active" : "inactive",
            "data-disabled": a ? "" : void 0,
            disabled: a,
            id: u,
            ...i,
            ref: n,
            onMouseDown: A(t.onMouseDown, (p) => {
              !a && p.button === 0 && p.ctrlKey === !1 ? c.onValueChange(r) : p.preventDefault();
            }),
            onKeyDown: A(t.onKeyDown, (p) => {
              a || p.target !== p.currentTarget || [" ", "Enter"].includes(p.key) && c.onValueChange(r);
            }),
            onFocus: A(t.onFocus, () => {
              const p = c.activationMode !== "manual";
              !f && !a && p && c.onValueChange(r);
            })
          }
        )
      }
    );
  }, "TabsTrigger")
), Zh = "TabsContent", Qh = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ Lt(function(t, n) {
    const { __scopeTabs: o, value: r, forceMount: a, children: i, ...c } = t, l = Or(Zh, o), u = Dr(l.baseId, r), m = Nr(l.baseId, r), f = r === l.value, p = s.useRef(f);
    return s.useEffect(() => {
      const h = requestAnimationFrame(() => p.current = !1);
      return () => cancelAnimationFrame(h);
    }, []), /* @__PURE__ */ d(he, { present: a || f, children: ({ present: h }) => /* @__PURE__ */ d(
      $.div,
      {
        "data-state": f ? "active" : "inactive",
        "data-orientation": l.orientation,
        role: "tabpanel",
        "aria-labelledby": u,
        hidden: !h,
        id: m,
        tabIndex: 0,
        ...c,
        ref: n,
        style: {
          ...t.style,
          animationDuration: p.current ? "0s" : void 0
        },
        children: h && i
      }
    ) });
  }, "TabsContent")
);
function Dr(e, t) {
  return `${e}-trigger-${t}`;
}
Lt(Dr, "makeTriggerId");
function Nr(e, t) {
  return `${e}-content-${t}`;
}
Lt(Nr, "makeContentId");
var Jh = jh, eg = Yh, tg = qh, ng = Qh, og = Object.defineProperty, de = (e, t) => og(e, "name", { value: t, configurable: !0 }), [Lr, xv] = /* @__PURE__ */ we("Tooltip", [
  Nt
]), Yn = Nt(), rg = "TooltipProvider", ag = 700, zo = "tooltip.open", [ig, $r] = Lr(rg), sg = /* @__PURE__ */ de((e) => {
  const {
    __scopeTooltip: t,
    delayDuration: n = ag,
    skipDelayDuration: o = 300,
    disableHoverableContent: r = !1,
    children: a
  } = e, i = s.useRef(!0), c = s.useRef(!1), l = s.useRef(0);
  return s.useEffect(() => {
    const u = l.current;
    return () => window.clearTimeout(u);
  }, []), /* @__PURE__ */ d(
    ig,
    {
      scope: t,
      isOpenDelayedRef: i,
      delayDuration: n,
      onOpen: s.useCallback(() => {
        o <= 0 || (window.clearTimeout(l.current), i.current = !1);
      }, [o]),
      onClose: s.useCallback(() => {
        o <= 0 || (window.clearTimeout(l.current), l.current = window.setTimeout(
          () => i.current = !0,
          o
        ));
      }, [o]),
      isPointerInTransitRef: c,
      onPointerInTransitChange: s.useCallback((u) => {
        c.current = u;
      }, []),
      disableHoverableContent: r,
      children: a
    }
  );
}, "TooltipProvider"), Bo = "Tooltip", [cg, tn] = Lr(Bo), lg = /* @__PURE__ */ de((e) => {
  const {
    __scopeTooltip: t,
    children: n,
    open: o,
    defaultOpen: r,
    onOpenChange: a,
    disableHoverableContent: i,
    delayDuration: c
  } = e, l = $r(Bo, e.__scopeTooltip), u = Yn(t), [m, f] = s.useState(null), [p, h] = s.useState(void 0), g = ve(), b = s.useRef(0), v = i ?? l.disableHoverableContent, y = c ?? l.delayDuration, x = s.useRef(!1), [w, C] = Re({
    prop: o,
    defaultProp: r ?? !1,
    onChange: /* @__PURE__ */ de((k) => {
      k ? (l.onOpen(), document.dispatchEvent(new CustomEvent(zo))) : l.onClose(), a?.(k);
    }, "onChange"),
    caller: Bo
  }), P = s.useMemo(() => w ? x.current ? "delayed-open" : "instant-open" : "closed", [w]), S = s.useCallback(() => {
    window.clearTimeout(b.current), b.current = 0, x.current = !1, C(!0);
  }, [C]), _ = s.useCallback(() => {
    window.clearTimeout(b.current), b.current = 0, C(!1);
  }, [C]), R = s.useCallback(() => {
    window.clearTimeout(b.current), b.current = window.setTimeout(() => {
      x.current = !0, C(!0), b.current = 0;
    }, y);
  }, [y, C]);
  return s.useEffect(() => () => {
    b.current && (window.clearTimeout(b.current), b.current = 0);
  }, []), /* @__PURE__ */ d(Bn, { ...u, children: /* @__PURE__ */ d(
    cg,
    {
      scope: t,
      contentId: p ?? g,
      setContentId: h,
      open: w,
      stateAttribute: P,
      trigger: m,
      onTriggerChange: f,
      onTriggerEnter: s.useCallback(() => {
        l.isOpenDelayedRef.current ? R() : S();
      }, [l.isOpenDelayedRef, R, S]),
      onTriggerLeave: s.useCallback(() => {
        v ? _() : (window.clearTimeout(b.current), b.current = 0);
      }, [_, v]),
      onOpen: S,
      onClose: _,
      disableHoverableContent: v,
      children: n
    }
  ) });
}, "Tooltip"), xa = "TooltipTrigger", ug = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ de(function(t, n) {
    const { __scopeTooltip: o, ...r } = t, a = tn(xa, o), i = $r(xa, o), c = Yn(o), l = s.useRef(null), u = H(n, l, a.onTriggerChange), m = s.useRef(!1), f = s.useRef(!1), p = s.useCallback(() => m.current = !1, []);
    return s.useEffect(() => () => document.removeEventListener("pointerup", p), [p]), /* @__PURE__ */ d(fr, { asChild: !0, ...c, children: /* @__PURE__ */ d(
      $.button,
      {
        "aria-describedby": a.open ? a.contentId : void 0,
        "data-state": a.stateAttribute,
        ...r,
        ref: u,
        onPointerMove: A(t.onPointerMove, (h) => {
          h.pointerType !== "touch" && !f.current && !i.isPointerInTransitRef.current && (a.onTriggerEnter(), f.current = !0);
        }),
        onPointerLeave: A(t.onPointerLeave, () => {
          a.onTriggerLeave(), f.current = !1;
        }),
        onPointerDown: A(t.onPointerDown, () => {
          a.open && a.onClose(), m.current = !0, document.addEventListener("pointerup", p, { once: !0 });
        }),
        onFocus: A(t.onFocus, () => {
          m.current || a.onOpen();
        }),
        onBlur: A(t.onBlur, a.onClose),
        onClick: A(t.onClick, a.onClose)
      }
    ) });
  }, "TooltipTrigger")
), Xs = "TooltipPortal", [dg, fg] = Lr(Xs, {
  forceMount: void 0
}), pg = /* @__PURE__ */ de((e) => {
  const { __scopeTooltip: t, forceMount: n, children: o, container: r } = e, a = tn(Xs, t);
  return /* @__PURE__ */ d(dg, { scope: t, forceMount: n, children: /* @__PURE__ */ d(he, { present: n || a.open, children: /* @__PURE__ */ d(In, { asChild: !0, container: r, children: o }) }) });
}, "TooltipPortal"), Gt = "TooltipContent", mg = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ de(function(t, n) {
    const o = fg(Gt, t.__scopeTooltip), { forceMount: r = o.forceMount, side: a = "top", ...i } = t, c = tn(Gt, t.__scopeTooltip);
    return /* @__PURE__ */ d(he, { present: r || c.open, children: c.disableHoverableContent ? /* @__PURE__ */ d(qs, { side: a, ...i, ref: n }) : /* @__PURE__ */ d(hg, { side: a, ...i, ref: n }) });
  }, "TooltipContent")
), hg = /* @__PURE__ */ s.forwardRef(/* @__PURE__ */ de(function(t, n) {
  const o = tn(Gt, t.__scopeTooltip), r = $r(Gt, t.__scopeTooltip), a = s.useRef(null), i = H(n, a), [c, l] = s.useState(null), { trigger: u, onClose: m } = o, f = a.current, { onPointerInTransitChange: p } = r, h = s.useCallback(() => {
    l(null), p(!1);
  }, [p]), g = s.useCallback(
    (b, v) => {
      const y = b.currentTarget, x = { x: b.clientX, y: b.clientY }, w = Zs(x, y.getBoundingClientRect()), C = Qs(x, w), P = Js(v.getBoundingClientRect()), S = tc([...C, ...P]);
      l(S), p(!0);
    },
    [p]
  );
  return s.useEffect(() => () => h(), [h]), s.useEffect(() => {
    if (u && f) {
      const b = /* @__PURE__ */ de((y) => g(y, f), "handleTriggerLeave"), v = /* @__PURE__ */ de((y) => g(y, u), "handleContentLeave");
      return u.addEventListener("pointerleave", b), f.addEventListener("pointerleave", v), () => {
        u.removeEventListener("pointerleave", b), f.removeEventListener("pointerleave", v);
      };
    }
  }, [u, f, g, h]), s.useEffect(() => {
    if (c) {
      const b = /* @__PURE__ */ de((v) => {
        const y = v.target, x = { x: v.clientX, y: v.clientY }, w = u?.contains(y) || f?.contains(y), C = !ec(x, c);
        w ? h() : C && (h(), m());
      }, "handleTrackPointerGrace");
      return document.addEventListener("pointermove", b), () => document.removeEventListener("pointermove", b);
    }
  }, [u, f, c, m, h]), /* @__PURE__ */ d(qs, { ...t, ref: i });
}, "TooltipContentHoverable")), gg = /* @__PURE__ */ Da("TooltipContent"), qs = /* @__PURE__ */ s.forwardRef(
  // blank line to reduce diff noise
  /* @__PURE__ */ de(function(t, n) {
    const {
      __scopeTooltip: o,
      children: r,
      "aria-label": a,
      id: i,
      onEscapeKeyDown: c,
      onPointerDownOutside: l,
      ...u
    } = t, m = tn(Gt, o), f = Yn(o), { onClose: p } = m;
    s.useEffect(() => (document.addEventListener(zo, p), () => document.removeEventListener(zo, p)), [p]), s.useEffect(() => {
      if (m.trigger) {
        const g = /* @__PURE__ */ de((b) => {
          b.target instanceof Node && b.target.contains(m.trigger) && p();
        }, "handleScroll");
        return window.addEventListener("scroll", g, { capture: !0 }), () => window.removeEventListener("scroll", g, { capture: !0 });
      }
    }, [m.trigger, p]);
    const { setContentId: h } = m;
    return re(() => (h(i), () => {
      h(void 0);
    }), [i, h]), /* @__PURE__ */ d(
      Tn,
      {
        asChild: !0,
        disableOutsidePointerEvents: !1,
        onEscapeKeyDown: c,
        onPointerDownOutside: l,
        onFocusOutside: (g) => g.preventDefault(),
        onDismiss: p,
        children: /* @__PURE__ */ Q(
          pr,
          {
            "data-state": m.stateAttribute,
            role: a ? void 0 : "tooltip",
            id: a ? void 0 : m.contentId,
            ...f,
            ...u,
            ref: n,
            style: {
              ...u.style,
              "--radix-tooltip-content-transform-origin": "var(--radix-popper-transform-origin)",
              "--radix-tooltip-content-available-width": "var(--radix-popper-available-width)",
              "--radix-tooltip-content-available-height": "var(--radix-popper-available-height)",
              "--radix-tooltip-trigger-width": "var(--radix-popper-anchor-width)",
              "--radix-tooltip-trigger-height": "var(--radix-popper-anchor-height)"
            },
            children: [
              /* @__PURE__ */ d(gg, { children: r }),
              a ? /* @__PURE__ */ d(Wc, { id: m.contentId, role: "tooltip", children: a }) : null
            ]
          }
        )
      }
    );
  }, "TooltipContentImpl")
), bg = /* @__PURE__ */ s.forwardRef(
  /* @__PURE__ */ de(function(t, n) {
    const { __scopeTooltip: o, ...r } = t, a = Yn(o);
    return /* @__PURE__ */ d(Tf, { ...a, ...r, ref: n });
  }, "TooltipArrow")
);
function Zs(e, t) {
  const n = Math.abs(t.top - e.y), o = Math.abs(t.bottom - e.y), r = Math.abs(t.right - e.x), a = Math.abs(t.left - e.x);
  switch (Math.min(n, o, r, a)) {
    case a:
      return "left";
    case r:
      return "right";
    case n:
      return "top";
    case o:
      return "bottom";
    default:
      throw new Error("unreachable");
  }
}
de(Zs, "getExitSideFromRect");
function Qs(e, t, n = 5) {
  const o = [];
  switch (t) {
    case "top":
      o.push(
        { x: e.x - n, y: e.y + n },
        { x: e.x + n, y: e.y + n }
      );
      break;
    case "bottom":
      o.push(
        { x: e.x - n, y: e.y - n },
        { x: e.x + n, y: e.y - n }
      );
      break;
    case "left":
      o.push(
        { x: e.x + n, y: e.y - n },
        { x: e.x + n, y: e.y + n }
      );
      break;
    case "right":
      o.push(
        { x: e.x - n, y: e.y - n },
        { x: e.x - n, y: e.y + n }
      );
      break;
  }
  return o;
}
de(Qs, "getPaddedExitPoints");
function Js(e) {
  const { top: t, right: n, bottom: o, left: r } = e;
  return [
    { x: r, y: t },
    { x: n, y: t },
    { x: n, y: o },
    { x: r, y: o }
  ];
}
de(Js, "getPointsFromRect");
function ec(e, t) {
  const { x: n, y: o } = e;
  let r = !1;
  for (let a = 0, i = t.length - 1; a < t.length; i = a++) {
    const c = t[a], l = t[i], u = c.x, m = c.y, f = l.x, p = l.y;
    m > o != p > o && n < (f - u) * (o - m) / (p - m) + u && (r = !r);
  }
  return r;
}
de(ec, "isPointInPolygon");
function tc(e) {
  const t = e.slice();
  return t.sort((n, o) => n.x < o.x ? -1 : n.x > o.x ? 1 : n.y < o.y ? -1 : n.y > o.y ? 1 : 0), nc(t);
}
de(tc, "getHull");
function nc(e) {
  if (e.length <= 1) return e.slice();
  const t = [];
  for (let o = 0; o < e.length; o++) {
    const r = e[o];
    for (; t.length >= 2; ) {
      const a = t[t.length - 1], i = t[t.length - 2];
      if ((a.x - i.x) * (r.y - i.y) >= (a.y - i.y) * (r.x - i.x)) t.pop();
      else break;
    }
    t.push(r);
  }
  t.pop();
  const n = [];
  for (let o = e.length - 1; o >= 0; o--) {
    const r = e[o];
    for (; n.length >= 2; ) {
      const a = n[n.length - 1], i = n[n.length - 2];
      if ((a.x - i.x) * (r.y - i.y) >= (a.y - i.y) * (r.x - i.x)) n.pop();
      else break;
    }
    n.push(r);
  }
  return n.pop(), t.length === 1 && n.length === 1 && t[0].x === n[0].x && t[0].y === n[0].y ? t : t.concat(n);
}
de(nc, "getHullPresorted");
var vg = sg, wg = lg, xg = ug, yg = pg, Cg = mg, Sg = bg;
const oc = (...e) => e.filter((t, n, o) => !!t && t.trim() !== "" && o.indexOf(t) === n).join(" ").trim();
const Pg = (e) => e.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
const Rg = (e) => e.replace(
  /^([A-Z])|[\s-_]+(\w)/g,
  (t, n, o) => o ? o.toUpperCase() : n.toLowerCase()
);
const ya = (e) => {
  const t = Rg(e);
  return t.charAt(0).toUpperCase() + t.slice(1);
};
var mo = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round"
};
const Eg = (e) => {
  for (const t in e)
    if (t.startsWith("aria-") || t === "role" || t === "title")
      return !0;
  return !1;
}, _g = Ic({}), Tg = () => Tc(_g), Ig = ka(
  ({ color: e, size: t, strokeWidth: n, absoluteStrokeWidth: o, className: r = "", children: a, iconNode: i, ...c }, l) => {
    const {
      size: u = 24,
      strokeWidth: m = 2,
      absoluteStrokeWidth: f = !1,
      color: p = "currentColor",
      className: h = ""
    } = Tg() ?? {}, g = o ?? f ? Number(n ?? m) * 24 / Number(t ?? u) : n ?? m;
    return bo(
      "svg",
      {
        ref: l,
        ...mo,
        width: t ?? u ?? mo.width,
        height: t ?? u ?? mo.height,
        stroke: e ?? p,
        strokeWidth: g,
        className: oc("lucide", h, r),
        ...!a && !Eg(c) && { "aria-hidden": "true" },
        ...c
      },
      [
        ...i.map(([b, v]) => bo(b, v)),
        ...Array.isArray(a) ? a : [a]
      ]
    );
  }
);
const yt = (e, t) => {
  const n = ka(
    ({ className: o, ...r }, a) => bo(Ig, {
      ref: a,
      iconNode: t,
      className: oc(
        `lucide-${Pg(ya(e))}`,
        `lucide-${e}`,
        o
      ),
      ...r
    })
  );
  return n.displayName = ya(e), n;
};
const Ag = [["path", { d: "M20 6 9 17l-5-5", key: "1gmf2c" }]], Fr = yt("check", Ag);
const kg = [["path", { d: "m6 9 6 6 6-6", key: "qrunsl" }]], zr = yt("chevron-down", kg);
const Mg = [["path", { d: "m9 18 6-6-6-6", key: "mthhwq" }]], Og = yt("chevron-right", Mg);
const Dg = [["path", { d: "m18 15-6-6-6 6", key: "153udz" }]], Ng = yt("chevron-up", Dg);
const Lg = [["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }]], $g = yt("circle", Lg);
const Fg = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M9 3v18", key: "fh3hqa" }]
], zg = yt("panel-left", Fg);
const Bg = [
  ["path", { d: "M18 6 6 18", key: "1bl5f8" }],
  ["path", { d: "m6 6 12 12", key: "d8bk6v" }]
], rc = yt("x", Bg);
function ac(e) {
  var t, n, o = "";
  if (typeof e == "string" || typeof e == "number") o += e;
  else if (typeof e == "object") if (Array.isArray(e)) {
    var r = e.length;
    for (t = 0; t < r; t++) e[t] && (n = ac(e[t])) && (o && (o += " "), o += n);
  } else for (n in e) e[n] && (o && (o += " "), o += n);
  return o;
}
function ic() {
  for (var e, t, n = 0, o = "", r = arguments.length; n < r; n++) (e = arguments[n]) && (t = ac(e)) && (o && (o += " "), o += t);
  return o;
}
const Vg = (e, t) => {
  const n = new Array(e.length + t.length);
  for (let o = 0; o < e.length; o++)
    n[o] = e[o];
  for (let o = 0; o < t.length; o++)
    n[e.length + o] = t[o];
  return n;
}, Wg = (e, t) => ({
  classGroupId: e,
  validator: t
}), sc = (e = /* @__PURE__ */ new Map(), t = null, n) => ({
  nextPart: e,
  validators: t,
  classGroupId: n
}), Pn = "-", Ca = [], Hg = "arbitrary..", Gg = (e) => {
  const t = jg(e), {
    conflictingClassGroups: n,
    conflictingClassGroupModifiers: o
  } = e;
  return {
    getClassGroupId: (i) => {
      if (i.startsWith("[") && i.endsWith("]"))
        return Ug(i);
      const c = i.split(Pn), l = c[0] === "" && c.length > 1 ? 1 : 0;
      return cc(c, l, t);
    },
    getConflictingClassGroupIds: (i, c) => {
      if (c) {
        const l = o[i], u = n[i];
        return l ? u ? Vg(u, l) : l : u || Ca;
      }
      return n[i] || Ca;
    }
  };
}, cc = (e, t, n) => {
  if (e.length - t === 0)
    return n.classGroupId;
  const r = e[t], a = n.nextPart.get(r);
  if (a) {
    const u = cc(e, t + 1, a);
    if (u) return u;
  }
  const i = n.validators;
  if (i === null)
    return;
  const c = t === 0 ? e.join(Pn) : e.slice(t).join(Pn), l = i.length;
  for (let u = 0; u < l; u++) {
    const m = i[u];
    if (m.validator(c))
      return m.classGroupId;
  }
}, Ug = (e) => e.slice(1, -1).indexOf(":") === -1 ? void 0 : (() => {
  const t = e.slice(1, -1), n = t.indexOf(":"), o = t.slice(0, n);
  return o ? Hg + o : void 0;
})(), jg = (e) => {
  const {
    theme: t,
    classGroups: n
  } = e;
  return Kg(n, t);
}, Kg = (e, t) => {
  const n = sc();
  for (const o in e) {
    const r = e[o];
    Br(r, n, o, t);
  }
  return n;
}, Br = (e, t, n, o) => {
  const r = e.length;
  for (let a = 0; a < r; a++) {
    const i = e[a];
    Yg(i, t, n, o);
  }
}, Yg = (e, t, n, o) => {
  if (typeof e == "string") {
    Xg(e, t, n);
    return;
  }
  if (typeof e == "function") {
    qg(e, t, n, o);
    return;
  }
  Zg(e, t, n, o);
}, Xg = (e, t, n) => {
  const o = e === "" ? t : lc(t, e);
  o.classGroupId = n;
}, qg = (e, t, n, o) => {
  if (Qg(e)) {
    Br(e(o), t, n, o);
    return;
  }
  t.validators === null && (t.validators = []), t.validators.push(Wg(n, e));
}, Zg = (e, t, n, o) => {
  const r = Object.entries(e), a = r.length;
  for (let i = 0; i < a; i++) {
    const [c, l] = r[i];
    Br(l, lc(t, c), n, o);
  }
}, lc = (e, t) => {
  let n = e;
  const o = t.split(Pn), r = o.length;
  for (let a = 0; a < r; a++) {
    const i = o[a];
    let c = n.nextPart.get(i);
    c || (c = sc(), n.nextPart.set(i, c)), n = c;
  }
  return n;
}, Qg = (e) => "isThemeGetter" in e && e.isThemeGetter === !0, Jg = (e) => {
  if (e < 1)
    return {
      get: () => {
      },
      set: () => {
      }
    };
  let t = 0, n = /* @__PURE__ */ Object.create(null), o = /* @__PURE__ */ Object.create(null);
  const r = (a, i) => {
    n[a] = i, t++, t > e && (t = 0, o = n, n = /* @__PURE__ */ Object.create(null));
  };
  return {
    get(a) {
      let i = n[a];
      if (i !== void 0)
        return i;
      if ((i = o[a]) !== void 0)
        return r(a, i), i;
    },
    set(a, i) {
      a in n ? n[a] = i : r(a, i);
    }
  };
}, Vo = "!", Sa = ":", eb = [], Pa = (e, t, n, o, r) => ({
  modifiers: e,
  hasImportantModifier: t,
  baseClassName: n,
  maybePostfixModifierPosition: o,
  isExternal: r
}), tb = (e) => {
  const {
    prefix: t,
    experimentalParseClassName: n
  } = e;
  let o = (r) => {
    const a = [];
    let i = 0, c = 0, l = 0, u;
    const m = r.length;
    for (let b = 0; b < m; b++) {
      const v = r[b];
      if (i === 0 && c === 0) {
        if (v === Sa) {
          a.push(r.slice(l, b)), l = b + 1;
          continue;
        }
        if (v === "/") {
          u = b;
          continue;
        }
      }
      v === "[" ? i++ : v === "]" ? i-- : v === "(" ? c++ : v === ")" && c--;
    }
    const f = a.length === 0 ? r : r.slice(l);
    let p = f, h = !1;
    f.endsWith(Vo) ? (p = f.slice(0, -1), h = !0) : (
      /**
       * In Tailwind CSS v3 the important modifier was at the start of the base class name. This is still supported for legacy reasons.
       * @see https://github.com/dcastil/tailwind-merge/issues/513#issuecomment-2614029864
       */
      f.startsWith(Vo) && (p = f.slice(1), h = !0)
    );
    const g = u && u > l ? u - l : void 0;
    return Pa(a, h, p, g);
  };
  if (t) {
    const r = t + Sa, a = o;
    o = (i) => i.startsWith(r) ? a(i.slice(r.length)) : Pa(eb, !1, i, void 0, !0);
  }
  if (n) {
    const r = o;
    o = (a) => n({
      className: a,
      parseClassName: r
    });
  }
  return o;
}, nb = (e) => {
  const t = /* @__PURE__ */ new Map();
  return e.orderSensitiveModifiers.forEach((n, o) => {
    t.set(n, 1e6 + o);
  }), (n) => {
    const o = [];
    let r = [];
    for (let a = 0; a < n.length; a++) {
      const i = n[a], c = i[0] === "[", l = t.has(i);
      c || l ? (r.length > 0 && (r.sort(), o.push(...r), r = []), o.push(i)) : r.push(i);
    }
    return r.length > 0 && (r.sort(), o.push(...r)), o;
  };
}, ob = (e) => ({
  cache: Jg(e.cacheSize),
  parseClassName: tb(e),
  sortModifiers: nb(e),
  postfixLookupClassGroupIds: rb(e),
  ...Gg(e)
}), rb = (e) => {
  const t = /* @__PURE__ */ Object.create(null), n = e.postfixLookupClassGroups;
  if (n)
    for (let o = 0; o < n.length; o++)
      t[n[o]] = !0;
  return t;
}, ab = /\s+/, ib = (e, t) => {
  const {
    parseClassName: n,
    getClassGroupId: o,
    getConflictingClassGroupIds: r,
    sortModifiers: a,
    postfixLookupClassGroupIds: i
  } = t, c = [], l = e.trim().split(ab);
  let u = "";
  for (let m = l.length - 1; m >= 0; m -= 1) {
    const f = l[m], {
      isExternal: p,
      modifiers: h,
      hasImportantModifier: g,
      baseClassName: b,
      maybePostfixModifierPosition: v
    } = n(f);
    if (p) {
      u = f + (u.length > 0 ? " " + u : u);
      continue;
    }
    let y = !!v, x;
    if (y) {
      const _ = b.substring(0, v);
      x = o(_);
      const R = x && i[x] ? o(b) : void 0;
      R && R !== x && (x = R, y = !1);
    } else
      x = o(b);
    if (!x) {
      if (!y) {
        u = f + (u.length > 0 ? " " + u : u);
        continue;
      }
      if (x = o(b), !x) {
        u = f + (u.length > 0 ? " " + u : u);
        continue;
      }
      y = !1;
    }
    const w = h.length === 0 ? "" : h.length === 1 ? h[0] : a(h).join(":"), C = g ? w + Vo : w, P = C + x;
    if (c.indexOf(P) > -1)
      continue;
    c.push(P);
    const S = r(x, y);
    for (let _ = 0; _ < S.length; ++_) {
      const R = S[_];
      c.push(C + R);
    }
    u = f + (u.length > 0 ? " " + u : u);
  }
  return u;
}, sb = (...e) => {
  let t = 0, n, o, r = "";
  for (; t < e.length; )
    (n = e[t++]) && (o = uc(n)) && (r && (r += " "), r += o);
  return r;
}, uc = (e) => {
  if (typeof e == "string")
    return e;
  let t, n = "";
  for (let o = 0; o < e.length; o++)
    e[o] && (t = uc(e[o])) && (n && (n += " "), n += t);
  return n;
}, cb = (e, ...t) => {
  let n, o, r, a;
  const i = (l) => {
    const u = t.reduce((m, f) => f(m), e());
    return n = ob(u), o = n.cache.get, r = n.cache.set, a = c, c(l);
  }, c = (l) => {
    const u = o(l);
    if (u)
      return u;
    const m = ib(l, n);
    return r(l, m), m;
  };
  return a = i, (...l) => a(sb(...l));
}, lb = [], ue = (e) => {
  const t = (n) => n[e] || lb;
  return t.isThemeGetter = !0, t;
}, dc = /^\[(?:(\w[\w-]*):)?(.+)\]$/i, fc = /^\((?:(\w[\w-]*):)?(.+)\)$/i, ub = /^\d+(?:\.\d+)?\/\d+(?:\.\d+)?$/, db = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/, fb = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/, pb = /^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/, mb = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/, hb = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/, et = (e) => ub.test(e), K = (e) => !!e && !Number.isNaN(Number(e)), Le = (e) => !!e && Number.isInteger(Number(e)), ho = (e) => e.endsWith("%") && K(e.slice(0, -1)), He = (e) => db.test(e), pc = () => !0, gb = (e) => (
  // `colorFunctionRegex` check is necessary because color functions can have percentages in them which which would be incorrectly classified as lengths.
  // For example, `hsl(0 0% 0%)` would be classified as a length without this check.
  // I could also use lookbehind assertion in `lengthUnitRegex` but that isn't supported widely enough.
  fb.test(e) && !pb.test(e)
), Vr = () => !1, bb = (e) => mb.test(e), vb = (e) => hb.test(e), wb = (e) => !O(e) && !D(e), xb = (e) => e.startsWith("@container") && (e[10] === "/" && e[11] !== void 0 || e[11] === "s" && e[16] !== void 0 && e.startsWith("-size/", 10) || e[11] === "n" && e[18] !== void 0 && e.startsWith("-normal/", 10)), yb = (e) => st(e, gc, Vr), O = (e) => dc.test(e), lt = (e) => st(e, bc, gb), Ra = (e) => st(e, Ib, K), Cb = (e) => st(e, wc, pc), Sb = (e) => st(e, vc, Vr), Ea = (e) => st(e, mc, Vr), Pb = (e) => st(e, hc, vb), pn = (e) => st(e, xc, bb), D = (e) => fc.test(e), $t = (e) => Ct(e, bc), Rb = (e) => Ct(e, vc), _a = (e) => Ct(e, mc), Eb = (e) => Ct(e, gc), _b = (e) => Ct(e, hc), mn = (e) => Ct(e, xc, !0), Tb = (e) => Ct(e, wc, !0), st = (e, t, n) => {
  const o = dc.exec(e);
  return o ? o[1] ? t(o[1]) : n(o[2]) : !1;
}, Ct = (e, t, n = !1) => {
  const o = fc.exec(e);
  return o ? o[1] ? t(o[1]) : n : !1;
}, mc = (e) => e === "position" || e === "percentage", hc = (e) => e === "image" || e === "url", gc = (e) => e === "length" || e === "size" || e === "bg-size", bc = (e) => e === "length", Ib = (e) => e === "number", vc = (e) => e === "family-name", wc = (e) => e === "number" || e === "weight", xc = (e) => e === "shadow", Ab = () => {
  const e = ue("color"), t = ue("font"), n = ue("text"), o = ue("font-weight"), r = ue("tracking"), a = ue("leading"), i = ue("breakpoint"), c = ue("container"), l = ue("spacing"), u = ue("radius"), m = ue("shadow"), f = ue("inset-shadow"), p = ue("text-shadow"), h = ue("drop-shadow"), g = ue("blur"), b = ue("perspective"), v = ue("aspect"), y = ue("ease"), x = ue("animate"), w = () => ["auto", "avoid", "all", "avoid-page", "page", "left", "right", "column"], C = () => [
    "center",
    "top",
    "bottom",
    "left",
    "right",
    "top-left",
    // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
    "left-top",
    "top-right",
    // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
    "right-top",
    "bottom-right",
    // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
    "right-bottom",
    "bottom-left",
    // Deprecated since Tailwind CSS v4.1.0, see https://github.com/tailwindlabs/tailwindcss/pull/17378
    "left-bottom"
  ], P = () => [...C(), D, O], S = () => ["auto", "hidden", "clip", "visible", "scroll"], _ = () => ["auto", "contain", "none"], R = () => [D, O, l], I = () => [et, "full", "auto", ...R()], k = () => [Le, "none", "subgrid", D, O], N = () => ["auto", {
    span: ["full", Le, D, O]
  }, Le, D, O], M = () => [Le, "auto", D, O], F = () => ["auto", "min", "max", "fr", D, O], V = () => ["start", "end", "center", "between", "around", "evenly", "stretch", "baseline", "center-safe", "end-safe"], j = () => ["start", "end", "center", "stretch", "center-safe", "end-safe"], B = () => ["auto", ...R()], z = () => [et, "auto", "full", "dvw", "dvh", "lvw", "lvh", "svw", "svh", "min", "max", "fit", ...R()], W = () => [et, "screen", "full", "dvw", "lvw", "svw", "min", "max", "fit", ...R()], U = () => [et, "screen", "full", "lh", "dvh", "lvh", "svh", "min", "max", "fit", ...R()], E = () => [e, D, O], ce = () => [...C(), _a, Ea, {
    position: [D, O]
  }], ee = () => ["no-repeat", {
    repeat: ["", "x", "y", "space", "round"]
  }], ae = () => ["auto", "cover", "contain", Eb, yb, {
    size: [D, O]
  }], ge = () => [ho, $t, lt], te = () => [
    // Deprecated since Tailwind CSS v4.0.0
    "",
    "none",
    "full",
    u,
    D,
    O
  ], ne = () => ["", K, $t, lt], fe = () => ["solid", "dashed", "dotted", "double"], L = () => ["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "hue", "saturation", "color", "luminosity"], G = () => [K, ho, _a, Ea], le = () => [
    // Deprecated since Tailwind CSS v4.0.0
    "",
    "none",
    g,
    D,
    O
  ], Z = () => ["none", K, D, O], J = () => ["none", K, D, O], oe = () => [K, D, O], Se = () => [et, "full", ...R()];
  return {
    cacheSize: 500,
    theme: {
      animate: ["spin", "ping", "pulse", "bounce"],
      aspect: ["video"],
      blur: [He],
      breakpoint: [He],
      color: [pc],
      container: [He],
      "drop-shadow": [He],
      ease: ["in", "out", "in-out"],
      font: [wb],
      "font-weight": ["thin", "extralight", "light", "normal", "medium", "semibold", "bold", "extrabold", "black"],
      "inset-shadow": [He],
      leading: ["none", "tight", "snug", "normal", "relaxed", "loose"],
      perspective: ["dramatic", "near", "normal", "midrange", "distant", "none"],
      radius: [He],
      shadow: [He],
      spacing: ["px", K],
      text: [He],
      "text-shadow": [He],
      tracking: ["tighter", "tight", "normal", "wide", "wider", "widest"]
    },
    classGroups: {
      // --------------
      // --- Layout ---
      // --------------
      /**
       * Aspect Ratio
       * @see https://tailwindcss.com/docs/aspect-ratio
       */
      aspect: [{
        aspect: ["auto", "square", et, O, D, v]
      }],
      /**
       * Container
       * @see https://tailwindcss.com/docs/container
       * @deprecated since Tailwind CSS v4.0.0
       */
      container: ["container"],
      /**
       * Container Type
       * @see https://tailwindcss.com/docs/responsive-design#container-queries
       */
      "container-type": [{
        "@container": ["", "normal", "size", D, O]
      }],
      /**
       * Container Name
       * @see https://tailwindcss.com/docs/responsive-design#named-containers
       */
      "container-named": [xb],
      /**
       * Columns
       * @see https://tailwindcss.com/docs/columns
       */
      columns: [{
        columns: [K, O, D, c]
      }],
      /**
       * Break After
       * @see https://tailwindcss.com/docs/break-after
       */
      "break-after": [{
        "break-after": w()
      }],
      /**
       * Break Before
       * @see https://tailwindcss.com/docs/break-before
       */
      "break-before": [{
        "break-before": w()
      }],
      /**
       * Break Inside
       * @see https://tailwindcss.com/docs/break-inside
       */
      "break-inside": [{
        "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"]
      }],
      /**
       * Box Decoration Break
       * @see https://tailwindcss.com/docs/box-decoration-break
       */
      "box-decoration": [{
        "box-decoration": ["slice", "clone"]
      }],
      /**
       * Box Sizing
       * @see https://tailwindcss.com/docs/box-sizing
       */
      box: [{
        box: ["border", "content"]
      }],
      /**
       * Display
       * @see https://tailwindcss.com/docs/display
       */
      display: ["block", "inline-block", "inline", "flex", "inline-flex", "table", "inline-table", "table-caption", "table-cell", "table-column", "table-column-group", "table-footer-group", "table-header-group", "table-row-group", "table-row", "flow-root", "grid", "inline-grid", "contents", "list-item", "hidden"],
      /**
       * Screen Reader Only
       * @see https://tailwindcss.com/docs/display#screen-reader-only
       */
      sr: ["sr-only", "not-sr-only"],
      /**
       * Floats
       * @see https://tailwindcss.com/docs/float
       */
      float: [{
        float: ["right", "left", "none", "start", "end"]
      }],
      /**
       * Clear
       * @see https://tailwindcss.com/docs/clear
       */
      clear: [{
        clear: ["left", "right", "both", "none", "start", "end"]
      }],
      /**
       * Isolation
       * @see https://tailwindcss.com/docs/isolation
       */
      isolation: ["isolate", "isolation-auto"],
      /**
       * Object Fit
       * @see https://tailwindcss.com/docs/object-fit
       */
      "object-fit": [{
        object: ["contain", "cover", "fill", "none", "scale-down"]
      }],
      /**
       * Object Position
       * @see https://tailwindcss.com/docs/object-position
       */
      "object-position": [{
        object: P()
      }],
      /**
       * Overflow
       * @see https://tailwindcss.com/docs/overflow
       */
      overflow: [{
        overflow: S()
      }],
      /**
       * Overflow X
       * @see https://tailwindcss.com/docs/overflow
       */
      "overflow-x": [{
        "overflow-x": S()
      }],
      /**
       * Overflow Y
       * @see https://tailwindcss.com/docs/overflow
       */
      "overflow-y": [{
        "overflow-y": S()
      }],
      /**
       * Overscroll Behavior
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      overscroll: [{
        overscroll: _()
      }],
      /**
       * Overscroll Behavior X
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      "overscroll-x": [{
        "overscroll-x": _()
      }],
      /**
       * Overscroll Behavior Y
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      "overscroll-y": [{
        "overscroll-y": _()
      }],
      /**
       * Position
       * @see https://tailwindcss.com/docs/position
       */
      position: ["static", "fixed", "absolute", "relative", "sticky"],
      /**
       * Inset
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      inset: [{
        inset: I()
      }],
      /**
       * Inset Inline
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      "inset-x": [{
        "inset-x": I()
      }],
      /**
       * Inset Block
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      "inset-y": [{
        "inset-y": I()
      }],
      /**
       * Inset Inline Start
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       * @todo class group will be renamed to `inset-s` in next major release
       */
      start: [{
        "inset-s": I(),
        /**
         * @deprecated since Tailwind CSS v4.2.0 in favor of `inset-s-*` utilities.
         * @see https://github.com/tailwindlabs/tailwindcss/pull/19613
         */
        start: I()
      }],
      /**
       * Inset Inline End
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       * @todo class group will be renamed to `inset-e` in next major release
       */
      end: [{
        "inset-e": I(),
        /**
         * @deprecated since Tailwind CSS v4.2.0 in favor of `inset-e-*` utilities.
         * @see https://github.com/tailwindlabs/tailwindcss/pull/19613
         */
        end: I()
      }],
      /**
       * Inset Block Start
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      "inset-bs": [{
        "inset-bs": I()
      }],
      /**
       * Inset Block End
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      "inset-be": [{
        "inset-be": I()
      }],
      /**
       * Top
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      top: [{
        top: I()
      }],
      /**
       * Right
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      right: [{
        right: I()
      }],
      /**
       * Bottom
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      bottom: [{
        bottom: I()
      }],
      /**
       * Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      left: [{
        left: I()
      }],
      /**
       * Visibility
       * @see https://tailwindcss.com/docs/visibility
       */
      visibility: ["visible", "invisible", "collapse"],
      /**
       * Z-Index
       * @see https://tailwindcss.com/docs/z-index
       */
      z: [{
        z: [Le, "auto", D, O]
      }],
      // ------------------------
      // --- Flexbox and Grid ---
      // ------------------------
      /**
       * Flex Basis
       * @see https://tailwindcss.com/docs/flex-basis
       */
      basis: [{
        basis: [et, "full", "auto", c, ...R()]
      }],
      /**
       * Flex Direction
       * @see https://tailwindcss.com/docs/flex-direction
       */
      "flex-direction": [{
        flex: ["row", "row-reverse", "col", "col-reverse"]
      }],
      /**
       * Flex Wrap
       * @see https://tailwindcss.com/docs/flex-wrap
       */
      "flex-wrap": [{
        flex: ["nowrap", "wrap", "wrap-reverse"]
      }],
      /**
       * Flex
       * @see https://tailwindcss.com/docs/flex
       */
      flex: [{
        flex: [K, et, "auto", "initial", "none", O]
      }],
      /**
       * Flex Grow
       * @see https://tailwindcss.com/docs/flex-grow
       */
      grow: [{
        grow: ["", K, D, O]
      }],
      /**
       * Flex Shrink
       * @see https://tailwindcss.com/docs/flex-shrink
       */
      shrink: [{
        shrink: ["", K, D, O]
      }],
      /**
       * Order
       * @see https://tailwindcss.com/docs/order
       */
      order: [{
        order: [Le, "first", "last", "none", D, O]
      }],
      /**
       * Grid Template Columns
       * @see https://tailwindcss.com/docs/grid-template-columns
       */
      "grid-cols": [{
        "grid-cols": k()
      }],
      /**
       * Grid Column Start / End
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-start-end": [{
        col: N()
      }],
      /**
       * Grid Column Start
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-start": [{
        "col-start": M()
      }],
      /**
       * Grid Column End
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-end": [{
        "col-end": M()
      }],
      /**
       * Grid Template Rows
       * @see https://tailwindcss.com/docs/grid-template-rows
       */
      "grid-rows": [{
        "grid-rows": k()
      }],
      /**
       * Grid Row Start / End
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-start-end": [{
        row: N()
      }],
      /**
       * Grid Row Start
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-start": [{
        "row-start": M()
      }],
      /**
       * Grid Row End
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-end": [{
        "row-end": M()
      }],
      /**
       * Grid Auto Flow
       * @see https://tailwindcss.com/docs/grid-auto-flow
       */
      "grid-flow": [{
        "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"]
      }],
      /**
       * Grid Auto Columns
       * @see https://tailwindcss.com/docs/grid-auto-columns
       */
      "auto-cols": [{
        "auto-cols": F()
      }],
      /**
       * Grid Auto Rows
       * @see https://tailwindcss.com/docs/grid-auto-rows
       */
      "auto-rows": [{
        "auto-rows": F()
      }],
      /**
       * Gap
       * @see https://tailwindcss.com/docs/gap
       */
      gap: [{
        gap: R()
      }],
      /**
       * Gap X
       * @see https://tailwindcss.com/docs/gap
       */
      "gap-x": [{
        "gap-x": R()
      }],
      /**
       * Gap Y
       * @see https://tailwindcss.com/docs/gap
       */
      "gap-y": [{
        "gap-y": R()
      }],
      /**
       * Justify Content
       * @see https://tailwindcss.com/docs/justify-content
       */
      "justify-content": [{
        justify: [...V(), "normal"]
      }],
      /**
       * Justify Items
       * @see https://tailwindcss.com/docs/justify-items
       */
      "justify-items": [{
        "justify-items": [...j(), "normal"]
      }],
      /**
       * Justify Self
       * @see https://tailwindcss.com/docs/justify-self
       */
      "justify-self": [{
        "justify-self": ["auto", ...j()]
      }],
      /**
       * Align Content
       * @see https://tailwindcss.com/docs/align-content
       */
      "align-content": [{
        content: ["normal", ...V()]
      }],
      /**
       * Align Items
       * @see https://tailwindcss.com/docs/align-items
       */
      "align-items": [{
        items: [...j(), {
          baseline: ["", "last"]
        }]
      }],
      /**
       * Align Self
       * @see https://tailwindcss.com/docs/align-self
       */
      "align-self": [{
        self: ["auto", ...j(), {
          baseline: ["", "last"]
        }]
      }],
      /**
       * Place Content
       * @see https://tailwindcss.com/docs/place-content
       */
      "place-content": [{
        "place-content": V()
      }],
      /**
       * Place Items
       * @see https://tailwindcss.com/docs/place-items
       */
      "place-items": [{
        "place-items": [...j(), "baseline"]
      }],
      /**
       * Place Self
       * @see https://tailwindcss.com/docs/place-self
       */
      "place-self": [{
        "place-self": ["auto", ...j()]
      }],
      // Spacing
      /**
       * Padding
       * @see https://tailwindcss.com/docs/padding
       */
      p: [{
        p: R()
      }],
      /**
       * Padding Inline
       * @see https://tailwindcss.com/docs/padding
       */
      px: [{
        px: R()
      }],
      /**
       * Padding Block
       * @see https://tailwindcss.com/docs/padding
       */
      py: [{
        py: R()
      }],
      /**
       * Padding Inline Start
       * @see https://tailwindcss.com/docs/padding
       */
      ps: [{
        ps: R()
      }],
      /**
       * Padding Inline End
       * @see https://tailwindcss.com/docs/padding
       */
      pe: [{
        pe: R()
      }],
      /**
       * Padding Block Start
       * @see https://tailwindcss.com/docs/padding
       */
      pbs: [{
        pbs: R()
      }],
      /**
       * Padding Block End
       * @see https://tailwindcss.com/docs/padding
       */
      pbe: [{
        pbe: R()
      }],
      /**
       * Padding Top
       * @see https://tailwindcss.com/docs/padding
       */
      pt: [{
        pt: R()
      }],
      /**
       * Padding Right
       * @see https://tailwindcss.com/docs/padding
       */
      pr: [{
        pr: R()
      }],
      /**
       * Padding Bottom
       * @see https://tailwindcss.com/docs/padding
       */
      pb: [{
        pb: R()
      }],
      /**
       * Padding Left
       * @see https://tailwindcss.com/docs/padding
       */
      pl: [{
        pl: R()
      }],
      /**
       * Margin
       * @see https://tailwindcss.com/docs/margin
       */
      m: [{
        m: B()
      }],
      /**
       * Margin Inline
       * @see https://tailwindcss.com/docs/margin
       */
      mx: [{
        mx: B()
      }],
      /**
       * Margin Block
       * @see https://tailwindcss.com/docs/margin
       */
      my: [{
        my: B()
      }],
      /**
       * Margin Inline Start
       * @see https://tailwindcss.com/docs/margin
       */
      ms: [{
        ms: B()
      }],
      /**
       * Margin Inline End
       * @see https://tailwindcss.com/docs/margin
       */
      me: [{
        me: B()
      }],
      /**
       * Margin Block Start
       * @see https://tailwindcss.com/docs/margin
       */
      mbs: [{
        mbs: B()
      }],
      /**
       * Margin Block End
       * @see https://tailwindcss.com/docs/margin
       */
      mbe: [{
        mbe: B()
      }],
      /**
       * Margin Top
       * @see https://tailwindcss.com/docs/margin
       */
      mt: [{
        mt: B()
      }],
      /**
       * Margin Right
       * @see https://tailwindcss.com/docs/margin
       */
      mr: [{
        mr: B()
      }],
      /**
       * Margin Bottom
       * @see https://tailwindcss.com/docs/margin
       */
      mb: [{
        mb: B()
      }],
      /**
       * Margin Left
       * @see https://tailwindcss.com/docs/margin
       */
      ml: [{
        ml: B()
      }],
      /**
       * Space Between X
       * @see https://tailwindcss.com/docs/margin#adding-space-between-children
       */
      "space-x": [{
        "space-x": R()
      }],
      /**
       * Space Between X Reverse
       * @see https://tailwindcss.com/docs/margin#adding-space-between-children
       */
      "space-x-reverse": ["space-x-reverse"],
      /**
       * Space Between Y
       * @see https://tailwindcss.com/docs/margin#adding-space-between-children
       */
      "space-y": [{
        "space-y": R()
      }],
      /**
       * Space Between Y Reverse
       * @see https://tailwindcss.com/docs/margin#adding-space-between-children
       */
      "space-y-reverse": ["space-y-reverse"],
      // --------------
      // --- Sizing ---
      // --------------
      /**
       * Size
       * @see https://tailwindcss.com/docs/width#setting-both-width-and-height
       */
      size: [{
        size: z()
      }],
      /**
       * Inline Size
       * @see https://tailwindcss.com/docs/width
       */
      "inline-size": [{
        inline: ["auto", ...W()]
      }],
      /**
       * Min-Inline Size
       * @see https://tailwindcss.com/docs/min-width
       */
      "min-inline-size": [{
        "min-inline": ["auto", ...W()]
      }],
      /**
       * Max-Inline Size
       * @see https://tailwindcss.com/docs/max-width
       */
      "max-inline-size": [{
        "max-inline": ["none", ...W()]
      }],
      /**
       * Block Size
       * @see https://tailwindcss.com/docs/height
       */
      "block-size": [{
        block: ["auto", ...U()]
      }],
      /**
       * Min-Block Size
       * @see https://tailwindcss.com/docs/min-height
       */
      "min-block-size": [{
        "min-block": ["auto", ...U()]
      }],
      /**
       * Max-Block Size
       * @see https://tailwindcss.com/docs/max-height
       */
      "max-block-size": [{
        "max-block": ["none", ...U()]
      }],
      /**
       * Width
       * @see https://tailwindcss.com/docs/width
       */
      w: [{
        w: [c, "screen", ...z()]
      }],
      /**
       * Min-Width
       * @see https://tailwindcss.com/docs/min-width
       */
      "min-w": [{
        "min-w": [
          c,
          "screen",
          /** Deprecated. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */
          "none",
          ...z()
        ]
      }],
      /**
       * Max-Width
       * @see https://tailwindcss.com/docs/max-width
       */
      "max-w": [{
        "max-w": [
          c,
          "screen",
          "none",
          /** Deprecated since Tailwind CSS v4.0.0. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */
          "prose",
          /** Deprecated since Tailwind CSS v4.0.0. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */
          {
            screen: [i]
          },
          ...z()
        ]
      }],
      /**
       * Height
       * @see https://tailwindcss.com/docs/height
       */
      h: [{
        h: ["screen", "lh", ...z()]
      }],
      /**
       * Min-Height
       * @see https://tailwindcss.com/docs/min-height
       */
      "min-h": [{
        "min-h": ["screen", "lh", "none", ...z()]
      }],
      /**
       * Max-Height
       * @see https://tailwindcss.com/docs/max-height
       */
      "max-h": [{
        "max-h": ["screen", "lh", ...z()]
      }],
      // ------------------
      // --- Typography ---
      // ------------------
      /**
       * Font Size
       * @see https://tailwindcss.com/docs/font-size
       */
      "font-size": [{
        text: ["base", n, $t, lt]
      }],
      /**
       * Font Smoothing
       * @see https://tailwindcss.com/docs/font-smoothing
       */
      "font-smoothing": ["antialiased", "subpixel-antialiased"],
      /**
       * Font Style
       * @see https://tailwindcss.com/docs/font-style
       */
      "font-style": ["italic", "not-italic"],
      /**
       * Font Weight
       * @see https://tailwindcss.com/docs/font-weight
       */
      "font-weight": [{
        font: [o, Tb, Cb]
      }],
      /**
       * Font Stretch
       * @see https://tailwindcss.com/docs/font-stretch
       */
      "font-stretch": [{
        "font-stretch": ["ultra-condensed", "extra-condensed", "condensed", "semi-condensed", "normal", "semi-expanded", "expanded", "extra-expanded", "ultra-expanded", ho, O]
      }],
      /**
       * Font Family
       * @see https://tailwindcss.com/docs/font-family
       */
      "font-family": [{
        font: [Rb, Sb, t]
      }],
      /**
       * Font Feature Settings
       * @see https://tailwindcss.com/docs/font-feature-settings
       */
      "font-features": [{
        "font-features": [O]
      }],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-normal": ["normal-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-ordinal": ["ordinal"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-slashed-zero": ["slashed-zero"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-figure": ["lining-nums", "oldstyle-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-spacing": ["proportional-nums", "tabular-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-fraction": ["diagonal-fractions", "stacked-fractions"],
      /**
       * Letter Spacing
       * @see https://tailwindcss.com/docs/letter-spacing
       */
      tracking: [{
        tracking: [r, D, O]
      }],
      /**
       * Line Clamp
       * @see https://tailwindcss.com/docs/line-clamp
       */
      "line-clamp": [{
        "line-clamp": [K, "none", D, Ra]
      }],
      /**
       * Line Height
       * @see https://tailwindcss.com/docs/line-height
       */
      leading: [{
        leading: [
          /** Deprecated since Tailwind CSS v4.0.0. @see https://github.com/tailwindlabs/tailwindcss.com/issues/2027#issuecomment-2620152757 */
          a,
          ...R()
        ]
      }],
      /**
       * List Style Image
       * @see https://tailwindcss.com/docs/list-style-image
       */
      "list-image": [{
        "list-image": ["none", D, O]
      }],
      /**
       * List Style Position
       * @see https://tailwindcss.com/docs/list-style-position
       */
      "list-style-position": [{
        list: ["inside", "outside"]
      }],
      /**
       * List Style Type
       * @see https://tailwindcss.com/docs/list-style-type
       */
      "list-style-type": [{
        list: ["disc", "decimal", "none", D, O]
      }],
      /**
       * Text Alignment
       * @see https://tailwindcss.com/docs/text-align
       */
      "text-alignment": [{
        text: ["left", "center", "right", "justify", "start", "end"]
      }],
      /**
       * Placeholder Color
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://v3.tailwindcss.com/docs/placeholder-color
       */
      "placeholder-color": [{
        placeholder: E()
      }],
      /**
       * Text Color
       * @see https://tailwindcss.com/docs/text-color
       */
      "text-color": [{
        text: E()
      }],
      /**
       * Text Decoration
       * @see https://tailwindcss.com/docs/text-decoration
       */
      "text-decoration": ["underline", "overline", "line-through", "no-underline"],
      /**
       * Text Decoration Style
       * @see https://tailwindcss.com/docs/text-decoration-style
       */
      "text-decoration-style": [{
        decoration: [...fe(), "wavy"]
      }],
      /**
       * Text Decoration Thickness
       * @see https://tailwindcss.com/docs/text-decoration-thickness
       */
      "text-decoration-thickness": [{
        decoration: [K, "from-font", "auto", D, lt]
      }],
      /**
       * Text Decoration Color
       * @see https://tailwindcss.com/docs/text-decoration-color
       */
      "text-decoration-color": [{
        decoration: E()
      }],
      /**
       * Text Underline Offset
       * @see https://tailwindcss.com/docs/text-underline-offset
       */
      "underline-offset": [{
        "underline-offset": [K, "auto", D, O]
      }],
      /**
       * Text Transform
       * @see https://tailwindcss.com/docs/text-transform
       */
      "text-transform": ["uppercase", "lowercase", "capitalize", "normal-case"],
      /**
       * Text Overflow
       * @see https://tailwindcss.com/docs/text-overflow
       */
      "text-overflow": ["truncate", "text-ellipsis", "text-clip"],
      /**
       * Text Wrap
       * @see https://tailwindcss.com/docs/text-wrap
       */
      "text-wrap": [{
        text: ["wrap", "nowrap", "balance", "pretty"]
      }],
      /**
       * Text Indent
       * @see https://tailwindcss.com/docs/text-indent
       */
      indent: [{
        indent: R()
      }],
      /**
       * Tab Size
       * @see https://tailwindcss.com/docs/tab-size
       */
      "tab-size": [{
        tab: [Le, D, O]
      }],
      /**
       * Vertical Alignment
       * @see https://tailwindcss.com/docs/vertical-align
       */
      "vertical-align": [{
        align: ["baseline", "top", "middle", "bottom", "text-top", "text-bottom", "sub", "super", D, O]
      }],
      /**
       * Whitespace
       * @see https://tailwindcss.com/docs/whitespace
       */
      whitespace: [{
        whitespace: ["normal", "nowrap", "pre", "pre-line", "pre-wrap", "break-spaces"]
      }],
      /**
       * Word Break
       * @see https://tailwindcss.com/docs/word-break
       */
      break: [{
        break: ["normal", "words", "all", "keep"]
      }],
      /**
       * Overflow Wrap
       * @see https://tailwindcss.com/docs/overflow-wrap
       */
      wrap: [{
        wrap: ["break-word", "anywhere", "normal"]
      }],
      /**
       * Hyphens
       * @see https://tailwindcss.com/docs/hyphens
       */
      hyphens: [{
        hyphens: ["none", "manual", "auto"]
      }],
      /**
       * Content
       * @see https://tailwindcss.com/docs/content
       */
      content: [{
        content: ["none", D, O]
      }],
      // -------------------
      // --- Backgrounds ---
      // -------------------
      /**
       * Background Attachment
       * @see https://tailwindcss.com/docs/background-attachment
       */
      "bg-attachment": [{
        bg: ["fixed", "local", "scroll"]
      }],
      /**
       * Background Clip
       * @see https://tailwindcss.com/docs/background-clip
       */
      "bg-clip": [{
        "bg-clip": ["border", "padding", "content", "text"]
      }],
      /**
       * Background Origin
       * @see https://tailwindcss.com/docs/background-origin
       */
      "bg-origin": [{
        "bg-origin": ["border", "padding", "content"]
      }],
      /**
       * Background Position
       * @see https://tailwindcss.com/docs/background-position
       */
      "bg-position": [{
        bg: ce()
      }],
      /**
       * Background Repeat
       * @see https://tailwindcss.com/docs/background-repeat
       */
      "bg-repeat": [{
        bg: ee()
      }],
      /**
       * Background Size
       * @see https://tailwindcss.com/docs/background-size
       */
      "bg-size": [{
        bg: ae()
      }],
      /**
       * Background Image
       * @see https://tailwindcss.com/docs/background-image
       */
      "bg-image": [{
        bg: ["none", {
          linear: [{
            to: ["t", "tr", "r", "br", "b", "bl", "l", "tl"]
          }, Le, D, O],
          radial: ["", D, O],
          conic: [Le, D, O]
        }, _b, Pb]
      }],
      /**
       * Background Color
       * @see https://tailwindcss.com/docs/background-color
       */
      "bg-color": [{
        bg: E()
      }],
      /**
       * Gradient Color Stops From Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-from-pos": [{
        from: ge()
      }],
      /**
       * Gradient Color Stops Via Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-via-pos": [{
        via: ge()
      }],
      /**
       * Gradient Color Stops To Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-to-pos": [{
        to: ge()
      }],
      /**
       * Gradient Color Stops From
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-from": [{
        from: E()
      }],
      /**
       * Gradient Color Stops Via
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-via": [{
        via: E()
      }],
      /**
       * Gradient Color Stops To
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-to": [{
        to: E()
      }],
      // ---------------
      // --- Borders ---
      // ---------------
      /**
       * Border Radius
       * @see https://tailwindcss.com/docs/border-radius
       */
      rounded: [{
        rounded: te()
      }],
      /**
       * Border Radius Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-s": [{
        "rounded-s": te()
      }],
      /**
       * Border Radius End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-e": [{
        "rounded-e": te()
      }],
      /**
       * Border Radius Top
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-t": [{
        "rounded-t": te()
      }],
      /**
       * Border Radius Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-r": [{
        "rounded-r": te()
      }],
      /**
       * Border Radius Bottom
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-b": [{
        "rounded-b": te()
      }],
      /**
       * Border Radius Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-l": [{
        "rounded-l": te()
      }],
      /**
       * Border Radius Start Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-ss": [{
        "rounded-ss": te()
      }],
      /**
       * Border Radius Start End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-se": [{
        "rounded-se": te()
      }],
      /**
       * Border Radius End End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-ee": [{
        "rounded-ee": te()
      }],
      /**
       * Border Radius End Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-es": [{
        "rounded-es": te()
      }],
      /**
       * Border Radius Top Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-tl": [{
        "rounded-tl": te()
      }],
      /**
       * Border Radius Top Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-tr": [{
        "rounded-tr": te()
      }],
      /**
       * Border Radius Bottom Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-br": [{
        "rounded-br": te()
      }],
      /**
       * Border Radius Bottom Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-bl": [{
        "rounded-bl": te()
      }],
      /**
       * Border Width
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w": [{
        border: ne()
      }],
      /**
       * Border Width Inline
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-x": [{
        "border-x": ne()
      }],
      /**
       * Border Width Block
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-y": [{
        "border-y": ne()
      }],
      /**
       * Border Width Inline Start
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-s": [{
        "border-s": ne()
      }],
      /**
       * Border Width Inline End
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-e": [{
        "border-e": ne()
      }],
      /**
       * Border Width Block Start
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-bs": [{
        "border-bs": ne()
      }],
      /**
       * Border Width Block End
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-be": [{
        "border-be": ne()
      }],
      /**
       * Border Width Top
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-t": [{
        "border-t": ne()
      }],
      /**
       * Border Width Right
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-r": [{
        "border-r": ne()
      }],
      /**
       * Border Width Bottom
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-b": [{
        "border-b": ne()
      }],
      /**
       * Border Width Left
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-l": [{
        "border-l": ne()
      }],
      /**
       * Divide Width X
       * @see https://tailwindcss.com/docs/border-width#between-children
       */
      "divide-x": [{
        "divide-x": ne()
      }],
      /**
       * Divide Width X Reverse
       * @see https://tailwindcss.com/docs/border-width#between-children
       */
      "divide-x-reverse": ["divide-x-reverse"],
      /**
       * Divide Width Y
       * @see https://tailwindcss.com/docs/border-width#between-children
       */
      "divide-y": [{
        "divide-y": ne()
      }],
      /**
       * Divide Width Y Reverse
       * @see https://tailwindcss.com/docs/border-width#between-children
       */
      "divide-y-reverse": ["divide-y-reverse"],
      /**
       * Border Style
       * @see https://tailwindcss.com/docs/border-style
       */
      "border-style": [{
        border: [...fe(), "hidden", "none"]
      }],
      /**
       * Divide Style
       * @see https://tailwindcss.com/docs/border-style#setting-the-divider-style
       */
      "divide-style": [{
        divide: [...fe(), "hidden", "none"]
      }],
      /**
       * Border Color
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color": [{
        border: E()
      }],
      /**
       * Border Color Inline
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-x": [{
        "border-x": E()
      }],
      /**
       * Border Color Block
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-y": [{
        "border-y": E()
      }],
      /**
       * Border Color Inline Start
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-s": [{
        "border-s": E()
      }],
      /**
       * Border Color Inline End
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-e": [{
        "border-e": E()
      }],
      /**
       * Border Color Block Start
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-bs": [{
        "border-bs": E()
      }],
      /**
       * Border Color Block End
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-be": [{
        "border-be": E()
      }],
      /**
       * Border Color Top
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-t": [{
        "border-t": E()
      }],
      /**
       * Border Color Right
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-r": [{
        "border-r": E()
      }],
      /**
       * Border Color Bottom
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-b": [{
        "border-b": E()
      }],
      /**
       * Border Color Left
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-l": [{
        "border-l": E()
      }],
      /**
       * Divide Color
       * @see https://tailwindcss.com/docs/divide-color
       */
      "divide-color": [{
        divide: E()
      }],
      /**
       * Outline Style
       * @see https://tailwindcss.com/docs/outline-style
       */
      "outline-style": [{
        outline: [...fe(), "none", "hidden"]
      }],
      /**
       * Outline Offset
       * @see https://tailwindcss.com/docs/outline-offset
       */
      "outline-offset": [{
        "outline-offset": [K, D, O]
      }],
      /**
       * Outline Width
       * @see https://tailwindcss.com/docs/outline-width
       */
      "outline-w": [{
        outline: ["", K, $t, lt]
      }],
      /**
       * Outline Color
       * @see https://tailwindcss.com/docs/outline-color
       */
      "outline-color": [{
        outline: E()
      }],
      // ---------------
      // --- Effects ---
      // ---------------
      /**
       * Box Shadow
       * @see https://tailwindcss.com/docs/box-shadow
       */
      shadow: [{
        shadow: [
          // Deprecated since Tailwind CSS v4.0.0
          "",
          "none",
          m,
          mn,
          pn
        ]
      }],
      /**
       * Box Shadow Color
       * @see https://tailwindcss.com/docs/box-shadow#setting-the-shadow-color
       */
      "shadow-color": [{
        shadow: E()
      }],
      /**
       * Inset Box Shadow
       * @see https://tailwindcss.com/docs/box-shadow#adding-an-inset-shadow
       */
      "inset-shadow": [{
        "inset-shadow": ["none", f, mn, pn]
      }],
      /**
       * Inset Box Shadow Color
       * @see https://tailwindcss.com/docs/box-shadow#setting-the-inset-shadow-color
       */
      "inset-shadow-color": [{
        "inset-shadow": E()
      }],
      /**
       * Ring Width
       * @see https://tailwindcss.com/docs/box-shadow#adding-a-ring
       */
      "ring-w": [{
        ring: ne()
      }],
      /**
       * Ring Width Inset
       * @see https://v3.tailwindcss.com/docs/ring-width#inset-rings
       * @deprecated since Tailwind CSS v4.0.0
       * @see https://github.com/tailwindlabs/tailwindcss/blob/v4.0.0/packages/tailwindcss/src/utilities.ts#L4158
       */
      "ring-w-inset": ["ring-inset"],
      /**
       * Ring Color
       * @see https://tailwindcss.com/docs/box-shadow#setting-the-ring-color
       */
      "ring-color": [{
        ring: E()
      }],
      /**
       * Ring Offset Width
       * @see https://v3.tailwindcss.com/docs/ring-offset-width
       * @deprecated since Tailwind CSS v4.0.0
       * @see https://github.com/tailwindlabs/tailwindcss/blob/v4.0.0/packages/tailwindcss/src/utilities.ts#L4158
       */
      "ring-offset-w": [{
        "ring-offset": [K, lt]
      }],
      /**
       * Ring Offset Color
       * @see https://v3.tailwindcss.com/docs/ring-offset-color
       * @deprecated since Tailwind CSS v4.0.0
       * @see https://github.com/tailwindlabs/tailwindcss/blob/v4.0.0/packages/tailwindcss/src/utilities.ts#L4158
       */
      "ring-offset-color": [{
        "ring-offset": E()
      }],
      /**
       * Inset Ring Width
       * @see https://tailwindcss.com/docs/box-shadow#adding-an-inset-ring
       */
      "inset-ring-w": [{
        "inset-ring": ne()
      }],
      /**
       * Inset Ring Color
       * @see https://tailwindcss.com/docs/box-shadow#setting-the-inset-ring-color
       */
      "inset-ring-color": [{
        "inset-ring": E()
      }],
      /**
       * Text Shadow
       * @see https://tailwindcss.com/docs/text-shadow
       */
      "text-shadow": [{
        "text-shadow": ["none", p, mn, pn]
      }],
      /**
       * Text Shadow Color
       * @see https://tailwindcss.com/docs/text-shadow#setting-the-shadow-color
       */
      "text-shadow-color": [{
        "text-shadow": E()
      }],
      /**
       * Opacity
       * @see https://tailwindcss.com/docs/opacity
       */
      opacity: [{
        opacity: [K, D, O]
      }],
      /**
       * Mix Blend Mode
       * @see https://tailwindcss.com/docs/mix-blend-mode
       */
      "mix-blend": [{
        "mix-blend": [...L(), "plus-darker", "plus-lighter"]
      }],
      /**
       * Background Blend Mode
       * @see https://tailwindcss.com/docs/background-blend-mode
       */
      "bg-blend": [{
        "bg-blend": L()
      }],
      /**
       * Mask Clip
       * @see https://tailwindcss.com/docs/mask-clip
       */
      "mask-clip": [{
        "mask-clip": ["border", "padding", "content", "fill", "stroke", "view"]
      }, "mask-no-clip"],
      /**
       * Mask Composite
       * @see https://tailwindcss.com/docs/mask-composite
       */
      "mask-composite": [{
        mask: ["add", "subtract", "intersect", "exclude"]
      }],
      /**
       * Mask Image
       * @see https://tailwindcss.com/docs/mask-image
       */
      "mask-image-linear-pos": [{
        "mask-linear": [K]
      }],
      "mask-image-linear-from-pos": [{
        "mask-linear-from": G()
      }],
      "mask-image-linear-to-pos": [{
        "mask-linear-to": G()
      }],
      "mask-image-linear-from-color": [{
        "mask-linear-from": E()
      }],
      "mask-image-linear-to-color": [{
        "mask-linear-to": E()
      }],
      "mask-image-t-from-pos": [{
        "mask-t-from": G()
      }],
      "mask-image-t-to-pos": [{
        "mask-t-to": G()
      }],
      "mask-image-t-from-color": [{
        "mask-t-from": E()
      }],
      "mask-image-t-to-color": [{
        "mask-t-to": E()
      }],
      "mask-image-r-from-pos": [{
        "mask-r-from": G()
      }],
      "mask-image-r-to-pos": [{
        "mask-r-to": G()
      }],
      "mask-image-r-from-color": [{
        "mask-r-from": E()
      }],
      "mask-image-r-to-color": [{
        "mask-r-to": E()
      }],
      "mask-image-b-from-pos": [{
        "mask-b-from": G()
      }],
      "mask-image-b-to-pos": [{
        "mask-b-to": G()
      }],
      "mask-image-b-from-color": [{
        "mask-b-from": E()
      }],
      "mask-image-b-to-color": [{
        "mask-b-to": E()
      }],
      "mask-image-l-from-pos": [{
        "mask-l-from": G()
      }],
      "mask-image-l-to-pos": [{
        "mask-l-to": G()
      }],
      "mask-image-l-from-color": [{
        "mask-l-from": E()
      }],
      "mask-image-l-to-color": [{
        "mask-l-to": E()
      }],
      "mask-image-x-from-pos": [{
        "mask-x-from": G()
      }],
      "mask-image-x-to-pos": [{
        "mask-x-to": G()
      }],
      "mask-image-x-from-color": [{
        "mask-x-from": E()
      }],
      "mask-image-x-to-color": [{
        "mask-x-to": E()
      }],
      "mask-image-y-from-pos": [{
        "mask-y-from": G()
      }],
      "mask-image-y-to-pos": [{
        "mask-y-to": G()
      }],
      "mask-image-y-from-color": [{
        "mask-y-from": E()
      }],
      "mask-image-y-to-color": [{
        "mask-y-to": E()
      }],
      "mask-image-radial": [{
        "mask-radial": [D, O]
      }],
      "mask-image-radial-from-pos": [{
        "mask-radial-from": G()
      }],
      "mask-image-radial-to-pos": [{
        "mask-radial-to": G()
      }],
      "mask-image-radial-from-color": [{
        "mask-radial-from": E()
      }],
      "mask-image-radial-to-color": [{
        "mask-radial-to": E()
      }],
      "mask-image-radial-shape": [{
        "mask-radial": ["circle", "ellipse"]
      }],
      "mask-image-radial-size": [{
        "mask-radial": [{
          closest: ["side", "corner"],
          farthest: ["side", "corner"]
        }]
      }],
      "mask-image-radial-pos": [{
        "mask-radial-at": C()
      }],
      "mask-image-conic-pos": [{
        "mask-conic": [K]
      }],
      "mask-image-conic-from-pos": [{
        "mask-conic-from": G()
      }],
      "mask-image-conic-to-pos": [{
        "mask-conic-to": G()
      }],
      "mask-image-conic-from-color": [{
        "mask-conic-from": E()
      }],
      "mask-image-conic-to-color": [{
        "mask-conic-to": E()
      }],
      /**
       * Mask Mode
       * @see https://tailwindcss.com/docs/mask-mode
       */
      "mask-mode": [{
        mask: ["alpha", "luminance", "match"]
      }],
      /**
       * Mask Origin
       * @see https://tailwindcss.com/docs/mask-origin
       */
      "mask-origin": [{
        "mask-origin": ["border", "padding", "content", "fill", "stroke", "view"]
      }],
      /**
       * Mask Position
       * @see https://tailwindcss.com/docs/mask-position
       */
      "mask-position": [{
        mask: ce()
      }],
      /**
       * Mask Repeat
       * @see https://tailwindcss.com/docs/mask-repeat
       */
      "mask-repeat": [{
        mask: ee()
      }],
      /**
       * Mask Size
       * @see https://tailwindcss.com/docs/mask-size
       */
      "mask-size": [{
        mask: ae()
      }],
      /**
       * Mask Type
       * @see https://tailwindcss.com/docs/mask-type
       */
      "mask-type": [{
        "mask-type": ["alpha", "luminance"]
      }],
      /**
       * Mask Image
       * @see https://tailwindcss.com/docs/mask-image
       */
      "mask-image": [{
        mask: ["none", D, O]
      }],
      // ---------------
      // --- Filters ---
      // ---------------
      /**
       * Filter
       * @see https://tailwindcss.com/docs/filter
       */
      filter: [{
        filter: [
          // Deprecated since Tailwind CSS v3.0.0
          "",
          "none",
          D,
          O
        ]
      }],
      /**
       * Blur
       * @see https://tailwindcss.com/docs/blur
       */
      blur: [{
        blur: le()
      }],
      /**
       * Brightness
       * @see https://tailwindcss.com/docs/brightness
       */
      brightness: [{
        brightness: [K, D, O]
      }],
      /**
       * Contrast
       * @see https://tailwindcss.com/docs/contrast
       */
      contrast: [{
        contrast: [K, D, O]
      }],
      /**
       * Drop Shadow
       * @see https://tailwindcss.com/docs/drop-shadow
       */
      "drop-shadow": [{
        "drop-shadow": [
          // Deprecated since Tailwind CSS v4.0.0
          "",
          "none",
          h,
          mn,
          pn
        ]
      }],
      /**
       * Drop Shadow Color
       * @see https://tailwindcss.com/docs/filter-drop-shadow#setting-the-shadow-color
       */
      "drop-shadow-color": [{
        "drop-shadow": E()
      }],
      /**
       * Grayscale
       * @see https://tailwindcss.com/docs/grayscale
       */
      grayscale: [{
        grayscale: ["", K, D, O]
      }],
      /**
       * Hue Rotate
       * @see https://tailwindcss.com/docs/hue-rotate
       */
      "hue-rotate": [{
        "hue-rotate": [K, D, O]
      }],
      /**
       * Invert
       * @see https://tailwindcss.com/docs/invert
       */
      invert: [{
        invert: ["", K, D, O]
      }],
      /**
       * Saturate
       * @see https://tailwindcss.com/docs/saturate
       */
      saturate: [{
        saturate: [K, D, O]
      }],
      /**
       * Sepia
       * @see https://tailwindcss.com/docs/sepia
       */
      sepia: [{
        sepia: ["", K, D, O]
      }],
      /**
       * Backdrop Filter
       * @see https://tailwindcss.com/docs/backdrop-filter
       */
      "backdrop-filter": [{
        "backdrop-filter": [
          // Deprecated since Tailwind CSS v3.0.0
          "",
          "none",
          D,
          O
        ]
      }],
      /**
       * Backdrop Blur
       * @see https://tailwindcss.com/docs/backdrop-blur
       */
      "backdrop-blur": [{
        "backdrop-blur": le()
      }],
      /**
       * Backdrop Brightness
       * @see https://tailwindcss.com/docs/backdrop-brightness
       */
      "backdrop-brightness": [{
        "backdrop-brightness": [K, D, O]
      }],
      /**
       * Backdrop Contrast
       * @see https://tailwindcss.com/docs/backdrop-contrast
       */
      "backdrop-contrast": [{
        "backdrop-contrast": [K, D, O]
      }],
      /**
       * Backdrop Grayscale
       * @see https://tailwindcss.com/docs/backdrop-grayscale
       */
      "backdrop-grayscale": [{
        "backdrop-grayscale": ["", K, D, O]
      }],
      /**
       * Backdrop Hue Rotate
       * @see https://tailwindcss.com/docs/backdrop-hue-rotate
       */
      "backdrop-hue-rotate": [{
        "backdrop-hue-rotate": [K, D, O]
      }],
      /**
       * Backdrop Invert
       * @see https://tailwindcss.com/docs/backdrop-invert
       */
      "backdrop-invert": [{
        "backdrop-invert": ["", K, D, O]
      }],
      /**
       * Backdrop Opacity
       * @see https://tailwindcss.com/docs/backdrop-opacity
       */
      "backdrop-opacity": [{
        "backdrop-opacity": [K, D, O]
      }],
      /**
       * Backdrop Saturate
       * @see https://tailwindcss.com/docs/backdrop-saturate
       */
      "backdrop-saturate": [{
        "backdrop-saturate": [K, D, O]
      }],
      /**
       * Backdrop Sepia
       * @see https://tailwindcss.com/docs/backdrop-sepia
       */
      "backdrop-sepia": [{
        "backdrop-sepia": ["", K, D, O]
      }],
      // --------------
      // --- Tables ---
      // --------------
      /**
       * Border Collapse
       * @see https://tailwindcss.com/docs/border-collapse
       */
      "border-collapse": [{
        border: ["collapse", "separate"]
      }],
      /**
       * Border Spacing
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing": [{
        "border-spacing": R()
      }],
      /**
       * Border Spacing X
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing-x": [{
        "border-spacing-x": R()
      }],
      /**
       * Border Spacing Y
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing-y": [{
        "border-spacing-y": R()
      }],
      /**
       * Table Layout
       * @see https://tailwindcss.com/docs/table-layout
       */
      "table-layout": [{
        table: ["auto", "fixed"]
      }],
      /**
       * Caption Side
       * @see https://tailwindcss.com/docs/caption-side
       */
      caption: [{
        caption: ["top", "bottom"]
      }],
      // ---------------------------------
      // --- Transitions and Animation ---
      // ---------------------------------
      /**
       * Transition Property
       * @see https://tailwindcss.com/docs/transition-property
       */
      transition: [{
        transition: ["", "all", "colors", "opacity", "shadow", "transform", "none", D, O]
      }],
      /**
       * Transition Behavior
       * @see https://tailwindcss.com/docs/transition-behavior
       */
      "transition-behavior": [{
        transition: ["normal", "discrete"]
      }],
      /**
       * Transition Duration
       * @see https://tailwindcss.com/docs/transition-duration
       */
      duration: [{
        duration: [K, "initial", D, O]
      }],
      /**
       * Transition Timing Function
       * @see https://tailwindcss.com/docs/transition-timing-function
       */
      ease: [{
        ease: ["linear", "initial", y, D, O]
      }],
      /**
       * Transition Delay
       * @see https://tailwindcss.com/docs/transition-delay
       */
      delay: [{
        delay: [K, D, O]
      }],
      /**
       * Animation
       * @see https://tailwindcss.com/docs/animation
       */
      animate: [{
        animate: ["none", x, D, O]
      }],
      // ------------------
      // --- Transforms ---
      // ------------------
      /**
       * Backface Visibility
       * @see https://tailwindcss.com/docs/backface-visibility
       */
      backface: [{
        backface: ["hidden", "visible"]
      }],
      /**
       * Perspective
       * @see https://tailwindcss.com/docs/perspective
       */
      perspective: [{
        perspective: [b, D, O]
      }],
      /**
       * Perspective Origin
       * @see https://tailwindcss.com/docs/perspective-origin
       */
      "perspective-origin": [{
        "perspective-origin": P()
      }],
      /**
       * Rotate
       * @see https://tailwindcss.com/docs/rotate
       */
      rotate: [{
        rotate: Z()
      }],
      /**
       * Rotate X
       * @see https://tailwindcss.com/docs/rotate
       */
      "rotate-x": [{
        "rotate-x": Z()
      }],
      /**
       * Rotate Y
       * @see https://tailwindcss.com/docs/rotate
       */
      "rotate-y": [{
        "rotate-y": Z()
      }],
      /**
       * Rotate Z
       * @see https://tailwindcss.com/docs/rotate
       */
      "rotate-z": [{
        "rotate-z": Z()
      }],
      /**
       * Scale
       * @see https://tailwindcss.com/docs/scale
       */
      scale: [{
        scale: J()
      }],
      /**
       * Scale X
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-x": [{
        "scale-x": J()
      }],
      /**
       * Scale Y
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-y": [{
        "scale-y": J()
      }],
      /**
       * Scale Z
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-z": [{
        "scale-z": J()
      }],
      /**
       * Scale 3D
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-3d": ["scale-3d"],
      /**
       * Skew
       * @see https://tailwindcss.com/docs/skew
       */
      skew: [{
        skew: oe()
      }],
      /**
       * Skew X
       * @see https://tailwindcss.com/docs/skew
       */
      "skew-x": [{
        "skew-x": oe()
      }],
      /**
       * Skew Y
       * @see https://tailwindcss.com/docs/skew
       */
      "skew-y": [{
        "skew-y": oe()
      }],
      /**
       * Transform
       * @see https://tailwindcss.com/docs/transform
       */
      transform: [{
        transform: [D, O, "", "none", "gpu", "cpu"]
      }],
      /**
       * Transform Origin
       * @see https://tailwindcss.com/docs/transform-origin
       */
      "transform-origin": [{
        origin: P()
      }],
      /**
       * Transform Style
       * @see https://tailwindcss.com/docs/transform-style
       */
      "transform-style": [{
        transform: ["3d", "flat"]
      }],
      /**
       * Translate
       * @see https://tailwindcss.com/docs/translate
       */
      translate: [{
        translate: Se()
      }],
      /**
       * Translate X
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-x": [{
        "translate-x": Se()
      }],
      /**
       * Translate Y
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-y": [{
        "translate-y": Se()
      }],
      /**
       * Translate Z
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-z": [{
        "translate-z": Se()
      }],
      /**
       * Translate None
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-none": ["translate-none"],
      /**
       * Zoom
       * @see https://tailwindcss.com/docs/zoom
       */
      zoom: [{
        zoom: [Le, D, O]
      }],
      // ---------------------
      // --- Interactivity ---
      // ---------------------
      /**
       * Accent Color
       * @see https://tailwindcss.com/docs/accent-color
       */
      accent: [{
        accent: E()
      }],
      /**
       * Appearance
       * @see https://tailwindcss.com/docs/appearance
       */
      appearance: [{
        appearance: ["none", "auto"]
      }],
      /**
       * Caret Color
       * @see https://tailwindcss.com/docs/just-in-time-mode#caret-color-utilities
       */
      "caret-color": [{
        caret: E()
      }],
      /**
       * Color Scheme
       * @see https://tailwindcss.com/docs/color-scheme
       */
      "color-scheme": [{
        scheme: ["normal", "dark", "light", "light-dark", "only-dark", "only-light"]
      }],
      /**
       * Cursor
       * @see https://tailwindcss.com/docs/cursor
       */
      cursor: [{
        cursor: ["auto", "default", "pointer", "wait", "text", "move", "help", "not-allowed", "none", "context-menu", "progress", "cell", "crosshair", "vertical-text", "alias", "copy", "no-drop", "grab", "grabbing", "all-scroll", "col-resize", "row-resize", "n-resize", "e-resize", "s-resize", "w-resize", "ne-resize", "nw-resize", "se-resize", "sw-resize", "ew-resize", "ns-resize", "nesw-resize", "nwse-resize", "zoom-in", "zoom-out", D, O]
      }],
      /**
       * Field Sizing
       * @see https://tailwindcss.com/docs/field-sizing
       */
      "field-sizing": [{
        "field-sizing": ["fixed", "content"]
      }],
      /**
       * Pointer Events
       * @see https://tailwindcss.com/docs/pointer-events
       */
      "pointer-events": [{
        "pointer-events": ["auto", "none"]
      }],
      /**
       * Resize
       * @see https://tailwindcss.com/docs/resize
       */
      resize: [{
        resize: ["none", "", "y", "x"]
      }],
      /**
       * Scroll Behavior
       * @see https://tailwindcss.com/docs/scroll-behavior
       */
      "scroll-behavior": [{
        scroll: ["auto", "smooth"]
      }],
      /**
       * Scrollbar Thumb Color
       * @see https://tailwindcss.com/docs/scrollbar-color
       */
      "scrollbar-thumb-color": [{
        "scrollbar-thumb": E()
      }],
      /**
       * Scrollbar Track Color
       * @see https://tailwindcss.com/docs/scrollbar-color
       */
      "scrollbar-track-color": [{
        "scrollbar-track": E()
      }],
      /**
       * Scrollbar Gutter
       * @see https://tailwindcss.com/docs/scrollbar-gutter
       */
      "scrollbar-gutter": [{
        "scrollbar-gutter": ["auto", "stable", "both"]
      }],
      /**
       * Scrollbar Width
       * @see https://tailwindcss.com/docs/scrollbar-width
       */
      "scrollbar-w": [{
        scrollbar: ["auto", "thin", "none"]
      }],
      /**
       * Scroll Margin
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-m": [{
        "scroll-m": R()
      }],
      /**
       * Scroll Margin Inline
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mx": [{
        "scroll-mx": R()
      }],
      /**
       * Scroll Margin Block
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-my": [{
        "scroll-my": R()
      }],
      /**
       * Scroll Margin Inline Start
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-ms": [{
        "scroll-ms": R()
      }],
      /**
       * Scroll Margin Inline End
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-me": [{
        "scroll-me": R()
      }],
      /**
       * Scroll Margin Block Start
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mbs": [{
        "scroll-mbs": R()
      }],
      /**
       * Scroll Margin Block End
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mbe": [{
        "scroll-mbe": R()
      }],
      /**
       * Scroll Margin Top
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mt": [{
        "scroll-mt": R()
      }],
      /**
       * Scroll Margin Right
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mr": [{
        "scroll-mr": R()
      }],
      /**
       * Scroll Margin Bottom
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mb": [{
        "scroll-mb": R()
      }],
      /**
       * Scroll Margin Left
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-ml": [{
        "scroll-ml": R()
      }],
      /**
       * Scroll Padding
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-p": [{
        "scroll-p": R()
      }],
      /**
       * Scroll Padding Inline
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-px": [{
        "scroll-px": R()
      }],
      /**
       * Scroll Padding Block
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-py": [{
        "scroll-py": R()
      }],
      /**
       * Scroll Padding Inline Start
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-ps": [{
        "scroll-ps": R()
      }],
      /**
       * Scroll Padding Inline End
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pe": [{
        "scroll-pe": R()
      }],
      /**
       * Scroll Padding Block Start
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pbs": [{
        "scroll-pbs": R()
      }],
      /**
       * Scroll Padding Block End
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pbe": [{
        "scroll-pbe": R()
      }],
      /**
       * Scroll Padding Top
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pt": [{
        "scroll-pt": R()
      }],
      /**
       * Scroll Padding Right
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pr": [{
        "scroll-pr": R()
      }],
      /**
       * Scroll Padding Bottom
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pb": [{
        "scroll-pb": R()
      }],
      /**
       * Scroll Padding Left
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pl": [{
        "scroll-pl": R()
      }],
      /**
       * Scroll Snap Align
       * @see https://tailwindcss.com/docs/scroll-snap-align
       */
      "snap-align": [{
        snap: ["start", "end", "center", "align-none"]
      }],
      /**
       * Scroll Snap Stop
       * @see https://tailwindcss.com/docs/scroll-snap-stop
       */
      "snap-stop": [{
        snap: ["normal", "always"]
      }],
      /**
       * Scroll Snap Type
       * @see https://tailwindcss.com/docs/scroll-snap-type
       */
      "snap-type": [{
        snap: ["none", "x", "y", "both"]
      }],
      /**
       * Scroll Snap Type Strictness
       * @see https://tailwindcss.com/docs/scroll-snap-type
       */
      "snap-strictness": [{
        snap: ["mandatory", "proximity"]
      }],
      /**
       * Touch Action
       * @see https://tailwindcss.com/docs/touch-action
       */
      touch: [{
        touch: ["auto", "none", "manipulation"]
      }],
      /**
       * Touch Action X
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-x": [{
        "touch-pan": ["x", "left", "right"]
      }],
      /**
       * Touch Action Y
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-y": [{
        "touch-pan": ["y", "up", "down"]
      }],
      /**
       * Touch Action Pinch Zoom
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-pz": ["touch-pinch-zoom"],
      /**
       * User Select
       * @see https://tailwindcss.com/docs/user-select
       */
      select: [{
        select: ["none", "text", "all", "auto"]
      }],
      /**
       * Will Change
       * @see https://tailwindcss.com/docs/will-change
       */
      "will-change": [{
        "will-change": ["auto", "scroll", "contents", "transform", D, O]
      }],
      // -----------
      // --- SVG ---
      // -----------
      /**
       * Fill
       * @see https://tailwindcss.com/docs/fill
       */
      fill: [{
        fill: ["none", ...E()]
      }],
      /**
       * Stroke Width
       * @see https://tailwindcss.com/docs/stroke-width
       */
      "stroke-w": [{
        stroke: [K, $t, lt, Ra]
      }],
      /**
       * Stroke
       * @see https://tailwindcss.com/docs/stroke
       */
      stroke: [{
        stroke: ["none", ...E()]
      }],
      // ---------------------
      // --- Accessibility ---
      // ---------------------
      /**
       * Forced Color Adjust
       * @see https://tailwindcss.com/docs/forced-color-adjust
       */
      "forced-color-adjust": [{
        "forced-color-adjust": ["auto", "none"]
      }]
    },
    conflictingClassGroups: {
      "container-named": ["container-type"],
      overflow: ["overflow-x", "overflow-y"],
      overscroll: ["overscroll-x", "overscroll-y"],
      inset: ["inset-x", "inset-y", "inset-bs", "inset-be", "start", "end", "top", "right", "bottom", "left"],
      "inset-x": ["right", "left"],
      "inset-y": ["top", "bottom"],
      flex: ["basis", "grow", "shrink"],
      gap: ["gap-x", "gap-y"],
      p: ["px", "py", "ps", "pe", "pbs", "pbe", "pt", "pr", "pb", "pl"],
      px: ["pr", "pl"],
      py: ["pt", "pb"],
      m: ["mx", "my", "ms", "me", "mbs", "mbe", "mt", "mr", "mb", "ml"],
      mx: ["mr", "ml"],
      my: ["mt", "mb"],
      size: ["w", "h"],
      "font-size": ["leading"],
      "fvn-normal": ["fvn-ordinal", "fvn-slashed-zero", "fvn-figure", "fvn-spacing", "fvn-fraction"],
      "fvn-ordinal": ["fvn-normal"],
      "fvn-slashed-zero": ["fvn-normal"],
      "fvn-figure": ["fvn-normal"],
      "fvn-spacing": ["fvn-normal"],
      "fvn-fraction": ["fvn-normal"],
      "line-clamp": ["display", "overflow"],
      rounded: ["rounded-s", "rounded-e", "rounded-t", "rounded-r", "rounded-b", "rounded-l", "rounded-ss", "rounded-se", "rounded-ee", "rounded-es", "rounded-tl", "rounded-tr", "rounded-br", "rounded-bl"],
      "rounded-s": ["rounded-ss", "rounded-es"],
      "rounded-e": ["rounded-se", "rounded-ee"],
      "rounded-t": ["rounded-tl", "rounded-tr"],
      "rounded-r": ["rounded-tr", "rounded-br"],
      "rounded-b": ["rounded-br", "rounded-bl"],
      "rounded-l": ["rounded-tl", "rounded-bl"],
      "border-spacing": ["border-spacing-x", "border-spacing-y"],
      "border-w": ["border-w-x", "border-w-y", "border-w-s", "border-w-e", "border-w-bs", "border-w-be", "border-w-t", "border-w-r", "border-w-b", "border-w-l"],
      "border-w-x": ["border-w-r", "border-w-l"],
      "border-w-y": ["border-w-t", "border-w-b"],
      "border-color": ["border-color-x", "border-color-y", "border-color-s", "border-color-e", "border-color-bs", "border-color-be", "border-color-t", "border-color-r", "border-color-b", "border-color-l"],
      "border-color-x": ["border-color-r", "border-color-l"],
      "border-color-y": ["border-color-t", "border-color-b"],
      translate: ["translate-x", "translate-y", "translate-none"],
      "translate-none": ["translate", "translate-x", "translate-y", "translate-z"],
      "scroll-m": ["scroll-mx", "scroll-my", "scroll-ms", "scroll-me", "scroll-mbs", "scroll-mbe", "scroll-mt", "scroll-mr", "scroll-mb", "scroll-ml"],
      "scroll-mx": ["scroll-mr", "scroll-ml"],
      "scroll-my": ["scroll-mt", "scroll-mb"],
      "scroll-p": ["scroll-px", "scroll-py", "scroll-ps", "scroll-pe", "scroll-pbs", "scroll-pbe", "scroll-pt", "scroll-pr", "scroll-pb", "scroll-pl"],
      "scroll-px": ["scroll-pr", "scroll-pl"],
      "scroll-py": ["scroll-pt", "scroll-pb"],
      touch: ["touch-x", "touch-y", "touch-pz"],
      "touch-x": ["touch"],
      "touch-y": ["touch"],
      "touch-pz": ["touch"]
    },
    conflictingClassGroupModifiers: {
      "font-size": ["leading"]
    },
    postfixLookupClassGroups: ["container-type"],
    orderSensitiveModifiers: ["*", "**", "after", "backdrop", "before", "details-content", "file", "first-letter", "first-line", "marker", "placeholder", "selection"]
  };
}, kb = /* @__PURE__ */ cb(Ab);
function T(...e) {
  return kb(ic(e));
}
function yv({ className: e, ...t }) {
  return /* @__PURE__ */ d(Ll, { "data-slot": "accordion", className: T("flex w-full flex-col", e), ...t });
}
function Cv({ className: e, ...t }) {
  return /* @__PURE__ */ d($l, { "data-slot": "accordion-item", className: T("border-b", e), ...t });
}
function Sv({ className: e, children: t, ...n }) {
  return /* @__PURE__ */ d(Fl, { className: "flex", children: /* @__PURE__ */ Q(zl, { "data-slot": "accordion-trigger", className: T("flex flex-1 items-center justify-between py-3 text-sm font-medium outline-none transition-all hover:underline focus-visible:ring-3 focus-visible:ring-ring/50 disabled:pointer-events-none disabled:opacity-50 [&[data-state=open]>svg]:rotate-180", e), ...n, children: [
    t,
    /* @__PURE__ */ d(zr, { "data-slot": "accordion-trigger-icon", className: "size-4 shrink-0 transition-transform duration-200" })
  ] }) });
}
function Pv({ className: e, children: t, ...n }) {
  return /* @__PURE__ */ d(Bl, { "data-slot": "accordion-content", className: "overflow-hidden text-sm data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down", ...n, children: /* @__PURE__ */ d("div", { className: T("pb-3 text-muted-foreground", e), children: t }) });
}
const Ta = (e) => typeof e == "boolean" ? `${e}` : e === 0 ? "0" : e, Ia = ic, Xn = (e, t) => (n) => {
  var o;
  if (t?.variants == null) return Ia(e, n?.class, n?.className);
  const { variants: r, defaultVariants: a } = t, i = Object.keys(r).map((u) => {
    const m = n?.[u], f = a?.[u];
    if (m === null) return null;
    const p = Ta(m) || Ta(f);
    return r[u][p];
  }), c = n && Object.entries(n).reduce((u, m) => {
    let [f, p] = m;
    return p === void 0 || (u[f] = p), u;
  }, {}), l = t == null || (o = t.compoundVariants) === null || o === void 0 ? void 0 : o.reduce((u, m) => {
    let { class: f, className: p, ...h } = m;
    return Object.entries(h).every((g) => {
      let [b, v] = g;
      return Array.isArray(v) ? v.includes({
        ...a,
        ...c
      }[b]) : {
        ...a,
        ...c
      }[b] === v;
    }) ? [
      ...u,
      f,
      p
    ] : u;
  }, []);
  return Ia(e, i, l, n?.class, n?.className);
}, Mb = Xn(
  "group/badge inline-flex h-5 w-fit shrink-0 items-center justify-center gap-1 overflow-hidden rounded-full border border-transparent px-2 py-0.5 text-xs font-medium whitespace-nowrap transition-all focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5 aria-invalid:border-destructive aria-invalid:ring-destructive/20 [&>svg]:pointer-events-none [&>svg]:size-3!",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground [a]:hover:bg-primary/80",
        secondary: "bg-secondary text-secondary-foreground [a]:hover:bg-secondary/80",
        destructive: "bg-destructive text-background focus-visible:ring-destructive/20 [a]:hover:bg-destructive/95",
        outline: "border-border text-foreground [a]:hover:bg-accent [a]:hover:text-accent-foreground",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline"
      }
    },
    defaultVariants: {
      variant: "default"
    }
  }
);
function Rv({
  className: e,
  variant: t = "default",
  asChild: n = !1,
  ...o
}) {
  return /* @__PURE__ */ d(
    n ? ht : "span",
    {
      "data-slot": "badge",
      "data-variant": t,
      className: T(Mb({ variant: t }), e),
      ...o
    }
  );
}
const Ob = Xn(
  "group/button inline-flex shrink-0 items-center justify-center rounded-md border border-transparent bg-clip-padding text-sm font-medium whitespace-nowrap transition-all outline-none select-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 active:not-aria-[haspopup]:translate-y-px disabled:pointer-events-none disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-3 aria-invalid:ring-destructive/20 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-primary/80",
        outline: "border-border bg-background hover:bg-accent hover:text-accent-foreground aria-expanded:bg-accent aria-expanded:text-accent-foreground",
        secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80 aria-expanded:bg-secondary aria-expanded:text-secondary-foreground",
        ghost: "hover:bg-accent hover:text-accent-foreground aria-expanded:bg-accent aria-expanded:text-accent-foreground",
        destructive: "bg-destructive text-background hover:bg-destructive/95 focus-visible:border-destructive/40 focus-visible:ring-destructive/20",
        link: "text-primary underline-offset-4 hover:underline"
      },
      size: {
        default: "h-8 gap-1.5 px-2.5 has-data-[icon=inline-end]:pr-2 has-data-[icon=inline-start]:pl-2",
        xs: "h-6 gap-1 rounded-sm px-2 text-xs in-data-[slot=button-group]:rounded-md has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5 [&_svg:not([class*='size-'])]:size-3",
        sm: "h-7 gap-1 rounded-sm px-2.5 text-xs in-data-[slot=button-group]:rounded-md has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5 [&_svg:not([class*='size-'])]:size-3.5",
        lg: "h-9 gap-1.5 px-2.5 has-data-[icon=inline-end]:pr-2 has-data-[icon=inline-start]:pl-2",
        icon: "size-8",
        "icon-xs": "size-6 rounded-sm in-data-[slot=button-group]:rounded-md [&_svg:not([class*='size-'])]:size-3",
        "icon-sm": "size-7 rounded-sm in-data-[slot=button-group]:rounded-md",
        "icon-lg": "size-9"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
), nn = s.forwardRef(({
  className: e,
  variant: t = "default",
  size: n = "default",
  asChild: o = !1,
  ...r
}, a) => /* @__PURE__ */ d(
  o ? ht : "button",
  {
    ref: a,
    "data-slot": "button",
    "data-variant": t,
    "data-size": n,
    className: T(Ob({ variant: t, size: n, className: e })),
    ...r
  }
));
nn.displayName = "Button";
function Ev({ className: e, size: t = "default", ...n }) {
  return /* @__PURE__ */ d("div", { "data-slot": "card", "data-size": t, className: T("group/card flex flex-col overflow-hidden rounded-xl border bg-card text-card-foreground", e), ...n });
}
function _v({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-slot": "card-header", className: T("grid gap-1.5 p-4 group-data-[size=sm]/card:p-3", e), ...t });
}
function Tv({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-slot": "card-title", className: T("font-heading text-base font-medium group-data-[size=sm]/card:text-sm", e), ...t });
}
function Iv({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-slot": "card-description", className: T("text-sm text-muted-foreground", e), ...t });
}
function Av({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-slot": "card-action", className: T("col-start-2 row-span-2 row-start-1 self-start justify-self-end", e), ...t });
}
function kv({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-slot": "card-content", className: T("px-4 pb-4 group-data-[size=sm]/card:px-3 group-data-[size=sm]/card:pb-3", e), ...t });
}
function Mv({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-slot": "card-footer", className: T("flex items-center border-t bg-muted/50 p-4 group-data-[size=sm]/card:p-3", e), ...t });
}
function Ov({ className: e, ...t }) {
  return /* @__PURE__ */ d(td, { "data-slot": "checkbox", className: T("peer size-4 shrink-0 rounded-[4px] border border-input outline-none transition-colors focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 data-[state=checked]:border-primary data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground disabled:cursor-not-allowed disabled:opacity-50", e), ...t, children: /* @__PURE__ */ d(od, { "data-slot": "checkbox-indicator", className: "grid place-content-center text-current", children: /* @__PURE__ */ d(Fr, { className: "size-3.5" }) }) });
}
function Dv({ ...e }) {
  return /* @__PURE__ */ d(Ri, { "data-slot": "dialog", ...e });
}
const Db = s.forwardRef(({ ...e }, t) => /* @__PURE__ */ d(Ei, { ref: t, "data-slot": "dialog-trigger", ...e }));
Db.displayName = "DialogTrigger";
function Nb({ ...e }) {
  return /* @__PURE__ */ d(Ii, { "data-slot": "dialog-portal", ...e });
}
function Nv({ ...e }) {
  return /* @__PURE__ */ d(qt, { "data-slot": "dialog-close", ...e });
}
const yc = s.forwardRef(({ className: e, ...t }, n) => /* @__PURE__ */ d(Ai, { ref: n, "data-slot": "dialog-overlay", className: T("fixed inset-0 z-50 bg-black/50 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:animate-in data-[state=open]:fade-in-0", e), ...t }));
yc.displayName = "DialogOverlay";
const Lb = s.forwardRef(({ className: e, children: t, showCloseButton: n = !0, portalContainer: o, ...r }, a) => /* @__PURE__ */ Q(Nb, { container: o, children: [
  /* @__PURE__ */ d(yc, {}),
  /* @__PURE__ */ Q(ki, { ref: a, "data-slot": "dialog-content", className: T("fixed top-1/2 left-1/2 z-50 grid w-full max-w-lg -translate-x-1/2 -translate-y-1/2 gap-4 rounded-lg border bg-background p-6 text-foreground shadow-lg", e), ...r, children: [
    t,
    n && /* @__PURE__ */ d(qt, { "data-slot": "dialog-close", asChild: !0, children: /* @__PURE__ */ Q(nn, { variant: "ghost", size: "icon-sm", className: "absolute top-4 right-4", children: [
      /* @__PURE__ */ d(rc, { className: "size-4" }),
      /* @__PURE__ */ d("span", { className: "sr-only", children: "Close" })
    ] }) })
  ] })
] }));
Lb.displayName = "DialogContent";
function Lv({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-slot": "dialog-header", className: T("flex flex-col gap-2 text-center sm:text-left", e), ...t });
}
function $v({ className: e, showCloseButton: t = !1, children: n, ...o }) {
  return /* @__PURE__ */ Q("div", { "data-slot": "dialog-footer", className: T("flex flex-col-reverse gap-2 sm:flex-row sm:justify-end", e), ...o, children: [
    n,
    t && /* @__PURE__ */ d(qt, { asChild: !0, children: /* @__PURE__ */ d(nn, { variant: "outline", children: "Close" }) })
  ] });
}
function Fv({ className: e, ...t }) {
  return /* @__PURE__ */ d(Oi, { "data-slot": "dialog-title", className: T("font-heading text-lg font-semibold", e), ...t });
}
function zv({ className: e, ...t }) {
  return /* @__PURE__ */ d(Di, { "data-slot": "dialog-description", className: T("text-sm text-muted-foreground", e), ...t });
}
function Bv({ ...e }) {
  return /* @__PURE__ */ d(tm, { "data-slot": "dropdown-menu", ...e });
}
function $b({ ...e }) {
  return /* @__PURE__ */ d(om, { "data-slot": "dropdown-menu-portal", ...e });
}
const Fb = s.forwardRef(({ ...e }, t) => /* @__PURE__ */ d(nm, { ref: t, "data-slot": "dropdown-menu-trigger", ...e }));
Fb.displayName = "DropdownMenuTrigger";
function Vv({ className: e, align: t = "start", sideOffset: n = 4, portalContainer: o, ...r }) {
  return /* @__PURE__ */ d($b, { container: o, children: /* @__PURE__ */ d(rm, { "data-slot": "dropdown-menu-content", sideOffset: n, align: t, className: T("z-50 max-h-[var(--radix-dropdown-menu-content-available-height)] min-w-32 overflow-x-hidden overflow-y-auto rounded-md border bg-popover p-1 text-popover-foreground shadow-md data-[state=closed]:overflow-hidden", e), ...r }) });
}
function Wv({ ...e }) {
  return /* @__PURE__ */ d(am, { "data-slot": "dropdown-menu-group", ...e });
}
function Hv({ className: e, inset: t, variant: n = "default", ...o }) {
  return /* @__PURE__ */ d(sm, { "data-slot": "dropdown-menu-item", "data-inset": t, "data-variant": n, className: T("relative flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none data-[highlighted]:bg-accent data-[highlighted]:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", n === "destructive" && "text-destructive", t && "pl-8", e), ...o });
}
function Gv({ className: e, children: t, checked: n, inset: o, ...r }) {
  return /* @__PURE__ */ Q(cm, { "data-slot": "dropdown-menu-checkbox-item", "data-inset": o, checked: n, className: T("relative flex cursor-default select-none items-center rounded-sm py-1.5 pr-2 text-sm outline-none data-[highlighted]:bg-accent data-[disabled]:pointer-events-none data-[disabled]:opacity-50", o ? "pl-8" : "pl-2", e), ...r, children: [
    /* @__PURE__ */ d("span", { className: "absolute left-2 flex size-3.5 items-center justify-center", children: /* @__PURE__ */ d(Ts, { children: /* @__PURE__ */ d(Fr, { className: "size-4" }) }) }),
    t
  ] });
}
function Uv({ ...e }) {
  return /* @__PURE__ */ d(lm, { "data-slot": "dropdown-menu-radio-group", ...e });
}
function jv({ className: e, children: t, inset: n, ...o }) {
  return /* @__PURE__ */ Q(um, { "data-slot": "dropdown-menu-radio-item", "data-inset": n, className: T("relative flex cursor-default select-none items-center rounded-sm py-1.5 pr-2 text-sm outline-none data-[highlighted]:bg-accent data-[disabled]:pointer-events-none data-[disabled]:opacity-50", n ? "pl-8" : "pl-2", e), ...o, children: [
    /* @__PURE__ */ d("span", { className: "absolute left-2 flex size-3.5 items-center justify-center", children: /* @__PURE__ */ d(Ts, { children: /* @__PURE__ */ d($g, { className: "size-2 fill-current" }) }) }),
    t
  ] });
}
function Kv({ className: e, inset: t, ...n }) {
  return /* @__PURE__ */ d(im, { "data-slot": "dropdown-menu-label", "data-inset": t, className: T("px-2 py-1.5 text-xs font-medium text-muted-foreground", t && "pl-8", e), ...n });
}
function Yv({ className: e, ...t }) {
  return /* @__PURE__ */ d(dm, { "data-slot": "dropdown-menu-separator", className: T("-mx-1 my-1 h-px bg-muted", e), ...t });
}
function Xv({ className: e, ...t }) {
  return /* @__PURE__ */ d("span", { "data-slot": "dropdown-menu-shortcut", className: T("ml-auto text-xs tracking-widest text-muted-foreground", e), ...t });
}
function qv({ ...e }) {
  return /* @__PURE__ */ d(fm, { "data-slot": "dropdown-menu-sub", ...e });
}
function Zv({ className: e, children: t, inset: n, ...o }) {
  return /* @__PURE__ */ Q(pm, { "data-slot": "dropdown-menu-sub-trigger", "data-inset": n, className: T("flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none data-[state=open]:bg-accent", n && "pl-8", e), ...o, children: [
    t,
    /* @__PURE__ */ d(Og, { className: "ml-auto size-4" })
  ] });
}
function Qv({ className: e, ...t }) {
  return /* @__PURE__ */ d(mm, { "data-slot": "dropdown-menu-sub-content", className: T("z-50 min-w-32 overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-lg", e), ...t });
}
function zb({ className: e, type: t, ...n }) {
  return /* @__PURE__ */ d(
    "input",
    {
      type: t,
      "data-slot": "input",
      className: T(
        "h-8 w-full min-w-0 rounded-md border border-input bg-transparent px-2.5 py-1 text-base transition-colors outline-none file:inline-flex file:h-6 file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 disabled:pointer-events-none disabled:cursor-not-allowed disabled:bg-input/50 disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-3 aria-invalid:ring-destructive/20 md:text-sm",
        e
      ),
      ...n
    }
  );
}
function Jv({ className: e, ...t }) {
  return /* @__PURE__ */ d(vm, { "data-slot": "label", className: T("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70", e), ...t });
}
function ew({ className: e, children: t, ...n }) {
  return /* @__PURE__ */ Q(Bm, { "data-slot": "scroll-area", className: T("relative overflow-hidden", e), ...n, children: [
    /* @__PURE__ */ d(Vm, { "data-slot": "scroll-area-viewport", tabIndex: 0, className: "size-full rounded-[inherit] outline-none focus-visible:ring-3 focus-visible:ring-ring/50", children: t }),
    /* @__PURE__ */ d(Bb, {}),
    /* @__PURE__ */ d(Wm, {})
  ] });
}
function Bb({ className: e, orientation: t = "vertical", ...n }) {
  return /* @__PURE__ */ d(Im, { "data-slot": "scroll-area-scrollbar", "data-orientation": t, orientation: t, className: T("flex touch-none select-none p-px transition-colors", t === "vertical" ? "h-full w-2.5 border-l border-l-transparent" : "h-2.5 w-full flex-col border-t border-t-transparent", e), ...n, children: /* @__PURE__ */ d(Nm, { "data-slot": "scroll-area-thumb", className: "relative flex-1 rounded-full bg-border" }) });
}
function tw({ ...e }) {
  return /* @__PURE__ */ d(qm, { "data-slot": "select", ...e });
}
function nw({ className: e, ...t }) {
  return /* @__PURE__ */ d(gh, { "data-slot": "select-group", className: T("p-1", e), ...t });
}
function ow({ ...e }) {
  return /* @__PURE__ */ d(eh, { "data-slot": "select-value", ...e });
}
function rw({ className: e, size: t = "default", children: n, ...o }) {
  return /* @__PURE__ */ Q(Qm, { "data-slot": "select-trigger", "data-size": t, className: T("flex h-8 w-fit min-w-28 items-center justify-between gap-2 rounded-md border border-input bg-transparent px-2.5 text-sm outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 disabled:cursor-not-allowed disabled:opacity-50 *:data-[slot=select-value]:line-clamp-1 *:data-[slot=select-value]:flex *:data-[slot=select-value]:items-center", t === "sm" && "h-7 text-xs", e), ...o, children: [
    n,
    /* @__PURE__ */ d(th, { asChild: !0, children: /* @__PURE__ */ d(zr, { className: "size-4 opacity-50" }) })
  ] });
}
function aw({ className: e, children: t, position: n = "item-aligned", align: o = "center", portalContainer: r, ...a }) {
  return /* @__PURE__ */ d(ah, { container: r, children: /* @__PURE__ */ Q(ih, { "data-slot": "select-content", "data-align-trigger": n === "item-aligned", position: n, align: o, className: T("relative z-50 max-h-96 min-w-32 overflow-x-hidden overflow-y-auto rounded-md border bg-popover text-popover-foreground shadow-md data-[align-trigger=true]:animate-none", n === "popper" && "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1", e), ...a, children: [
    /* @__PURE__ */ d(Vb, {}),
    /* @__PURE__ */ d(fh, { "data-position": n, className: T("p-1", n === "popper" && "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]"), children: t }),
    /* @__PURE__ */ d(Wb, {})
  ] }) });
}
function iw({ className: e, ...t }) {
  return /* @__PURE__ */ d(vh, { "data-slot": "select-label", className: T("px-2 py-1.5 text-xs text-muted-foreground", e), ...t });
}
function sw({ className: e, children: t, ...n }) {
  return /* @__PURE__ */ Q(xh, { "data-slot": "select-item", className: T("relative flex w-full cursor-default items-center rounded-sm py-1.5 pr-8 pl-2 text-sm outline-none data-[highlighted]:bg-accent data-[highlighted]:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", e), ...n, children: [
    /* @__PURE__ */ d("span", { className: "absolute right-2 flex size-3.5 items-center justify-center", children: /* @__PURE__ */ d(Sh, { children: /* @__PURE__ */ d(Fr, { className: "size-4" }) }) }),
    /* @__PURE__ */ d(yh, { children: t })
  ] });
}
function cw({ className: e, ...t }) {
  return /* @__PURE__ */ d(Eh, { "data-slot": "select-separator", className: T("-mx-1 my-1 h-px bg-muted", e), ...t });
}
function Vb({ className: e, ...t }) {
  return /* @__PURE__ */ d(Ph, { "data-slot": "select-scroll-up-button", className: T("flex cursor-default items-center justify-center py-1", e), ...t, children: /* @__PURE__ */ d(Ng, { className: "size-4" }) });
}
function Wb({ className: e, ...t }) {
  return /* @__PURE__ */ d(Rh, { "data-slot": "select-scroll-down-button", className: T("flex cursor-default items-center justify-center py-1", e), ...t, children: /* @__PURE__ */ d(zr, { className: "size-4" }) });
}
function Hb({
  className: e,
  orientation: t = "horizontal",
  decorative: n = !0,
  ...o
}) {
  return /* @__PURE__ */ d(
    Mh,
    {
      "data-slot": "separator",
      decorative: n,
      orientation: t,
      className: T(
        "shrink-0 bg-border data-horizontal:h-px data-horizontal:w-full data-vertical:w-px data-vertical:self-stretch",
        e
      ),
      ...o
    }
  );
}
function Gb({ ...e }) {
  return /* @__PURE__ */ d(Ri, { "data-slot": "sheet", ...e });
}
const Ub = s.forwardRef(({ ...e }, t) => /* @__PURE__ */ d(Ei, { ref: t, "data-slot": "sheet-trigger", ...e }));
Ub.displayName = "SheetTrigger";
function lw({ ...e }) {
  return /* @__PURE__ */ d(qt, { "data-slot": "sheet-close", ...e });
}
function jb({ ...e }) {
  return /* @__PURE__ */ d(Ii, { "data-slot": "sheet-portal", ...e });
}
const Cc = s.forwardRef(({ className: e, ...t }, n) => /* @__PURE__ */ d(Ai, { ref: n, "data-slot": "sheet-overlay", className: T("fixed inset-0 z-50 bg-black/50", e), ...t }));
Cc.displayName = "SheetOverlay";
const Sc = s.forwardRef(({ className: e, children: t, side: n = "right", showCloseButton: o = !0, portalContainer: r, ...a }, i) => /* @__PURE__ */ Q(jb, { container: r, children: [
  /* @__PURE__ */ d(Cc, {}),
  /* @__PURE__ */ Q(ki, { ref: i, "data-slot": "sheet-content", "data-side": n, className: T("fixed z-50 flex flex-col gap-4 border bg-background p-6 shadow-lg", n === "right" && "inset-y-0 right-0 h-full w-3/4 max-w-sm border-l", n === "left" && "inset-y-0 left-0 h-full w-3/4 max-w-sm border-r", n === "top" && "inset-x-0 top-0 border-b", n === "bottom" && "inset-x-0 bottom-0 border-t", e), ...a, children: [
    t,
    o && /* @__PURE__ */ d(qt, { "data-slot": "sheet-close", asChild: !0, children: /* @__PURE__ */ Q(nn, { variant: "ghost", size: "icon-sm", className: "absolute top-4 right-4", children: [
      /* @__PURE__ */ d(rc, { className: "size-4" }),
      /* @__PURE__ */ d("span", { className: "sr-only", children: "Close" })
    ] }) })
  ] })
] }));
Sc.displayName = "SheetContent";
function Kb({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-slot": "sheet-header", className: T("flex flex-col gap-2", e), ...t });
}
function uw({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-slot": "sheet-footer", className: T("mt-auto flex flex-col gap-2", e), ...t });
}
function Yb({ className: e, ...t }) {
  return /* @__PURE__ */ d(Oi, { "data-slot": "sheet-title", className: T("font-heading text-lg font-semibold", e), ...t });
}
function Xb({ className: e, ...t }) {
  return /* @__PURE__ */ d(Di, { "data-slot": "sheet-description", className: T("text-sm text-muted-foreground", e), ...t });
}
function Aa({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-slot": "skeleton", className: T("animate-pulse rounded-md bg-muted", e), ...t });
}
function dw({ delayDuration: e = 0, ...t }) {
  return /* @__PURE__ */ d(vg, { "data-slot": "tooltip-provider", delayDuration: e, ...t });
}
function qb({ ...e }) {
  return /* @__PURE__ */ d(wg, { "data-slot": "tooltip", ...e });
}
const Pc = s.forwardRef(({ ...e }, t) => /* @__PURE__ */ d(xg, { ref: t, "data-slot": "tooltip-trigger", ...e }));
Pc.displayName = "TooltipTrigger";
function Zb({ className: e, sideOffset: t = 0, children: n, portalContainer: o, ...r }) {
  return /* @__PURE__ */ d(yg, { container: o, children: /* @__PURE__ */ Q(Cg, { "data-slot": "tooltip-content", sideOffset: t, className: T("z-50 rounded-md bg-foreground px-3 py-1.5 text-xs text-background shadow-md", e), ...r, children: [
    n,
    /* @__PURE__ */ d(Sg, { className: "fill-foreground" })
  ] }) });
}
const go = 768;
function Qb() {
  const [e, t] = s.useState(void 0);
  return s.useEffect(() => {
    const n = window.matchMedia(`(max-width: ${go - 1}px)`), o = () => {
      t(window.innerWidth < go);
    };
    return n.addEventListener("change", o), t(window.innerWidth < go), () => n.removeEventListener("change", o);
  }, []), !!e;
}
const Jb = "sidebar_state", ev = 3600 * 24 * 7, tv = "16rem", nv = "18rem", ov = "3rem", rv = "b", Rc = s.createContext(null);
function qn() {
  const e = s.useContext(Rc);
  if (!e) throw new Error("useSidebar must be used within a SidebarProvider.");
  return e;
}
function fw({
  defaultOpen: e = !0,
  open: t,
  onOpenChange: n,
  className: o,
  style: r,
  children: a,
  ...i
}) {
  const c = Qb(), [l, u] = s.useState(!1), [m, f] = s.useState(e), p = t ?? m, h = s.useCallback(
    (y) => {
      const x = typeof y == "function" ? y(p) : y;
      n ? n(x) : f(x), typeof document < "u" && (document.cookie = `${Jb}=${x}; path=/; max-age=${ev}`);
    },
    [n, p]
  ), g = s.useCallback(() => c ? u((y) => !y) : h((y) => !y), [c, h]);
  s.useEffect(() => {
    const y = (x) => {
      x.key === rv && (x.metaKey || x.ctrlKey) && (x.preventDefault(), g());
    };
    return window.addEventListener("keydown", y), () => window.removeEventListener("keydown", y);
  }, [g]);
  const b = p ? "expanded" : "collapsed", v = s.useMemo(
    () => ({ state: b, open: p, setOpen: h, isMobile: c, openMobile: l, setOpenMobile: u, toggleSidebar: g }),
    [b, p, h, c, l, g]
  );
  return /* @__PURE__ */ d(Rc.Provider, { value: v, children: /* @__PURE__ */ d(
    "div",
    {
      "data-slot": "sidebar-wrapper",
      style: { "--sidebar-width": tv, "--sidebar-width-icon": ov, ...r },
      className: T("group/sidebar-wrapper flex min-h-svh w-full has-data-[variant=inset]:bg-sidebar", o),
      ...i,
      children: a
    }
  ) });
}
function pw({
  side: e = "left",
  variant: t = "sidebar",
  collapsible: n = "offcanvas",
  className: o,
  children: r,
  dir: a,
  ...i
}) {
  const { isMobile: c, state: l, openMobile: u, setOpenMobile: m } = qn();
  return n === "none" ? /* @__PURE__ */ d("div", { "data-slot": "sidebar", className: T("flex h-full w-(--sidebar-width) flex-col bg-sidebar text-sidebar-foreground", o), ...i, children: r }) : c ? /* @__PURE__ */ d(Gb, { open: u, onOpenChange: m, ...i, children: /* @__PURE__ */ Q(
    Sc,
    {
      dir: a,
      "data-sidebar": "sidebar",
      "data-slot": "sidebar",
      "data-mobile": "true",
      className: "w-(--sidebar-width) bg-sidebar p-0 text-sidebar-foreground [&>button]:hidden",
      style: { "--sidebar-width": nv },
      side: e,
      children: [
        /* @__PURE__ */ Q(Kb, { className: "sr-only", children: [
          /* @__PURE__ */ d(Yb, { children: "Sidebar" }),
          /* @__PURE__ */ d(Xb, { children: "Displays the mobile sidebar." })
        ] }),
        /* @__PURE__ */ d("div", { className: "flex h-full w-full flex-col", children: r })
      ]
    }
  ) }) : /* @__PURE__ */ Q("div", { className: "group peer hidden text-sidebar-foreground md:block", "data-state": l, "data-collapsible": l === "collapsed" ? n : "", "data-variant": t, "data-side": e, "data-slot": "sidebar", children: [
    /* @__PURE__ */ d("div", { "data-slot": "sidebar-gap", className: T("relative w-(--sidebar-width) bg-transparent", "group-data-[collapsible=offcanvas]:w-0", "group-data-[side=right]:rotate-180", t === "floating" || t === "inset" ? "group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)+--spacing(4))]" : "group-data-[collapsible=icon]:w-(--sidebar-width-icon)") }),
    /* @__PURE__ */ d("div", { "data-slot": "sidebar-container", "data-side": e, className: T("fixed inset-y-0 z-10 hidden h-svh w-(--sidebar-width) transition-[left,right,width] duration-200 ease-linear data-[side=left]:left-0 data-[side=left]:group-data-[collapsible=offcanvas]:left-[calc(var(--sidebar-width)*-1)] data-[side=right]:right-0 data-[side=right]:group-data-[collapsible=offcanvas]:right-[calc(var(--sidebar-width)*-1)] md:flex", t === "floating" || t === "inset" ? "p-2 group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)+--spacing(4)+2px)]" : "group-data-[collapsible=icon]:w-(--sidebar-width-icon) group-data-[side=left]:border-r group-data-[side=right]:border-l", o), ...i, children: /* @__PURE__ */ d("div", { "data-sidebar": "sidebar", "data-slot": "sidebar-inner", className: "flex size-full flex-col", children: r }) })
  ] });
}
function mw({ className: e, onClick: t, ...n }) {
  const { toggleSidebar: o } = qn();
  return /* @__PURE__ */ Q(nn, { "data-sidebar": "trigger", "data-slot": "sidebar-trigger", variant: "ghost", size: "icon-sm", className: e, onClick: (r) => {
    t?.(r), o();
  }, ...n, children: [
    /* @__PURE__ */ d(zg, { className: "size-4" }),
    /* @__PURE__ */ d("span", { className: "sr-only", children: "Toggle Sidebar" })
  ] });
}
function hw({ className: e, ...t }) {
  const { toggleSidebar: n } = qn();
  return /* @__PURE__ */ d("button", { "data-sidebar": "rail", "data-slot": "sidebar-rail", "aria-label": "Toggle Sidebar", tabIndex: -1, onClick: n, title: "Toggle Sidebar", className: T("absolute inset-y-0 z-20 hidden w-4 transition-all ease-linear group-data-[side=left]:-right-4 group-data-[side=right]:left-0 after:absolute after:inset-y-0 after:start-1/2 after:w-[2px] sm:flex ltr:-translate-x-1/2 rtl:-translate-x-1/2 in-data-[side=left]:cursor-w-resize in-data-[side=right]:cursor-e-resize [[data-side=left][data-state=collapsed]_&]:cursor-e-resize [[data-side=right][data-state=collapsed]_&]:cursor-w-resize group-data-[collapsible=offcanvas]:translate-x-0 group-data-[collapsible=offcanvas]:after:left-full hover:group-data-[collapsible=offcanvas]:bg-sidebar [[data-side=left][data-collapsible=offcanvas]_&]:-right-2 [[data-side=right][data-collapsible=offcanvas]_&]:-left-2", e), ...t });
}
function gw({ className: e, ...t }) {
  return /* @__PURE__ */ d("main", { "data-slot": "sidebar-inset", className: T("relative flex w-full flex-1 flex-col bg-background", e), ...t });
}
function bw({ className: e, ...t }) {
  return /* @__PURE__ */ d(zb, { "data-sidebar": "input", "data-slot": "sidebar-input", className: T("h-8 w-full rounded-md bg-background shadow-none", e), ...t });
}
function vw({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-sidebar": "header", "data-slot": "sidebar-header", className: T("flex flex-col gap-2 p-2", e), ...t });
}
function ww({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-sidebar": "footer", "data-slot": "sidebar-footer", className: T("flex flex-col gap-2 p-2", e), ...t });
}
function xw({ className: e, ...t }) {
  return /* @__PURE__ */ d(Hb, { "data-sidebar": "separator", "data-slot": "sidebar-separator", className: T("mx-2 w-auto", e), ...t });
}
function yw({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-sidebar": "content", "data-slot": "sidebar-content", className: T("flex min-h-0 flex-1 flex-col gap-2 overflow-auto group-data-[collapsible=icon]:overflow-hidden", e), ...t });
}
function Cw({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-sidebar": "group", "data-slot": "sidebar-group", className: T("relative flex w-full min-w-0 flex-col p-2", e), ...t });
}
function Sw({ className: e, asChild: t = !1, ...n }) {
  return /* @__PURE__ */ d(t ? ht : "div", { "data-sidebar": "group-label", "data-slot": "sidebar-group-label", className: T("flex h-8 shrink-0 items-center rounded-md px-2 text-xs font-medium text-sidebar-foreground/70", e), ...n });
}
function Pw({ className: e, asChild: t = !1, ...n }) {
  return /* @__PURE__ */ d(t ? ht : "button", { "data-sidebar": "group-action", "data-slot": "sidebar-group-action", className: T("flex aspect-square items-center justify-center rounded-md outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 transition-transform group-data-[collapsible=icon]:hidden after:absolute after:-inset-2 md:after:hidden [&>svg]:shrink-0", e), ...n });
}
function Rw({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-sidebar": "group-content", "data-slot": "sidebar-group-content", className: T("w-full text-sm", e), ...t });
}
function Ew({ className: e, ...t }) {
  return /* @__PURE__ */ d("ul", { "data-sidebar": "menu", "data-slot": "sidebar-menu", className: T("flex w-full min-w-0 flex-col gap-1", e), ...t });
}
function _w({ className: e, ...t }) {
  return /* @__PURE__ */ d("li", { "data-sidebar": "menu-item", "data-slot": "sidebar-menu-item", className: T("group/menu-item relative", e), ...t });
}
const av = Xn(
  "peer/menu-button group/menu-button flex w-full items-center overflow-hidden rounded-md px-2 py-1.5 text-left text-sm outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 transition-colors disabled:pointer-events-none disabled:opacity-50 aria-disabled:pointer-events-none aria-disabled:opacity-50 [&_svg]:size-4 [&_svg]:shrink-0 [&>span:last-child]:truncate",
  {
    variants: {
      variant: {
        default: "hover:bg-sidebar-accent hover:text-sidebar-accent-foreground data-[active=true]:bg-sidebar-accent data-[active=true]:font-medium",
        outline: "border border-sidebar-border shadow-[0_0_0_1px_var(--sidebar-border)] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground hover:shadow-[0_0_0_1px_var(--sidebar-accent)]"
      },
      size: { default: "h-8", sm: "h-7 text-xs", lg: "h-12 text-sm" }
    },
    defaultVariants: { variant: "default", size: "default" }
  }
), iv = s.forwardRef(({
  asChild: e = !1,
  isActive: t = !1,
  variant: n = "default",
  size: o = "default",
  tooltip: r,
  className: a,
  ...i
}, c) => {
  const l = e ? ht : "button", { isMobile: u, state: m } = qn(), f = /* @__PURE__ */ d(l, { ref: c, "data-sidebar": "menu-button", "data-slot": "sidebar-menu-button", "data-size": o, "data-active": t, className: T(av({ variant: n, size: o }), a), ...i });
  return r ? /* @__PURE__ */ Q(qb, { children: [
    /* @__PURE__ */ d(Pc, { asChild: !0, children: f }),
    /* @__PURE__ */ d(Zb, { side: "right", align: "center", hidden: m !== "collapsed" || u, ...typeof r == "string" ? { children: r } : r })
  ] }) : f;
});
iv.displayName = "SidebarMenuButton";
const sv = s.forwardRef(({ className: e, asChild: t = !1, showOnHover: n = !1, ...o }, r) => /* @__PURE__ */ d(t ? ht : "button", { ref: r, "data-sidebar": "menu-action", "data-slot": "sidebar-menu-action", className: T("absolute right-1 top-1.5 flex size-5 items-center justify-center rounded-md outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 transition-transform group-data-[collapsible=icon]:hidden after:absolute after:-inset-2 md:after:hidden [&>svg]:shrink-0", n && "group-focus-within/menu-item:opacity-100 group-hover/menu-item:opacity-100 peer-data-active/menu-button:text-sidebar-accent-foreground aria-expanded:opacity-100 md:opacity-0", e), ...o }));
sv.displayName = "SidebarMenuAction";
function Tw({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-sidebar": "menu-badge", "data-slot": "sidebar-menu-badge", className: T("flex items-center justify-center tabular-nums select-none group-data-[collapsible=icon]:hidden", e), ...t });
}
function Iw({ className: e, showIcon: t = !1, ...n }) {
  const [o] = s.useState(() => `${Math.floor(Math.random() * 40) + 50}%`);
  return /* @__PURE__ */ Q("div", { "data-sidebar": "menu-skeleton", "data-slot": "sidebar-menu-skeleton", className: T("flex items-center gap-2 rounded-md px-2 py-1.5", e), ...n, children: [
    t && /* @__PURE__ */ d(Aa, { "data-sidebar": "menu-skeleton-icon", "data-slot": "sidebar-menu-skeleton-icon", className: "size-4 rounded-md" }),
    /* @__PURE__ */ d(Aa, { "data-sidebar": "menu-skeleton-text", "data-slot": "sidebar-menu-skeleton-text", className: "h-4 max-w-(--skeleton-width) flex-1", style: { "--skeleton-width": o } })
  ] });
}
function Aw({ className: e, ...t }) {
  return /* @__PURE__ */ d("ul", { "data-sidebar": "menu-sub", "data-slot": "sidebar-menu-sub", className: T("mx-3.5 flex min-w-0 translate-x-px flex-col gap-1 border-l border-sidebar-border px-2.5 py-0.5", e), ...t });
}
function kw({ className: e, ...t }) {
  return /* @__PURE__ */ d("li", { "data-sidebar": "menu-sub-item", "data-slot": "sidebar-menu-sub-item", className: T("group/menu-sub-item relative", e), ...t });
}
function Mw({ asChild: e = !1, size: t = "md", isActive: n = !1, className: o, ...r }) {
  return /* @__PURE__ */ d(e ? ht : "a", { "data-sidebar": "menu-sub-button", "data-slot": "sidebar-menu-sub-button", "data-size": t, "data-active": n, className: T("flex min-w-0 -translate-x-px items-center gap-2 overflow-hidden rounded-md px-2 py-1.5 text-left text-sm outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground data-[active=true]:bg-sidebar-accent data-[active=true]:font-medium group-data-[collapsible=icon]:hidden disabled:pointer-events-none disabled:opacity-50 aria-disabled:pointer-events-none aria-disabled:opacity-50 [&>span:last-child]:truncate [&>svg]:size-4 [&>svg]:shrink-0", t === "sm" && "text-xs", o), ...r });
}
function Ow({ className: e, size: t = "default", ...n }) {
  return /* @__PURE__ */ d(
    Fh,
    {
      "data-slot": "switch",
      "data-size": t,
      className: T(
        "peer inline-flex shrink-0 items-center rounded-full border border-transparent outline-none transition-colors focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=unchecked]:bg-input",
        t === "sm" ? "h-3.5 w-6" : "h-[18.4px] w-8",
        e
      ),
      ...n,
      children: /* @__PURE__ */ d(
        Bh,
        {
          "data-slot": "switch-thumb",
          className: T(
            "pointer-events-none block rounded-full bg-background ring-0 transition-transform data-[state=unchecked]:translate-x-0 data-[state=checked]:translate-x-[calc(100%-2px)]",
            t === "sm" ? "size-3" : "size-4"
          )
        }
      )
    }
  );
}
function Dw({ className: e, ...t }) {
  return /* @__PURE__ */ d("div", { "data-slot": "table-container", className: "relative w-full overflow-auto", children: /* @__PURE__ */ d("table", { "data-slot": "table", className: T("w-full caption-bottom text-sm", e), ...t }) });
}
function Nw({ className: e, ...t }) {
  return /* @__PURE__ */ d("thead", { "data-slot": "table-header", className: T("[&_tr]:border-b", e), ...t });
}
function Lw({ className: e, ...t }) {
  return /* @__PURE__ */ d("tbody", { "data-slot": "table-body", className: T("[&_tr:last-child]:border-0", e), ...t });
}
function $w({ className: e, ...t }) {
  return /* @__PURE__ */ d("tfoot", { "data-slot": "table-footer", className: T("border-t bg-muted/50 font-medium", e), ...t });
}
function Fw({ className: e, ...t }) {
  return /* @__PURE__ */ d("tr", { "data-slot": "table-row", className: T("border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted", e), ...t });
}
function zw({ className: e, ...t }) {
  return /* @__PURE__ */ d("th", { "data-slot": "table-head", className: T("h-10 px-2 text-left align-middle font-medium text-muted-foreground", e), ...t });
}
function Bw({ className: e, ...t }) {
  return /* @__PURE__ */ d("td", { "data-slot": "table-cell", className: T("p-2 align-middle", e), ...t });
}
function Vw({ className: e, ...t }) {
  return /* @__PURE__ */ d("caption", { "data-slot": "table-caption", className: T("mt-4 text-sm text-muted-foreground", e), ...t });
}
function Ww({ className: e, orientation: t = "horizontal", ...n }) {
  return /* @__PURE__ */ d(Jh, { "data-slot": "tabs", "data-orientation": t, className: T("group/tabs flex data-[orientation=horizontal]:flex-col has-[>[data-slot=tabs-list][data-variant=line]]:gap-2", e), ...n });
}
const cv = Xn("group/tabs-list inline-flex w-fit items-center justify-center text-muted-foreground group-data-[orientation=vertical]/tabs:h-fit group-data-[orientation=vertical]/tabs:flex-col", { variants: { variant: { default: "rounded-lg bg-muted p-1", line: "gap-1 border-b bg-transparent" } }, defaultVariants: { variant: "default" } });
function Hw({ className: e, variant: t = "default", ...n }) {
  return /* @__PURE__ */ d(eg, { "data-slot": "tabs-list", "data-variant": t, className: T(cv({ variant: t }), e), ...n });
}
function Gw({ className: e, ...t }) {
  return /* @__PURE__ */ d(tg, { "data-slot": "tabs-trigger", className: T(
    "relative inline-flex h-[calc(100%-1px)] flex-1 items-center justify-center whitespace-nowrap rounded-md px-3 text-sm font-medium text-foreground/60 transition-all group-data-[orientation=vertical]/tabs:w-full group-data-[orientation=vertical]/tabs:justify-start hover:text-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow-sm",
    "group-data-[variant=line]/tabs-list:bg-transparent group-data-[variant=line]/tabs-list:data-[state=active]:bg-transparent group-data-[variant=line]/tabs-list:data-[state=active]:shadow-none",
    "after:absolute after:bg-foreground after:opacity-0 after:transition-opacity group-data-[orientation=horizontal]/tabs:after:inset-x-0 group-data-[orientation=horizontal]/tabs:after:bottom-[-5px] group-data-[orientation=horizontal]/tabs:after:h-0.5 group-data-[orientation=vertical]/tabs:after:inset-y-0 group-data-[orientation=vertical]/tabs:after:-right-1 group-data-[orientation=vertical]/tabs:after:w-0.5 group-data-[variant=line]/tabs-list:data-[state=active]:after:opacity-100",
    e
  ), ...t });
}
function Uw({ className: e, ...t }) {
  return /* @__PURE__ */ d(ng, { "data-slot": "tabs-content", className: T("flex-1 outline-none", e), ...t });
}
function jw({ className: e, ...t }) {
  return /* @__PURE__ */ d("textarea", { "data-slot": "textarea", className: T("min-h-16 w-full rounded-md border border-input bg-transparent px-2.5 py-2 text-sm outline-none placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 disabled:cursor-not-allowed disabled:opacity-50", e), ...t });
}
export {
  yv as Accordion,
  Pv as AccordionContent,
  Cv as AccordionItem,
  Sv as AccordionTrigger,
  Rv as Badge,
  nn as Button,
  Ev as Card,
  Av as CardAction,
  kv as CardContent,
  Iv as CardDescription,
  Mv as CardFooter,
  _v as CardHeader,
  Tv as CardTitle,
  Ov as Checkbox,
  Dv as Dialog,
  Nv as DialogClose,
  Lb as DialogContent,
  zv as DialogDescription,
  $v as DialogFooter,
  Lv as DialogHeader,
  yc as DialogOverlay,
  Nb as DialogPortal,
  Fv as DialogTitle,
  Db as DialogTrigger,
  Bv as DropdownMenu,
  Gv as DropdownMenuCheckboxItem,
  Vv as DropdownMenuContent,
  Wv as DropdownMenuGroup,
  Hv as DropdownMenuItem,
  Kv as DropdownMenuLabel,
  $b as DropdownMenuPortal,
  Uv as DropdownMenuRadioGroup,
  jv as DropdownMenuRadioItem,
  Yv as DropdownMenuSeparator,
  Xv as DropdownMenuShortcut,
  qv as DropdownMenuSub,
  Qv as DropdownMenuSubContent,
  Zv as DropdownMenuSubTrigger,
  Fb as DropdownMenuTrigger,
  zb as Input,
  Jv as Label,
  ew as ScrollArea,
  Bb as ScrollBar,
  tw as Select,
  aw as SelectContent,
  nw as SelectGroup,
  sw as SelectItem,
  iw as SelectLabel,
  Wb as SelectScrollDownButton,
  Vb as SelectScrollUpButton,
  cw as SelectSeparator,
  rw as SelectTrigger,
  ow as SelectValue,
  Hb as Separator,
  Gb as Sheet,
  lw as SheetClose,
  Sc as SheetContent,
  Xb as SheetDescription,
  uw as SheetFooter,
  Kb as SheetHeader,
  Yb as SheetTitle,
  Ub as SheetTrigger,
  pw as Sidebar,
  yw as SidebarContent,
  ww as SidebarFooter,
  Cw as SidebarGroup,
  Pw as SidebarGroupAction,
  Rw as SidebarGroupContent,
  Sw as SidebarGroupLabel,
  vw as SidebarHeader,
  bw as SidebarInput,
  gw as SidebarInset,
  Ew as SidebarMenu,
  sv as SidebarMenuAction,
  Tw as SidebarMenuBadge,
  iv as SidebarMenuButton,
  _w as SidebarMenuItem,
  Iw as SidebarMenuSkeleton,
  Aw as SidebarMenuSub,
  Mw as SidebarMenuSubButton,
  kw as SidebarMenuSubItem,
  fw as SidebarProvider,
  hw as SidebarRail,
  xw as SidebarSeparator,
  mw as SidebarTrigger,
  Aa as Skeleton,
  Ow as Switch,
  Dw as Table,
  Lw as TableBody,
  Vw as TableCaption,
  Bw as TableCell,
  $w as TableFooter,
  zw as TableHead,
  Nw as TableHeader,
  Fw as TableRow,
  Ww as Tabs,
  Uw as TabsContent,
  Hw as TabsList,
  Gw as TabsTrigger,
  jw as Textarea,
  qb as Tooltip,
  Zb as TooltipContent,
  dw as TooltipProvider,
  Pc as TooltipTrigger,
  Mb as badgeVariants,
  Ob as buttonVariants,
  cv as tabsListVariants,
  qn as useSidebar
};

import type { DeepReadonly, LoadedComponentContracts } from "../contracts/components/loader";
import type { TokenContract } from "../contracts/tokens/types";
import type { ExecutableRelease } from "../validator/types";
/** Returns the checked-in release verified at package build time. */
export declare function getExecutableRelease(): DeepReadonly<ExecutableRelease>;
export declare function getComponentContracts(): LoadedComponentContracts;
export declare function getTokenContract(): DeepReadonly<TokenContract>;
export type { LoadedComponentContracts } from "../contracts/components/loader";
export type { ComponentContractSet, ComponentFamilyContract, InheritedInterfaceContract } from "../contracts/components/types";
export type { TokenContract, TokenDefinition } from "../contracts/tokens/types";
export type { ExecutableRelease, ExecutableContract } from "../validator/types";
